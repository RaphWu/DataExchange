﻿using System;
using System.Collections.Generic;
using Advantech.Motion;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;

namespace Calin.MotionControl.Advantech.Services
{
    // 裝置(Device)與控制卡(Board)操作
    // 裝置設定檔操作
    public partial class AcmService : IAcmService_Device
    {
        #region properties

        public uint DeviceCount => _deviceCount;
        public List<DeviceInfo> AvailableDevices => _availableDevices;
        public IntPtr DeviceHandle => _deviceHandle;
        public bool IsBoardInit => _boardInit;
        public bool IsServoOn => _servoOn;
        public uint DaqDiMaxChannel => _daqDiMaxChannel;
        public uint DaqDoMaxChannel => _daqDoMaxChannel;

        #endregion properties

        #region methods

        /// <inheritdoc/>
        public uint GetAvailableDevs()
        {
            DEV_LIST[] availableDevices = new DEV_LIST[Motion.MAX_DEVICES];
            ErrCode = (uint)Motion.mAcm_GetAvailableDevs(availableDevices, Motion.MAX_DEVICES, ref _deviceCount);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(GetAvailableDevs)}", "取得裝置編號及名稱列表失敗！"))
                return 0;

            _availableDevices.Clear();
            for (int i = 0; i < _deviceCount; i++)
                _availableDevices.Add(new DeviceInfo()
                {
                    DeviceName = availableDevices[i].DeviceName,
                    DeviceNumber = availableDevices[i].DeviceNum,
                    NumofSubDevice = availableDevices[i].NumofSubDevice,
                });

            ErrCode = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.FT_DaqDiMaxChan, ref _daqDiMaxChannel);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(GetAvailableDevs)}", "取得數位輸入最大通道數失敗！"))
                return 0;

            ErrCode = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.FT_DaqDoMaxChan, ref _daqDoMaxChannel);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(GetAvailableDevs)}", "取得數位輸出最大通道數失敗！"))
                return 0;

            return _deviceCount;
        }

        /// <inheritdoc/>
        public bool BoardClose()
        {
            if (_boardInit)
            {
                ushort[] axisState = new ushort[32];
                int axisNum;

                PollingStop();

                for (axisNum = 0; axisNum < _axisCount; axisNum++)
                {
                    // 取得軸的當前狀態
                    ErrCode = Motion.mAcm_AxGetState(_axisHandles[axisNum], ref axisState[axisNum]);
                    if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardClose)}", $"無法取得軸 {axisNum + 1} 的當前狀態！")) return false;

                    if (axisState[axisNum] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        // 重置座標軸狀態。如果座標軸處於 ErrorStop 狀態，呼叫此函數後，其狀態將變更為 Ready
                        ErrCode = Motion.mAcm_AxResetError(_axisHandles[axisNum]);
                        if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardClose)}", $"無法重置軸 {axisNum + 1} 的座標軸狀態！")) return false;
                    }

                    // 命令軸減速直至停止
                    ErrCode = Motion.mAcm_AxStopDec(_axisHandles[axisNum]);
                    if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardClose)}", $"軸 {axisNum + 1} 減速至停的動作失敗！")) return false;
                }

                for (axisNum = 0; axisNum < _axisCount; axisNum++)
                {
                    ErrCode = Motion.mAcm_AxClose(ref _axisHandles[axisNum]);
                    if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardClose)}", $"軸 {axisNum + 1} 關閉失敗！")) return false;
                }
                _axisCount = 0;

                ErrCode = Motion.mAcm_DevClose(ref _deviceHandle);
                if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardClose)}", "裝置關閉失敗！")) return false;

                _deviceHandle = IntPtr.Zero;
                _boardInit = false;
            }
            return true;
        }

        /// <inheritdoc/>
        public bool BoardOpen(uint deviceNum)
        {
            ErrCode = Motion.mAcm_DevOpen(deviceNum, ref _deviceHandle);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardOpen)}", "裝置開啟失敗！"))
                return false;

            ErrCode = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.FT_DevAxesCount, ref _axisCount);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardOpen)}", "無法取得控制卡上的軸數量！"))
                return false;

            if (_axisCount == 0)
            {
                SetErr($"{nameof(IAcmService_Device)}.{nameof(BoardOpen)}", "控制卡軸數量為 0，無法進行後續操作！");
                return false;
            }

            // init arrays
            _axisHandles = new IntPtr[_axisCount];
            _rawAxisStates = new RawAxisState[_axisCount];
            _parsedAxisStates = new ParsedAxisState[_axisCount];

            for (int axisNum = 0; axisNum < _axisCount; axisNum++)
            {
                ErrCode = Motion.mAcm_AxOpen(_deviceHandle, (ushort)axisNum, ref _axisHandles[axisNum]);
                if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardOpen)}", $"軸 {axisNum + 1} 開啟失敗！"))
                    return false;

                // 設定命令位置及實際位置為 0
                _ = Motion.mAcm_AxSetCmdPosition(_axisHandles[axisNum], 0.0);
                _ = Motion.mAcm_AxSetActualPosition(_axisHandles[axisNum], 0.0);
            }

            PollingStart();
            _boardInit = true;
            return true;
        }

        /// <inheritdoc/>
        public bool ServoOn()
        {
            if (!_boardInit)
            {
                SetErr($"{nameof(IAcmService_Device)}.{nameof(ServoOn)}", "控制卡尚未開啟");
                return false;
            }

            for (int axisNum = 0; axisNum < _axisCount; axisNum++)
            {
                ErrCode = Motion.mAcm_AxSetSvOn(_axisHandles[axisNum], 1);
                if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(ServoOn)}", $"軸 {axisNum + 1} 伺服開啟失敗！")) return false;
            }
            _servoOn = true;
            return true;
        }

        /// <inheritdoc/>
        public bool ServoOff()
        {
            if (!_boardInit)
            {
                SetErr($"{nameof(IAcmService_Device)}.{nameof(ServoOff)}", "控制卡尚未開啟");
                return false;
            }

            for (int axisNum = 0; axisNum < _axisCount; axisNum++)
            {
                ErrCode = Motion.mAcm_AxSetSvOn(_axisHandles[axisNum], 0);
                if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(ServoOff)}", $"軸 {axisNum + 1} 伺服關閉失敗！")) return false;
            }
            _servoOn = false;
            return true;
        }

        /// <inheritdoc/>
        public bool LoadCfg(string filePath)
        {
            if (!_boardInit)
            {
                SetErr($"{nameof(IAcmService_Device)}.{nameof(LoadCfg)}", "控制卡尚未開啟");
                return false;
            }

            ErrCode = Motion.mAcm_DevLoadConfig(_deviceHandle, filePath);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(LoadCfg)}", "裝置Config檔載入失敗！")) return false;

            return true;
        }

        #endregion methods
    }
}
