﻿using System;
using System.Collections.Generic;
using Calin.Logging.Abstractions;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;
using Microsoft.Extensions.Logging;

namespace Calin.MotionControl.Advantech.Services
{
    /// <summary>
    /// Advantech ACM 服務。
    /// </summary>
    public partial class AcmService : IAcm
    {
        private readonly ILogger<AcmService> _logger = LoggingBridge.CreateLogger<AcmService>();

        /********************
         * devices
         ********************/
        /// <summary>
        /// 裝置編號。
        /// </summary>
        private uint _deviceNum = 0;

        /// <summary>
        /// 裝置句柄。
        /// </summary>
        private IntPtr _deviceHandle = IntPtr.Zero;

        /// <summary>
        /// 控制卡是否初始化。
        /// </summary>
        private bool _boardInit = false;

        /// <summary>
        /// 伺服是否開啟。
        /// </summary>
        private bool _servoOn = false;

        /// <summary>
        /// 有效裝置數量。
        /// </summary>
        private uint _deviceCount = 0;

        /// <summary>
        /// 可用裝置列表。
        /// </summary>
        private List<DeviceInfo> _availableDevices = new List<DeviceInfo>();

        /********************
         * axises
         ********************/
        /// <summary>
        /// 有效軸數量。
        /// </summary>
        private uint _axisCount = 0;

        /// <summary>
        /// 各軸句柄。
        /// </summary>
        private IntPtr[] _axisHandles;

        /// <summary>
        /// 數位輸入最大通道數。
        /// </summary>
        private uint _daqDiMaxChannel;

        /// <summary>
        /// 數位輸出最大通道數。
        /// </summary>
        private uint _daqDoMaxChannel;
    }
}
