﻿//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Threading.Tasks;
//using RJCP.IO.Ports;

//namespace Calin.SerialPort
//{
//    /// <summary>
//    /// SerialPort 驅動程式（舊版，建議使用 SerialPortService）。
//    /// </summary>
//    /// <remarks>使用套件: <see href="https://github.com/jcurl/serialportstream">Serial Port Stream。</see></remarks>
//    [Obsolete("此類別已過時，請使用 SerialPortService 或 SerialPortManager")]
//    public class SerialPortDriver
//    {
//        #region fields

//        private readonly SerialPortConfig _config;
//        private readonly SerialPortParameters _spp = SerialPortParameters.Instance;
//        private SerialPortStream _port;

//        private const string SerialPortFileName = "SerialPort.json";
//        private readonly string DirectoryBase
//            = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Calin");

//        #endregion fields

//        public SerialPortDriver(SerialPortConfig config)
//        {
//            _config = config;
//            RefreshPortNameList();
//        }

//        #region Database

//        /// <summary>
//        /// 寫入資料庫。
//        /// </summary>
//        public bool WriteToJson()
//        {
//            JsonFileHelper.Save(DirectoryBase, SerialPortFileName, new SerialPortConfig()
//            {
//                PortName = _config.PortName,
//                BaudRate = _config.BaudRate,
//                DataBits = _config.DataBits,
//                Parity = _config.Parity,
//                StopBits = _config.StopBits,
//                Handshake = _config.Handshake,
//                ReadTimeout = _config.ReadTimeout,
//                WriteTimeout = _config.WriteTimeout,
//                RtsEnable = _config.RtsEnable,
//                DtrEnable = _config.DtrEnable
//            });

//            return true;
//        }

//        /// <summary>
//        /// 讀取資料庫。
//        /// </summary>
//        public bool ReadFromJson()
//        {
//            SerialPortConfig spDb = JsonFileHelper.Read<SerialPortConfig>(DirectoryBase, SerialPortFileName);
//            try
//            {
//                if (spDb != null)
//                {
//                    _spp.PortName = spDb.PortName;
//                    _spp.BaudRate = spDb.BaudRate;
//                    _spp.Parity = spDb.Parity;
//                    _spp.DataBits = spDb.DataBits;
//                    _spp.StopBits = spDb.StopBits;
//                    _spp.Handshake = spDb.Handshake;

//                    return true;
//                }
//            }
//            catch
//            {
//                // do nothing
//            }

//            _spp.PortName = _spp.PortNameList.Count > 0 ? _spp.PortNameList[0] : "";
//            _spp.BaudRate = 9600;
//            _spp.Parity = Parity.Odd;
//            _spp.DataBits = 8;
//            _spp.StopBits = StopBits.One;
//            _spp.Handshake = Handshake.None;

//            return false;
//        }

//        #endregion Database

//        #region Properties

//        /// <summary>
//        /// SerialPort 是否已開啟。
//        /// </summary>
//        public bool IsOpen => _port != null && _port.IsOpen;

//        /// <summary>
//        /// SerialPort 名稱。
//        /// </summary>
//        public string PortName => _spp.PortName;

//        /// <summary>
//        /// 鮑率。
//        /// </summary>
//        public int BaudRate
//        {
//            get => _spp.BaudRate;
//            set => _spp.BaudRate = value;
//        }

//        /// <summary>
//        /// 同位位元。
//        /// </summary>
//        public Parity Parity
//        {
//            get => _spp.Parity;
//            set => _spp.Parity = value;
//        }

//        /// <summary>
//        /// 資料位元
//        /// </summary>
//        public int DataBits
//        {
//            get => _spp.DataBits;
//            set => _spp.DataBits = value;
//        }

//        /// <summary>
//        /// 停止位元。
//        /// </summary>
//        public StopBits StopBits
//        {
//            get => _spp.StopBits;
//            set => _spp.StopBits = value;
//        }

//        #endregion Properties

//        #region functions

//        /// <summary>
//        /// 關閉 SerialPort。
//        /// </summary>
//        public void Close()
//        {
//            try
//            {
//                if (_port != null && _port.IsOpen)
//                {
//                    _port.DataReceived -= SerialPort_DataReceived;
//                    _port.ErrorReceived -= SerialPort_ErrorReceived;
//                    _port.PinChanged -= SerialPort_PinChanged;
//                    _port.Close();
//                    _spp.IsOpen = false;
//                }
//            }
//            catch
//            {
//                return;
//            }
//        }

//        /// <summary>
//        /// 開啟 SerialPort。
//        /// </summary>
//        public bool Open()
//        {
//            if (_port != null && _port.IsOpen)
//                return true;

//            try
//            {
//                _port = new SerialPortStream()
//                {
//                    PortName = _config.PortName,
//                    BaudRate = _config.BaudRate,
//                    DataBits = _config.DataBits,
//                    Parity = _config.Parity,
//                    StopBits = _config.StopBits,
//                    Handshake = _config.Handshake,
//                    ReadTimeout = _config.ReadTimeout,
//                    WriteTimeout = _config.WriteTimeout,
//                    RtsEnable = _config.RtsEnable,
//                    DtrEnable = _config.DtrEnable
//                };
//                _port.Open();

//                if (IsOpen)
//                {
//                    _spp.IsOpen = true;
//                    _port.DataReceived += SerialPort_DataReceived;
//                    _port.ErrorReceived += SerialPort_ErrorReceived;
//                    _port.PinChanged += SerialPort_PinChanged;
//                    return true;
//                }
//                else
//                {
//                    _spp.IsOpen = false;
//                    _port.DataReceived -= SerialPort_DataReceived;
//                    _port.ErrorReceived -= SerialPort_ErrorReceived;
//                    _port.PinChanged -= SerialPort_PinChanged;
//                    return false;
//                }

//            }
//            catch
//            {
//                _spp.IsOpen = false;
//                _port.DataReceived -= SerialPort_DataReceived;
//                _port.ErrorReceived -= SerialPort_ErrorReceived;
//                _port.PinChanged -= SerialPort_PinChanged;
//                return false;
//            }
//        }

//        /// <summary>
//        /// 重新整理 SerialPort 名稱列表。
//        /// </summary>
//        public List<string> RefreshPortNameList()
//        {
//            using (var tempPort = new SerialPortStream())
//            {
//                _spp.PortNameList = tempPort.GetPortNames().ToList();
//            }
//            _spp.PortNameList.Sort();
//            return _spp.PortNameList;
//        }

//        /// <summary>
//        /// 傳送資料。
//        /// </summary>
//        public void SendData(string data)
//        {
//            if (_port != null && _port.IsOpen)
//            {
//                try
//                {
//                    _port.Write(data);
//                }
//                catch (TimeoutException e)
//                {
//                    throw new Exception($"SendData Timeout: {e.Message}");
//                }
//            }
//        }

//        #endregion functions

//        #region event handlers

//        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
//        {
//            if (!IsOpen)
//                return;

//            var sps = sender as SerialPortStream;
//            _spp.ReceivedMessages = sps.ReadExisting().Split('\r')[0];
//        }

//        private void SerialPort_ErrorReceived(object sender, SerialErrorReceivedEventArgs e)
//        {
//            Task.Delay(10);
//        }

//        private void SerialPort_PinChanged(object sender, SerialPinChangedEventArgs e)
//        {
//            //UpdatePinState();
//        }

//        #endregion event handlers
//    }
//}
