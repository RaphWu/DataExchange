using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace Calin.SerialPort
{
    /// <summary>
    /// �h SerialPort �޲z���A�Ω�޲z�h�� SerialPort �s�u�C
    /// Thread-safe �]�p�A�䴩�P�ɺ޲z�h�ӳ]�ơC
    /// </summary>
    public class SerialPortManager : ISerialPortManager
    {
        #region Fields

        private readonly ConcurrentDictionary<string, SerialPortService> _ports;
        private readonly object _lock = new object();
        private bool _disposed = false;

        #endregion Fields

        #region Events

        /// <summary>
        /// �����@ SerialPort ���A���ܮ�Ĳ�o�C
        /// </summary>
        public event EventHandler<SerialPortStateChangedEventArgs> StateChanged;

        /// <summary>
        /// �����@ SerialPort �������Ʈ�Ĳ�o�C
        /// </summary>
        public event EventHandler<SerialPortDataReceivedEventArgs> DataReceived;

        /// <summary>
        /// �����@ SerialPort �o�Ϳ��~��Ĳ�o�C
        /// </summary>
        public event EventHandler<SerialPortErrorEventArgs> ErrorOccurred;

        #endregion Events

        #region Properties

        /// <summary>
        /// ���o�w���U�� SerialPort �ƶq�C
        /// </summary>
        public int PortCount => _ports.Count;

        /// <summary>
        /// ���o�Ҧ��w���U�� SerialPort �W�١C
        /// </summary>
        public IReadOnlyList<string> RegisteredPorts => _ports.Keys.ToList();

        #endregion Properties

        #region Constructor

        /// <summary>
        /// �إ� SerialPort �޲z���C
        /// </summary>
        public SerialPortManager()
        {
            _ports = new ConcurrentDictionary<string, SerialPortService>();
        }

        #endregion Constructor

        #region Public Methods - Port Management

        /// <summary>
        /// ���U�ö}�Ҥ@�ӷs�� SerialPort�C
        /// </summary>
        /// <param name="config">SerialPort �]�w�C</param>
        /// <returns>�O�_���\���U�ö}�ҡC</returns>
        public bool RegisterPort(SerialPortConfig config)
        {
            if (config == null)
                throw new ArgumentNullException(nameof(config));

            if (string.IsNullOrWhiteSpace(config.PortName))
                throw new ArgumentException("PortName ���i����", nameof(config));

            try
            {
                lock (_lock)
                {
                    if (_ports.ContainsKey(config.PortName))
                    {
                        OnError(config.PortName, "RegisterPort",
                            $"SerialPort {config.PortName} �w�g���U", null);
                        return false;
                    }

                    var service = new SerialPortService(config);

                    // �q�\�ƥ�
                    service.StateChanged += OnPortStateChanged;
                    service.DataReceived += OnPortDataReceived;
                    service.ErrorOccurred += OnPortErrorOccurred;

                    if (!_ports.TryAdd(config.PortName, service))
                    {
                        service.Dispose();
                        return false;
                    }

                    // �}�ҳs�u
                    return service.Open();
                }
            }
            catch (Exception ex)
            {
                OnError(config.PortName, "RegisterPort",
                    $"���U SerialPort �ɵo�Ϳ��~: {ex.Message}", ex);
                return false;
            }
        }

        /// <summary>
        /// �������U���������w�� SerialPort�C
        /// </summary>
        /// <param name="portName">�n�������U�� SerialPort �W�١C</param>
        /// <returns>�O�_���\�������U�C</returns>
        public bool UnregisterPort(string portName)
        {
            if (string.IsNullOrWhiteSpace(portName))
                return false;

            try
            {
                lock (_lock)
                {
                    if (_ports.TryRemove(portName, out var service))
                    {
                        // �����q�\�ƥ�
                        service.StateChanged -= OnPortStateChanged;
                        service.DataReceived -= OnPortDataReceived;
                        service.ErrorOccurred -= OnPortErrorOccurred;

                        service.Dispose();
                        return true;
                    }

                    return false;
                }
            }
            catch (Exception ex)
            {
                OnError(portName, "UnregisterPort",
                    $"�������U SerialPort �ɵo�Ϳ��~: {ex.Message}", ex);
                return false;
            }
        }

        /// <summary>
        /// ���o���w�� SerialPort �A�ȡC
        /// </summary>
        /// <param name="portName">SerialPort �W�١C</param>
        /// <returns>SerialPort �A�ȡA�p�G���s�b�h��^ null�C</returns>
        public SerialPortService GetPort(string portName)
        {
            if (string.IsNullOrWhiteSpace(portName))
                return null;

            _ports.TryGetValue(portName, out var service);
            return service;
        }

        /// <summary>
        /// �ˬd���w�� SerialPort �O�_�w���U�C
        /// </summary>
        /// <param name="portName">SerialPort �W�١C</param>
        /// <returns>�O�_�w���U�C</returns>
        public bool IsPortRegistered(string portName)
        {
            return !string.IsNullOrWhiteSpace(portName) && _ports.ContainsKey(portName);
        }

        /// <summary>
        /// ���o���w SerialPort �����A�C
        /// </summary>
        /// <param name="portName">SerialPort �W�١C</param>
        /// <returns>SerialPort ���A�A�p�G���s�b�h��^ Disconnected�C</returns>
        public SerialPortState GetPortState(string portName)
        {
            var service = GetPort(portName);
            return service?.State ?? SerialPortState.Disconnected;
        }

        /// <summary>
        /// �}�ҫ��w�� SerialPort�C
        /// </summary>
        /// <param name="portName">SerialPort �W�١C</param>
        /// <returns>�O�_���\�}�ҡC</returns>
        public bool OpenPort(string portName)
        {
            var service = GetPort(portName);
            if (service == null)
            {
                OnError(portName, "OpenPort",
                    $"SerialPort {portName} ���s�b", null);
                return false;
            }

            return service.Open();
        }

        /// <summary>
        /// �������w�� SerialPort�C
        /// </summary>
        /// <param name="portName">SerialPort �W�١C</param>
        public void ClosePort(string portName)
        {
            var service = GetPort(portName);
            service?.Close();
        }

        /// <summary>
        /// �}�ҩҦ��w���U�� SerialPort�C
        /// </summary>
        /// <returns>���\�}�Ҫ� SerialPort �ƶq�C</returns>
        public int OpenAllPorts()
        {
            int successCount = 0;

            foreach (var service in _ports.Values)
            {
                try
                {
                    if (service.Open())
                        successCount++;
                }
                catch (Exception ex)
                {
                    OnError(service.PortName, "OpenAllPorts",
                        $"�}�� SerialPort �ɵo�Ϳ��~: {ex.Message}", ex);
                }
            }

            return successCount;
        }

        /// <summary>
        /// �����Ҧ��w���U�� SerialPort�C
        /// </summary>
        public void CloseAllPorts()
        {
            foreach (var service in _ports.Values)
            {
                try
                {
                    service.Close();
                }
                catch (Exception ex)
                {
                    OnError(service.PortName, "CloseAllPorts",
                        $"���� SerialPort �ɵo�Ϳ��~: {ex.Message}", ex);
                }
            }
        }

        #endregion Public Methods - Port Management

        #region Public Methods - Data Operations

        /// <summary>
        /// �ǰe�r���ƨ���w�� SerialPort�C
        /// </summary>
        /// <param name="portName">SerialPort �W�١C</param>
        /// <param name="data">�n�ǰe���r���ơC</param>
        /// <returns>�O�_���\�ǰe�C</returns>
        public bool SendData(string portName, string data)
        {
            var service = GetPort(portName);
            if (service == null)
            {
                OnError(portName, "SendData",
                    $"SerialPort {portName} ���s�b", null);
                return false;
            }

            return service.SendData(data);
        }

        /// <summary>
        /// �ǰe�줸�ո�ƨ���w�� SerialPort�C
        /// </summary>
        /// <param name="portName">SerialPort �W�١C</param>
        /// <param name="data">�n�ǰe���줸�հ}�C�C</param>
        /// <returns>�O�_���\�ǰe�C</returns>
        public bool SendData(string portName, byte[] data)
        {
            var service = GetPort(portName);
            if (service == null)
            {
                OnError(portName, "SendData",
                    $"SerialPort {portName} ���s�b", null);
                return false;
            }

            return service.SendData(data);
        }

        /// <summary>
        /// �s���r���ƨ�Ҧ��w�N���� SerialPort�C
        /// </summary>
        /// <param name="data">�n�s�����r���ơC</param>
        /// <returns>���\�ǰe�� SerialPort �ƶq�C</returns>
        public int BroadcastData(string data)
        {
            int successCount = 0;

            foreach (var service in _ports.Values)
            {
                try
                {
                    if (service.IsReady && service.SendData(data))
                        successCount++;
                }
                catch (Exception ex)
                {
                    OnError(service.PortName, "BroadcastData",
                        $"�s����Ʈɵo�Ϳ��~: {ex.Message}", ex);
                }
            }

            return successCount;
        }

        /// <summary>
        /// �s���줸�ո�ƨ�Ҧ��w�N���� SerialPort�C
        /// </summary>
        /// <param name="data">�n�s�����줸�հ}�C�C</param>
        /// <returns>���\�ǰe�� SerialPort �ƶq�C</returns>
        public int BroadcastData(byte[] data)
        {
            int successCount = 0;

            foreach (var service in _ports.Values)
            {
                try
                {
                    if (service.IsReady && service.SendData(data))
                        successCount++;
                }
                catch (Exception ex)
                {
                    OnError(service.PortName, "BroadcastData",
                        $"�s����Ʈɵo�Ϳ��~: {ex.Message}", ex);
                }
            }

            return successCount;
        }

        /// <summary>
        /// �ǰe ASCII �r���ƨ���w�� SerialPort�]���۰ʥ[�浲���^�C
        /// </summary>
        public bool SendAscii(string portName, string data)
        {
            var service = GetPort(portName);
            if (service == null)
            {
                OnError(portName, "SendAscii",
                    $"SerialPort {portName} ���s�b", null);
                return false;
            }

            return service.SendAscii(data);
        }

        /// <summary>
        /// �ǰe ASCII �r���ƨ���w�� SerialPort�A�æ۰ʥ[�W�浲���]�w�] \r\n�A�i�ѳ]�w�վ�^�C
        /// </summary>
        public bool SendAsciiLine(string portName, string line)
        {
            var service = GetPort(portName);
            if (service == null)
            {
                OnError(portName, "SendAsciiLine",
                    $"SerialPort {portName} ���s�b", null);
                return false;
            }

            return service.SendAsciiLine(line);
        }

        #endregion Public Methods - Data Operations

        #region Public Methods - Utility

        /// <summary>
        /// ���o�Ҧ� SerialPort �����A�K�n�C
        /// </summary>
        /// <returns>���A�K�n�r��]PortName -> State�^�C</returns>
        public Dictionary<string, SerialPortState> GetAllPortStates()
        {
            var states = new Dictionary<string, SerialPortState>();

            foreach (var kvp in _ports)
            {
                states[kvp.Key] = kvp.Value.State;
            }

            return states;
        }

        /// <summary>
        /// ���o�t�ΤW�Ҧ��i�Ϊ� SerialPort �W�١C
        /// </summary>
        public static List<string> GetAvailablePorts()
        {
            return SerialPortService.GetAvailablePorts();
        }

        #endregion Public Methods - Utility

        #region Public Methods - Configuration Persistence

        /// <summary>
        /// �x�s�Ҧ��w���U�� Port �t�m�� JSON �ɮסC
        /// </summary>
        /// <param name="filePath">�ɮ׸��|�C</param>
        /// <returns>�O�_���\�x�s�C</returns>
        public bool SaveAllConfigs(string filePath)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(filePath))
                {
                    OnError("", "SaveAllConfigs", "�ɮ׸��|���i����", null);
                    return false;
                }

                var configs = new List<SerialPortConfig>();
                foreach (var service in _ports.Values)
                {
                    configs.Add(service.Config);
                }

                JsonFileHelper.Save(filePath, configs);
                return true;
            }
            catch (Exception ex)
            {
                OnError("", "SaveAllConfigs", $"�x�s�t�m����: {ex.Message}", ex);
                return false;
            }
        }

        /// <summary>
        /// �q JSON �ɮ׸��J�õ��U�h�� Port �t�m�C
        /// </summary>
        /// <param name="filePath">�ɮ׸��|�C</param>
        /// <param name="autoOpen">�O�_�۰ʶ}�Ҹ��J�� Port�C�w�]�� true�C</param>
        /// <returns>���\���J�õ��U�� Port �ƶq�C</returns>
        public int LoadAllConfigs(string filePath, bool autoOpen = true)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(filePath))
                {
                    OnError("", "LoadAllConfigs", "�ɮ׸��|���i����", null);
                    return 0;
                }

                var configs = JsonFileHelper.Read<List<SerialPortConfig>>(filePath);
                if (configs == null || configs.Count == 0)
                {
                    return 0;
                }

                int successCount = 0;
                foreach (var config in configs)
                {
                    try
                    {
                        // �p�G Port �w�s�b�A������
                        if (IsPortRegistered(config.PortName))
                        {
                            UnregisterPort(config.PortName);
                        }

                        // ���U�s�� Port
                        var service = new SerialPortService(config);

                        // �q�\�ƥ�
                        service.StateChanged += OnPortStateChanged;
                        service.DataReceived += OnPortDataReceived;
                        service.ErrorOccurred += OnPortErrorOccurred;

                        if (_ports.TryAdd(config.PortName, service))
                        {
                            if (autoOpen)
                            {
                                service.Open();
                            }
                            successCount++;
                        }
                        else
                        {
                            service.Dispose();
                        }
                    }
                    catch (Exception ex)
                    {
                        OnError(config?.PortName ?? "", "LoadAllConfigs",
                            $"���J Port �t�m����: {ex.Message}", ex);
                    }
                }

                return successCount;
            }
            catch (Exception ex)
            {
                OnError("", "LoadAllConfigs", $"���J�t�m�ɮץ���: {ex.Message}", ex);
                return 0;
            }
        }

        /// <summary>
        /// �x�s�S�w Port ���t�m�� JSON �ɮסC
        /// </summary>
        /// <param name="portName">Port �W�١C</param>
        /// <param name="filePath">�ɮ׸��|�C</param>
        /// <returns>�O�_���\�x�s�C</returns>
        public bool SavePortConfig(string portName, string filePath)
        {
            var service = GetPort(portName);
            if (service == null)
            {
                OnError(portName, "SavePortConfig",
                    $"SerialPort {portName} ���s�b", null);
                return false;
            }

            return service.SaveConfig(filePath);
        }

        /// <summary>
        /// ���J�S�w Port ���t�m�îM�Ρ]�ݭn��ʭ��s�}�ҥH�M�ηs�t�m�^�C
        /// </summary>
        /// <param name="portName">Port �W�١C</param>
        /// <param name="filePath">�ɮ׸��|�C</param>
        /// <returns>�O�_���\���J�C</returns>
        public bool LoadPortConfig(string portName, string filePath)
        {
            var service = GetPort(portName);
            if (service == null)
            {
                OnError(portName, "LoadPortConfig",
                    $"SerialPort {portName} ���s�b", null);
                return false;
            }

            return service.LoadConfig(filePath);
        }

        #endregion Public Methods - Configuration Persistence

        #region Event Handlers

        private void OnPortStateChanged(object sender, SerialPortStateChangedEventArgs e)
        {
            StateChanged?.Invoke(this, e);
        }

        private void OnPortDataReceived(object sender, SerialPortDataReceivedEventArgs e)
        {
            DataReceived?.Invoke(this, e);
        }

        private void OnPortErrorOccurred(object sender, SerialPortErrorEventArgs e)
        {
            ErrorOccurred?.Invoke(this, e);
        }

        private void OnError(string portName, string errorType, string errorMessage, Exception exception)
        {
            try
            {
                ErrorOccurred?.Invoke(this, new SerialPortErrorEventArgs(
                    portName,
                    errorType,
                    errorMessage,
                    exception));
            }
            catch
            {
                // �קK�ƥ�B�z���������~�y�����D
            }
        }

        #endregion Event Handlers

        #region IDisposable

        /// <summary>
        /// ����Ҧ��귽�C
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
                return;

            if (disposing)
            {
                CloseAllPorts();

                foreach (var service in _ports.Values)
                {
                    try
                    {
                        service.StateChanged -= OnPortStateChanged;
                        service.DataReceived -= OnPortDataReceived;
                        service.ErrorOccurred -= OnPortErrorOccurred;
                        service.Dispose();
                    }
                    catch
                    {
                        // Ignore
                    }
                }

                _ports.Clear();
            }

            _disposed = true;
        }

        #endregion IDisposable
    }
}
