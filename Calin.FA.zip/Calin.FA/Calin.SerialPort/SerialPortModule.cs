using Autofac;

namespace Calin.SerialPort
{
    /// <summary>
    /// SerialPort Autofac �ҲաC
    /// ���� SerialPort �A�Ȫ��̿�`�J���U�C
    /// </summary>
    /// <remarks>
    /// �ϥνd�ҡG
    /// <code>
    /// var builder = new ContainerBuilder();
    /// builder.RegisterModule&lt;SerialPortModule&gt;();
    /// 
    /// // �ε��U�S�w�]�w
    /// builder.RegisterModule(new SerialPortModule
    /// {
    ///     RegisterManager = true,
    ///     RegisterService = false
    /// });
    /// </code>
    /// </remarks>
    public class SerialPortModule : Module
    {
        /// <summary>
        /// �O�_���U SerialPortManager�C
        /// �w�]�� true�C
        /// </summary>
        public bool RegisterManager { get; set; } = true;

        /// <summary>
        /// �O�_���U SerialPortService�C
        /// �w�]�� false�]�q�`�ϥ� Manager �Ӻ޲z�h�� Service�^�C
        /// </summary>
        public bool RegisterService { get; set; } = false;

        /// <summary>
        /// SerialPortService ���w�]�]�w�]�� RegisterService = true �ɨϥΡ^�C
        /// </summary>
        public SerialPortConfig DefaultServiceConfig { get; set; }

        protected override void Load(ContainerBuilder builder)
        {
            if (RegisterManager)
            {
                // ���U SerialPortManager �����
                builder.RegisterType<SerialPortManager>()
                    .As<ISerialPortManager>()
                    .SingleInstance();
            }

            if (RegisterService)
            {
                // ���U SerialPortService�]�ݭn���ѳ]�w�^
                if (DefaultServiceConfig != null)
                {
                    builder.Register(c => new SerialPortService(DefaultServiceConfig))
                        .As<ISerialPortService>()
                        .SingleInstance();
                }
                else
                {
                    // ���\�q�e�����ѪR�]�w
                    builder.Register(c => new SerialPortService(c.Resolve<SerialPortConfig>()))
                        .As<ISerialPortService>()
                        .InstancePerDependency();
                }
            }
        }
    }
}
