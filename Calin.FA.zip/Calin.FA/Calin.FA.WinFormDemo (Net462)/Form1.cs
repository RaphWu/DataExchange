﻿using System.Windows.Forms;

namespace Calin.FA.Demo__Net462_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
    }
}
