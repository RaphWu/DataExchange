﻿using Autofac;
using Calin.LDS.Keyence_LK_G5000;
using Calin.SerialPort;

namespace Calin.LDS
{
    public class LdsModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // 註冊 SerialPortService
            builder.Register(c =>
            {
                var config = new SerialPortConfig
                {
                    AsciiLineTerminator = "\r",
                    EnableAutoReconnect = false,
                    EnableHeartbeat = false
                };
                return new SerialPortService(config);
            }).As<ISerialPortService>().SingleInstance();

            builder.RegisterType<LK_G5000Service>().As<ILK_G5000>().SingleInstance();
        }
    }
}
