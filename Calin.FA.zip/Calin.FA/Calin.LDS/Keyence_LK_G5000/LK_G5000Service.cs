﻿using System;
using System.Collections.Generic;
using Calin.SerialPort;

namespace Calin.LDS.Keyence_LK_G5000
{
    /// <summary>
    /// Keyence LK-G5000 服務實做。
    /// </summary>
    public class LK_G5000Service : ILK_G5000
    {
        #region Constants

        private ISerialPortService _serialPort;
        private SerialPortConfig _serialPortConfig;
        private List<CommandStruct> _commandList = new List<CommandStruct>();

        #endregion Constants

        // 建構式（依賴注入）
        public LK_G5000Service(ISerialPortService serialPortService)
        {
            _serialPort = serialPortService ?? throw new ArgumentNullException(nameof(serialPortService));
            _serialPortConfig = serialPortService.Config;
        }

        // 工廠方法（直接初始化 SerialPortService）
        public static LK_G5000Service CreateWithDefaultConfig()
        {
            var config = new SerialPortConfig
            {
                AsciiLineTerminator = "\r",
                EnableAutoReconnect = false,
                EnableHeartbeat = false
            };

            return new LK_G5000Service(new SerialPortService(config));
        }

        #region Properties

        public SerialPortConfig Config => _serialPortConfig;
        public SerialPortState State => _serialPort.State;
        public bool IsReady => _serialPort.IsReady;
        public bool IsOpen => _serialPort.IsOpen;

        #endregion Properties

        #region Methods

        public bool Open()
        {
            if (_serialPort == null)
                throw new InvalidOperationException("Serial port service is not initialized.");

            if (_serialPort.IsOpen)
                return true;

            if (!_serialPort.Open())
                return false;

            CreateCommandList();

            _serialPort.StateChanged += (s, e) =>
            {
                // Handle state changes
                var newState = e.NewState;
                // React to state changes as needed
            };

            _serialPort.DataReceived += (s, e) =>
            {
                string data = e.Data.Substring(0, e.Data.Length - 1);

                //ParseData(data);
            };

            _serialPort.ErrorOccurred += (s, e) =>
            {
                // Handle errors
                string errorType = e.ErrorType;
                string errorMessage = e.ErrorMessage;
                Exception exception = e.Exception;
                // Log or process the error as needed
            };

            return true;
        }

        public void Close()
        {
            _serialPort?.Close();
        }

        public bool SendAsciiLine(CommandStruct command)
        {
            if (_serialPort.IsReady)
            {
                string cmd = command.CommandHead;
                if (!string.IsNullOrWhiteSpace(command.SendParams))
                {
                    //cmd += "," + tbParams.Text.Trim();
                }
                cmd += "\r";
                return _serialPort.SendAscii(cmd);
                //_serialPort.Port.WriteLine(cs);
            }
            return false;
        }

        private void ParseData(string data)
        {
            // 符號 + 7 bytes
            string resCommand = data;

            //if (resCommand.EndsWith("\r"))
            //    resCommand = resCommand.Substring(0, resCommand.Length - 1); // 去掉 CR

            //int responseLength = _sendCommand.SendParams.Length;
            //if (resCommand.Substring(0, responseLength) == _sendCommand.SendParams)
            //{
            //    _measuredString = resCommand.Substring(responseLength + 1, resCommand.Length - responseLength)
            //        .Split(',')
            //        .Where(s => !string.IsNullOrWhiteSpace(s))
            //        .ToList();

            //    // 收到回應
            //    _dataSended = false;
            //}
            //else
            //{
            //}
        }

        #endregion Methods

        #region File Config Methods

        public bool LoadConfig(string filePath)
        {
            throw new NotImplementedException();
        }

        public bool SaveConfig(string filePath)
        {
            throw new NotImplementedException();
        }

        #endregion File Config Methods

        #region Command List

        private void CreateCommandList()
        {
            int id = 0;
            _commandList = new List<CommandStruct>();

            // 模式變更指令 p.5-7
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "變更為通訊模式",
                CommandHead = "Q0",
                SendParams = "",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "變更為一般模式",
                CommandHead = "R0",
                SendParams = "",
                ResponseParams = "",
            });

            // 量測控制指令格式 p.5-8
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "量測值輸出（一個）",
                CommandHead = "MS",
                SendParams = "aa",
                ResponseParams = "aa,hhhhhhhh",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "量測值輸出（多個）",
                CommandHead = "MM",
                SendParams = "iiiiiiiiiiii",
                ResponseParams = "iiiiiiiiiiii,hhhhhhhh",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "量測值輸出（全部）",
                CommandHead = "MA",
                SendParams = "",
                ResponseParams = "hhhhhhhh",
            });

            // TIM ON/OFF
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "TIM ON/OFF（一個）",
                CommandHead = "TS",
                SendParams = "p,aa",
                ResponseParams = "p,aa",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "TIM ON/OFF （多個）",
                CommandHead = "TM",
                SendParams = "p,iiiiiiiiiiii",
                ResponseParams = "p,iiiiiiiiiiii",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "TIM ON/OFF （同步）",
                CommandHead = "TP",
                SendParams = "",
                ResponseParams = "",
            });

            // 自動歸零 p.5-9
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "自動歸零 ON （一個）",
                CommandHead = "VS",
                SendParams = "aa",
                ResponseParams = "aa",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "自動歸零 ON （多個）",
                CommandHead = "VM",
                SendParams = "iiiiiiiiiiii",
                ResponseParams = "iiiiiiiiiiii",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "自動歸零 ON （同步）",
                CommandHead = "VA",
                SendParams = "",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "自動歸零 OFF （一個）",
                CommandHead = "WS",
                SendParams = "aa",
                ResponseParams = "aa",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "自動歸零 OFF （多個）",
                CommandHead = "WM",
                SendParams = "iiiiiiiiiiii",
                ResponseParams = "iiiiiiiiiiii",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "自動歸零 OFF （同步）",
                CommandHead = "WA",
                SendParams = "",
                ResponseParams = "",
            });

            // 重置
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "重置（一個）",
                CommandHead = "DS",
                SendParams = "aa",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "重置（多個）",
                CommandHead = "DM",
                SendParams = "iiiiiiiiiiii",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "重置（同步）",
                CommandHead = "DA",
                SendParams = "",
                ResponseParams = "",
            });

            //
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "面板鎖定",
                CommandHead = "KL",
                SendParams = "p",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "程式切換",
                CommandHead = "PW",
                SendParams = "o",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "程式確認",
                CommandHead = "PR",
                SendParams = "",
                ResponseParams = "o",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "資料存儲開始",
                CommandHead = "AS",
                SendParams = "",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "資料存儲停止",
                CommandHead = "AP",
                SendParams = "",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "資料存儲初始化",
                CommandHead = "AQ",
                SendParams = "",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "資料存儲資料輸出",
                CommandHead = "AO",
                SendParams = "aa",
                ResponseParams = "hhhhhhhh",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "資料存儲狀態輸出",
                CommandHead = "AN",
                SendParams = "",
                ResponseParams = "s,ddddddd",
            });

            // 設定變更指令 p.5-14
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "量測顯示切換",
                CommandHead = "DC",
                SendParams = "bb,bb",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "公差設定",
                CommandHead = "SW,LM",
                SendParams = "aa,fffffff,fffffff,fffffff",
                ResponseParams = "",
            });

            // 感測頭設定
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "ABLE",
                CommandHead = "SW,HA",
                SendParams = "M,qq,m",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "ABLE 控制範圍",
                CommandHead = "SW,HA",
                SendParams = "R,qq,xx,xx",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "量測模式",
                CommandHead = "SW,HB",
                SendParams = "M,qq,c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "基礎坐標",
                CommandHead = "SW,HB",
                SendParams = "B,qq,c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "警報處理",
                CommandHead = "SW,HC",
                SendParams = "N,qq,nnnn,nnnn",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "警報級別",
                CommandHead = "SW,HC",
                SendParams = "L,qq,c",
                ResponseParams = "",
            });

            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "ABLE 補正開始",
                CommandHead = "SW,HD",
                SendParams = "S,qq",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "ABLE 補正完成",
                CommandHead = "SW,HD",
                SendParams = "P",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "ABLE 補正停止",
                CommandHead = "SW,HD",
                SendParams = "C",
                ResponseParams = "",
            });

            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "安裝模式",
                CommandHead = "SW,HE",
                SendParams = "qq,c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "遮蔽設定",
                CommandHead = "SW,HF",
                SendParams = "qq,c,fffffff,fffffff",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "中值",
                CommandHead = "SW,HG",
                SendParams = "qq,c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "LASER CTRL 組",
                CommandHead = "SW,HH",
                SendParams = "qq,c",
                ResponseParams = "qq",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "範圍設定",
                CommandHead = "SW,HI",
                SendParams = "qq,c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "防止互相干擾組",
                CommandHead = "SW,HJ",
                SendParams = "qq,c",
                ResponseParams = "",
            });

            // OUT 設定 p.5-18
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "計算方式",
                CommandHead = "SW,OA",
                SendParams = "H,aa,ggg",
                ResponseParams = "aa",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "待測表面",
                CommandHead = "SW,OA",
                SendParams = "T,aa,c",
                ResponseParams = "aa",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "待計算 (ADD, SUB)",
                CommandHead = "SW,OA",
                SendParams = "C,aa,jj,jj",
                ResponseParams = "aa",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "待計算 (AVE, MAX, MIN, P-P)",
                CommandHead = "SW,OA",
                SendParams = "M,aa,iiiiiiiiiiii",
                ResponseParams = "aa",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "比例",
                CommandHead = "SW,OB",
                SendParams = "aa,fffffff,fffffff,fffffff,fffffff",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "濾波器",
                CommandHead = "SW,OC",
                SendParams = "aa,c,c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "量測（保持）模式",
                CommandHead = "SW,OD",
                SendParams = "aa,c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "觸發模式",
                CommandHead = "SW,OE",
                SendParams = "M,aa,c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "偏移",
                CommandHead = "SW,OF",
                SendParams = "aa,fffffff",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "最小顯示單位",
                CommandHead = "SW,OG",
                SendParams = "aa,c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "類比輸出比例",
                CommandHead = "SW,OH",
                SendParams = "aa,fffffff,fffffff,fffffff,fffffff",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "量測型式",
                CommandHead = "SW,OI",
                SendParams = "aa,c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "同步設定",
                CommandHead = "SW,OJ",
                SendParams = "aa,c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "儲存（OUT 編號規格）",
                CommandHead = "SW,OK",
                SendParams = "aa,c",
                ResponseParams = "",
            });

            // 通用設定 p.5-22
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "取樣週期",
                CommandHead = "SW,CA",
                SendParams = "c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "防止互相干擾",
                CommandHead = "SW,CB",
                SendParams = "c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "比較器輸出形式",
                CommandHead = "SW,CD",
                SendParams = "c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "單擊時間",
                CommandHead = "SW,CE",
                SendParams = "c",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "資料存儲",
                CommandHead = "SW,CF",
                SendParams = "ddddddd,ll",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "類比輸出通道",
                CommandHead = "SW,CG",
                SendParams = "ee,bb",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "警報輸出型式",
                CommandHead = "SW,CH",
                SendParams = "c",
                ResponseParams = "",
            });

            // 環境設定 p.5-23
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "使用 OUT 計數",
                CommandHead = "SW,EE",
                SendParams = "yy",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "使用感測頭計數",
                CommandHead = "SW,EF",
                SendParams = "yy",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "使用類比輸出通道計數",
                CommandHead = "SW,EG",
                SendParams = "yy",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "IP 位址",
                CommandHead = "SW,EH",
                SendParams = "I,zzzzzzzzzzzz",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "子網路遮罩",
                CommandHead = "SW,EH",
                SendParams = "M,zzzzzzzzzzzz",
                ResponseParams = "",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "原廠閘道",
                CommandHead = "SW,EH",
                SendParams = "G,zzzzzzzzzzzz",
                ResponseParams = "",
            });

            // 設定確認指令格式 p.5-25
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "量測顯示確認",
                CommandHead = "DR",
                SendParams = "",
                ResponseParams = "bb,bb",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "公差設定",
                CommandHead = "SR,LM",
                SendParams = "aa",
                ResponseParams = "aa,ffffffff,ffffffff,fffffff",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "ABLE",
                CommandHead = "SR,HA,M",
                SendParams = "qq",
                ResponseParams = "qq,m",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "ABLE 控制範圍",
                CommandHead = "SR,HA,R",
                SendParams = "qq",
                ResponseParams = "qq,xx,xx",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "量測模式",
                CommandHead = "SR,HB,M",
                SendParams = "qq",
                ResponseParams = "qq,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "基礎坐標",
                CommandHead = "SR,HB,B",
                SendParams = "qq",
                ResponseParams = "qq,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "警報處理",
                CommandHead = "SR,HC,N",
                SendParams = "qq",
                ResponseParams = "qq,nnnn,nnnn",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "警報級別",
                CommandHead = "SR,HC,L",
                SendParams = "qq",
                ResponseParams = "qq,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "安裝模式",
                CommandHead = "SR,HE",
                SendParams = "qq",
                ResponseParams = "qq,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "遮罩設定",
                CommandHead = "SR,HF",
                SendParams = "qq,c",
                ResponseParams = "qq,c,fffffff,fffffff",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "中值",
                CommandHead = "SR,HG",
                SendParams = "qq",
                ResponseParams = "qq,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "LASER CTRL 組",
                CommandHead = "SR,HH",
                SendParams = "qq",
                ResponseParams = "qq,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "範圍設定",
                CommandHead = "SR,HI",
                SendParams = "qq",
                ResponseParams = "qq,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "防止互相干擾組",
                CommandHead = "SR,HJ",
                SendParams = "qq",
                ResponseParams = "qq,c",
            });

            // OUT 設定 p.5-28
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "計算方式",
                CommandHead = "SR,OA,H",
                SendParams = "aa",
                ResponseParams = "aa,ggg",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "待測表面",
                CommandHead = "SR,OA,T",
                SendParams = "aa",
                ResponseParams = "aa,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "待計算 (Add, Sub)",
                CommandHead = "SR,OA,C",
                SendParams = "aa",
                ResponseParams = "aa,jj,jj",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "待計算 (AVE, MAX, MIN, P-P)",
                CommandHead = "SR,OA,M",
                SendParams = "aa",
                ResponseParams = "aa,iiiiiiiiiiii",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "比例",
                CommandHead = "SR,OB",
                SendParams = "aa",
                ResponseParams = "aa,fffffff,fffffff,fffffff,fffffff",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "濾波器",
                CommandHead = "SR,OC",
                SendParams = "aa",
                ResponseParams = "aa,c,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "量測模式",
                CommandHead = "SR,OD",
                SendParams = "aa",
                ResponseParams = "aa,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "觸發模式",
                CommandHead = "SR,OE,M",
                SendParams = "aa",
                ResponseParams = "aa,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "偏移",
                CommandHead = "SR,OF",
                SendParams = "aa",
                ResponseParams = "aa,fffffff",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "最小顯示單位",
                CommandHead = "SR,OG",
                SendParams = "aa",
                ResponseParams = "aa,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "類比輸出比例",
                CommandHead = "SR,OH",
                SendParams = "aa",
                ResponseParams = "aa,fffffff,fffffff,fffffff,fffffff",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "量測型式",
                CommandHead = "SR,OI",
                SendParams = "aa",
                ResponseParams = "aa,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "同步設定",
                CommandHead = "SR,OJ",
                SendParams = "aa",
                ResponseParams = "aa,c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "存儲（OUT 編號儲存對象）",
                CommandHead = "SR,OK",
                SendParams = "aa",
                ResponseParams = "aa,c",
            });

            // 通用設定 5-31
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "取樣週期",
                CommandHead = "SR,CA",
                SendParams = "",
                ResponseParams = "c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "防止互相干擾",
                CommandHead = "SR,CB",
                SendParams = "",
                ResponseParams = "c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "比較器輸出形式",
                CommandHead = "SR,CD",
                SendParams = "",
                ResponseParams = "c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "單擊時間",
                CommandHead = "SR,CE",
                SendParams = "",
                ResponseParams = "c",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "資料存儲",
                CommandHead = "SR,CF",
                SendParams = "",
                ResponseParams = "ddddddd,ll",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "類比輸出通道",
                CommandHead = "SR,CG",
                SendParams = "ee",
                ResponseParams = "ee,bb",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "警報輸出型式",
                CommandHead = "SR,CB",
                SendParams = "",
                ResponseParams = "c",
            });

            // 環境設定 5-33
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "使用 OUT 計數",
                CommandHead = "SR,EE",
                SendParams = "",
                ResponseParams = "yy",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "使用感測頭計數",
                CommandHead = "SR,EF",
                SendParams = "",
                ResponseParams = "yy",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "使用類比輸出通道計數",
                CommandHead = "SR,EG",
                SendParams = "",
                ResponseParams = "yy",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "IP 位址",
                CommandHead = "SR,EH,I",
                SendParams = "",
                ResponseParams = "zzzzzzzzzzzz",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "子網路遮罩",
                CommandHead = "SR,EH,M",
                SendParams = "",
                ResponseParams = "zzzzzzzzzzzz",
            });
            _commandList.Add(new CommandStruct()
            {
                Id = ++id,
                CommandName = "原廠閘道",
                CommandHead = "SR,EH,G",
                SendParams = "",
                ResponseParams = "zzzzzzzzzzzz",
            });
        }

        #endregion Command List
    }
}
