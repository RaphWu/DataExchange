﻿namespace Calin.LDS.Keyence_LK_G5000
{
    /// <summary>
    /// 表示一個指令結構的類別，用於描述指令的相關屬性。
    /// </summary>
    public class CommandStruct
    {
        /// <summary>
        /// 取得或設定指令的唯一編號。
        /// </summary>
        public int Id { get; internal set; }

        /// <summary>
        /// 取得或設定指令的名稱。
        /// </summary>
        public string CommandName { get; internal set; } = "";

        /// <summary>                     
        /// 取得或設定指令的指令頭內容。     
        /// </summary>
        public string CommandHead { get; internal set; } = "";

        /// <summary>
        /// 取得或設定指令的傳入參數。
        /// </summary>
        public string SendParams { get; internal set; } = "";

        /// <summary>
        /// 取得或設定指令的回傳參數。
        /// </summary>
        public string ResponseParams { get; internal set; } = "";
    }
}
