﻿
using Calin.SerialPort;

namespace Calin.LDS.Keyence_LK_G5000
{
    /// <summary>
    /// Keyence LK-G5000 介面。
    /// </summary>
    public interface ILK_G5000
    {
        #region Properties

        /// <summary>
        /// 取得目前的連線狀態。
        /// </summary>
        SerialPortState State { get; }

        /// <summary>
        /// 取得 LK-G500 是否已開啟並就緒。
        /// </summary>
        bool IsReady { get; }

        /// <summary>
        /// 取得 LK-G500 是否已開啟。
        /// </summary>
        bool IsOpen { get; }

        /// <summary>
        /// 取得設定資訊。
        /// </summary>
        SerialPortConfig Config { get; }

        #endregion Properties

        #region Methods

        /// <summary>
        /// 開啟 LK-G500 連線。
        /// </summary>
        /// <returns>是否成功開啟。</returns>
        bool Open();

        /// <summary>
        /// 關閉 LK-G500 連線。
        /// </summary>
        void Close();

        /// <summary>
        /// 傳送 ASCII 字串資料並自動加上行結尾。
        /// </summary>
        /// <param name="command">要傳送的指令結構。</param>
        /// <returns>是否成功傳送。</returns>
        bool SendAsciiLine(CommandStruct command);

        #endregion Methods

        #region File Config Methods

        /// <summary>
        /// 儲存目前配置到 JSON 檔案。
        /// </summary>
        /// <param name="filePath">檔案路徑。</param>
        /// <returns>是否成功儲存。</returns>
        bool SaveConfig(string filePath);

        /// <summary>
        /// 從 JSON 檔案載入配置並更新設定。
        /// </summary>
        /// <param name="filePath">檔案路徑。</param>
        /// <returns>是否成功載入。</returns>
        bool LoadConfig(string filePath);

        #endregion File Config Methods
    }
}
