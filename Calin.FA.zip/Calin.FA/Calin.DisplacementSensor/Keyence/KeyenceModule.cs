﻿namespace Calin.DisplacementSensor.Keyence
{
    public class KeyenceModule
    {
    }
}
