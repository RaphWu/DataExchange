﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using Calin.SerialPort;

namespace Calin.DisplacementSensor.Keyence
{
    public class LK_G5000Service : ILK_G5000
    {
        private SerialPortConfig _config = new SerialPortConfig();
        private ISerialPortService _lkG5000;

        public LK_G5000Service()
        {
        }

        public void Close()
        {
            _lkG5000?.Close();
        }

        public void Open()
        {
            if (_lkG5000 != null && _lkG5000.IsOpen)
                return;

            _lkG5000 = new SerialPortService(_config);
            _lkG5000.Open();

            _lkG5000.StateChanged += (s, e) =>
            {
                // Handle state changes
                var newState = e.NewState;
                // React to state changes as needed
            };

            _lkG5000.DataReceived += (s, e) =>
            {
                // Handle data received from the sensor
                string data = e.Data;
                // Process the data as needed
            };

            _lkG5000.ErrorOccurred += (s, e) =>
            {
                // Handle errors
                string errorType = e.ErrorType;
                string errorMessage = e.ErrorMessage;
                Exception exception = e.Exception;
                // Log or process the error as needed
            };
        }
    }
}
