﻿using System;

namespace CALIN.Data.Verify
{
    public static class LRC
    {
        /// <summary>
        /// 計算 LRC 值。
        /// </summary>
        /// <param name="frame">要計算的 byte 陣列。</param>
        /// <param name="lenght">要計算的長度，預設為 0，表示計算整個陣列。</param>
        /// <returns>LRC 值。</returns>
        public static byte Lrc(byte[] frame, int lenght = 0)
        {
            int startIndex = (frame[0] == 0x3A) ? 1 : 0;
            int len = (lenght == 0) ? frame.Length : lenght;
            byte lrc = 0;
            for (int i = startIndex; i < len; i++)
                lrc += frame[i];
            return (byte)((lrc ^ 0xFF) + 1);
        }

        /// <summary>
        /// 計算字串的 LRC 值。
        /// </summary>
        /// <param name="frameString">要計算的指令幀字串。</param>
        /// <returns>LRC 值。</returns>
        /// <remarks>用於 Modbus ASCII 模式指令幀字串的 LRC 計算。</remarks>
        public static byte LrcByAscii(string frameString)
        {
            byte lrc = 0;
            int startIndex = (frameString.Substring(0, 1) == ":") ? 1 : 0;
            int totalLen = (frameString.Length - startIndex) / 2;

            for (int i = startIndex; i < totalLen; i++)
                lrc += Convert.ToByte(frameString.Substring((i - startIndex) * 2, 2), 16);

            return (byte)((lrc ^ 0xFF) + 1);
        }
    }
}
