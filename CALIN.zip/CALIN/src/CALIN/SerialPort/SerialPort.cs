﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Threading;

namespace CALIN.SerialPort
{
    /// <summary>
    /// SerialPort實例化。
    /// </summary>
    public class SerialPort : ISerialPort
    {
        private System.IO.Ports.SerialPort _sp = new System.IO.Ports.SerialPort();
        private readonly SerialPortParameters _spp = new SerialPortParameters();

        private static readonly object _spLocker = new object();

        /*************************
         * Serial Port Pin State
         *************************/
        //private static bool _cdHolding;
        //private static bool _ctsHolding;
        //private static bool _dsrHolding;

        /********************
         * ctor
         ********************/
        public SerialPort()
        {
        }

        public SerialPort(string portName, int baudRate, Parity parity, int dataBits, StopBits stopBits)
        {
            _sp.PortName = portName;
            _sp.BaudRate = baudRate;
            _sp.Parity = parity;
            _sp.DataBits = dataBits;
            _sp.StopBits = stopBits;
        }

        /********************
         * 內部參數
         ********************/
        /// <inheritdoc/>
        public bool IsOpen => _sp != null && _sp.IsOpen;

        /// <inheritdoc/>
        public List<string> PortNameList
        {
            get
            {
                _spp.PortNameList = System.IO.Ports.SerialPort.GetPortNames().ToList();
                _spp.PortNameList.Sort();
                return _spp.PortNameList;
            }
        }

        /********************
         * Port開啟與關閉。
         ********************/
        /// <inheritdoc/>
        public void Close()
        {
            if (IsOpen)
            {
                _sp.DataReceived -= SerialPort_DataReceived;
                _sp.ErrorReceived -= SerialPort_ErrorReceived;
                _sp.PinChanged -= SerialPort_PinChanged;
                _sp.Close();
                Thread.Sleep(100); // 等待關閉完成
            }
        }

        /// <inheritdoc/>
        public void Open()
        {
            try
            {
                _sp.Open();

                if (IsOpen)
                {
                    Console.WriteLine(string.Concat(_sp.PortName, " 已開啟。"));

                    _sp.DataReceived += SerialPort_DataReceived;
                    _sp.ErrorReceived += SerialPort_ErrorReceived;
                    _sp.PinChanged += SerialPort_PinChanged;
                }
                else
                {
                    Console.WriteLine(string.Concat(_sp.PortName, " 開啟失敗！"));
                }
            }
            catch (TimeoutException te)
            {
                Console.WriteLine(string.Concat(_sp.PortName, " 開啟逾時: ", te.Message));
                Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Concat(_sp.PortName, " 開啟異常: ", ex.Message));
                Close();
            }
        }

        /// <summary>
        /// 接收資料事件。
        /// </summary>
        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (!IsOpen)
            {
                _spp.BytesToReceived = 0;
                return;
            }

            var sps = sender as System.IO.Ports.SerialPort;
            _spp.BytesToReceived = sps.Read(_spp.ReceivedMessages, 0, sps.BytesToRead);
            return;
        }

        /// <summary>
        /// 錯誤發生處理事件。
        /// </summary>
        private void SerialPort_ErrorReceived(object sender, SerialErrorReceivedEventArgs e)
        {
            //Task.Delay(10);
        }

        /// <summary>
        /// 序列通訊埠上控制引腳狀態變更的事件。
        /// </summary>
        private void SerialPort_PinChanged(object sender, SerialPinChangedEventArgs e)
        {
            // UpdatePinState();
        }

        //private void UpdatePinState()
        //{
        //    _ = Task.Run(() =>
        //    {
        //        _ctsHolding = _serialPort.CtsHolding;
        //        _dsrHolding = _serialPort.DsrHolding;
        //        _cdHolding = _serialPort.CDHolding;
        //    });
        //}

        /********************
         * Functions
         ********************/
        /// <inheritdoc/>
        public bool SendData(string data)
        {
            if (_sp != null && _sp.IsOpen)
            {
                lock (_spLocker)
                {
                    try
                    {
                        if (data == null || data.Length == 0)
                            throw new ArgumentException("傳送的資料不能為空或null。");

                        _sp.Write(data);
                    }
                    catch (TimeoutException te)
                    {
                        throw new Exception($"傳送逾時: {te.Message}");
                    }
                    catch (Exception ex)
                    {
                        throw new Exception($"傳送異常: {ex.Message}");
                    }
                }
                return true;
            }
            return false;
        }

        /// <inheritdoc/>
        public bool SendData(byte[] data)
        {
            if (_sp != null && _sp.IsOpen)
            {
                lock (_spLocker)
                {
                    try
                    {
                        if (data == null || data.Length == 0)
                            throw new ArgumentException("傳送的資料不能為空或null。");

                        _sp.Write(data, 0, data.Length);
                    }
                    catch (TimeoutException te)
                    {
                        throw new Exception($"傳送逾時: {te.Message}");
                    }
                    catch (Exception ex)
                    {
                        throw new Exception($"傳送異常: {ex.Message}");
                    }
                }
                return true;
            }
            return false;
        }
    }
}
