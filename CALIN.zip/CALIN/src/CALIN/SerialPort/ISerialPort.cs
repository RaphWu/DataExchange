﻿using System.Collections.Generic;

namespace CALIN.SerialPort
{
    /// <summary>
    /// SerialPort實例化。
    /// </summary>
    public interface ISerialPort
    {
        /// <summary>
        /// SerialPort是否開啟。
        /// </summary>
        bool IsOpen { get; }

        /// <summary>
        /// 更新並返回Port Name列表。
        /// </summary>
        /// <returns>Port Name列表。</returns>
        List<string> PortNameList { get; }

        /// <summary>
        /// 關閉Port。
        /// </summary>
        void Close();

        /// <summary>
        /// 依設定的參數開啟Port。
        /// </summary>
        void Open();

        /// <summary>
        /// 傳送Data。
        /// </summary>
        /// <param name="data">要傳送的字串資料。</param>
        /// <returns>傳送是否成功。</returns>
        bool SendData(string data);

        /// <summary>
        /// 傳送Data。
        /// </summary>
        /// <param name="data">要傳送的byte陣列資料。</param>
        /// <returns>傳送是否成功。</returns>
        bool SendData(byte[] data);
    }
}
