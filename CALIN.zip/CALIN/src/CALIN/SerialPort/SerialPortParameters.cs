﻿using System.Collections.Generic;
using System.IO.Ports;
using System.Text;

namespace CALIN.SerialPort
{
    public class SerialPortParameters
    {
        /********************
         * Modbus 參數
         ********************/
        /// <summary>
        /// 站號。
        /// </summary>
        public byte Station { get; internal set; }

        public string StationString
        {
            get { return Station.ToString("X2"); }
        }

        public byte[] StationBytes
        {
            get { return Encoding.ASCII.GetBytes(StationString); }
        }

        /********************
         * Serial Port 參數
         ********************/
        ///// <summary>
        ///// SerialPort名稱。
        ///// </summary>
        //public string PortName { get; set; } = string.Empty;

        ///// <summary>
        ///// 鮑率。
        ///// </summary>
        //public int BaudRate { get; set; }

        ///// <summary>
        ///// 同位位元。
        ///// </summary>
        ///// <remarks>
        ///// 參考: <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.io.ports.parity">Parity 列舉</see>
        ///// </remarks>
        //public Parity Parity { get; set; } = Parity.None;

        ///// <summary>
        ///// 資料位元
        ///// </summary>
        //public int DataBits { get; set; }

        ///// <summary>
        ///// 停止位元。
        ///// </summary>
        ///// <remarks>
        ///// 參考: <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.io.ports.stopbits">StopBits 列舉</see>
        ///// </remarks>
        //public StopBits StopBits { get; set; } = StopBits.One;

        ///// <summary>
        ///// 控制通訊協定。
        ///// </summary>
        ///// <remarks>
        ///// 參考: <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.io.ports.handshake">Handshake 列舉</see>
        ///// </remarks>
        //public Handshake Handshake { get; set; } = Handshake.None;

        ///// <summary>
        ///// 讀取作業逾時的毫秒數。
        ///// </summary>
        //public int ReadTimeout { get; set; } = 500;

        ///// <summary>
        ///// 寫入作業逾時的毫秒數。
        ///// </summary>
        //public int WriteTimeout { get; set; } = 500;

        /********************
         * 列表
         ********************/
        /// <summary>
        /// SerialPort名稱列表。
        /// </summary>
        public List<string> PortNameList = new List<string>();

        /// <summary>
        /// 鮑率列表。
        /// </summary>
        public List<int> BaudRateList { get; } = new List<int>() { 2400, 4800, 9600, 19200, 38400, 57600, 115200 };

        /// <summary>
        /// 資料位元列表。
        /// </summary>
        public List<int> DataBitsList { get; } = new List<int>() { 5, 6, 7, 8, 9 };

        /********************
         * 通訊
         ********************/
        /// <summary>
        /// 接收的訊息。
        /// </summary>
        public byte[] ReceivedMessages { get; set; }

        /// <summary>
        /// 接收的訊息長度。
        /// </summary>
        public int BytesToReceived { get; set; } = 0;
    }
}
