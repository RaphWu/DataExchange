﻿using CALIN.Data.Verify;
using System;

namespace CALIN.ToyoCylinder
{
    /// <summary>
    /// 座標值處理
    /// </summary>
    public static class Core
    {
        internal const int ONE_WORD = 4;
        internal const int TWO_WORD = 8;

        #region 數學運算

        /// <summary>
        /// 座標小數有效位數。
        /// </summary>
        /// <remarks>座標的單位均為 mm，小數3位則為 µm，故小數抓位 6 位數即可避免算術誤差累積。</remarks>
        internal const int SIGNIFICANT_FIGURES = 6;

        /// <summary>
        /// 將數值格式化為指定的小數位數。
        /// </summary>
        /// <param name="value">待格式化的數值。</param>
        /// <param name="digit">小數位數。</param>
        /// <returns>格式化完成後的數值。</returns>
        public static double Format(this double value, int digit)
        {
            if (!double.IsNaN(value))
                return Math.Round(value, digit, MidpointRounding.AwayFromZero);

            return double.NaN;
        }

        #endregion

        #region 座標處理

        /// <summary>
        /// 有效位數修正為系統需求。
        /// </summary>
        /// <param name="coordinate">待格式化的座標值。</param>
        /// <returns>格式化完成後的座標值。</returns>
        public static double CoorFormat(this double coordinate)
        {
            return coordinate.Format(SIGNIFICANT_FIGURES);
        }

        #endregion

        #region 通訊幀處理

        /// <summary>
        /// 檢查通訊幀的有效性。
        /// </summary>
        /// <param name="frame"></param>
        /// <returns>幀是否有效。</returns>
        public static bool ValidFrame(string frame)
        {
            int len = frame.Length;

            if (frame.Substring(0, 1) != ":")
                return false;

            if (frame.Substring(len - 1, 1) != "\r")
                return false;

            string lrc = frame.Substring(len - 1 - 2, 2);
            frame = frame.Substring(1, len - 1 - 1 - 2);
            if (LRC.LrcByAscii(frame) != Convert.ToByte(lrc, 16))
                return false;

            return true;
        }

        #endregion

        #region 訊息轉換

        /// <summary>
        /// 取得警報狀態的說明。
        /// </summary>
        /// <param name="code">警報狀態的編號。</param>
        /// <returns>警報狀態的說明。</returns>
        public static string GetDescriptionOfAlarmStatus(int code)
        {
            switch (code)
            {
                case 0:
                    return "無警報";
                case 1:
                    return "Loop error";
                case 2:
                    return "Full Count";
                case 3:
                    return "過速度";
                case 4:
                    return "增益值調整不良";
                case 5:
                    return "過電壓";
                case 6:
                    return "初期化異常";
                case 7:
                    return "EEPROM 異常";
                case 8:
                    return "主迴路電源電壓不足";
                case 9:
                    return "過電流";
                case 10:
                    return "回生異常";
                case 11:
                    return "緊急停止";
                case 12:
                    return "馬達斷線";
                case 13:
                    return "編碼器斷線";
                case 14:
                    return "保護電流值";
                case 15:
                    return "電源再投入";
                case 16:
                    return "動作超時";
                default:
                    return "不明錯誤";
            }
        }

        /// <summary>
        /// 取得錯誤狀態的說明。
        /// </summary>
        /// <param name="code">錯誤狀態的編號。</param>
        /// <returns>錯誤狀態的說明。</returns>
        public static string GetDescriptionOfErrorStatus(int code)
        {
            switch (code)
            {
                case 0:
                    return "沒有錯誤";
                case 1:
                    return "在動作中接收動作指令";
                case 2:
                    return "上下限錯誤";
                case 3:
                    return "位置錯誤";
                case 4:
                    return "格式錯誤";
                case 5:
                    return "控制模式錯誤";
                case 6:
                    return "斷電重開";
                case 7:
                    return "初始化未完成";
                case 8:
                    return "Servo ON/OFF 錯誤";
                case 9:
                    return "LOCK";
                case 10:
                    return "軟體極限";
                case 11:
                    return "參數寫入權限不足";
                case 12:
                    return "原點復歸未完成";
                case 13:
                    return "剎車已解除";
                default:
                    return "不明錯誤";
            }
        }

        #endregion

    }
}
