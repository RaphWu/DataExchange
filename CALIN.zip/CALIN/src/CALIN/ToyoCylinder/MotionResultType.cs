﻿namespace CALIN.ToyoCylinder
{
    /// <summary>
    /// 運動指令結果的類型。
    /// </summary>
    public enum MotionResultType
    {
        /// <summary>
        /// 完成目標動作且到達目標位置。
        /// </summary>
        Success,

        /// <summary>
        /// 因位置沒有移動達到指定時間，而判定完成目標動作。
        /// </summary>
        /// <remarks>運動指令專屬。</remarks>
        SuccessByHoldingPosition,

        /// <summary>
        /// 參數錯誤。
        /// </summary>
        ParameterError,
    }
}
