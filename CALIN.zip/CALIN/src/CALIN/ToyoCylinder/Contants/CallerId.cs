﻿namespace CALIN.ToyoCylinder.Contants
{
    /// <summary>
    /// 傳送命令的呼叫來源。
    /// </summary>
    internal enum CallerId
    {
        /// <summary>
        /// Port 初始化。
        /// </summary>
        Initializer,

        /// <summary>
        /// 看門狗。
        /// </summary>
        WatchDog,

        /// <summary>
        /// 傳送命令。
        /// </summary>
        Command,

        /// <summary>
        /// 讀取電動缸狀態。
        /// </summary>
        CylinderStatus,

        /// <summary>
        /// 輸出訊號。
        /// </summary>
        PortOut,

        /// <summary>
        /// 輸入訊號。
        /// </summary>
        PortIn,
    }
}
