﻿namespace CALIN.ToyoCylinder.Contants
{
    /// <summary>
    /// 資料傳送結構。
    /// </summary>
    internal struct FrameStruct
    {
        /// <summary>
        /// 呼叫來源。
        /// </summary>
        public CallerId CallerId { get; set; }

        /// <summary>
        /// 幀內容。
        /// </summary>
        public byte[] ByteArray { get; set; }

        /// <summary>
        /// 資料長度。
        /// </summary>
        public int Length { get; set; }
    }
}
