﻿namespace CALIN.ToyoCylinder
{
    public class CylinderParams
    {
        /// <summary>
        /// 當命令傳送失敗時，重試的次數。
        /// </summary>
        public int RetryTimes { get; set; }

        /// <summary>
        /// 電動缸最小位置。
        /// </summary>
        public double MinPosition { get; set; }

        /// <summary>
        /// 電動缸最大位置。
        /// </summary>
        public double MaxPosition { get; set; }
    }
}
