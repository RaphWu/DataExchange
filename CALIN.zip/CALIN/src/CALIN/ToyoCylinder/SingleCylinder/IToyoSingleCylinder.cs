﻿using System.IO.Ports;

namespace CALIN.ToyoCylinder.SingleCylinder
{
    public interface IToyoSingleCylinder : IPolling, IMotion
    {
        #region MODBUS 參數

        /// <summary>
        /// 站號。
        /// </summary>
        byte Station { get; set; }

        /// <summary>
        /// 電動缸關閉連接。
        /// </summary>
        void Close();

        /// <summary>
        /// 電動缸開啟連接。
        /// </summary>
        void Open();

        #endregion

        #region Serial Port 參數

        /// <summary>
        /// 此 SerialPort 是否已開啟。
        /// </summary>
        bool IsOpen { get; }

        /// <summary>
        /// SerialPort 名稱。
        /// </summary>
        string PortName { get; }

        /// <summary>
        /// BaudRate 鮑率。
        /// </summary>
        int BaudRate { get; set; }

        /// <summary>
        /// Parity 同位位元。
        /// </summary>
        Parity Parity { get; set; }

        /// <summary>
        /// DataBits 資料位元。
        /// </summary>
        int DataBits { get; set; }

        /// <summary>
        /// StopBits 停止位元。
        /// </summary>
        StopBits StopBits { get; set; }

        /// <summary>
        /// ReadTimeout 讀取作業逾時的毫秒數。
        /// </summary>
        int ReadTimeout { get; set; }

        /// <summary>
        /// WriteTimeout 寫入作業逾時的毫秒數。
        /// </summary>
        int WriteTimeout { get; set; }

        #endregion

        /// <summary>
        /// 看門狗計數器。
        /// </summary>
        uint WatchDogCounter { get; }
    }
}
