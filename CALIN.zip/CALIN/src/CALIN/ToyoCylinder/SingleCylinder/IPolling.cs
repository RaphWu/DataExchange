﻿namespace CALIN.ToyoCylinder.SingleCylinder
{
    public interface IPolling
    {
        /// <summary>
        /// 當命令傳送失敗時，重試的次數。
        /// </summary>
        int RetryTimes { get; set; }
    }
}
