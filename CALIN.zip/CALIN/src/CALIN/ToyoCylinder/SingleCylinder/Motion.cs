﻿using CALIN.ToyoCylinder.Contants;
using System;
using System.Text;
using System.Threading.Tasks;

namespace CALIN.ToyoCylinder.SingleCylinder
{
    public partial class ToyoSingleCylinder : IMotion
    {
        private TimeSpan _timeJudgment; // 時間到位判定

        #region 運動到位判斷

        private bool InPosition(double position)
        {
            return _cylinderStatus.ActionStatus == 0
                    && _cylinderStatus.InpStatus == 1
                    && Math.Abs(_cylinderStatus.CmdNowPos - position) <= 0.01
                    && Math.Abs(_cylinderStatus.EcdPos - position) <= 0.01;
        }

        #endregion

        #region 運動參數

        /// <summary>
        /// 設定運動速度。
        /// </summary>
        /// <param name="speed">運動速度，0~100，為最高速度的比例設定值。</param>
        /// <returns>MotionResult 運動指令結果。</returns>
        public MotionResult SetSpeed(int speed)
        {
            try
            {
                if (speed < 0 || speed > 100)
                    throw new ArgumentOutOfRangeException("Speed 必須介於 0~100 之間。");

                SendRequestFrame(CallerId.Command, GetSingleAddressFrame(0x06, 0x2014, speed));
            }
            catch (ArgumentOutOfRangeException ae)
            {
                return new MotionResult
                {
                    ResultType = MotionResultType.ParameterError,
                    Exception = ae,
                };
            }
            return new MotionResult { ResultType = MotionResultType.Success };
        }

        /// <summary>
        /// 設定推壓 (CW)。
        /// </summary>
        /// <param name="push">推壓，0~1000，為扭力值的比例設定值 x 0.1%。</param>
        /// <returns>MotionResult 運動指令結果。</returns>
        public MotionResult SetPushCw(double push)
        {
            try
            {
                if (push < 0 || push > 1000)
                    throw new ArgumentOutOfRangeException("Push 必須介於 0~1000 之間。");

                SendRequestFrame(CallerId.Command, GetSingleAddressFrame(0x06, 0x0400, (int)(push * 10)));
            }
            catch (ArgumentOutOfRangeException ae)
            {
                return new MotionResult
                {
                    ResultType = MotionResultType.ParameterError,
                    Exception = ae,
                };
            }
            return new MotionResult { ResultType = MotionResultType.Success };
        }

        /// <summary>
        /// 設定推壓 (CCW)。
        /// </summary>
        /// <param name="push">推壓，0~1000，為扭力值的比例設定值 x 0.1%。</param>
        /// <returns>MotionResult 運動指令結果。</returns>
        public MotionResult SetPushCcw(double push)
        {
            try
            {
                if (push < 0 || push > 1000)
                    throw new ArgumentOutOfRangeException("Push 必須介於 0~1000 之間。");

                SendRequestFrame(CallerId.Command, GetSingleAddressFrame(0x06, 0x0401, (int)(push * 10)));
            }
            catch (ArgumentOutOfRangeException ae)
            {
                return new MotionResult
                {
                    ResultType = MotionResultType.ParameterError,
                    Exception = ae,
                };
            }
            return new MotionResult { ResultType = MotionResultType.Success };
        }

        /// <summary>
        /// 設定推壓 (CW, CCW)。
        /// </summary>
        /// <param name="pushCW">+ 方向推壓，0~1000，為扭力值的比例設定值 x 0.1%。</param>
        /// <param name="pushCCW">- 方向推壓，0~1000，為扭力值的比例設定值 x 0.1%。</param>
        /// <returns>MotionResult 運動指令結果。</returns>
        public MotionResult SetPush(double pushCW, double pushCCW)
        {
            var mr = SetPushCw(pushCW);
            if (mr.ResultType != MotionResultType.Success)
                return new MotionResult
                {
                    ResultType = MotionResultType.ParameterError,
                    Exception = mr.Exception,
                };

            mr = SetPushCcw(pushCCW);
            if (mr.ResultType != MotionResultType.Success)
                return new MotionResult
                {
                    ResultType = MotionResultType.ParameterError,
                    Exception = mr.Exception,
                };

            return mr;
        }

        /// <summary>
        /// 設定移動量。
        /// </summary>
        /// <param name="amount">移動量。目標位置，單位 mm。</param>
        public MotionResult SetAmount(double amount)
        {
            try
            {
                if (amount < _cp.MinPosition || amount > _cp.MaxPosition)
                    throw new ArgumentOutOfRangeException(String.Concat("移動量必須介於 ", _cp.MinPosition, "~", _cp.MaxPosition, " 之間。"));

                SendRequestFrame(CallerId.Command, GetMultipleAddressFrame(0x10, 0x2002, 2, 4, Encoding.ASCII.GetBytes(((int)(amount * 100)).ToString("X8"))));
            }
            catch (ArgumentOutOfRangeException ae)
            {
                return new MotionResult
                {
                    ResultType = MotionResultType.ParameterError,
                    Exception = ae,
                };
            }
            return new MotionResult { ResultType = MotionResultType.Success };
        }

        #endregion

        #region 運動命令

        /// <summary>
        /// 原點復歸。
        /// </summary>
        private void OriginReturn()
        {
            SendRequestFrame(CallerId.Command, GetSingleAddressFrame(0x06, 0x201E, 3));
        }

        /// <summary>
        /// 絕對位置運動。
        /// </summary>
        /// <param name="position">目標位置，單位 mm。</param>
        /// <param name="speed">運動速度，0~100，為最高速度的比例設定值。</param>
        /// <param name="pushCW">+ 方向的推壓，0~1000，為扭力值的比例設定值 x 0.1%。</param>
        /// <param name="HoldTime">保持時間，單位 ms。如果電動缸未到目標位置，但仍保持不動超過此時間時，視為已到目標位置。</param>
        /// <returns>MotionResult 運動指令結果。</returns>
        public async Task<MotionResult> AbsMove(double position, int speed, double pushCW, double pushCCW, uint HoldTime = 0)
        {
            try
            {
                if (speed < 0 || speed > 100)
                    throw new ArgumentOutOfRangeException("Speed 必須介於 0~100 之間。");
                if (pushCW < 0 || pushCW > 1000)
                    throw new ArgumentOutOfRangeException("Push 必須介於 0~1000 之間。");
                //if (position < _cp.MinPosition || position > _cp.MaxPosition)
                //    throw new ArgumentOutOfRangeException($"Position 必須介於 {_cp.MinPosition}~{_cp.MaxPosition} 之間。");

                // 速度
                string cmd = string.Concat(":01062014", speed.ToString("X4"));
                byte[] frame = GetSingleAddressFrame(0x06, 0x2014, speed);
                SendRequestFrame(CallerId.Command, cmd);

                // 推壓 CW
                cmd = string.Concat(":01060400", ((int)(pushCW * 10)).ToString("X4"));
                SendRequestFrame(CallerId.Command, cmd);

                // 推壓 CCW
                cmd = string.Concat(":01060401", ((int)(pushCW * 10)).ToString("X4"));
                SendRequestFrame(CallerId.Command, cmd);

                // 目標位置
                cmd = string.Concat(":01102002000204", ((int)(position * 100)).ToString("X8"));
                SendRequestFrame(CallerId.Command, cmd);

                // ABS Move
                SendRequestFrame(CallerId.Command, ":0106201E0001");

                // 到位檢測
                while (!InPosition(position))
                    await Task.Delay(50, _cts.Token);
                //await Task.CompletedTask;

                return MotionResultType.Success;
            }
            catch (ArgumentOutOfRangeException ex)
            {
                throw ex;
            }
        }

        #endregion

    }
}
