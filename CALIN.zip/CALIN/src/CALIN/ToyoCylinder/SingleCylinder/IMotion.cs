﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CALIN.ToyoCylinder.SingleCylinder
{
    public interface IMotion
    {
    }
}
