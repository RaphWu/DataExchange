﻿using CALIN.Data.Verify;
using CALIN.SerialPort;
using CALIN.ToyoCylinder.Contants;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CALIN.ToyoCylinder.SingleCylinder
{
    public partial class ToyoSingleCylinder : IToyoSingleCylinder
    {
        private CancellationTokenSource _cts;
        private readonly System.IO.Ports.SerialPort _sp;
        private readonly SerialPortParameters _spp;
        private readonly CylinderParams _cp;

        /// <summary>
        /// 指令 Queue 的最大容量。
        /// </summary>
        private const int MAX_QUEUE_CAPACITY = 100;

        /// <summary>
        /// 負責 SerialPort 存取的執行緒。
        /// </summary>
        private Thread _portAccessThread = null;

        /// <summary>
        /// 看門狗計時器。
        /// </summary>
        private System.Timers.Timer _watchDog;

        /// <summary>
        /// 看門狗計數器。
        /// </summary>
        private uint _watchDogCounter = 0;

        /// <summary>
        /// 狀態讀取計時器。
        /// </summary>
        private System.Timers.Timer _statusReadingTimer;

        /// <summary>
        /// 最高優先權指令 Queue。
        /// </summary>
        private Queue<FrameStruct> _highPriorityQueue = new Queue<FrameStruct>();

        /// <summary>
        /// 重試指令 Queue。
        /// </summary>
        private Queue<FrameStruct> _retryQueue = new Queue<FrameStruct>();

        /// <summary>
        /// 一般指令 Queue。
        /// </summary>
        private Queue<FrameStruct> _requestQueue = new Queue<FrameStruct>();

        private CylinderStatus _cylinderStatus = new CylinderStatus();
        private string _cylinderStatusMessage = string.Empty;
        private string _portOutMessage = string.Empty;
        private string _portInMessage = string.Empty;

        /// <summary>
        /// 請求發送暫停。
        /// </summary>
        /// <remarks>當有指令發送失敗須重送時，此 Flag 會 ON。此時 HighPriorityQueue 仍不會停，但 RequestQueue 會停止發送。</remarks>
        private bool _requestHolding = false;

        #region ctor

        public ToyoSingleCylinder(byte station,
                                  string portName,
                                  int baudRate,
                                  Parity parity,
                                  int dataBits,
                                  StopBits stopBits,
                                  double minPosition,
                                  double maxPosition,
                                  int retryTimes = 5)
        {
            _cp = new CylinderParams
            {
                MinPosition = minPosition,
                MaxPosition = maxPosition,
                RetryTimes = retryTimes,
            };

            _spp = new SerialPortParameters
            {
                Station = station,
            };

            _sp = new System.IO.Ports.SerialPort()
            {
                PortName = portName,
                BaudRate = baudRate,
                Parity = parity,
                DataBits = dataBits,
                StopBits = stopBits,
                ReadTimeout = 500,
                WriteTimeout = 500,
            };
        }

        #endregion

        #region 內部變數

        /// <inheritdoc/>
        public byte Station
        {
            get => _spp.Station;
            set => _spp.Station = value;
        }

        /// <inheritdoc/>
        public bool IsOpen => _sp != null && _sp.IsOpen;

        /// <inheritdoc/>
        public string PortName => _sp.PortName;

        /// <inheritdoc/>
        public int BaudRate
        {
            get => _sp.BaudRate;
            set => _sp.BaudRate = value;
        }

        /// <inheritdoc/>
        public Parity Parity
        {
            get => _sp.Parity;
            set => _sp.Parity = value;
        }

        /// <inheritdoc/>
        public int DataBits
        {
            get => _sp.DataBits;
            set => _sp.DataBits = value;
        }

        /// <inheritdoc/>
        public StopBits StopBits
        {
            get => _sp.StopBits;
            set => _sp.StopBits = value;
        }

        /// <inheritdoc/>
        public int ReadTimeout
        {
            get => _sp.ReadTimeout;
            set => _sp.ReadTimeout = value;
        }

        /// <inheritdoc/>
        public int WriteTimeout
        {
            get => _sp.WriteTimeout;
            set => _sp.WriteTimeout = value;
        }

        /// <inheritdoc/>
        public uint WatchDogCounter => _watchDogCounter;

        #endregion

        #region Open/Close

        /// <inheritdoc/>
        public void Close()
        {
            CylinderClose();
        }

        /// <summary>
        /// 電動缸關閉連接。
        /// </summary>
        private void CylinderClose()
        {
            if (_cts != null)
            {
                _cts.Cancel();
                _cts.Dispose();
            }

            _requestQueue.Clear();
            _retryQueue.Clear();
            _highPriorityQueue.Clear();

            _statusReadingTimer.Stop();
            _statusReadingTimer.Elapsed -= StatusReadingProc;
            _watchDog.Stop();
            _watchDog.Elapsed -= WatchDogProc;

            if (_portAccessThread != null)
            {
                _portAccessThread.Join(1000);
                _portAccessThread = null;
            }

            if (IsOpen)
                _sp.Close();
        }

        /// <inheritdoc/>
        public void Open()
        {
            CylinderOpen();
        }

        /// <summary>
        /// 電動缸開啟連接。
        /// </summary>
        private void CylinderOpen()
        {
            if (!IsOpen)
            {
                try
                {
                    if (_cts != null)
                        _cts.Dispose();
                    _cts = new CancellationTokenSource();

                    _sp.Open();
                    if (_sp.IsOpen)
                    {
                        if (_portAccessThread == null || _portAccessThread.ThreadState == ThreadState.Stopped)
                        {
                            _portAccessThread = new Thread(PortAccessPolling)
                            {
                                Name = "PortAccessPolling",
                                IsBackground = true
                            };
                            _portAccessThread.Start(_cts);
                        }

                        HighPriorityRequest(CallerId.Initializer,
                                            string.Concat(":", _spp.StationString, "10999B0004084C7630315479566702"),
                                            includeLRC: true); // 權限開通請求

                        _watchDog = new System.Timers.Timer()
                        {
                            Interval = 1000,
                            AutoReset = true,
                        };
                        _watchDog.Elapsed += WatchDogProc;
                        _watchDog.Start();

                        _statusReadingTimer = new System.Timers.Timer()
                        {
                            Interval = 233,
                            AutoReset = true,
                        };
                        _statusReadingTimer.Elapsed += StatusReadingProc;
                        _statusReadingTimer.Start();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(string.Concat("Failed to open serial port: ", ex.Message));
                }
            }
        }

        #endregion

    }
}
