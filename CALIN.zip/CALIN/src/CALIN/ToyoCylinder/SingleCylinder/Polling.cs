﻿using CALIN.ToyoCylinder.Contants;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CALIN.ToyoCylinder.SingleCylinder
{
    public partial class ToyoSingleCylinder : IPolling
    {
        /// <inheritdoc/>
        public int RetryTimes
        {
            get => _cp.RetryTimes;
            set
            {
                if (value > 0)
                    _cp.RetryTimes = value;
            }
        }

        #region 通訊處理

        /// <summary>
        /// Modbus 通訊輪詢。
        /// </summary>
        /// <param name="cancellation">CancellationTokenSource</param>
        private async void PortAccessPolling(object cancellation)
        {
            CancellationTokenSource cts = cancellation as CancellationTokenSource;
            CancellationToken token = cts.Token;

            int retryCounter = 0; // 重試次數計數器
            bool requestFinished = true; // 是否完成一個 Request 的傳送與接收
            FrameStruct nextRequest = new FrameStruct(); // 下一個要傳送的 Request

            string initResponse = string.Concat(":", _spp.StationString, "10999B0004B7\r");
            string watchDogResponse = string.Concat(":", _spp.StationString, "0302544363\r");

            try
            {
                while (true)
                {
                    if (token.IsCancellationRequested)
                        token.ThrowIfCancellationRequested();

                    if (requestFinished)
                    {
                        if (_highPriorityQueue.Count > 0 || _retryQueue.Count > 0 || _requestQueue.Count > 0)
                        {
                            nextRequest = _highPriorityQueue.Count > 0
                                ? _highPriorityQueue.Dequeue()
                                : _retryQueue.Count > 0
                                    ? _retryQueue.Dequeue()
                                    : _requestQueue.Dequeue();

                            await Task.Delay(10, token);
                            //Thread.Sleep(10);
                            //_sp.DiscardInBuffer();
                            _sp.DiscardOutBuffer();
                            _sp.Write(nextRequest.ByteArray, 0, nextRequest.Length);

                            requestFinished = false;
                        }
                    }

                    if (!requestFinished && _sp.BytesToRead > 0)
                    {
                        byte st = 0;
                        byte fCode = 0xFF;

                        //byte[] readBuffer = new byte[_bytesToRead];
                        string responseString = _sp.ReadLine();
                        int bytesToRead = _sp.BytesToRead;

                        bool validation = Core.ValidFrame(responseString);
                        if (validation)
                        {
                            //ShowConsoleMessage("Response訊息OK.");
                            st = Convert.ToByte(responseString.Substring(1, 2), 16);
                            fCode = Convert.ToByte(responseString.Substring(3, 2), 16);
                        }

                        if (validation && fCode < 0x80)
                        {
                            if (!_requestHolding)
                                retryCounter = 0;

                            switch (nextRequest.CallerId)
                            {
                                case CallerId.CylinderStatus:
                                    _cylinderStatusMessage = responseString;
                                    requestFinished = true;
                                    break;
                                case CallerId.PortOut:
                                    _portOutMessage = responseString;
                                    requestFinished = true;
                                    break;
                                case CallerId.PortIn:
                                    _portInMessage = responseString;
                                    requestFinished = true;
                                    break;
                                case CallerId.Command:
                                    requestFinished = true;
                                    break;
                                case CallerId.WatchDog:
                                    if (responseString == watchDogResponse)
                                    {
                                        requestFinished = true;
                                    }
                                    else
                                    {
                                        CylinderClose();
                                        throw new Exception("電動缸斷線！");
                                    }
                                    break;
                                case CallerId.Initializer:
                                    if (responseString == initResponse)
                                    {
                                        requestFinished = true;
                                    }
                                    else
                                    {
                                        CylinderClose();
                                        throw new Exception("權限開通異常！");
                                    }
                                    break;
                                default:
                                    throw new Exception(string.Concat("CallerId錯誤:\n", nextRequest.CallerId,
                                                                      "\nResponse Message: ", responseString));
                            }

                            _requestHolding = false;
                        }
                        else
                        {
                            string msg = string.Concat("CallerID: ", nextRequest.CallerId, ", Frame: ", Encoding.ASCII.GetString(nextRequest.ByteArray));
                            if (++retryCounter <= _cp.RetryTimes)
                            {
                                _requestHolding = true;
                                Thread.Sleep(300);
                                SendRetryFrame(nextRequest);
#if DEBUG
                                Console.WriteLine(string.Concat("重試第 ", retryCounter, " 次, ", msg));
#endif
                            }
                            else
                            {
                                retryCounter = 0;
                                _requestHolding = false;
#if DEBUG
                                Console.WriteLine(string.Concat("重試3次失敗，此指令已放棄！", msg));
#endif
                            }
                            requestFinished = true;
                        }
                    }

                    //if (_commStatus == CommStatus.ERROR)
                    //    throw new Exception(string.Concat("未知錯誤:\n", _lastCommStatus, " / ", _commStatus, "\nFunctionCode: ", fCode, "\nResponse Message: ", _responseString));

                }
            }
            catch (OperationCanceledException)
            {
                // do nothing for Cancellation
            }
            catch (TimeoutException te)
            {
#if DEBUG
                Console.WriteLine(te.Message);
#endif
                requestFinished = false;
            }
            catch (UnauthorizedAccessException)
            {
                CylinderClose();
                requestFinished = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Concat("接收輪詢的執行緒異常: ", ex.Message));
            }
        }

        #endregion

        #region Timer

        /// <summary>
        /// 看門狗計時器處理程序。
        /// </summary>
        private void WatchDogProc(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (IsOpen)
            {
                foreach (var rq in _highPriorityQueue)
                    if (rq.CallerId == CallerId.WatchDog)
                        return;
                HighPriorityRequest(CallerId.WatchDog, 01, 0x03, 0x10E0, 1);
                _watchDogCounter++;
            }

            //if (_watchDogCounter % 10 == 0)
            //    GC.Collect();
        }

        private int _sendingLoopId = 0;

        /// <summary>
        /// 電動缸狀態讀取處理程序。
        /// </summary>
        private void StatusReadingProc(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (IsOpen && !_requestHolding)
            {
                foreach (var rq in _requestQueue)
                    if (rq.CallerId == CallerId.CylinderStatus)
                        return;

                switch (_sendingLoopId)
                {
                    case 0:
                        SendRequestFrame(CallerId.CylinderStatus, _spp.Station, 0x03, 0x1000, 0x0D);
                        break;
                    case 1:
                        SendRequestFrame(CallerId.PortOut, _spp.Station, 0x03, 0x1020, 1);
                        break;
                    case 2:
                        SendRequestFrame(CallerId.PortIn, _spp.Station, 0x03, 0x1040, 1);
                        break;
                }

                if (++_sendingLoopId > 2)
                    _sendingLoopId = 0;
            }
        }

        #endregion

    }
}
