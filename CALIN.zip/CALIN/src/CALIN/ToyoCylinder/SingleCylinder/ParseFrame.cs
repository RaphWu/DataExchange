﻿using CALIN.Data.Verify;
using System;
using System.Text;

namespace CALIN.ToyoCylinder.SingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        private byte[] GetSingleAddressFrame(byte functionCode, int address, int dataOrLength)
        {
            byte[] st = _spp.StationBytes;
            byte[] funcCode = Encoding.ASCII.GetBytes(functionCode.ToString("X2"));
            byte[] addr = Encoding.ASCII.GetBytes(address.ToString("X4"));
            byte[] dl = Encoding.ASCII.GetBytes(dataOrLength.ToString("X4"));

            byte[] frame = new byte[17];
            frame[00] = 0x3A;
            frame[01] = st[0];
            frame[02] = st[1];
            frame[03] = funcCode[0];
            frame[04] = funcCode[1];
            frame[05] = addr[0];
            frame[06] = addr[1];
            frame[07] = addr[2];
            frame[08] = addr[3];
            frame[09] = dl[0];
            frame[10] = dl[1];
            frame[11] = dl[2];
            frame[12] = dl[3];

            byte[] lc = Encoding.ASCII.GetBytes(LRC.Lrc(frame, 13).ToString("X2"));
            frame[13] = lc[0];
            frame[14] = lc[1];
            frame[15] = 0x0D;
            frame[16] = 0x0A;

            return frame;
        }

        private byte[] GetMultipleAddressFrame(byte functionCode, int address, int quantity, int byteCount, byte[] data)
        {
            byte[] st = _spp.StationBytes;
            byte[] funcCode = Encoding.ASCII.GetBytes(functionCode.ToString("X2"));
            byte[] addr = Encoding.ASCII.GetBytes(address.ToString("X4"));
            byte[] qty = Encoding.ASCII.GetBytes(quantity.ToString("X4"));
            byte[] bc = Encoding.ASCII.GetBytes(byteCount.ToString("X2"));

            //byte[] dl = new byte[byteCount];
            //for (int i = 0; i < quantity; i++)
            //    dl[i * 2] = Convert.ToByte(data[i].ToString("X4"), 16);

            byte[] frame = new byte[15 + byteCount + 4];
            frame[00] = 0x3A;
            frame[01] = st[0];
            frame[02] = st[1];
            frame[03] = funcCode[0];
            frame[04] = funcCode[1];
            frame[05] = addr[0];
            frame[06] = addr[1];
            frame[07] = addr[2];
            frame[08] = addr[3];
            frame[09] = qty[0];
            frame[10] = qty[1];
            frame[11] = qty[2];
            frame[12] = qty[3];
            frame[13] = bc[0];
            frame[14] = bc[1];

            Buffer.BlockCopy(data, 0, frame, 15, byteCount);
            byte[] lc = Encoding.ASCII.GetBytes(LRC.Lrc(frame, 15 + byteCount).ToString("X2"));

            frame[15 + byteCount + 0] = lc[0];
            frame[15 + byteCount + 1] = lc[1];
            frame[15 + byteCount + 2] = 0x0D;
            frame[15 + byteCount + 3] = 0x0D;

            return frame;
        }

        private byte[] GetRequestFrame(string requestFrame)
        {
            byte[] frame = new byte[requestFrame.Length / 2];
            for (int i = 0; i < requestFrame.Length; i += 2)
            {
                frame[i / 2] = Convert.ToByte(requestFrame.Substring(i, 2), 16);
            }
            return frame;
        }
    }
}
