﻿using CALIN.Data.Verify;
using CALIN.ToyoCylinder.Contants;
using System;
using System.Collections.Generic;
using System.Text;

namespace CALIN.ToyoCylinder.SingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 發送指令幀至最高優先權 Queue。
        /// </summary>
        /// <param name="callerId">呼叫來源。</param>
        /// <param name="station">站號。</param>
        /// <param name="functionCode">功能碼。</param>
        /// <param name="address">資料位址。</param>
        /// <param name="length">資料長度。</param>
        private void HighPriorityRequest(CallerId callerId, byte station, byte functionCode, int address, int length)
        {
            if (_highPriorityQueue.Count < MAX_QUEUE_CAPACITY)
            {
                byte[] requestFrame = GetSingleAddressFrame(station, functionCode, address, length);
                _highPriorityQueue.Enqueue(new FrameStruct
                {
                    CallerId = callerId,
                    ByteArray = requestFrame,
                    Length = requestFrame.Length
                });
            }
        }

        /// <summary>
        /// 發送指令幀至最高優先權 Queue。
        /// </summary>
        /// <param name="callerId">呼叫來源。</param>
        /// <param name="requestFrame">完整指令幀字串。</param>
        /// <param name="includeLRC">指示 requestFrame 是否已包含 LRC。</param>
        /// <remarks>函數要求的的指令幀，LRC 可有可無，但預設是沒有的。</remarks>
        private void HighPriorityRequest(CallerId callerId, string requestFrame, bool includeLRC = false)
        {
            if (_highPriorityQueue.Count < MAX_QUEUE_CAPACITY)
            {
                string lrc = includeLRC ? string.Empty : LRC.LrcByAscii(requestFrame).ToString("X2");
                byte[] frame = Encoding.ASCII.GetBytes(string.Concat(requestFrame, lrc, "\r\n"));
                _highPriorityQueue.Enqueue(new FrameStruct
                {
                    CallerId = callerId,
                    ByteArray = frame,
                    Length = frame.Length
                });
            }
        }

        /// <summary>
        /// 重送指令幀至重試 Queue。
        /// </summary>
        /// <param name="requestFrame">要重送的指令幀。</param>
        private void SendRetryFrame(FrameStruct requestFrame)
        {
            if (_retryQueue.Count < MAX_QUEUE_CAPACITY)
                _retryQueue.Enqueue(requestFrame);
        }

        /// <summary>
        /// 發送 byte[] 型式的指令幀至一般指令 Queue。
        /// </summary>
        /// <param name="callerId">呼叫來源。</param>
        /// <param name="requestFrame">完整指令幀。</param>
        private void SendRequestFrame(CallerId callerId, byte[] requestFrame)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                _requestQueue.Enqueue(new FrameStruct
                {
                    CallerId = callerId,
                    ByteArray = requestFrame,
                    Length = requestFrame.Length
                });
            }
        }

        /// <summary>
        /// 依各參數發送指令幀至一般指令 Queue。
        /// </summary>
        /// <param name="callerId">呼叫來源。</param>
        /// <param name="station">站號。</param>
        /// <param name="functionCode">功能碼。</param>
        /// <param name="address">資料位址。</param>
        /// <param name="length">資料長度。</param>
        private void SendRequestFrame(CallerId callerId, byte station, byte functionCode, int address, int length)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                byte[] requestFrame = GetSingleAddressFrame(station, functionCode, address, length);
                _requestQueue.Enqueue(new FrameStruct
                {
                    CallerId = callerId,
                    ByteArray = requestFrame,
                    Length = requestFrame.Length
                });
            }
        }

        /// <summary>
        /// 發送字串型式的指令幀至一般指令 Queue。
        /// </summary>
        /// <param name="callerId">呼叫來源。</param>
        /// <param name="requestString">字串型式的指令幀。</param>
        /// <param name="includeLRC">指示 requestString 是否已包含 LRC。</param>
        /// <remarks>函數要求的的指令幀，LRC 可有可無，但預設是沒有的。</remarks>
        private void SendRequestFrame(CallerId callerId, string requestString, bool includeLRC = false)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                string lrc = includeLRC ? string.Empty : LRC.LrcByAscii(requestString).ToString("X2");
                byte[] requestFrame = Encoding.ASCII.GetBytes(string.Concat(requestString, lrc, "\r\n"));
                _requestQueue.Enqueue(new FrameStruct
                {
                    CallerId = callerId,
                    ByteArray = requestFrame,
                    Length = requestFrame.Length
                });
            }
        }
    }
}
