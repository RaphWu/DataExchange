﻿using System;

namespace CALIN.ToyoCylinder
{
    /// <summary>
    /// 運動指令結果。
    /// </summary>
    public class MotionResult
    {
        /// <summary>
        /// 運動指令結果的類型。
        /// </summary>
        public MotionResultType ResultType { get; set; }

        /// <summary>
        /// 附加異常狀態。
        /// </summary>
        public Exception Exception { get; set; } = null;
    }
}
