﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Views;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    public partial class MaintiFlowService : ITaskOrderAction
    {
        /// <inheritdoc/>
        public bool CreateNewFlow()
        {
            _createFlow.Title = "新建工單";
            if (_createFlow.ShowDialog() == DialogResult.OK)
            {
                _taskOrderView.Title = "工單已建立";
                _taskOrderView.NewWorkOrderNos = _createFlow.NewWorkOrderNos;
                _taskOrderView.Initialize();
                FormEx.ShowDialogWithMask(_taskOrderView);
                return true;
            }

            return false;
        }

        /// <inheritdoc/>
        public async Task<bool> CancelFlow()
        {
            var to = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.NewTaskOrder).ToList();
            if (to.Any())
            {
                _acceptFlow.Title = "取消工單";
                _acceptFlow.OkCaption = "取消工單";
                _acceptFlow.Orders = to;
                if (FormEx.ShowDialogWithMask(_acceptFlow) == DialogResult.OK)
                {
                    _context.taskOrders
                        .FirstOrDefault(t => t.Id == _acceptFlow.SelectedOrder)
                        .Status = OrderStatus.Completed;
                    _context.SaveChangesAsync();
                    await UpdateCache();
                }
                return true;
            }
            else
            {
                MessageBox.Show("無可取消的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> AcceptFlow()
        {
            var to = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.NewTaskOrder).ToList();
            if (to.Any())
            {
                _acceptFlow.Title = "接單";
                _acceptFlow.OkCaption = "接單";
                _acceptFlow.Orders = to;
                if (FormEx.ShowDialogWithMask(_acceptFlow) == DialogResult.OK)
                {
                    _context.taskOrders
                        .FirstOrDefault(t => t.Id == _acceptFlow.SelectedOrder)
                        .Status = OrderStatus.InProgress;
                    _context.SaveChangesAsync();
                    await UpdateCache();
                }
                return true;
            }
            else
            {
                MessageBox.Show("沒有新的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> MaintiWork()
        {
            var to = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.InProgress).ToList();
            if (to.Any())
            {

            }
            else
            {
                MessageBox.Show("沒有維護中的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            return false;
        }

        /// <inheritdoc/>
        public async Task<bool> FlowConfirmed()
        {
            var to = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.Pending).ToList();
            if (to.Any())
            {

            }
            else
            {
                MessageBox.Show("沒有待確認的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return false;
        }
    }
}
