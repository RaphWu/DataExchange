﻿using System;
using Autofac;
using Calin.TaskPulse.ToolQuest.Views;

namespace Calin.TaskPulse.ToolQuest
{
    public class ToolQuestMoudle : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            //SplashMessenger.Post("委託工單模組...");

            // Views (InstancePerLifetimeScope)
            builder.RegisterType<ToolQuestPage>().InstancePerLifetimeScope();
        }
    }
}
