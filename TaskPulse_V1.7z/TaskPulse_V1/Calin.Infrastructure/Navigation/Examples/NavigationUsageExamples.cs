#if DEBUG || OFFLINE

namespace Calin.Infrastructure.Navigation.Examples
{
    /// <summary>
    /// �ɯ�A�Ȩϥνd�ҡC
    /// </summary>
    /// <remarks>
    /// <para>�����O�ȥΩ�i�ܾɯ�A�Ȫ��ϥΤ覡�A�����b�Ͳ����Ҥ������ϥΡC</para>
    /// </remarks>
    public static class NavigationUsageExamples
    {
        #region Region ���U�d��

        /// <summary>
        /// �i�ܦp����U Region�C
        /// </summary>
        /// <example>
        /// <code>
        /// public class MainForm : Form
        /// {
        ///     private readonly IRegionManager _regionManager;
        ///     private readonly Panel _contentPanel;
        ///     
        ///     public MainForm(IRegionManager regionManager)
        ///     {
        ///         _regionManager = regionManager;
        ///         _contentPanel = new Panel { Dock = DockStyle.Fill };
        ///         Controls.Add(_contentPanel);
        ///         
        ///         // ���U Region�A�N Panel �@�� UI �e��
        ///         _regionManager.RegisterRegion(
        ///             "MainContent",
        ///             view =>
        ///             {
        ///                 // �Ұ� View �ɡG�M���¤��e�å[�J�s View
        ///                 _contentPanel.Controls.Clear();
        ///                 if (view is Control control)
        ///                 {
        ///                     control.Dock = DockStyle.Fill;
        ///                     _contentPanel.Controls.Add(control);
        ///                 }
        ///             },
        ///             view =>
        ///             {
        ///                 // ���� View �ɡG�q�e������
        ///                 if (view is Control control)
        ///                 {
        ///                     _contentPanel.Controls.Remove(control);
        ///                 }
        ///             });
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void RegisterRegionExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region �ɯ�d��

        /// <summary>
        /// �i�ܦp��i�歶���ɯ�C
        /// </summary>
        /// <example>
        /// <code>
        /// public class NavigationController
        /// {
        ///     private readonly INavigationService _navigationService;
        ///     
        ///     public NavigationController(INavigationService navigationService)
        ///     {
        ///         _navigationService = navigationService;
        ///     }
        ///     
        ///     public void NavigateToDetail(int itemId)
        ///     {
        ///         // �إ߾ɯ�Ѽ�
        ///         var parameters = new NavigationParameters();
        ///         parameters.Add("ItemId", itemId);
        ///         parameters.Add("Mode", "Edit");
        ///         
        ///         // �ɯ�� DetailView�A�����ѧO�X�� 1001
        ///         var result = _navigationService.NavigateTo&lt;DetailView&gt;(
        ///             "MainContent",  // Region �W��
        ///             1001,           // �����ѧO�X
        ///             parameters);    // �ɯ�Ѽ�
        ///         
        ///         if (!result.Success)
        ///         {
        ///             MessageBox.Show($"�ɯ襢��: {result.ErrorMessage}");
        ///         }
        ///     }
        ///     
        ///     public void GoBack()
        ///     {
        ///         if (_navigationService.CanGoBack("MainContent"))
        ///         {
        ///             _navigationService.GoBack("MainContent");
        ///         }
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void NavigationExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region INavigationAware ��@�d��

        /// <summary>
        /// �i�ܦp���@ INavigationAware �����C
        /// </summary>
        /// <example>
        /// <code>
        /// public class DetailView : UserControl, INavigationAware
        /// {
        ///     private readonly ILogger _logger;
        ///     private int _itemId;
        ///     private bool _hasUnsavedChanges;
        ///     
        ///     public DetailView(ILogger logger)
        ///     {
        ///         _logger = logger;
        ///     }
        ///     
        ///     public void OnNavigatedTo(INavigationParameters parameters)
        ///     {
        ///         // �ɯ�i�J�ɪ�l��
        ///         _itemId = parameters.GetValue&lt;int&gt;("ItemId");
        ///         var mode = parameters.GetValue&lt;string&gt;("Mode");
        ///         
        ///         _logger.Information("�i�J DetailView, ItemId: {ItemId}, Mode: {Mode}", _itemId, mode);
        ///         
        ///         // ���J���
        ///         LoadData(_itemId);
        ///     }
        ///     
        ///     public void OnNavigatedFrom(INavigationParameters parameters)
        ///     {
        ///         // �ɯ����}�ɫO�s���A�βM�z�귽
        ///         _logger.Information("���} DetailView");
        ///     }
        ///     
        ///     public bool OnNavigatingFrom(INavigationParameters parameters)
        ///     {
        ///         // �ˬd�O�_�����x�s���ܧ�
        ///         if (_hasUnsavedChanges)
        ///         {
        ///             var result = MessageBox.Show(
        ///                 "�����x�s���ܧ�A�T�w�n���}�ܡH",
        ///                 "�T�{",
        ///                 MessageBoxButtons.YesNo);
        ///             
        ///             return result == DialogResult.Yes;
        ///         }
        ///         
        ///         return true; // ���\�ɯ�
        ///     }
        ///     
        ///     private void LoadData(int itemId)
        ///     {
        ///         // ���J����޿�
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void NavigationAwareExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region ViewLifetime �ݩʽd��

        /// <summary>
        /// �i�ܦp��ϥ� ViewLifetime �ݩʱ��� View �ͩR�g���C
        /// </summary>
        /// <example>
        /// <code>
        /// // IsAlive = true: View �|�Q�֨��A�ɯ����}�ᤣ����
        /// [ViewLifetime(IsAlive = true)]
        /// public class DashboardView : UserControl, INavigationAware
        /// {
        ///     // �� View �u�|�إߤ@���A����ɯ�|���ΦP�@�ӹ��
        ///     // �A�X�Ω�D�n�����B�����O���ݭn�O�����A������
        ///     
        ///     public void OnNavigatedTo(INavigationParameters parameters)
        ///     {
        ///         // �C���ɯ�i�J�ɷ|�Q�I�s
        ///         // �i�Ω󭫷s��z���
        ///     }
        ///     
        ///     public void OnNavigatedFrom(INavigationParameters parameters) { }
        ///     public bool OnNavigatingFrom(INavigationParameters parameters) => true;
        /// }
        /// 
        /// // IsAlive = false (�w�]): View �|�b Region ����ɦ۰�����
        /// [ViewLifetime(IsAlive = false)]
        /// public class EditItemView : UserControl, INavigationAware
        /// {
        ///     // �� View �C���ɯ賣�|�إ߷s���
        ///     // �A�X�Ω�s�譶���B�Ȯɩʭ���
        ///     
        ///     public void OnNavigatedTo(INavigationParameters parameters) { }
        ///     public void OnNavigatedFrom(INavigationParameters parameters) { }
        ///     public bool OnNavigatingFrom(INavigationParameters parameters) => true;
        /// }
        /// </code>
        /// </example>
        public static void ViewLifetimeExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region �h Region �d��

        /// <summary>
        /// �i�ܦp��ϥΦh�� Region�C
        /// </summary>
        /// <example>
        /// <code>
        /// public class MultiRegionForm : Form
        /// {
        ///     private readonly IRegionManager _regionManager;
        ///     private readonly INavigationService _navigationService;
        ///     private readonly Panel _leftPanel;
        ///     private readonly Panel _rightPanel;
        ///     private readonly TabControl _tabControl;
        ///     
        ///     public MultiRegionForm(IRegionManager regionManager, INavigationService navigationService)
        ///     {
        ///         _regionManager = regionManager;
        ///         _navigationService = navigationService;
        ///         
        ///         InitializeComponents();
        ///         RegisterRegions();
        ///     }
        ///     
        ///     private void InitializeComponents()
        ///     {
        ///         // �إ� UI ����
        ///         _leftPanel = new Panel { Dock = DockStyle.Left, Width = 200 };
        ///         _rightPanel = new Panel { Dock = DockStyle.Fill };
        ///         _tabControl = new TabControl { Dock = DockStyle.Fill };
        ///         
        ///         Controls.Add(_rightPanel);
        ///         Controls.Add(_leftPanel);
        ///     }
        ///     
        ///     private void RegisterRegions()
        ///     {
        ///         // �����ɯ譱�O Region
        ///         _regionManager.RegisterRegion("NavigationPanel", view =>
        ///         {
        ///             _leftPanel.Controls.Clear();
        ///             if (view is Control c) { c.Dock = DockStyle.Fill; _leftPanel.Controls.Add(c); }
        ///         });
        ///         
        ///         // �k���D�n���e Region
        ///         _regionManager.RegisterRegion("MainContent", view =>
        ///         {
        ///             _rightPanel.Controls.Clear();
        ///             if (view is Control c) { c.Dock = DockStyle.Fill; _rightPanel.Controls.Add(c); }
        ///         });
        ///     }
        ///     
        ///     public void NavigateInMultipleRegions()
        ///     {
        ///         // �b���� Region ��ܿ��
        ///         _navigationService.NavigateTo&lt;MenuView&gt;("NavigationPanel", 100);
        ///         
        ///         // �b�k�� Region ��ܤ��e
        ///         _navigationService.NavigateTo&lt;ContentView&gt;("MainContent", 200);
        ///         
        ///         // �d�ߦU Region �����ʭ���
        ///         var allPageIds = _regionManager.GetAllActivePageIds();
        ///         // allPageIds = { "NavigationPanel": 100, "MainContent": 200 }
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void MultiRegionExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region Autofac ���U�d��

        /// <summary>
        /// �i�ܦp��b Autofac �����U View�C
        /// </summary>
        /// <example>
        /// <code>
        /// public class ViewModule : Module
        /// {
        ///     protected override void Load(ContainerBuilder builder)
        ///     {
        ///         // ���U View (InstancePerDependency)
        ///         // �C���ѪR���|�إ߷s���
        ///         builder.RegisterType&lt;DashboardView&gt;()
        ///             .AsSelf()
        ///             .InstancePerDependency();
        ///         
        ///         builder.RegisterType&lt;DetailView&gt;()
        ///             .AsSelf()
        ///             .InstancePerDependency();
        ///         
        ///         builder.RegisterType&lt;EditItemView&gt;()
        ///             .AsSelf()
        ///             .InstancePerDependency();
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void AutofacRegistrationExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion
    }
}

#endif