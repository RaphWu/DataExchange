using Autofac;
using Calin.Infrastructure.Coordination;
using Calin.Infrastructure.Dialogs;
using Calin.Infrastructure.Logging;
using Calin.Infrastructure.Navigation;

namespace Calin.Infrastructure
{
    public class CalinFrameworkModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterModule<LoggingModule>();
            builder.RegisterModule<NavigationModule>();
            builder.RegisterModule<DialogModule>();
            builder.RegisterModule<CoordinationModule>();
        }
    }
}
