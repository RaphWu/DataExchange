﻿namespace Calin.Infrastructure.Coordination
{
    /// <summary>
    /// 定義選擇性協調結果發布者的介面。
    /// 協調完成後，透過此介面發布結果。
    /// </summary>
    public interface ISelectiveResultPublisher
    {
        /// <summary>
        /// 取得目標名稱。
        /// </summary>
        string TargetName { get; }

        /// <summary>
        /// 非同步發布協調結果。
        /// </summary>
        /// <param name="taskKey">任務的唯一識別碼。</param>
        /// <param name="result">協調的結果。</param>
        /// <returns>代表非同步操作的 <see cref="Task"/>。</returns>
        Task PublishAsync(TaskKey taskKey, ICoordinationResult result);
    }
}
