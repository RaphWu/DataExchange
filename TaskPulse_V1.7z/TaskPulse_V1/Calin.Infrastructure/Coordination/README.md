﻿# Calin.Infrastructure.Coordination

## 簡介

`Calin.Infrastructure.Coordination` 提供一套通用的工作協調（coordination）基礎設施，目標是協助應用程式將複雜的任務調度、重試、併發與結果發布邏輯抽離出來。此模組為純粹基礎層（infrastructure），不包含任何業務特定邏輯，可作為各類桌面或服務應用的協調核心。

主要功能包括：

- 任務唯一識別（`TaskKey`）與去重保證
- 協調請求與會話追蹤（`ICoordinationRequest`、`ICoordinationSession`）
- 可插拔的任務處理器與解析器（`ITaskHandler`、`ITaskHandlerResolver`）
- 可配置的執行策略（順序、平行、延遲批次、重試、逾時等）
- 結果發布機制（`IResultPublisher`），支援延伸為事件或訊息匯出

## 架構與主要檔案

位於 `Calin.Infrastructure.Coordination` 命名空間的主要檔案/介面如下：

| 檔案 | 說明 |
|---|---|
| `ICoordinationRequest.cs` | 協調請求介面定義 |
| `TaskKey.cs` | 工作單元唯一識別（struct，支援隱式轉換） |
| `ICoordinationSession.cs` / `CoordinationSession.cs` | 會話介面與實作（包含狀態與診斷資訊） |
| `ITaskHandler.cs` / `TaskHandlerBase.cs` | 任務處理器介面與抽象基底 |
| `ITaskMappingStrategy.cs` / `TaskMappingStrategyBase.cs` | 請求至 TaskKey 映射策略 |
| `IExecutionPolicy.cs` / `ExecutionPolicyBase.cs` | 執行策略介面與抽象實作 |
| `ICoordinator.cs` / `Coordinator.cs` | 協調者介面與核心實作 |
| `ITaskHandlerResolver.cs` | Handler 解析器（支援 DI） |
| `IResultPublisher.cs` / `NullResultPublisher.cs` | 結果發布者介面與預設空實作 |
| `CoordinationModule.cs` | Autofac 模組，提供必要註冊 |
| `CoordinationContainerBuilderExtensions.cs` | Autofac 擴充方法 |

另外，`Calin.Infrastructure.Coordination.Policies` 包含數個內建執行策略：

- `SequentialExecutionPolicy`：順序執行
- `ParallelExecutionPolicy`：平行執行（支援最大平行度限制）
- `DeferredBatchExecutionPolicy`：延遲批次（收集後一次處理）
- `RetryExecutionPolicy`：重試策略（配置重試次數與間隔）
- `TimeoutExecutionPolicy`：逾時控制

範例程式放在 `Calin.Infrastructure.Coordination.Examples`，包括：
- `CoordinationUsageExamples.cs`：基本使用範例，示範容器註冊、Handler 實作與 Coordinator 使用流程
- `ExecutionPolicyExamples.cs`：執行策略使用範例，展示各種策略（順序、平行、重試、逾時）的使用方式
- `SelectivePublisherExamples.cs`：選擇性結果發布範例，展示如何根據 TaskKey 選擇不同的發布目標

## 架構圖表

### 組件關係圖

以下圖表展示 Coordination 模組中各核心組件之間的關係與依賴：

```mermaid
classDiagram
    class ICoordinator {
        <<interface>>
        +CoordinateAsync(request, cancellationToken) Task~ICoordinationResult~
    }
    
    class Coordinator {
        -ITaskMappingStrategy mappingStrategy
        -ITaskHandlerResolver handlerResolver
        -IExecutionPolicy executionPolicy
        -IResultPublisher resultPublisher
        +CoordinateAsync(request, cancellationToken) Task~ICoordinationResult~
    }
    
    class ICoordinationRequest {
        <<interface>>
        +RequestId string
        +RequestType string
    }
    
    class ITaskMappingStrategy {
        <<interface>>
        +CanHandle(request) bool
        +GetRequiredTasks(request) IEnumerable~TaskKey~
    }
    
    class TaskMappingStrategyBase~TRequest~ {
        <<abstract>>
        +CanHandle(request) bool
        #GetRequiredTasks(request)* IEnumerable~TaskKey~
    }
    
    class ITaskHandler {
        <<interface>>
        +TaskKey TaskKey
        +ExecuteAsync(context) Task
    }
    
    class TaskHandlerBase~TRequest~ {
        <<abstract>>
        +TaskKey TaskKey
        +ExecuteAsync(context) Task
        #ExecuteAsync(context, request)* Task
    }
    
    class ITaskHandlerResolver {
        <<interface>>
        +Resolve(taskKey) ITaskHandler
        +CanResolve(taskKey) bool
    }
    
    class IExecutionPolicy {
        <<interface>>
        +PolicyName string
        +ExecuteAsync(session, taskKeys, handlerResolver, cancellationToken) Task
    }
    
    class ExecutionPolicyBase {
        <<abstract>>
        +PolicyName string
        +ExecuteAsync(session, taskKeys, handlerResolver, cancellationToken) Task
        #ExecuteTasksAsync(session, taskKeys, handlerResolver, cancellationToken)* Task
    }
    
    class ICoordinationSession {
        <<interface>>
        +SessionId string
        +Request ICoordinationRequest
        +State CoordinationSessionState
        +RequiredTasks IReadOnlyCollection~TaskKey~
        +CompletedTasks IReadOnlyCollection~TaskKey~
        +PendingTasks IReadOnlyCollection~TaskKey~
        +FailedTasks IReadOnlyDictionary~TaskKey, Exception~
        +IsFinished bool
        +IsSuccessful bool
        +Duration TimeSpan?
    }
    
    class CoordinationSession {
        +SessionId string
        +Request ICoordinationRequest
        +State CoordinationSessionState
        +MarkTaskCompleted(taskKey)
        +MarkTaskFailed(taskKey, exception)
        +Start()
        +Complete()
    }
    
    class IResultPublisher {
        <<interface>>
        +PublishAsync(result) Task
    }
    
    class ICoordinationResult {
        <<interface>>
        +Session ICoordinationSession
        +IsSuccess bool
        +Errors IReadOnlyDictionary~TaskKey, Exception~
    }
    
    class TaskKey {
        <<struct>>
        +Value string
        +ToString() string
        +Equals(other) bool
    }
    
    class CoordinationModule {
        <<Autofac Module>>
        +Load(builder)
    }

    ICoordinator <|.. Coordinator : implements
    Coordinator --> ITaskMappingStrategy : uses
    Coordinator --> ITaskHandlerResolver : uses
    Coordinator --> IExecutionPolicy : uses
    Coordinator --> IResultPublisher : uses
    Coordinator --> ICoordinationSession : creates
    Coordinator --> ICoordinationResult : returns
    
    ITaskMappingStrategy <|.. TaskMappingStrategyBase : implements
    TaskMappingStrategyBase --> TaskKey : produces
    TaskMappingStrategyBase --> ICoordinationRequest : consumes
    
    ITaskHandler <|.. TaskHandlerBase : implements
    TaskHandlerBase --> TaskKey : identifies
    
    ITaskHandlerResolver --> ITaskHandler : resolves
    
    IExecutionPolicy <|.. ExecutionPolicyBase : implements
    ExecutionPolicyBase --> ITaskHandlerResolver : uses
    ExecutionPolicyBase --> ICoordinationSession : updates
    ExecutionPolicyBase --> ITaskHandler : executes
    
    ICoordinationSession <|.. CoordinationSession : implements
    CoordinationSession --> ICoordinationRequest : contains
    CoordinationSession --> TaskKey : tracks
    
    IResultPublisher --> ICoordinationResult : publishes
    ICoordinationResult --> ICoordinationSession : contains
    
    CoordinationModule --> ICoordinator : registers
    CoordinationModule --> ITaskHandlerResolver : registers
    CoordinationModule --> IExecutionPolicy : registers
    CoordinationModule --> IResultPublisher : registers
```

### 組件運作流程圖

以下圖表展示從提交請求到獲得結果的完整運作流程：

```mermaid
sequenceDiagram
    participant Client as 客戶端
    participant Coord as Coordinator
    participant Mapping as TaskMappingStrategy
    participant Session as CoordinationSession
    participant Policy as ExecutionPolicy
    participant Resolver as TaskHandlerResolver
    participant Handler as TaskHandler
    participant Publisher as ResultPublisher
    
    Client->>Coord: CoordinateAsync(request)
    activate Coord
    
    Note over Coord: 1. 映射階段
    Coord->>Mapping: GetRequiredTasks(request)
    activate Mapping
    Mapping-->>Coord: IEnumerable<TaskKey>
    deactivate Mapping
    
    Note over Coord: 2. 建立會話
    Coord->>Session: new CoordinationSession(request, taskKeys)
    activate Session
    Session-->>Coord: session
    Coord->>Session: Start()
    
    Note over Coord: 3. 執行階段
    Coord->>Policy: ExecuteAsync(session, taskKeys, handlerResolver)
    activate Policy
    
    loop 每個 TaskKey
        Policy->>Resolver: Resolve(taskKey)
        activate Resolver
        Resolver-->>Policy: handler
        deactivate Resolver
        
        Policy->>Handler: ExecuteAsync(context)
        activate Handler
        
        alt 執行成功
            Handler-->>Policy: completed
            Policy->>Session: MarkTaskCompleted(taskKey)
        else 執行失敗
            Handler-->>Policy: exception
            Policy->>Session: MarkTaskFailed(taskKey, exception)
        end
        deactivate Handler
    end
    
    Policy-->>Coord: execution completed
    deactivate Policy
    
    Note over Coord: 4. 完成會話
    Coord->>Session: Complete()
    Session-->>Coord: final session state
    deactivate Session
    
    Note over Coord: 5. 建立結果
    Coord->>Coord: CreateResult(session)
    
    Note over Coord: 6. 發布結果
    Coord->>Publisher: PublishAsync(result)
    activate Publisher
    Publisher-->>Coord: published
    deactivate Publisher
    
    Coord-->>Client: ICoordinationResult
    deactivate Coord
    
    Note over Client: 檢查 result.IsSuccess<br/>處理 result.Errors
```

### 執行策略流程

不同執行策略的任務執行方式：

```mermaid
graph LR
    subgraph Sequential[順序執行 SequentialExecutionPolicy]
        S1[Task 1] --> S2[Task 2]
        S2 --> S3[Task 3]
        S3 --> S4[Task 4]
    end
    
    subgraph Parallel[平行執行 ParallelExecutionPolicy]
        P1[Task 1]
        P2[Task 2]
        P3[Task 3]
        P4[Task 4]
    end
    
    subgraph Retry[重試執行 RetryExecutionPolicy]
        R1[Task 1]
        R1 -->|失敗| R1R[Retry 1]
        R1R -->|失敗| R1R2[Retry 2]
        R1R2 -->|成功| R2[Task 2]
    end
    
    subgraph Timeout[逾時控制 TimeoutExecutionPolicy]
        T1[Task 1] -->|監控時間| T1C{逾時?}
        T1C -->|否| T2[繼續執行]
        T1C -->|是| T3[取消任務]
    end
    
    subgraph Batch[延遲批次 DeferredBatchExecutionPolicy]
        B1[收集 Task 1-N]
        B1 --> B2[等待批次觸發]
        B2 --> B3[批次執行所有 Tasks]
    end
    
    style Sequential fill:#4A90E2,stroke:#2E5C8A,stroke-width:3px,color:#fff
    style Parallel fill:#F5A623,stroke:#C17D11,stroke-width:3px,color:#fff
    style Retry fill:#E94B3C,stroke:#B02E24,stroke-width:3px,color:#fff
    style Timeout fill:#9B59B6,stroke:#6C3483,stroke-width:3px,color:#fff
    style Batch fill:#27AE60,stroke:#1E8449,stroke-width:3px,color:#fff
```

### 應用程式開發者使用流程

以下圖表展示應用程式開發者如何整合和使用 Coordination 框架的完整流程：

```mermaid
flowchart TD
    Start([開始使用 Coordination 框架]) --> Step1[步驟 1: 定義請求類型]
    
    Step1 --> Step1Detail["定義 Request 類別<br/>繼承 CoordinationRequest<br/>例: SystemInitializationRequest"]
    
    Step1Detail --> Step2[步驟 2: 定義 TaskKey 常數]
    
    Step2 --> Step2Detail["建立靜態類別定義 TaskKey<br/>例: InitializationTaskKeys.LoadConfiguration<br/>例: InitializationTaskKeys.ConnectDatabase"]
    
    Step2Detail --> Step3[步驟 3: 實作 TaskHandler]
    
    Step3 --> Step3Detail["為每個 TaskKey 實作 Handler<br/>繼承 TaskHandlerBase&lt;TRequest&gt;<br/>覆寫 ExecuteAsync 方法<br/>例: LoadConfigurationHandler<br/>例: ConnectDatabaseHandler"]
    
    Step3Detail --> Step4[步驟 4: 實作 MappingStrategy]
    
    Step4 --> Step4Detail["繼承 TaskMappingStrategyBase&lt;TRequest&gt;<br/>實作 GetRequiredTasks 方法<br/>根據 Request 決定需要執行的 TaskKey<br/>例: SystemInitializationMappingStrategy"]
    
    Step4Detail --> Step5{是否需要自訂<br/>結果處理?}
    
    Step5 -->|是| Step5Yes["步驟 5a: 實作 ResultPublisher<br/>實作 IResultPublisher 介面<br/>處理成功/失敗結果<br/>例: LoggingResultPublisher"]
    
    Step5 -->|否| Step5No["步驟 5b: 使用預設<br/>NullResultPublisher"]
    
    Step5Yes --> Step6
    Step5No --> Step6
    
    Step6[步驟 6: 註冊到 Autofac 容器]
    
    Step6 --> Step6Detail["建立 Module 繼承 Autofac.Module<br/>註冊 CoordinationModule<br/>RegisterTaskHandler&lt;T&gt;()<br/>RegisterTaskMappingStrategy&lt;T&gt;()<br/>RegisterResultPublisher&lt;T&gt;()<br/>可選: 註冊自訂 ExecutionPolicy"]
    
    Step6Detail --> Step7[步驟 7: 建置容器並解析 ICoordinator]
    
    Step7 --> Step7Detail["var container = builder.Build()<br/>var coordinator = container.Resolve&lt;ICoordinator&gt;()"]
    
    Step7Detail --> Step8[步驟 8: 建立請求並執行協調]
    
    Step8 --> Step8Detail["var request = new MyRequest()<br/>var result = await coordinator.CoordinateAsync(request)"]
    
    Step8Detail --> Step9{檢查執行結果}
    
    Step9 -->|成功| Success["result.IsSuccess == true<br/>所有任務執行完成<br/>處理業務邏輯"]
    
    Step9 -->|失敗| Failure["result.IsSuccess == false<br/>檢查 result.Errors<br/>處理錯誤情況<br/>記錄失敗的 TaskKey 與 Exception"]
    
    Success --> End([完成])
    Failure --> End
    
    style Start fill:#27AE60,stroke:#1E8449,stroke-width:3px,color:#fff
    style End fill:#E74C3C,stroke:#C0392B,stroke-width:3px,color:#fff
    style Step1 fill:#3498DB,stroke:#2874A6,stroke-width:2px,color:#fff
    style Step2 fill:#3498DB,stroke:#2874A6,stroke-width:2px,color:#fff
    style Step3 fill:#3498DB,stroke:#2874A6,stroke-width:2px,color:#fff
    style Step4 fill:#3498DB,stroke:#2874A6,stroke-width:2px,color:#fff
    style Step5 fill:#F39C12,stroke:#CA6F1E,stroke-width:2px,color:#fff
    style Step6 fill:#9B59B6,stroke:#6C3483,stroke-width:2px,color:#fff
    style Step7 fill:#E67E22,stroke:#BA4A00,stroke-width:2px,color:#fff
    style Step8 fill:#E67E22,stroke:#BA4A00,stroke-width:2px,color:#fff
    style Step9 fill:#F39C12,stroke:#CA6F1E,stroke-width:2px,color:#fff
    style Success fill:#27AE60,stroke:#1E8449,stroke-width:3px,color:#fff
    style Failure fill:#E74C3C,stroke:#C0392B,stroke-width:3px,color:#fff
    style Step1Detail fill:#5DADE2,stroke:#2874A6,stroke-width:1px,color:#fff
    style Step2Detail fill:#5DADE2,stroke:#2874A6,stroke-width:1px,color:#fff
    style Step3Detail fill:#5DADE2,stroke:#2874A6,stroke-width:1px,color:#fff
    style Step4Detail fill:#5DADE2,stroke:#2874A6,stroke-width:1px,color:#fff
    style Step5Yes fill:#F8C471,stroke:#CA6F1E,stroke-width:1px,color:#333
    style Step5No fill:#F8C471,stroke:#CA6F1E,stroke-width:1px,color:#333
    style Step6Detail fill:#AF7AC5,stroke:#6C3483,stroke-width:1px,color:#fff
    style Step7Detail fill:#EB984E,stroke:#BA4A00,stroke-width:1px,color:#fff
    style Step8Detail fill:#EB984E,stroke:#BA4A00,stroke-width:1px,color:#fff
```

### 實際使用範例流程

以系統初始化為例，展示完整的實作流程：

```mermaid
sequenceDiagram
    autonumber
    participant Dev as 開發者
    participant Code as 程式碼
    participant Container as DI 容器
    participant Coord as Coordinator
    participant App as 應用程式

    Note over Dev,Code: 開發階段
    Dev->>Code: 定義 InitializationRequest
    Dev->>Code: 定義 TaskKeys（多個初始化任務）
    Dev->>Code: 實作 TaskHandler<TTask>
    Dev->>Code: 實作 TaskMappingStrategy
    Dev->>Code: （可選）實作 ResultPublisher
    Dev->>Code: 建立 CoordinationModule

    Note over Dev,Container: 註冊階段
    Dev->>Container: RegisterModule(CoordinationModule)
    Dev->>Container: RegisterTaskHandlers(...)
    Dev->>Container: RegisterMappingStrategy(...)
    Dev->>Container: RegisterResultPublisher(...)
    Container->>Container: Build Container

    Note over App,Coord: 執行階段
    App->>Container: Resolve ICoordinator
    Container-->>App: Coordinator 實例
    App->>App: 建立 InitializationRequest
    App->>Coord: CoordinateAsync(request)

    activate Coord
    Note over Coord: 框架自動處理<br/>• 映射 TaskKeys<br/>• 解析對應 TaskHandler<br/>• 執行與追蹤狀態<br/>• 彙整並發布結果
    Coord-->>App: CoordinationResult
    deactivate Coord

    App->>App: 檢查 result.IsSuccess

    alt 成功
        App->>App: 繼續應用程式流程
    else 失敗
        App->>App: 處理 result.Errors
    end

    Note over App: 應用程式持續運行
```

## 快速開始（使用說明）

1. 注入模組與註冊 Handler

    ```csharp
    var builder = new Autofac.ContainerBuilder();
    // 註冊 Coordination 基礎元件與預設實作
    builder.RegisterModule<CoordinationModule>();
    // 註冊自訂 TaskHandler
    builder.RegisterType<MyTaskHandler>().As<ITaskHandler<MyRequest>>();
    var container = builder.Build();
    ```

2. 透過 Coordinator 提交請求

    ```csharp
    using (var scope = container.BeginLifetimeScope())
    {
        var coordinator = scope.Resolve<ICoordinator>();

        var request = new MyCoordinationRequest(/* ... */);
        // 同步或非同步 API 依實作而定
        var result = coordinator.Execute(request);

        if (result.IsSuccess)
        {
            // 成功處理
        }
    }
    ```

3. 替換策略或進階設定

    ```csharp
    builder.RegisterType<CustomMappingStrategy>().As<ITaskMappingStrategy>();
    builder.RegisterType<CustomExecutionPolicy>().As<IExecutionPolicy>();
    ```

## 使用範例

以下為簡化示範，顯示如何定義 Request、實作 Handler 並提交：

```csharp
// 自訂 Request
public class MyCoordinationRequest : ICoordinationRequest
{
    public string Payload { get; set; }
}

// 實作 TaskHandler
public class MyTaskHandler : TaskHandlerBase<MyCoordinationRequest>
{
    public override void Handle(MyCoordinationRequest request, TaskExecutionContext context)
    {
        // 處理邏輯
    }
}

// 提交範例
var request = new MyCoordinationRequest { Payload = "data" };
var result = coordinator.Execute(request);
```

實際 API 名稱（例如 `Execute` 或 `ExecuteAsync`）請依專案中 `ICoordinator` 的定義為準。

## 進階主題

- 日誌與診斷：`ICoordinationSession` 提供詳盡追蹤資訊，可在 `IResultPublisher` 或自訂 LogHandler 中使用。
- 容錯與補償：搭配 `RetryExecutionPolicy` 與外部補償機制可實現健壯的錯誤恢復流程。
- 外部擴充：替換 `ITaskHandlerResolver` 可使 Handler 來源為外部服務或動態載入插件。
- 測試支援：可替換 `IResultPublisher` 為測試假件以收集並驗證執行結果。

## 設計特點

1. 完全泛型化 - 不含業務語意，便於重用
2. 符合 Open-Closed Principle - 透過介面擴充新行為
3. Autofac 整合 - 提供 Module 與擴充方法
4. 可插拔策略 - 映射、執行與發布策略可替換
5. 完整狀態追蹤 - `ICoordinationSession` 提供 Debug/Trace 所需資訊
6. 執行保證 - 同一 `TaskKey` 在同一會話中最多執行一次

## 注意事項

- 本模組為 infrastructure 層，應透過介面進行擴充，而非修改核心實作。
- 在高併發情境下，選擇合適的 `IExecutionPolicy` 與 `ITaskMappingStrategy` 以避免資源競爭。
- 目標平台為 .NET Framework 4.6.2；若移植至其他平臺，請確認 DI 與同步 API 相容性。

## 範例參考

### 基本使用範例
- `Calin.Infrastructure.Coordination.Examples.CoordinationUsageExamples`：常見情境示範
  - 系統初始化請求與任務定義
  - TaskHandler 實作範例
  - 映射策略實作
  - Autofac 容器註冊
  - 協調者使用與結果處理
  
### 錯誤處理

使用 `ICoordinationResult` 和 `ICoordinationSession` 可以輕鬆檢查成功與失敗的任務：

```csharp
foreach (var completed in result.Session.CompletedTasks)
{
    Console.WriteLine($"Task {completed} completed successfully.");
}

foreach (var failed in result.Session.FailedTasks)
{
    Console.WriteLine($"Task {failed.Key} failed: {failed.Value.Message}");
}
```

### 動態任務生成

根據條件動態生成 `TaskKey`：

```csharp
var taskKeys = new List<TaskKey>();
if (includeA) taskKeys.Add(SelectiveTaskKeys.TaskA);
if (includeB) taskKeys.Add(SelectiveTaskKeys.TaskB);
if (includeC) taskKeys.Add(SelectiveTaskKeys.TaskC);

var request = new SelectiveTaskRequest(taskKeys.ToArray());
```

### 執行策略範例
- `Calin.Infrastructure.Coordination.Examples.ExecutionPolicyExamples`：各種執行策略的使用範例
  - **順序執行策略 (SequentialExecutionPolicy)**：任務依次執行，適用於有依賴關係的任務
  - **平行執行策略 (ParallelExecutionPolicy)**：任務同時執行，適用於互相獨立的任務
  - **限制平行度策略**：控制最大並行任務數量，避免資源過度消耗
  - **重試執行策略 (RetryExecutionPolicy)**：任務失敗時自動重試
  - **逾時控制策略 (TimeoutExecutionPolicy)**：限制任務執行時間
  - 執行時間比較範例
  - **多策略使用範例**：
    - 使用命名註冊 (Named Registration) 註冊多個執行策略
    - 使用工廠模式 (Factory Pattern) 動態選擇執行策略
    - 使用策略選擇器 (ExecutionPolicySelector) 智能選擇策略
    - 根據請求特性（資料量、優先級）自動選擇最佳策略

```csharp
var policySelector = scope.Resolve<ExecutionPolicySelector>();
var coordinator = policySelector.CreateCoordinator("Sequential");
var result = await coordinator.CoordinateAsync(request);
```

### 選擇性結果發布範例

`SelectiveResultPublisher` 和 `SelectiveResultPublisherWithTracking` 支援根據 `TaskKey` 選擇不同的發布目標。

- `Calin.Infrastructure.Coordination.Examples.SelectivePublisherExamples`：
  - 多個 TaskKey (TaskA, TaskB, TaskC) 與對應的 Handler
  - 多個發布目標 (PublisherA, PublisherB, PublisherC)
  - 選擇性結果發布者實作（根據執行的 TaskKey 選擇對應的發布目標）
  - 帶追蹤功能的發布者實作
  - 動態選擇執行任務的範例
  - 部分失敗情況的處理範例
  
```csharp
var publisher = new SelectiveResultPublisher(publisherA, publisherB, publisherC);
await publisher.PublishAsync(result);
```

---

# 多執行策略使用指南

本指南說明如何在 Autofac 容器中註冊多個執行策略，並根據需求動態選擇使用不同的策略。

## 重要提示：CoordinationModule 的預設註冊

`CoordinationModule` 預設會註冊一個執行策略：
- 預設為 `SequentialExecutionPolicy`（順序執行）
- 可透過 `CoordinationModuleOptions` 設定為 `ParallelExecutionPolicy`（平行執行）
- 使用 `.IfNotRegistered(typeof(IExecutionPolicy))` - **如果容器中已註冊 `IExecutionPolicy`，則不會覆蓋**

### 預設註冊範例

```csharp
// 預設註冊順序執行策略
builder.RegisterModule<CoordinationModule>();

// 自訂預設策略為平行執行
builder.RegisterModule(new CoordinationModule(new CoordinationModuleOptions
{
    DefaultExecutionPolicy = DefaultExecutionPolicy.Parallel
}));
```

### 覆蓋預設策略

由於 `CoordinationModule` 使用 `IfNotRegistered`，您可以透過以下方式覆蓋預設策略：

```csharp
// 方法 1：在註冊 CoordinationModule 之前註冊策略
builder.RegisterType<ParallelExecutionPolicy>()
       .As<IExecutionPolicy>()
       .SingleInstance();
builder.RegisterModule<CoordinationModule>();

// 方法 2：在註冊 CoordinationModule 之後，使用 PreserveExistingDefaults() 註冊策略
builder.RegisterModule<CoordinationModule>();
builder.RegisterType<RetryExecutionPolicy>()
       .As<IExecutionPolicy>()
       .PreserveExistingDefaults(); // 不會覆蓋已註冊的預設策略
```

## 概述

在 `Calin.Infrastructure.Coordination` 中，每個 `Coordinator` 實例在建立時會綁定一個執行策略。當需要在同一個應用程式中使用多種執行策略時，有以下三種方法：

1. **命名註冊 (Named Registration)** - 適合需要在同一容器中註冊多個策略的場景
2. **工廠模式 (Factory Pattern)** - 適合需要動態選擇策略的場景
3. **策略選擇器 (Policy Selector)** - 適合需要智能策略選擇的場景

## 方法 1：使用命名註冊

### 優點
- 簡單直觀
- Autofac 原生支援
- 適合策略種類固定的場景
- **可與預設策略共存**

### 實作範例

```csharp
// 註冊 CoordinationModule（會註冊預設的 Sequential 策略作為 IExecutionPolicy）
builder.RegisterModule<CoordinationModule>();

// 註冊多個執行策略，使用命名註冊（不會與預設策略衝突）
builder.RegisterType<SequentialExecutionPolicy>()
       .Named<IExecutionPolicy>("Sequential")
       .SingleInstance();

builder.RegisterType<ParallelExecutionPolicy>()
       .Named<IExecutionPolicy>("Parallel")
       .WithParameter("maxDegreeOfParallelism", 0)
       .SingleInstance();

builder.RegisterType<RetryExecutionPolicy>()
       .Named<IExecutionPolicy>("Retry")
       .WithParameter("maxRetries", 3)
       .WithParameter("retryDelay", TimeSpan.FromMilliseconds(500))
       .SingleInstance();

// 使用時根據名稱解析特定策略
var sequentialPolicy = scope.ResolveNamed<IExecutionPolicy>("Sequential");
var coordinator = new Coordinator(mappingStrategies, handlerResolver, sequentialPolicy, resultPublisher);

// 或使用預設策略（透過 Resolve<ICoordinator> 時會自動使用預設的 IExecutionPolicy）
var defaultCoordinator = scope.Resolve<ICoordinator>(); // 使用預設的 Sequential 策略
```

### 完整範例
參見 `ExecutionPolicyExamples.UseMultiplePoliciesWithNamedRegistrationAsync()`

## 方法 2：使用工廠模式

### 優點
- 更符合 DI 原則
- 可以透過介面注入
- 便於單元測試

### 實作範例

```csharp
// 註冊策略使用 Keyed
builder.RegisterType<SequentialExecutionPolicy>()
       .Keyed<IExecutionPolicy>("Sequential")
       .SingleInstance();

builder.RegisterType<ParallelExecutionPolicy>()
       .Keyed<IExecutionPolicy>("Parallel")
       .WithParameter("maxDegreeOfParallelism", 0)
       .SingleInstance();

// 註冊工廠函式
builder.Register<Func<string, IExecutionPolicy>>(c =>
{
    var context = c.Resolve<IComponentContext>();
    return policyName => context.ResolveKeyed<IExecutionPolicy>(policyName);
});

// 使用工廠來獲取策略
var policyFactory = scope.Resolve<Func<string, IExecutionPolicy>>();
var policy = policyFactory("Sequential");
var coordinator = new Coordinator(mappingStrategies, handlerResolver, policy, resultPublisher);
```

### 完整範例
參見 `ExecutionPolicyExamples.UseMultiplePoliciesWithFactoryAsync()`

## 方法 3：使用策略選擇器

### 優點
- 最高的靈活性
- 封裝策略選擇邏輯
- 支援智能策略選擇
- 可擴展性最強
- **可以同時管理預設策略和命名策略**

### 實作步驟

#### 步驟 1：創建策略選擇器類別

```csharp
public class ExecutionPolicySelector
{
    private readonly IComponentContext _context;

    public ExecutionPolicySelector(IComponentContext context)
    {
        _context = context;
    }

    public IExecutionPolicy GetPolicy(string policyName)
    {
        return _context.ResolveNamed<IExecutionPolicy>(policyName);
    }

    public ICoordinator CreateCoordinator(string policyName)
    {
        var policy = GetPolicy(policyName);
        var mappingStrategies = _context.Resolve<IEnumerable<ITaskMappingStrategy>>();
        var handlerResolver = _context.Resolve<ITaskHandlerResolver>();
        var resultPublisher = _context.Resolve<IResultPublisher>();

        return new Coordinator(mappingStrategies, handlerResolver, policy, resultPublisher);
    }
}
```

#### 步驟 2：註冊策略選擇器

```csharp
public class MultiPolicyModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        // 註冊所有執行策略
        builder.RegisterType<SequentialExecutionPolicy>()
               .Named<IExecutionPolicy>("Sequential")
               .SingleInstance();

        builder.RegisterType<ParallelExecutionPolicy>()
               .Named<IExecutionPolicy>("Parallel")
               .WithParameter("maxDegreeOfParallelism", 0)
               .SingleInstance();

        // ... 註冊其他策略

        // 註冊策略選擇器
        builder.RegisterType<ExecutionPolicySelector>()
               .AsSelf()
               .SingleInstance();
    }
}
```

#### 步驟 3：使用策略選擇器

```csharp
var policySelector = scope.Resolve<ExecutionPolicySelector>();
var coordinator = policySelector.CreateCoordinator("Sequential");
var result = await coordinator.CoordinateAsync(request);
```

### 完整範例
參見 `MultiPolicyUsageExamples.UseExecutionPolicySelectorAsync()`

## 智能策略選擇

策略選擇器可以實現智能策略選擇，根據請求特性自動選擇最適合的執行策略。

### 範例：根據資料量和優先級選擇策略

```csharp
public static string SelectPolicyBasedOnRequest(DataProcessingRequest request)
{
    // 大量資料 + 高優先級 -> 平行執行
    if (request.DataCount > 500 && request.HighPriority)
    {
        return "Parallel";
    }
    // 中等資料量 -> 限制平行度
    else if (request.DataCount > 100)
    {
        return "ParallelThrottled";
    }
    // 高優先級 -> 使用重試策略
    else if (request.HighPriority)
    {
        return "Retry";
    }
    // 其他情況 -> 順序執行
    else
    {
        return "Sequential";
    }
}

// 使用
var policyName = SelectPolicyBasedOnRequest(request);
var coordinator = policySelector.CreateCoordinator(policyName);
var result = await coordinator.CoordinateAsync(request);
```

### 完整範例
參見 `MultiPolicyUsageExamples.UseSmartPolicySelectionAsync()`

## 可用的執行策略

| 策略名稱 | 建議用途 | 參數 |
|---------|---------|------|
| `Sequential` | 有依賴關係的任務（CoordinationModule 預設） | 無 |
| `Parallel` | 互相獨立的任務，無限制 | `maxDegreeOfParallelism = 0` |
| `ParallelThrottled` | 互相獨立的任務，限制併發數 | `maxDegreeOfParallelism = 3` (可調整) |
| `Retry` | 需要容錯的操作 | `maxRetries = 3`, `retryDelay = 500ms` |
| `Timeout` | 需要時間限制的操作 | `timeout = 5s` |

## 最佳實踐

1. **理解預設註冊** - `CoordinationModule` 會註冊預設策略，使用 `IfNotRegistered` 避免覆蓋
2. **使用命名註冊管理多策略** - 將不同的策略註冊為命名服務，不會與預設策略衝突
3. **策略選擇器作為推薦方式** - 提供最大的靈活性，可同時管理預設和命名策略
4. **智能策略選擇** - 根據請求特性自動選擇最適合的策略
5. **命名規範** - 使用清晰的策略名稱，例如：`"Sequential"`, `"Parallel"`, `"Retry"`
6. **參數調整** - 根據實際環境調整策略參數（如重試次數、平行度等）
7. **監控和日誌** - 記錄使用的策略和執行時間，用於效能優化

## 常見場景與解決方案

### 場景 1：使用預設策略 + 特定場景使用其他策略

```csharp
// 註冊 CoordinationModule（預設 Sequential）
builder.RegisterModule<CoordinationModule>();

// 註冊額外的命名策略
builder.RegisterType<ParallelExecutionPolicy>()
       .Named<IExecutionPolicy>("Parallel")
       .WithParameter("maxDegreeOfParallelism", 0)
       .SingleInstance();

// 大部分情況使用預設 Coordinator（Sequential）
var defaultCoordinator = scope.Resolve<ICoordinator>();
var result1 = await defaultCoordinator.CoordinateAsync(normalRequest);

// 特定情況手動創建使用 Parallel 策略的 Coordinator
var parallelPolicy = scope.ResolveNamed<IExecutionPolicy>("Parallel");
var mappingStrategies = scope.Resolve<IEnumerable<ITaskMappingStrategy>>();
var handlerResolver = scope.Resolve<ITaskHandlerResolver>();
var resultPublisher = scope.Resolve<IResultPublisher>();
var parallelCoordinator = new Coordinator(mappingStrategies, handlerResolver, parallelPolicy, resultPublisher);
var result2 = await parallelCoordinator.CoordinateAsync(heavyRequest);
```

### 場景 2：替換預設策略為 Parallel

```csharp
// 使用 CoordinationModuleOptions 指定預設策略
builder.RegisterModule(new CoordinationModule(new CoordinationModuleOptions
{
    DefaultExecutionPolicy = DefaultExecutionPolicy.Parallel
}));

// 現在 Resolve<ICoordinator> 會使用 Parallel 策略
var coordinator = scope.Resolve<ICoordinator>(); // 使用 Parallel 策略
```

### 場景 3：完全自訂策略，不使用預設註冊

```csharp
// 先註冊自訂策略
builder.RegisterType<RetryExecutionPolicy>()
       .As<IExecutionPolicy>()
       .WithParameter("maxRetries", 5)
       .SingleInstance();

// 再註冊 CoordinationModule（由於已有 IExecutionPolicy，預設不會註冊）
builder.RegisterModule<CoordinationModule>();

// Resolve<ICoordinator> 會使用我們註冊的 Retry 策略
var coordinator = scope.Resolve<ICoordinator>(); // 使用 Retry 策略
```

## 範例程式碼位置

- `ExecutionPolicyExamples.cs` - 包含所有範例的完整實作
  - `UseMultiplePoliciesWithNamedRegistrationAsync()` - 命名註冊範例
  - `UseMultiplePoliciesWithFactoryAsync()` - 工廠模式範例
  - `MultiPolicyUsageExamples.UseExecutionPolicySelectorAsync()` - 策略選擇器範例
  - `MultiPolicyUsageExamples.UseSmartPolicySelectionAsync()` - 智能策略選擇範例

## 總結

根據應用程式的需求選擇適合的方法：

- **簡單場景**：使用 `CoordinationModule` 的預設策略（Sequential 或 Parallel）
- **需要多策略但有主要策略**：保留預設策略 + 使用命名註冊添加其他策略
- **中等複雜度**：使用工廠模式 (方法 2) 動態選擇策略
- **複雜場景**：使用策略選擇器 (方法 3)，支援智能策略選擇

### 關鍵要點

1. **CoordinationModule 預設註冊策略** - 理解 `IfNotRegistered` 的行為
2. **命名註冊不會衝突** - 可以同時有預設策略和多個命名策略
3. **策略選擇器是最靈活的** - 可以管理所有策略（包括預設策略）
4. **根據需求覆蓋預設** - 可以在註冊 `CoordinationModule` 前註冊自己的策略

策略選擇器是最推薦的方式，因為它提供了最大的靈活性和可擴展性，同時可以與 `CoordinationModule` 的預設註冊和諧共存。
