#if DEBUG || OFFLINE

namespace Calin.Infrastructure.Dialogs.Examples
{
    /// <summary>
    /// ��ܮتA�Ȩϥνd�ҡC
    /// </summary>
    /// <remarks>
    /// <para>�����O�ȥΩ�i�ܹ�ܮتA�Ȫ��ϥΤ覡�A�����b�Ͳ����Ҥ������ϥΡC</para>
    /// </remarks>
    public static class DialogUsageExamples
    {
        #region �ҺA��ܮؽd��

        /// <summary>
        /// �i�ܦp����ܼҺA��ܮءC
        /// </summary>
        /// <example>
        /// <code>
        /// public class OrderController
        /// {
        ///     private readonly IDialogService _dialogService;
        ///     
        ///     public OrderController(IDialogService dialogService)
        ///     {
        ///         _dialogService = dialogService;
        ///     }
        ///     
        ///     public void DeleteOrder(int orderId)
        ///     {
        ///         // �إ߰Ѽ�
        ///         var parameters = new DialogParameters();
        ///         parameters.Add("Title", "�T�{�R��");
        ///         parameters.Add("Message", $"�T�w�n�R���q�� #{orderId} �ܡH");
        ///         parameters.Add("OrderId", orderId);
        ///         
        ///         // ��ܼҺA��ܮ�
        ///         var result = _dialogService.ShowDialog&lt;ConfirmDeleteDialog&gt;(parameters);
        ///         
        ///         if (result.Result == ButtonResult.OK)
        ///         {
        ///             // �ϥΪ��I���T�{�A����R��
        ///             ExecuteDelete(orderId);
        ///         }
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void ShowModalDialogExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region �D�ҺA��ܮؽd��

        /// <summary>
        /// �i�ܦp����ܫD�ҺA��ܮءC
        /// </summary>
        /// <example>
        /// <code>
        /// public class DataController
        /// {
        ///     private readonly IDialogService _dialogService;
        ///     
        ///     public DataController(IDialogService dialogService)
        ///     {
        ///         _dialogService = dialogService;
        ///     }
        ///     
        ///     public void StartLongOperation()
        ///     {
        ///         // �إ߰Ѽ�
        ///         var parameters = new DialogParameters();
        ///         parameters.Add("Title", "�B�z��");
        ///         parameters.Add("Message", "���b�B�z��ơA�еy��...");
        ///         
        ///         // ��ܫD�ҺA��ܮء]�i�׹�ܮء^
        ///         _dialogService.ShowModeless&lt;ProgressDialog&gt;(parameters, result =>
        ///         {
        ///             // ��ܮ������ɪ��^�I
        ///             if (result.Result == ButtonResult.Cancel)
        ///             {
        ///                 // �ϥΪ̨����ާ@
        ///                 CancelOperation();
        ///             }
        ///         });
        ///         
        ///         // �}�l�D�P�B�ާ@
        ///         StartAsyncOperation();
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void ShowModelessDialogExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region �۩w�q��ܮع�@�d��

        /// <summary>
        /// �i�ܦp���@�۩w�q��ܮءC
        /// </summary>
        /// <example>
        /// <code>
        /// public class InputDialog : DialogBase
        /// {
        ///     private Label lblMessage;
        ///     private TextBox txtInput;
        ///     private Button btnOK;
        ///     private Button btnCancel;
        ///     
        ///     public InputDialog()
        ///     {
        ///         Title = "��J";
        ///         InitializeComponents();
        ///     }
        ///     
        ///     private void InitializeComponents()
        ///     {
        ///         Size = new Size(300, 150);
        ///         
        ///         lblMessage = new Label
        ///         {
        ///             Location = new Point(10, 10),
        ///             Size = new Size(280, 20),
        ///             Text = "�п�J���e�G"
        ///         };
        ///         
        ///         txtInput = new TextBox
        ///         {
        ///             Location = new Point(10, 35),
        ///             Size = new Size(280, 25)
        ///         };
        ///         
        ///         btnOK = new Button
        ///         {
        ///             Location = new Point(120, 70),
        ///             Size = new Size(80, 30),
        ///             Text = "�T�w"
        ///         };
        ///         btnOK.Click += BtnOK_Click;
        ///         
        ///         btnCancel = new Button
        ///         {
        ///             Location = new Point(210, 70),
        ///             Size = new Size(80, 30),
        ///             Text = "����"
        ///         };
        ///         btnCancel.Click += BtnCancel_Click;
        ///         
        ///         Controls.AddRange(new Control[] { lblMessage, txtInput, btnOK, btnCancel });
        ///     }
        ///     
        ///     protected override void OnDialogOpenedCore(IDialogParameters parameters)
        ///     {
        ///         // �q�Ѽƨ��o�w�]��
        ///         if (parameters.TryGetValue&lt;string&gt;("Message", out var message))
        ///         {
        ///             lblMessage.Text = message;
        ///         }
        ///         
        ///         if (parameters.TryGetValue&lt;string&gt;("DefaultValue", out var defaultValue))
        ///         {
        ///             txtInput.Text = defaultValue;
        ///         }
        ///         
        ///         if (parameters.TryGetValue&lt;string&gt;("Title", out var title))
        ///         {
        ///             Title = title;
        ///         }
        ///     }
        ///     
        ///     public override bool CanCloseDialog()
        ///     {
        ///         // �i�[�J�����޿�
        ///         return true;
        ///     }
        ///     
        ///     private void BtnOK_Click(object sender, EventArgs e)
        ///     {
        ///         // �إߪ�^�Ѽ�
        ///         var resultParams = new DialogParameters();
        ///         resultParams.Add("InputValue", txtInput.Text);
        ///         
        ///         // ������ܮ�
        ///         CloseDialog(ButtonResult.OK, resultParams);
        ///     }
        ///     
        ///     private void BtnCancel_Click(object sender, EventArgs e)
        ///     {
        ///         CloseDialog(ButtonResult.Cancel);
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void CustomDialogExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region �Ѽƶǻ��P��^���G�d��

        /// <summary>
        /// �i�ܧ��㪺�Ѽƶǻ��P��^���G�y�{�C
        /// </summary>
        /// <example>
        /// <code>
        /// public class ProductController
        /// {
        ///     private readonly IDialogService _dialogService;
        ///     private readonly ILogger _logger;
        ///     
        ///     public ProductController(IDialogService dialogService, ILogger logger)
        ///     {
        ///         _dialogService = dialogService;
        ///         _logger = logger;
        ///     }
        ///     
        ///     public void EditProduct(Product product)
        ///     {
        ///         // 1. �إ߶ǤJ�Ѽ�
        ///         var parameters = new DialogParameters();
        ///         parameters.Add("Product", product);
        ///         parameters.Add("Mode", "Edit");
        ///         parameters.Add("Categories", GetCategories());
        ///         
        ///         _logger.Information("�}�Ҳ��~�s���ܮ�: {ProductId}", product.Id);
        ///         
        ///         // 2. ��ܹ�ܮ�
        ///         var result = _dialogService.ShowDialog&lt;ProductEditDialog&gt;(parameters);
        ///         
        ///         // 3. �B�z��^���G
        ///         if (result.Result == ButtonResult.OK)
        ///         {
        ///             // ���o�s��᪺���~
        ///             var editedProduct = result.Parameters.GetValue&lt;Product&gt;("EditedProduct");
        ///             
        ///             // �x�s�ܧ�
        ///             SaveProduct(editedProduct);
        ///             
        ///             _logger.Information("���~�w��s: {ProductId}", editedProduct.Id);
        ///         }
        ///         else
        ///         {
        ///             _logger.Information("�ϥΪ̨����s��");
        ///         }
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void ParameterPassingExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region �T����ܮؽd��

        /// <summary>
        /// �i�ܦp��ϥΤ��ذT����ܮءC
        /// </summary>
        /// <example>
        /// <code>
        /// public class NotificationController
        /// {
        ///     private readonly IDialogService _dialogService;
        ///     
        ///     public NotificationController(IDialogService dialogService)
        ///     {
        ///         _dialogService = dialogService;
        ///     }
        ///     
        ///     public void ShowInfo()
        ///     {
        ///         // ��ܸ�T�T��
        ///         _dialogService.ShowMessage("�ާ@�w�����C", "��T");
        ///     }
        ///     
        ///     public void ShowError(string errorMessage)
        ///     {
        ///         // ��ܿ��~�T��
        ///         _dialogService.ShowMessage(errorMessage, "���~", MessageDialogButtons.OK);
        ///     }
        ///     
        ///     public bool ConfirmAction(string message)
        ///     {
        ///         // ��ܽT�{��ܮ�
        ///         return _dialogService.ShowConfirm(message, "�T�{");
        ///     }
        ///     
        ///     public ButtonResult AskUser(string question)
        ///     {
        ///         // ��ܿ�ܹ�ܮ�
        ///         return _dialogService.ShowMessage(
        ///             question,
        ///             "�п��",
        ///             MessageDialogButtons.YesNoCancel);
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void MessageDialogExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region Autofac ���U�d��

        /// <summary>
        /// �i�ܦp��b Autofac �����U��ܮءC
        /// </summary>
        /// <example>
        /// <code>
        /// public class DialogRegistrationModule : Module
        /// {
        ///     protected override void Load(ContainerBuilder builder)
        ///     {
        ///         // ���U�۩w�q��ܮ�
        ///         builder.RegisterType&lt;ConfirmDeleteDialog&gt;()
        ///             .AsSelf()
        ///             .InstancePerDependency();
        ///         
        ///         builder.RegisterType&lt;InputDialog&gt;()
        ///             .AsSelf()
        ///             .InstancePerDependency();
        ///         
        ///         builder.RegisterType&lt;ProductEditDialog&gt;()
        ///             .AsSelf()
        ///             .InstancePerDependency();
        ///         
        ///         builder.RegisterType&lt;ProgressDialog&gt;()
        ///             .AsSelf()
        ///             .InstancePerDependency();
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void AutofacRegistrationExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion
    }
}

#endif