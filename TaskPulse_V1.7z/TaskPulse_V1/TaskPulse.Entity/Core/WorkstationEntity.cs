﻿/*
工站實體類別。

關聯設定：
ModelEntity: 多對一關聯，表示多個工站可屬於同一機種，當機種被刪除時，導航屬性設為 null。
MachineEntity: 透過 MachineWorkstation 中介表與 MachineEntity 建立多對多關聯。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 工站。
    /// </summary>
    public class WorkstationEntity : IEquatable<WorkstationEntity>
    {
        /// <summary>
        /// 工站主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 工站名稱。
        /// </summary>
        public string WorkstationName { get; set; }

        /// <summary>
        /// 機種。
        /// </summary>
        public virtual ModelEntity Model { get; set; }

        /// <summary>
        /// 機種外鍵。
        /// </summary>
        public int? ModelId { get; set; }

        /// <summary>
        /// 工站與機台關聯（透過中介表）。
        /// </summary>
        public virtual ICollection<MachineWorkstation> MachineWorkstations { get; set; } = new HashSet<MachineWorkstation>();

        #region IEquatable<WorkstationEntity>

        public bool Equals(WorkstationEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as WorkstationEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(WorkstationEntity left, WorkstationEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(WorkstationEntity left, WorkstationEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
