/*
�s�ջP�v���������A�Ω�إ� GroupEntity �P PermissionEntity ���h��h���p�C
*/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// �s�ջP�v�����p�]�h��h�������^�C
    /// </summary>
    public class GroupPermission : IEquatable<GroupPermission>
    {
        /// <summary>
        /// �s�եD��C
        /// </summary>
        [Key, Column(Order = 0)]
        public int GroupId { get; set; }

        /// <summary>
        /// �v���D��C
        /// </summary>
        [Key, Column(Order = 1)]
        public int PermissionId { get; set; }

        /// <summary>
        /// �s�աC
        /// </summary>
        public virtual GroupEntity Group { get; set; }

        /// <summary>
        /// �v���C
        /// </summary>
        public virtual PermissionEntity Permission { get; set; }

        #region IEquatable<GroupPermission>

        public bool Equals(GroupPermission other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return GroupId == other.GroupId && PermissionId == other.PermissionId;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as GroupPermission);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (GroupId * 397) ^ PermissionId;
            }
        }

        public static bool operator ==(GroupPermission left, GroupPermission right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(GroupPermission left, GroupPermission right)
        {
            return !(left == right);
        }

        #endregion
    }
}
