﻿/*
機台設備別實體類別。

關聯設定：
MachineNameEntity: 一對多關聯，表示一個設備別可以包含多個機台名稱。
MachineCategoryEntity: 多對一關聯，表示多個設備別可以屬於同一分類，當分類被刪除時，導航屬性設為 null。
MachineEntity: 一對多關聯，表示多個機台可以直接擁有相同的設備別（當沒有 MachineName 時）。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機台設備別。
    /// </summary>
    public class MachineTypeEntity : IEquatable<MachineTypeEntity>
    {
        /// <summary>
        /// 設備別主鍵。
        /// </summary>
        [Description("型式代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 設備別名稱。
        /// </summary>
        public string TypeName { get; set; }

        /// <summary>
        /// 所屬分類。
        /// </summary>
        public virtual MachineCategoryEntity Category { get; set; }

        /// <summary>
        /// 分類外鍵。
        /// </summary>
        public int? CategoryId { get; set; }

        /// <summary>
        /// 此設備別下的機台型號清單。
        /// </summary>
        public virtual ICollection<MachineNameEntity> MachineNames { get; set; } = new HashSet<MachineNameEntity>();

        /// <summary>
        /// 直接使用此設備別的機台清單（無 MachineName 時）。
        /// </summary>
        public virtual ICollection<MachineEntity> Machines { get; set; } = new HashSet<MachineEntity>();

        #region IEquatable<MachineTypeEntity>

        public bool Equals(MachineTypeEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as MachineTypeEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(MachineTypeEntity left, MachineTypeEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(MachineTypeEntity left, MachineTypeEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
