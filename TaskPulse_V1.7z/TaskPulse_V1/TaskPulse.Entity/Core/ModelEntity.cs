﻿/*
機種實體類別。
機種永不刪除，而是透過狀態來表示是否啟用。

關聯設定：
ModelStatusEntity: 多對一關聯，表示多個機種可屬於同一狀態，當狀態被刪除時，FK 設為 1。
WorkstationEntity: 一對多關聯，表示一個機種可包含多個工站。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機種。
    /// </summary>
    public class ModelEntity : IEquatable<ModelEntity>
    {
        /// <summary>
        /// 機種主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 機種名稱。
        /// </summary>
        public string ModelName { get; set; }

        /// <summary>
        /// 機種狀態。
        /// </summary>
        public virtual ModelStatusEntity ModelStatus { get; set; }

        /// <summary>
        /// 機種狀態外鍵（預設為 1）。
        /// </summary>
        public int ModelStatusId { get; set; } = 1;

        /// <summary>
        /// 工站清單。
        /// </summary>
        public virtual ICollection<WorkstationEntity> Workstations { get; set; } = new HashSet<WorkstationEntity>();

        #region IEquatable<ModelEntity>

        public bool Equals(ModelEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as ModelEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(ModelEntity left, ModelEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(ModelEntity left, ModelEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
