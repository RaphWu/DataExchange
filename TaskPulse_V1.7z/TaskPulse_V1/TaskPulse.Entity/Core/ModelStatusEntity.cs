﻿/*
機種運行狀態。

關聯設定：
與 ModelEntity 實體類別有一對多關係，表示多個機種可屬於同一狀態。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機種運行狀態。
    /// </summary>
    public class ModelStatusEntity : IEquatable<ModelStatusEntity>
    {
        /// <summary>
        /// 狀態代號。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 運行狀態。
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// 擁有此狀態的機種清單。
        /// </summary>
        public virtual ICollection<ModelEntity> Models { get; set; } = new HashSet<ModelEntity>();

        #region IEquatable<ModelStatusEntity>

        public bool Equals(ModelStatusEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as ModelStatusEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(ModelStatusEntity left, ModelStatusEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(ModelStatusEntity left, ModelStatusEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
