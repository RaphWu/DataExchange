﻿/*
員工狀態實體類別，包含員工狀態的相關屬性和關聯。

關聯設定：
與 EmployeeEntity 實體有一對多的關係，表示多個員工可以擁有相同的狀態。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 員工狀態。
    /// </summary>
    /// <remarks>預設 在職=1, 已離職=2, 不可變，固定在前兩筆</remarks>
    public class EmployeeStatusEntity : IEquatable<EmployeeStatusEntity>
    {
        /// <summary>
        /// 狀態主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 狀態名稱。
        /// </summary>
        public string StatusName { get; set; }

        /// <summary>
        /// 擁有此狀態的員工清單。
        /// </summary>
        public virtual ICollection<EmployeeEntity> Employees { get; set; } = new HashSet<EmployeeEntity>();

        #region IEquatable<EmployeeStatusEntity>

        public bool Equals(EmployeeStatusEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as EmployeeStatusEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(EmployeeStatusEntity left, EmployeeStatusEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(EmployeeStatusEntity left, EmployeeStatusEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
