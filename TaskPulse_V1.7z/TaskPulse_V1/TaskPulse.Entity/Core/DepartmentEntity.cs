﻿/*
部門實體類別，包含部門的基本資訊如代號、名稱及排序。

關聯設定：
EmployeeEntity: 一對多關聯，表示多個員工可以屬於同一部門。
PermissionEntity: 透過 DepartmentPermission 中介表建立多對多關聯。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 部門。
    /// </summary>
    public class DepartmentEntity : IEquatable<DepartmentEntity>
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        public string DepartmentName { get; set; }

        public virtual ICollection<EmployeeEntity> Employees { get; set; } = new HashSet<EmployeeEntity>();

        public virtual ICollection<DepartmentPermission> DepartmentPermissions { get; set; } = new HashSet<DepartmentPermission>();

        #region IEquatable<DepartmentEntity>

        public bool Equals(DepartmentEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as DepartmentEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(DepartmentEntity left, DepartmentEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(DepartmentEntity left, DepartmentEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
