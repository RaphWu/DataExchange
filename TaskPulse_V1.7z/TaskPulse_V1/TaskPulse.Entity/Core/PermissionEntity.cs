﻿/*
權限實體類別。

關聯設定：
EmployeeEntity: 透過 EmployeePermission 中介表建立多對多關聯。
DepartmentEntity: 透過 DepartmentPermission 中介表建立多對多關聯。
GroupEntity: 透過 GroupPermission 中介表建立多對多關聯。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 系統權限。
    /// </summary>
    /// <remarks>格式：<code><![CDATA[
    /// [Module]_[Page]_[Control]_[Action]
    /// 
    ///  Module 模組： 定義系統中的主要功能分類或模組，如「工具任務 (ToolQuest)」、「維護流程 (MaintiFlow)」等。
    ///    Page 頁面： 定義模組中的特定視圖或頁面，如「任務請求編輯 (RequestEdit)」、「工單列表 (WorkOrderList)」等。
    /// Control 控件： 定義頁面中的特定元件或控制項，如「儲存按鈕 (btnSave)」、「搜尋欄位 (txtSearch)」等。
    ///  Action 動作： 定義使用者在該視圖或功能分類中可執行的操作，如「檢視 (View)」、「新增 (Add)」、「編輯 (Edit)」、「刪除 (Delete)」等。
    ///  
    /// 如果某權限為 "**"，表示從該層級開始的所有子層級皆包含在內。
    /// 如果某權限為 "*"，表示該層級沒有限定範圍，但仍要看以下層級的設定。
    /// ]]></code></remarks>
    public class PermissionEntity : IEquatable<PermissionEntity>
    {
        /// <summary>
        /// 權限主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 模組。
        /// </summary>
        public string Module { get; set; }

        /// <summary>
        /// 頁面。
        /// </summary>
        public string Page { get; set; }

        /// <summary>
        /// 控件。
        /// </summary>
        public string Control { get; set; }

        /// <summary>
        /// 動作。
        /// </summary>
        public string Action { get; set; }

        /// <summary>
        /// 權限類型：1=允許(Allow)、2=禁止(Deny)。預設為允許。
        /// </summary>
        public int PermissionType { get; set; } = 1;

        /// <summary>
        /// 員工與權限關聯（透過中介表）。
        /// </summary>
        public virtual ICollection<EmployeePermission> EmployeePermissions { get; set; } = new HashSet<EmployeePermission>();

        /// <summary>
        /// 部門與權限關聯（透過中介表）。
        /// </summary>
        public virtual ICollection<DepartmentPermission> DepartmentPermissions { get; set; } = new HashSet<DepartmentPermission>();

        /// <summary>
        /// 群組與權限關聯（透過中介表）。
        /// </summary>
        public virtual ICollection<GroupPermission> GroupPermissions { get; set; } = new HashSet<GroupPermission>();

        #region IEquatable<PermissionEntity>

        public bool Equals(PermissionEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as PermissionEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(PermissionEntity left, PermissionEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(PermissionEntity left, PermissionEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
