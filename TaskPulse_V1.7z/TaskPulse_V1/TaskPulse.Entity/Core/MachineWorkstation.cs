/*
���x�P�u���������A�Ω�إ� MachineEntity �P WorkstationEntity ���h��h���p�C
���ܤ@�Ӿ��x�i�H�@�~��h�Ӥu���A�@�Ӥu���]�i�H�b�h�Ӿ��x�W�@�~�C
*/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// ���x�P�u�����p�]�h��h�������^�C
    /// </summary>
    public class MachineWorkstation : IEquatable<MachineWorkstation>
    {
        /// <summary>
        /// ���x�D��C
        /// </summary>
        [Key, Column(Order = 0)]
        public int MachineId { get; set; }

        /// <summary>
        /// �u���D��C
        /// </summary>
        [Key, Column(Order = 1)]
        public int WorkstationId { get; set; }

        /// <summary>
        /// ���x�C
        /// </summary>
        public virtual MachineEntity Machine { get; set; }

        /// <summary>
        /// �u���C
        /// </summary>
        public virtual WorkstationEntity Workstation { get; set; }

        #region IEquatable<MachineWorkstation>

        public bool Equals(MachineWorkstation other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return MachineId == other.MachineId && WorkstationId == other.WorkstationId;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as MachineWorkstation);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (MachineId * 397) ^ WorkstationId;
            }
        }

        public static bool operator ==(MachineWorkstation left, MachineWorkstation right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(MachineWorkstation left, MachineWorkstation right)
        {
            return !(left == right);
        }

        #endregion
    }
}
