﻿/*
機台資料實體類別。

特別說明：考量到有些機台可能沒有明確的型號名稱，但設備別一定有，因此在此實體中同時包含 MachineNameId 與 MachineTypeId 屬性。
原本沒有 MachineTypeId 時的做法是如果沒有型號名稱，程式內自動建一個「空白」的 MachineNameEntity 實體，但這樣會導致資料庫中出現大量重複的「空白」型號名稱，影響資料的整潔性與查詢效率。
修正後的做法是直接在 MachineEntity 中同時保留 MachineNameId 與 MachineTypeId 屬性，
如果機台有 MachineNameId，則與 MachineNameEntity 關聯，MachineTypeId 為空；如果沒有 MachineName，則 MachineNameId 為空，指定 MachineTypeId 與 MachineTypeEntity 關聯。

關聯設定：
MachineNameEntity: 多對一關聯，表示多個機台可以擁有相同的機台名稱，當實體被刪除時，導航屬性設為 null。
MachineTypeEntity: 多對一關聯，表示多個機台可以擁有相同的設備別，當實體被刪除時，導航屬性設為 null。
MachineConditionEntity: 多對一關聯，表示多個機台可以擁有相同的狀態，當實體被刪除時，FK 設為 1。
MachineBrandEntity: 多對一關聯，表示多個機台可以擁有相同的廠牌，當實體被刪除時，導航屬性設為 null。
MachineLocationEntity: 多對一關聯，表示多個機台可以位於相同的位置，當實體被刪除時，導航屬性設為 null。
MachineAssetEntity: 多對一關聯，表示一個機台可以擁有多個資產編號。
MachineIssueCategoryEntity: 多對一關聯，表示多個機台可以屬於相同的維護類型，當實體被刪除時，導航屬性設為 null。
WorkstationEntity: 透過 MachineWorkstation 中介表與 WorkstationEntity 建立多對多關聯。
GroupEntity: 透過 MachineGroup 中介表與 GroupEntity 建立多對多關聯，表示機台的分組。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機台資料。
    /// </summary>
    public class MachineEntity : IEquatable<MachineEntity>
    {
        /// <summary>
        /// 機台主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 機台編號（唯一）。
        /// </summary>
        [Index(IsUnique = true)]
        public string MachineCode { get; set; }

        /// <summary>
        /// 機台型號。
        /// </summary>
        public virtual MachineNameEntity MachineName { get; set; }

        /// <summary>
        /// 機台型號外鍵。
        /// </summary>
        public int? MachineNameId { get; set; }

        /// <summary>
        /// 機台設備別。
        /// </summary>
        public virtual MachineTypeEntity MachineType { get; set; }

        /// <summary>
        /// 機台設備別外鍵。
        /// </summary>
        public int? MachineTypeId { get; set; }

        /// <summary>
        /// 機台狀態。
        /// </summary>
        public virtual MachineConditionEntity Condition { get; set; }

        /// <summary>
        /// 機台狀態外鍵（預設為 1）。
        /// </summary>
        public int ConditionId { get; set; } = 1;

        /// <summary>
        /// 廠牌。
        /// </summary>
        public virtual MachineBrandEntity Brand { get; set; }

        /// <summary>
        /// 廠牌外鍵。
        /// </summary>
        public int? BrandId { get; set; }

        /// <summary>
        /// 位置。
        /// </summary>
        public virtual MachineLocationEntity Location { get; set; }

        /// <summary>
        /// 位置外鍵。
        /// </summary>
        public int? LocationId { get; set; }

        /// <summary>
        /// 資產編號（一對多關聯）。
        /// </summary>
        public virtual ICollection<MachineAssetEntity> Assets { get; set; } = new HashSet<MachineAssetEntity>();

        /// <summary>
        /// 機台序號。
        /// </summary>
        public string SerialNumber { get; set; }

        /// <summary>
        /// 條碼。
        /// </summary>
        public string Barcode { get; set; }

        /// <summary>
        /// 維護類型。
        /// </summary>
        public virtual MachineIssueCategoryEntity IssueCategory { get; set; }

        /// <summary>
        /// 維護類型外鍵。
        /// </summary>
        public int? IssueCategoryId { get; set; }

        /// <summary>
        /// 能否連網。
        /// </summary>
        public bool Connected { get; set; } = false;

        /// <summary>
        /// 機台是否已被處置（除帳/報廢等）。
        /// </summary>
        public bool Disposal { get; set; } = false;

        /// <summary>
        /// 備註。
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// 機台與工站關聯（透過中介表）。
        /// </summary>
        public virtual ICollection<MachineWorkstation> MachineWorkstations { get; set; } = new HashSet<MachineWorkstation>();

        /// <summary>
        /// 機台與群組關聯（透過中介表）。
        /// </summary>
        public virtual ICollection<MachineGroup> MachineGroups { get; set; } = new HashSet<MachineGroup>();

        #region IEquatable<MachineEntity>

        public bool Equals(MachineEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as MachineEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(MachineEntity left, MachineEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(MachineEntity left, MachineEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
