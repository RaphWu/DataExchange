﻿/*
機台狀態實體類別。

關聯設定：
MachineEntity: 一對多關聯，表示多個機台可以擁有相同的狀態。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機台狀態。
    /// </summary>
    public class MachineConditionEntity : IEquatable<MachineConditionEntity>
    {
        /// <summary>
        /// 狀態主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 狀態名稱。
        /// </summary>
        public string ConditionName { get; set; }

        /// <summary>
        /// 擁有此狀態的機台清單。
        /// </summary>
        public virtual ICollection<MachineEntity> Machines { get; set; } = new HashSet<MachineEntity>();

        #region IEquatable<MachineCondition>

        public bool Equals(MachineConditionEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as MachineConditionEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(MachineConditionEntity left, MachineConditionEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(MachineConditionEntity left, MachineConditionEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
