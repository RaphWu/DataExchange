/*
�����P�v���������A�Ω�إ� DepartmentEntity �P PermissionEntity ���h��h���p�C
*/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// �����P�v�����p�]�h��h�������^�C
    /// </summary>
    public class DepartmentPermission : IEquatable<DepartmentPermission>
    {
        /// <summary>
        /// �����D��C
        /// </summary>
        [Key, Column(Order = 0)]
        public int DepartmentId { get; set; }

        /// <summary>
        /// �v���D��C
        /// </summary>
        [Key, Column(Order = 1)]
        public int PermissionId { get; set; }

        /// <summary>
        /// �����C
        /// </summary>
        public virtual DepartmentEntity Department { get; set; }

        /// <summary>
        /// �v���C
        /// </summary>
        public virtual PermissionEntity Permission { get; set; }

        #region IEquatable<DepartmentPermission>

        public bool Equals(DepartmentPermission other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return DepartmentId == other.DepartmentId && PermissionId == other.PermissionId;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as DepartmentPermission);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (DepartmentId * 397) ^ PermissionId;
            }
        }

        public static bool operator ==(DepartmentPermission left, DepartmentPermission right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(DepartmentPermission left, DepartmentPermission right)
        {
            return !(left == right);
        }

        #endregion
    }
}
