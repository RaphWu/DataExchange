/*
���x�P�s�դ������A�Ω�إ� MachineEntity �P GroupEntity ���h��h���p�C
���ܤ@�Ӿ��x�i�H�ݩ�h�Ӹs�աA�@�Ӹs�դ]�i�H�]�t�h�Ӿ��x�C
*/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// ���x�P�s�����p�]�h��h�������^�C
    /// </summary>
    public class MachineGroup : IEquatable<MachineGroup>
    {
        /// <summary>
        /// ���x�D��C
        /// </summary>
        [Key, Column(Order = 0)]
        public int MachineId { get; set; }

        /// <summary>
        /// �s�եD��C
        /// </summary>
        [Key, Column(Order = 1)]
        public int GroupId { get; set; }

        /// <summary>
        /// ���x�C
        /// </summary>
        public virtual MachineEntity Machine { get; set; }

        /// <summary>
        /// �s�աC
        /// </summary>
        public virtual GroupEntity Group { get; set; }

        #region IEquatable<MachineGroup>

        public bool Equals(MachineGroup other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return MachineId == other.MachineId && GroupId == other.GroupId;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as MachineGroup);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (MachineId * 397) ^ GroupId;
            }
        }

        public static bool operator ==(MachineGroup left, MachineGroup right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(MachineGroup left, MachineGroup right)
        {
            return !(left == right);
        }

        #endregion
    }
}
