﻿/*
員工實體類別，包含員工的基本資訊如工號、姓名、部門、職稱、電子郵件等，以及與維護流程相關的屬性和關聯。
PasswordHash: 儲存員工的密碼雜湊值以確保安全性。(因系統目前採用 LDAP 驗證，此欄位暫不使用)

關聯設定：
DepartmentEntity: 多對一關聯，表示該員工隸屬於某個部門，當部門被刪除時，導航屬性設為 null。
JobTitleEntity: 多對一關聯，表示該員工擁有某個職稱，當職稱被刪除時，導航屬性設為 null。
EmployeeStatusEntity: 多對一關聯，表示該員工擁有某個在職狀態，當狀態被刪除時，FK 設為 1（預設在職）。
CarbonCopies: 透過 EmployeeCarbonCopy 中介表與 EmployeeEntity 自己建立多對多關聯，表示該員工的副本人員設定。
GroupEntity: 透過 EmployeeGroup 中介表建立多對多關聯。
PermissionEntity: 透過 EmployeePermission 中介表建立多對多關聯。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 員工清單。
    /// </summary>
    public class EmployeeEntity : IEquatable<EmployeeEntity>
    {
        /// <summary>
        /// 員工主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 工號（唯一）。    
        /// </summary>
        [Index(IsUnique = true)]
        public string EmployeeId { get; set; }

        /// <summary>
        /// 姓名。
        /// </summary>
        public string EmployeeName { get; set; }

        /// <summary>
        /// 密碼雜湊（暫不使用，系統採用 LDAP 驗證）。
        /// </summary>
        public string PasswordHash { get; set; }

        /// <summary>
        /// 所屬部門。
        /// </summary>
        public virtual DepartmentEntity Department { get; set; }

        /// <summary>
        /// 部門外鍵。
        /// </summary>
        public int? DepartmentId { get; set; }

        /// <summary>
        /// 職稱。
        /// </summary>
        public virtual JobTitleEntity JobTitle { get; set; }

        /// <summary>
        /// 職稱外鍵。
        /// </summary>
        public int? JobTitleId { get; set; }

        /// <summary>
        /// 是否為維護工程師。
        /// </summary>
        public bool IsEngineer { get; set; } = false;

        /// <summary>
        /// 在職狀態（在職/離職/調職等）。
        /// </summary>
        public virtual EmployeeStatusEntity Status { get; set; }

        /// <summary>
        /// 狀態外鍵（預設為 1，表示在職）。
        /// </summary>
        public int StatusId { get; set; } = 1;

        /// <summary>
        /// 狀態變更日期。
        /// </summary>
        public DateTime? StatusChangeAt { get; set; }

        /// <summary>
        /// 電子郵件。
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// 副本人員關聯（透過中介表）。
        /// </summary>
        public virtual ICollection<EmployeeCarbonCopy> CarbonCopyRelations { get; set; } = new HashSet<EmployeeCarbonCopy>();

        /// <summary>
        /// 員工與群組關聯（透過中介表）。
        /// </summary>
        public virtual ICollection<EmployeeGroup> EmployeeGroups { get; set; } = new HashSet<EmployeeGroup>();

        /// <summary>
        /// 員工與權限關聯（透過中介表）。
        /// </summary>
        public virtual ICollection<EmployeePermission> EmployeePermissions { get; set; } = new HashSet<EmployeePermission>();

        #region IEquatable<EmployeeEntity>

        public bool Equals(EmployeeEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as EmployeeEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(EmployeeEntity left, EmployeeEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(EmployeeEntity left, EmployeeEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
