﻿#region License
// Advanced DataGridView
//
// Original work Copyright (c), 2013 Zuby <zuby@me.com> 
// Modified work Copyright (c), 2014 Davide Gironi <davide.gironi@gmail.com>
//
// Please refer to LICENSE file for licensing information.
#endregion

using System;
using System.Drawing;
using System.Windows.Forms;

namespace Calin.Framework.ADGV
{

    [System.ComponentModel.DesignerCategory("")]
    internal class ColumnHeaderCell : DataGridViewColumnHeaderCell
    {

        #region 公開 事件

        public event ColumnHeaderCellEventHandler FilterPopup;
        public event ColumnHeaderCellEventHandler SortChanged;
        public event ColumnHeaderCellEventHandler FilterChanged;

        #endregion


        #region 常數

        /// <summary>
        /// 日期/時間篩選的預設行為
        /// </summary>
        private const bool FilterDateAndTimeDefaultEnabled = false;

        /// <summary>
        /// 篩選按鈕影像的預設寬高
        /// </summary>
        public const int FilterButtonImageDefaultSize = 23;

        #endregion


        #region 類別 欄位與屬性

        private readonly AdvancedDataGridView dataGridView;

        private Image _filterImage = Calin.Framework.Properties.Resources.ColumnHeader_UnFiltered;
        private Size _filterButtonImageSize = new Size(FilterButtonImageDefaultSize, FilterButtonImageDefaultSize);
        private bool _filterButtonPressed = false;
        private bool _filterButtonOver = false;
        private Rectangle _filterButtonOffsetBounds = Rectangle.Empty;
        private Rectangle _filterButtonImageBounds = Rectangle.Empty;
        private Padding _filterButtonMargin = new Padding(3, 4, 3, 4);
        private bool _filterEnabled = false;

        /// <summary>
        /// 取得此 ColumnHeaderCell 對應的 MenuStrip
        /// </summary>
        public MenuStrip MenuStrip { get; private set; }

        #endregion


        #region 建構子

        /// <summary>
        /// ColumnHeaderCell 建構子
        /// </summary>
        /// <param name="dataGridView"></param>
        /// <param name="oldCell"></param>
        /// <param name="filterEnabled"></param>
        public ColumnHeaderCell(AdvancedDataGridView dataGridView, DataGridViewColumnHeaderCell oldCell, bool filterEnabled)
            : base()
        {
            this.dataGridView = dataGridView;

            Tag = oldCell.Tag;
            ErrorText = oldCell.ErrorText;
            ToolTipText = oldCell.ToolTipText;
            Value = oldCell.Value;
            ValueType = oldCell.ValueType;
            ContextMenuStrip = oldCell.ContextMenuStrip;
            Style = oldCell.Style;
            _filterEnabled = filterEnabled;

            if (oldCell.Size.Height > dataGridView.MaxAllCellHeight)
                dataGridView.MaxAllCellHeight = oldCell.Size.Height;
            int filterButtonImageHeight = dataGridView.MaxFilterButtonImageHeight < dataGridView.MaxAllCellHeight ? dataGridView.MaxFilterButtonImageHeight : dataGridView.MaxAllCellHeight;
            _filterButtonImageSize = new Size((int)Math.Round(filterButtonImageHeight * 0.8), (int)Math.Round(filterButtonImageHeight * 0.8));

            ColumnHeaderCell oldCellt = oldCell as ColumnHeaderCell;
            if (oldCellt != null && oldCellt.MenuStrip != null)
            {
                MenuStrip = oldCellt.MenuStrip;
                _filterImage = oldCellt._filterImage;
                _filterButtonPressed = oldCellt._filterButtonPressed;
                _filterButtonOver = oldCellt._filterButtonOver;
                _filterButtonOffsetBounds = oldCellt._filterButtonOffsetBounds;
                _filterButtonImageBounds = oldCellt._filterButtonImageBounds;
                MenuStrip.FilterChanged += new EventHandler(MenuStrip_FilterChanged);
                MenuStrip.SortChanged += new EventHandler(MenuStrip_SortChanged);
            }
            else
            {
                MenuStrip = new MenuStrip(oldCell.OwningColumn.ValueType);
                MenuStrip.FilterChanged += new EventHandler(MenuStrip_FilterChanged);
                MenuStrip.SortChanged += new EventHandler(MenuStrip_SortChanged);
            }

            IsFilterDateAndTimeEnabled = FilterDateAndTimeDefaultEnabled;
            IsSortEnabled = true;
            IsFilterEnabled = true;
            IsFilterChecklistEnabled = true;
        }
        ~ColumnHeaderCell()
        {
            if (MenuStrip != null)
            {
                MenuStrip.FilterChanged -= MenuStrip_FilterChanged;
                MenuStrip.SortChanged -= MenuStrip_SortChanged;
            }
        }

        #endregion


        #region 公開 方法

        /// <summary>
        /// 取得或設定 篩選與排序功能是否啟用
        /// </summary>
        public bool FilterAndSortEnabled
        {
            get
            {
                return _filterEnabled;
            }
            set
            {
                if (!value)
                {
                    _filterButtonPressed = false;
                    _filterButtonOver = false;
                }

                if (value != _filterEnabled)
                {
                    _filterEnabled = value;
                    bool refreshed = false;
                    if (MenuStrip.FilterString.Length > 0)
                    {
                        MenuStrip_FilterChanged(this, new EventArgs());
                        refreshed = true;
                    }
                    if (MenuStrip.SortString.Length > 0)
                    {
                        MenuStrip_SortChanged(this, new EventArgs());
                        refreshed = true;
                    }
                    if (!refreshed)
                        RepaintCell();
                }
            }
        }

        /// <summary>
        /// 設定或取消 Loaded 模式
        /// </summary>
        /// <param name="enabled"></param>
        public void SetLoadedMode(bool enabled)
        {
            MenuStrip.SetLoadedMode(enabled);
            RefreshImage();
            RepaintCell();
        }

        /// <summary>
        /// 清除排序
        /// </summary>
        public void CleanSort()
        {
            if (MenuStrip != null && FilterAndSortEnabled)
            {
                MenuStrip.CleanSort();
                RefreshImage();
                RepaintCell();
            }
        }

        /// <summary>
        /// 清除篩選
        /// </summary>
        public void CleanFilter()
        {
            if (MenuStrip != null && FilterAndSortEnabled)
            {
                MenuStrip.CleanFilter();
                RefreshImage();
                RepaintCell();
            }
        }

        /// <summary>
        /// 排序 ASC
        /// </summary>
        public void SortASC()
        {
            if (MenuStrip != null && FilterAndSortEnabled)
            {
                MenuStrip.SortASC();
            }
        }

        /// <summary>
        /// 排序 DESC
        /// </summary>
        public void SortDESC()
        {
            if (MenuStrip != null && FilterAndSortEnabled)
            {
                MenuStrip.SortDESC();
            }
        }

        /// <summary>
        /// Clone ColumnHeaderCell
        /// </summary>
        /// <returns></returns>
        public override object Clone()
        {
            return new ColumnHeaderCell(dataGridView, this, FilterAndSortEnabled);
        }

        /// <summary>
        /// 取得 MenuStrip 的排序類型
        /// </summary>
        public MenuStrip.SortType ActiveSortType
        {
            get
            {
                if (MenuStrip != null && FilterAndSortEnabled)
                    return MenuStrip.ActiveSortType;
                else
                    return MenuStrip.SortType.None;
            }
        }

        /// <summary>
        /// 取得 MenuStrip 的篩選類型
        /// </summary>
        public MenuStrip.FilterType ActiveFilterType
        {
            get
            {
                if (MenuStrip != null && FilterAndSortEnabled)
                    return MenuStrip.ActiveFilterType;
                else
                    return MenuStrip.FilterType.None;
            }
        }

        /// <summary>
        /// 取得排序字串
        /// </summary>
        public string SortString
        {
            get
            {
                if (MenuStrip != null && FilterAndSortEnabled)
                    return MenuStrip.SortString;
                else
                    return "";
            }
        }

        /// <summary>
        /// 取得篩選字串
        /// </summary>
        public string FilterString
        {
            get
            {
                if (MenuStrip != null && FilterAndSortEnabled)
                    return MenuStrip.FilterString;
                else
                    return "";
            }
        }

        /// <summary>
        /// 取得最小尺寸
        /// </summary>
        public Size MinimumSize
        {
            get
            {
                return new Size(_filterButtonImageSize.Width + _filterButtonMargin.Left + _filterButtonMargin.Right,
                    _filterButtonImageSize.Height + _filterButtonMargin.Bottom + _filterButtonMargin.Top);
            }
        }

        /// <summary>
        /// 取得或設定 排序是否啟用
        /// </summary>
        public bool IsSortEnabled
        {
            get
            {
                return MenuStrip.IsSortEnabled;
            }
            set
            {
                MenuStrip.IsSortEnabled = value;
            }
        }

        /// <summary>
        /// 取得或設定 篩選是否啟用
        /// </summary>
        public bool IsFilterEnabled
        {
            get
            {
                return MenuStrip.IsFilterEnabled;
            }
            set
            {
                MenuStrip.IsFilterEnabled = value;
            }
        }

        /// <summary>
        /// 取得或設定 checklist 篩選是否啟用
        /// </summary>
        public bool IsFilterChecklistEnabled
        {
            get
            {
                return MenuStrip.IsFilterChecklistEnabled;
            }
            set
            {
                MenuStrip.IsFilterChecklistEnabled = value;
            }
        }

        /// <summary>
        /// 取得或設定 日期/時間 篩選是否啟用
        /// </summary>
        public bool IsFilterDateAndTimeEnabled
        {
            get
            {
                return MenuStrip.IsFilterDateAndTimeEnabled;
            }
            set
            {
                MenuStrip.IsFilterDateAndTimeEnabled = value;
            }
        }

        /// <summary>
        /// 取得或設定 NOT IN 邏輯
        /// </summary>
        public bool IsMenuStripFilterNOTINLogicEnabled
        {
            get
            {
                return MenuStrip.IsFilterNOTINLogicEnabled;
            }
            set
            {
                MenuStrip.IsFilterNOTINLogicEnabled = value;
            }
        }

        /// <summary>
        /// 設定文字篩選搜尋時是否移除節點
        /// </summary>
        public bool DoesTextFilterRemoveNodesOnSearch
        {
            get
            {
                return MenuStrip.DoesTextFilterRemoveNodesOnSearch;
            }
            set
            {
                MenuStrip.DoesTextFilterRemoveNodesOnSearch = value;
            }
        }

        /// <summary>
        /// 啟用文字篩選 TextChanged 延遲所需的節點數量
        /// </summary>
        public int TextFilterTextChangedDelayNodes
        {
            get
            {
                return MenuStrip.TextFilterTextChangedDelayNodes;
            }
            set
            {
                MenuStrip.TextFilterTextChangedDelayNodes = value;
            }
        }

        /// <summary>
        /// 顯示時是否將篩選文字框設為焦點
        /// </summary>
        public bool FilterTextFocusOnShow
        {
            get
            {
                return MenuStrip.FilterTextFocusOnShow;
            }
            set
            {
                MenuStrip.FilterTextFocusOnShow = value;
            }
        }

        /// <summary>
        /// 啟用或停用排序功能
        /// </summary>
        /// <param name="enabled"></param>
        public void SetSortEnabled(bool enabled)
        {
            if (MenuStrip != null)
            {
                MenuStrip.IsSortEnabled = enabled;
                MenuStrip.SetSortEnabled(enabled);
            }
        }

        /// <summary>
        /// 啟用或停用篩選功能
        /// </summary>
        /// <param name="enabled"></param>
        public void SetFilterEnabled(bool enabled)
        {
            if (MenuStrip != null)
            {
                MenuStrip.IsFilterEnabled = enabled;
                MenuStrip.SetFilterEnabled(enabled);
            }
        }

        /// <summary>
        /// 啟用或停用 checklist 篩選功能
        /// </summary>
        /// <param name="enabled"></param>
        public void SetFilterChecklistEnabled(bool enabled)
        {
            if (MenuStrip != null)
            {
                MenuStrip.IsFilterChecklistEnabled = enabled;
                MenuStrip.SetFilterChecklistEnabled(enabled);
            }
        }

        /// <summary>
        /// 設定 checklist 節點最大數量
        /// </summary>
        /// <param name="maxnodes"></param>
        public void SetFilterChecklistNodesMax(int maxnodes)
        {
            if (maxnodes >= 0)
            {
                MenuStrip.MaxChecklistNodes = maxnodes;
            }
        }

        /// <summary>
        /// 啟用或停用 checklist 節點數量上限功能
        /// </summary>
        /// <param name="enabled"></param>
        public void EnabledFilterChecklistNodesMax(bool enabled)
        {
            if (MenuStrip.MaxChecklistNodes == 0 && enabled)
                MenuStrip.MaxChecklistNodes = MenuStrip.DefaultMaxChecklistNodes;
            else if (MenuStrip.MaxChecklistNodes != 0 && !enabled)
                MenuStrip.MaxChecklistNodes = 0;
        }

        /// <summary>
        /// 啟用或停用自訂篩選功能
        /// </summary>
        /// <param name="enabled"></param>
        public void SetFilterCustomEnabled(bool enabled)
        {
            if (MenuStrip != null)
            {
                MenuStrip.IsFilterCustomEnabled = enabled;
                MenuStrip.SetFilterCustomEnabled(enabled);
            }
        }

        /// <summary>
        /// 設定文字篩選在搜尋時是否移除節點
        /// </summary>
        /// <param name="enabled"></param>
        public void SetChecklistTextFilterRemoveNodesOnSearchMode(bool enabled)
        {
            if (MenuStrip != null)
            {
                MenuStrip.SetChecklistTextFilterRemoveNodesOnSearchMode(enabled);
            }
        }

        /// <summary>
        /// 停用文字篩選 TextChanged 延遲
        /// </summary>
        public void SetTextFilterTextChangedDelayNodesDisabled()
        {
            if (MenuStrip != null)
            {
                MenuStrip.SetTextFilterTextChangedDelayNodesDisabled();
            }
        }

        /// <summary>
        /// 設定文字篩選延遲毫秒數
        /// </summary>
        public void SetTextFilterTextChangedDelayMs(int milliseconds)
        {
            if (MenuStrip != null)
            {
                MenuStrip.TextFilterTextChangedDelayMs = milliseconds;
            }
        }

        #endregion


        #region MenuStrip 事件處理

        /// <summary>
        /// MenuStrip 篩選改變事件處理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuStrip_FilterChanged(object sender, EventArgs e)
        {
            RefreshImage();
            RepaintCell();
            if (FilterAndSortEnabled && FilterChanged != null)
                FilterChanged(this, new ColumnHeaderCellEventArgs(MenuStrip, OwningColumn));
        }

        /// <summary>
        /// MenuStrip 排序改變事件處理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuStrip_SortChanged(object sender, EventArgs e)
        {
            RefreshImage();
            RepaintCell();
            if (FilterAndSortEnabled && SortChanged != null)
                SortChanged(this, new ColumnHeaderCellEventArgs(MenuStrip, OwningColumn));
        }

        /// <summary>
        /// 清除已附加的事件
        /// </summary>
        public void CleanEvents()
        {
            MenuStrip.FilterChanged -= MenuStrip_FilterChanged;
            MenuStrip.SortChanged -= MenuStrip_SortChanged;
        }


        #endregion


        #region 繪製 方法

        /// <summary>
        /// 重新繪製儲存格
        /// </summary>
        private void RepaintCell()
        {
            if (Displayed && DataGridView != null)
                DataGridView.InvalidateCell(this);
        }

        /// <summary>
        /// 更新儲存格上的圖示
        /// </summary>
        private void RefreshImage()
        {
            if (ActiveFilterType == MenuStrip.FilterType.Loaded)
            {
                _filterImage = Calin.Framework.Properties.Resources.ColumnHeader_SavedFilters;
            }
            else
            {
                if (ActiveFilterType == MenuStrip.FilterType.None)
                {
                    if (ActiveSortType == MenuStrip.SortType.None)
                        _filterImage = Calin.Framework.Properties.Resources.ColumnHeader_UnFiltered;
                    else if (ActiveSortType == MenuStrip.SortType.ASC)
                        _filterImage = Calin.Framework.Properties.Resources.ColumnHeader_OrderedASC;
                    else
                        _filterImage = Calin.Framework.Properties.Resources.ColumnHeader_OrderedDESC;
                }
                else
                {
                    if (ActiveSortType == MenuStrip.SortType.None)
                        _filterImage = Calin.Framework.Properties.Resources.ColumnHeader_Filtered;
                    else if (ActiveSortType == MenuStrip.SortType.ASC)
                        _filterImage = Calin.Framework.Properties.Resources.ColumnHeader_FilteredAndOrderedASC;
                    else
                        _filterImage = Calin.Framework.Properties.Resources.ColumnHeader_FilteredAndOrderedDESC;
                }
            }
        }

        /// <summary>
        /// 繪製方法
        /// </summary>
        /// <param name="graphics"></param>
        /// <param name="clipBounds"></param>
        /// <param name="cellBounds"></param>
        /// <param name="rowIndex"></param>
        /// <param name="cellState"></param>
        /// <param name="value"></param>
        /// <param name="formattedValue"></param>
        /// <param name="errorText"></param>
        /// <param name="cellStyle"></param>
        /// <param name="advancedBorderStyle"></param>
        /// <param name="paintParts"></param>
        protected override void Paint(
            Graphics graphics,
            Rectangle clipBounds,
            Rectangle cellBounds,
            int rowIndex,
            DataGridViewElementStates cellState,
            object value,
            object formattedValue,
            string errorText,
            DataGridViewCellStyle cellStyle,
            DataGridViewAdvancedBorderStyle advancedBorderStyle,
            DataGridViewPaintParts paintParts)
        {
            if (SortGlyphDirection != SortOrder.None)
                SortGlyphDirection = SortOrder.None;

            base.Paint(graphics, clipBounds, cellBounds, rowIndex,
                cellState, value, formattedValue,
                errorText, cellStyle, advancedBorderStyle, paintParts);

            // 對影像欄不顯示下拉選單
            if (this.OwningColumn.ValueType == typeof(Bitmap))
                return;

            if (FilterAndSortEnabled && paintParts.HasFlag(DataGridViewPaintParts.ContentBackground))
            {
                _filterButtonOffsetBounds = GetFilterBounds(true);
                _filterButtonImageBounds = GetFilterBounds(false);
                Rectangle buttonBounds = _filterButtonOffsetBounds;
                if (clipBounds.IntersectsWith(buttonBounds))
                {
                    ControlPaint.DrawBorder(graphics, buttonBounds, Color.Gray, ButtonBorderStyle.Solid);
                    buttonBounds.Inflate(-1, -1);
                    using (Brush b = new SolidBrush(_filterButtonOver ? Color.WhiteSmoke : Color.White))
                        graphics.FillRectangle(b, buttonBounds);
                    graphics.DrawImage(_filterImage, buttonBounds);
                }
            }
        }

        /// <summary>
        /// 取得 ColumnHeaderCell 上篩選按鈕的 Bounds
        /// </summary>
        /// <param name="withOffset"></param>
        /// <returns></returns>
        private Rectangle GetFilterBounds(bool withOffset = true)
        {
            Rectangle cell = DataGridView.GetCellDisplayRectangle(ColumnIndex, -1, false);

            Point p = new Point(
                (withOffset ? cell.Right : cell.Width) - _filterButtonImageSize.Width - _filterButtonMargin.Right,
                (withOffset ? cell.Bottom + 2 : cell.Height) - _filterButtonImageSize.Height - _filterButtonMargin.Bottom);

            return new Rectangle(p, _filterButtonImageSize);
        }

        #endregion


        #region 滑鼠 事件

        /// <summary>
        /// OnMouseMove 事件
        /// </summary>
        /// <param name="e"></param>
        protected override void OnMouseMove(DataGridViewCellMouseEventArgs e)
        {
            if (FilterAndSortEnabled)
            {
                if (_filterButtonImageBounds.Contains(e.X, e.Y) && !_filterButtonOver)
                {
                    _filterButtonOver = true;
                    RepaintCell();
                }
                else if (!_filterButtonImageBounds.Contains(e.X, e.Y) && _filterButtonOver)
                {
                    _filterButtonOver = false;
                    RepaintCell();
                }
            }
            base.OnMouseMove(e);
        }

        /// <summary>
        /// OnMouseDown 事件
        /// </summary>
        /// <param name="e"></param>
        protected override void OnMouseDown(DataGridViewCellMouseEventArgs e)
        {
            if (FilterAndSortEnabled && _filterButtonImageBounds.Contains(e.X, e.Y))
            {
                if (e.Button == MouseButtons.Left && !_filterButtonPressed)
                {
                    _filterButtonPressed = true;
                    _filterButtonOver = true;
                    RepaintCell();
                }
            }
            else
                base.OnMouseDown(e);
        }

        /// <summary>
        /// OnMouseUp 事件
        /// </summary>
        /// <param name="e"></param>
        protected override void OnMouseUp(DataGridViewCellMouseEventArgs e)
        {
            if (FilterAndSortEnabled && e.Button == MouseButtons.Left && _filterButtonPressed)
            {
                _filterButtonPressed = false;
                _filterButtonOver = false;
                RepaintCell();
                if (_filterButtonImageBounds.Contains(e.X, e.Y) && FilterPopup != null)
                {
                    FilterPopup(this, new ColumnHeaderCellEventArgs(MenuStrip, OwningColumn));
                }
            }
            base.OnMouseUp(e);
        }

        /// <summary>
        /// OnMouseLeave 事件
        /// </summary>
        /// <param name="rowIndex"></param>
        protected override void OnMouseLeave(int rowIndex)
        {
            if (FilterAndSortEnabled && _filterButtonOver)
            {
                _filterButtonOver = false;
                RepaintCell();
            }

            base.OnMouseLeave(rowIndex);
        }

        #endregion

    }

    internal delegate void ColumnHeaderCellEventHandler(object sender, ColumnHeaderCellEventArgs e);
    internal class ColumnHeaderCellEventArgs : EventArgs
    {
        public MenuStrip FilterMenu { get; private set; }

        public DataGridViewColumn Column { get; private set; }

        public ColumnHeaderCellEventArgs(MenuStrip filterMenu, DataGridViewColumn column)
        {
            FilterMenu = filterMenu;
            Column = column;
        }
    }

}