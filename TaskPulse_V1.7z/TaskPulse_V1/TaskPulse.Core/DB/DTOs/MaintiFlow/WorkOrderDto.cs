using System;
using System.Collections.Generic;
using Calin.TaskPulse.Entity.Contants;

namespace Calin.TaskPulse.Core.DB.DTOs
{
    /// <summary>
    /// ���@�u���ƶǿ骫��C
    /// </summary>
    public class WorkOrderDto
    {
        public int Id { get; set; }
        public string WorkOrderNo { get; set; }
        public FlowStatus Status { get; set; }
        public int? MachineId { get; set; }
        public string MachineCode { get; set; }
        public int? WorkstationId { get; set; }
        public string WorkstationName { get; set; }
        public int CreatorId { get; set; }
        public string CreatorName { get; set; }
        public DateTime CreationDateTime { get; set; }
        public int? MaintenanceUnitId { get; set; }
        public string MaintenanceUnitName { get; set; }
        public DateTime? AcceptedTime { get; set; }
        public int? RequestingUnitId { get; set; }
        public string RequestingUnitName { get; set; }
        public string Responsible { get; set; }
        public List<MaintenanceRecordDto> MaintenanceRecords { get; set; } = new List<MaintenanceRecordDto>();
    }
}
