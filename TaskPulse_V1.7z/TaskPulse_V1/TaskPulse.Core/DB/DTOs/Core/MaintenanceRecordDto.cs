using System;
using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DB.DTOs
{
    /// <summary>
    /// ���@�O����ƶǿ骫��C
    /// </summary>
    public class MaintenanceRecordDto
    {
        public int Id { get; set; }
        public int WorkOrderId { get; set; }
        public int? IssueCategoryId { get; set; }
        public string IssueCategoryName { get; set; }
        public string IssueDescription { get; set; }
        public string Details { get; set; }
        public DateTime? FillingTime { get; set; }
        public int? FeedbackEmployeeId { get; set; }
        public string FeedbackEmployeeName { get; set; }
        public string Feedback { get; set; }
        public DateTime? OutageStarted { get; set; }
        public DateTime? OutageEnded { get; set; }
        public long OutageDurationTick { get; set; }
        public List<int> EngineerIds { get; set; } = new List<int>();
    }
}
