﻿using System.ComponentModel;

namespace Calin.TaskPulse.Core.DB.DTOs
{
    /// <summary>
    /// 機台編輯資料傳輸物件。
    /// </summary>
    public class MachineEditDto
    {
        [Description("機台識別碼")]
        public int Id { get; set; }

        [Description("編號")]
        public string MachineCode { get; set; }

        [Description("型號識別碼")]
        public int? MachineNameId { get; set; }

        [Description("型號")]
        public string ModelName { get; set; }

        [Description("設備別識別碼")]
        public int? TypeId { get; set; }

        [Description("設備別")]
        public string TypeName { get; set; }

        [Description("狀態識別碼")]
        public int ConditionId { get; set; }

        [Description("狀態")]
        public string ConditionName { get; set; }

        [Description("廠牌識別碼")]
        public int? BrandId { get; set; }

        [Description("廠牌")]
        public string BrandName { get; set; }

        [Description("位置識別碼")]
        public int? LocationId { get; set; }

        [Description("位置")]
        public string LocationName { get; set; }

        [Description("資產編號")]
        public string Assets { get; set; }

        [Description("序號")]
        public string SerialNumber { get; set; }

        [Description("條碼")]
        public string Barcode { get; set; }

        [Description("維護類型識別碼")]
        public int? IssueCategoryId { get; set; }

        [Description("維護類型")]
        public string IssueCategory { get; set; }

        [Description("連網")]
        public bool Connected { get; set; }

        [Description("處置")]
        public bool Disposal { get; set; }

        [Description("備註")]
        public string Remark { get; set; }
    }
}
