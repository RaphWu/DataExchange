namespace Calin.TaskPulse.Core.DB.DTOs
{
    /// <summary>
    /// �s�ո�ƶǿ骫��C
    /// </summary>
    public class GroupDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string Name { get; set; }
    }
}
