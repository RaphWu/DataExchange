namespace Calin.TaskPulse.Core.DB.DTOs
{
    /// <summary>
    /// ¾�ٸ�ƶǿ骫��C
    /// </summary>
    public class JobTitleDto
    {
        /// <summary>
        /// ¾���ѧO�X�C
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// ��ܱƧǡC
        /// </summary>
        public int OrderNo { get; set; }

        /// <summary>
        /// ¾�٦W�١C
        /// </summary>
        public string JobTitleName { get; set; }
    }
}
