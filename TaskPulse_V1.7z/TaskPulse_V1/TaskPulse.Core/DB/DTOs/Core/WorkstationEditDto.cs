﻿using System.ComponentModel;

namespace Calin.TaskPulse.Core.DB.DTOs
{
    /// <summary>
    /// 工站編輯資料傳輸物件。
    /// </summary>
    public class WorkstationEditDto
    {
        [Description("工站編號")]
        public int Id { get; set; }

        [Description("顯示排序")]
        public int OrderNo { get; set; }

        [Description("工站")]
        public string WorkstationName { get; set; }

        [Description("機種編號")]
        public int? ModelId { get; set; }

        [Description("機種")]
        public string ModelName { get; set; }
    }
}
