using System.ComponentModel;

namespace Calin.TaskPulse.Core.DB.DTOs
{
    /// <summary>
    /// ���xŪ����ƶǿ骫��C
    /// </summary>
    public class MachineReadDto
    {
        [Description("���x�ѧO�X")]
        public int Id { get; set; }

        [Description("�s��")]
        public string MachineCode { get; set; }

        [Description("�����ѧO�X")]
        public int? MachineNameId { get; set; }

        [Description("����")]
        public string ModelName { get; set; }

        [Description("�]�ƧO�ѧO�X")]
        public int? TypeId { get; set; }

        [Description("�]�ƧO")]
        public string TypeName { get; set; }

        [Description("���A�ѧO�X")]
        public int ConditionId { get; set; }

        [Description("���A")]
        public string ConditionName { get; set; }

        [Description("�t�P�ѧO�X")]
        public int? BrandId { get; set; }

        [Description("�t�P")]
        public string BrandName { get; set; }

        [Description("��m�ѧO�X")]
        public int? LocationId { get; set; }

        [Description("��m")]
        public string LocationName { get; set; }

        [Description("�겣�s��")]
        public string Assets { get; set; }

        [Description("�Ǹ�")]
        public string SerialNumber { get; set; }

        [Description("���X")]
        public string Barcode { get; set; }

        [Description("���@�����ѧO�X")]
        public int? IssueCategoryId { get; set; }

        [Description("���@����")]
        public string IssueCategory { get; set; }

        [Description("�s��")]
        public bool Connected { get; set; }

        [Description("�B�m")]
        public bool Disposal { get; set; }

        [Description("�Ƶ�")]
        public string Remark { get; set; }

        /********************
         * �B�~�ݩ�
         ********************/

        [Description("�����ѧO�X")]
        public int? CategoryId { get; set; }

        [Description("����")]
        public string CategoryName { get; set; }

        [Description("������ܱƧ�")]
        public int CategoryOrderNo { get; set; }

        [Description("�]�ƧO��ܱƧ�")]
        public int TypeOrderNo { get; set; }

        [Description("�겣�s���M��")]
        public string AssetList { get; set; }

        [Description("�s��")]
        public string ConnectedString { get; set; }

        [Description("�B�m")]
        public string DisposalString { get; set; }
    }
}
