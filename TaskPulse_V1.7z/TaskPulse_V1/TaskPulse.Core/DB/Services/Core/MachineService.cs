using System;
using System.Collections.Generic;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Mappers;
using Calin.TaskPulse.Core.DB.Repositories;
using Serilog;

namespace Calin.TaskPulse.Core.DB.Services
{
    /// <summary>
    /// ���x�A�Ȥ����C
    /// </summary>
    public interface IMachineService
    {
        /// <summary>
        /// ���o�Ҧ����x����ơC
        /// </summary>
        /// <returns>�]�t�Ҧ����x����ƶ��X�C</returns>
        IEnumerable<MachineReadDto> GetAll();

        /// <summary>
        /// ���o�Ҧ����x����� (�]�t�w�B�m�����x)�C
        /// </summary>
        /// <returns>�]�t�Ҧ����x����ƶ��X�C</returns>
        IEnumerable<MachineReadDto> GetAllWithDisposal();

        /// <summary>
        /// �ھھ��x���ߤ@�ѧO�X���o���x��ơC
        /// </summary>
        /// <param name="id">���x���ߤ@�ѧO�X�C</param>
        /// <returns>���������x��ơA�Y���s�b�h�^�� null�C</returns>
        MachineReadDto GetById(int id);

        /// <summary>
        /// �ھھ��x�N�X���o���x��ơC
        /// </summary>
        /// <param name="machineCode">���x�N�X�C</param>
        /// <returns>���������x��ơA�Y���s�b�h�^�� null�C</returns>
        MachineReadDto GetByMachineCode(string machineCode);

        /// <summary>
        /// �ھڱ��� ID ���o�ŦX���󪺾��x��ƶ��X�C
        /// </summary>
        /// <param name="conditionId">���� ID�C</param>
        /// <returns>�ŦX���󪺾��x��ƶ��X�C</returns>
        IEnumerable<MachineReadDto> GetByConditionId(int conditionId);

        /// <summary>
        /// �ھڦ�m ID ���o�ŦX���󪺾��x��ƶ��X�C
        /// </summary>
        /// <param name="locationId">��m ID�C</param>
        /// <returns>�ŦX���󪺾��x��ƶ��X�C</returns>
        IEnumerable<MachineReadDto> GetByLocationId(int locationId);

        /// <summary>
        /// ���o�Ҧ��ҥΤ������x��ơC
        /// </summary>
        /// <returns>�]�t�Ҧ��ҥΤ����x����ƶ��X�C</returns>
        IEnumerable<MachineReadDto> GetActiveMachines();

        /// <summary>
        /// �إ߷s�����x��ơC
        /// </summary>
        /// <param name="dto">�]�t���x��ƪ� DTO�C</param>
        /// <returns>�إߦ��\�᪺���x��ơC</returns>
        MachineReadDto Create(MachineReadDto dto);

        /// <summary>
        /// ��s�{�������x��ơC
        /// </summary>
        /// <param name="dto">�]�t��s����x��ƪ� DTO�C</param>
        void Update(MachineReadDto dto);

        /// <summary>
        /// �R�����w ID �����x��ơC
        /// </summary>
        /// <param name="id">�n�R�������x ID�C</param>
        void Delete(int id);
    }

    /// <summary>
    /// ���x�A�ȹ�@�C
    /// </summary>
    public class MachineService : IMachineService
    {
        private readonly Func<CoreContext> _contextFactory;
        private readonly ILogger _logger;

        public MachineService(Func<CoreContext> contextFactory, ILogger logger)
        {
            _contextFactory = contextFactory ?? throw new ArgumentNullException(nameof(contextFactory));
            _logger = logger?.ForContext<MachineService>() ?? Log.Logger.ForContext<MachineService>();
        }

        /// <inheritdoc/>
        public IEnumerable<MachineReadDto> GetAll()
        {
            using (var context = _contextFactory())
            {
                var repository = new MachineRepository(context, _logger);
                return repository.GetAll().ToDtoList();
            }
        }

        /// <inheritdoc/>
        public IEnumerable<MachineReadDto> GetAllWithDisposal()
        {
            using (var context = _contextFactory())
            {
                var repository = new MachineRepository(context, _logger);
                return repository.GetAllWithDisposal().ToDtoList();
            }
        }

        /// <inheritdoc/>
        public MachineReadDto GetById(int id)
        {
            using (var context = _contextFactory())
            {
                var repository = new MachineRepository(context, _logger);
                return repository.GetById(id)?.ToDto();
            }
        }

        /// <inheritdoc/>
        public MachineReadDto GetByMachineCode(string machineCode)
        {
            using (var context = _contextFactory())
            {
                var repository = new MachineRepository(context, _logger);
                return repository.GetByMachineCode(machineCode)?.ToDto();
            }
        }

        /// <inheritdoc/>
        public IEnumerable<MachineReadDto> GetByConditionId(int conditionId)
        {
            using (var context = _contextFactory())
            {
                var repository = new MachineRepository(context, _logger);
                return repository.GetByConditionId(conditionId).ToDtoList();
            }
        }

        /// <inheritdoc/>
        public IEnumerable<MachineReadDto> GetByLocationId(int locationId)
        {
            using (var context = _contextFactory())
            {
                var repository = new MachineRepository(context, _logger);
                return repository.GetByLocationId(locationId).ToDtoList();
            }
        }

        /// <inheritdoc/>
        public IEnumerable<MachineReadDto> GetActiveMachines()
        {
            using (var context = _contextFactory())
            {
                var repository = new MachineRepository(context, _logger);
                return repository.GetActiveMachines().ToDtoList();
            }
        }

        /// <inheritdoc/>
        public MachineReadDto Create(MachineReadDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l�إ߾��x�G{MachineCode}", dto.MachineCode);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new MachineRepository(context, _logger);
                    var entity = dto.ToEntity();
                    var added = repository.Add(entity);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("���x�إߦ��\�G{MachineCode}�AId={Id}", dto.MachineCode, added.Id);
                    return added.ToDto();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "���x�إߥ��ѡG{MachineCode}", dto.MachineCode);
                    throw;
                }
            }
        }

        /// <inheritdoc/>
        public void Update(MachineReadDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l��s���x�GId={Id}", dto.Id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new MachineRepository(context, _logger);
                    var existing = repository.GetById(dto.Id);
                    if (existing == null)
                    {
                        throw new InvalidOperationException($"�䤣����x�AId={dto.Id}");
                    }

                    existing.MachineCode = dto.MachineCode;
                    existing.MachineNameId = dto.MachineNameId;
                    existing.MachineTypeId = dto.TypeId;
                    existing.ConditionId = dto.ConditionId;
                    existing.BrandId = dto.BrandId;
                    existing.LocationId = dto.LocationId;
                    //existing.Assets = dto.Assets;
                    existing.SerialNumber = dto.SerialNumber;
                    existing.Barcode = dto.Barcode;
                    existing.IssueCategoryId = dto.IssueCategoryId;
                    existing.Connected = dto.Connected;
                    existing.Disposal = dto.Disposal;
                    existing.Remark = dto.Remark;

                    repository.Update(existing);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("���x��s���\�GId={Id}", dto.Id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "���x��s���ѡGId={Id}", dto.Id);
                    throw;
                }
            }
        }

        /// <inheritdoc/>
        public void Delete(int id)
        {
            _logger.Information("�}�l�R�����x�GId={Id}", id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new MachineRepository(context, _logger);
                    repository.DeleteById(id);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("���x�R�����\�GId={Id}", id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "���x�R�����ѡGId={Id}", id);
                    throw;
                }
            }
        }
    }
}
