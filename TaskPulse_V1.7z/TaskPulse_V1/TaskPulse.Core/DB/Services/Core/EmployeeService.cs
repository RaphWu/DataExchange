using System;
using System.Collections.Generic;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Mappers;
using Calin.TaskPulse.Core.DB.Repositories;
using Serilog;

namespace Calin.TaskPulse.Core.DB.Services
{
    /// <summary>
    /// ���u�A�Ȥ����C
    /// </summary>
    public interface IEmployeeService
    {
        /// <summary>
        /// ���o�Ҧ����u����ơC
        /// </summary>
        /// <returns>�]�t�Ҧ����u�� <see cref="IEnumerable{EmployeeReadDto}"/>�C</returns>
        IEnumerable<EmployeeReadDto> GetAll();

        /// <summary>
        /// �ھڭ��u���ߤ@�ѧO�X���o���u��ơC
        /// </summary>
        /// <param name="id">���u���ߤ@�ѧO�X�C</param>
        /// <returns>������ <see cref="EmployeeReadDto"/>�A�p�G�䤣��h�^�� null�C</returns>
        EmployeeReadDto GetById(int id);

        /// <summary>
        /// �ھڭ��u�u�����o���u��ơC
        /// </summary>
        /// <param name="employeeId">���u�u���C</param>
        /// <returns>������ <see cref="EmployeeReadDto"/>�A�p�G�䤣��h�^�� null�C</returns>
        EmployeeReadDto GetByEmployeeId(string employeeId);

        /// <summary>
        /// �ھڳ����ѧO�X���o�ӳ������Ҧ����u��ơC
        /// </summary>
        /// <param name="departmentId">�������ߤ@�ѧO�X�C</param>
        /// <returns>�]�t�ӳ����Ҧ����u�� <see cref="IEnumerable{EmployeeReadDto}"/>�C</returns>
        IEnumerable<EmployeeReadDto> GetByDepartmentId(int departmentId);

        /// <summary>
        /// ���o�Ҧ��u�{�v�����u��ơC
        /// </summary>
        /// <returns>�]�t�Ҧ��u�{�v�� <see cref="IEnumerable{EmployeeReadDto}"/>�C</returns>
        IEnumerable<EmployeeReadDto> GetEngineers();

        /// <summary>
        /// ���o�Ҧ��ثe�b¾�����u��ơC
        /// </summary>
        /// <returns>�]�t�Ҧ��b¾���u�� <see cref="IEnumerable{EmployeeReadDto}"/>�C</returns>
        IEnumerable<EmployeeReadDto> GetActiveEmployees();

        /// <summary>
        /// �إ߷s�����u��ơC
        /// </summary>
        /// <param name="dto">�]�t���u��ƪ� <see cref="EmployeeReadDto"/>�C</param>
        /// <returns>�إߦ��\�����u��� <see cref="EmployeeReadDto"/>�C</returns>
        EmployeeReadDto Create(EmployeeReadDto dto);

        /// <summary>
        /// ��s�{�������u��ơC
        /// </summary>
        /// <param name="dto">�]�t��s���ƪ� <see cref="EmployeeReadDto"/>�C</param>
        void Update(EmployeeReadDto dto);

        /// <summary>
        /// �R�����w�ѧO�X�����u��ơC
        /// </summary>
        /// <param name="id">�n�R�������u�ߤ@�ѧO�X�C</param>
        void Delete(int id);
    }

    /// <summary>
    /// ���u�A�ȹ�@�C
    /// </summary>
    public class EmployeeService : IEmployeeService
    {
        private readonly Func<CoreContext> _contextFactory;
        private readonly ILogger _logger;

        /// <summary>
        /// ��l�� <see cref="EmployeeService"/> ���O���s�������C
        /// </summary>
        /// <param name="contextFactory">�Ω�إ߸�Ʈw�W�U�媺�u�t��k�C</param>
        /// <param name="logger">�Ω�O���� <see cref="ILogger"/> ��ҡC</param>
        public EmployeeService(Func<CoreContext> contextFactory, ILogger logger)
        {
            _contextFactory = contextFactory ?? throw new ArgumentNullException(nameof(contextFactory));
            _logger = logger?.ForContext<EmployeeService>() ?? Log.Logger.ForContext<EmployeeService>();
        }

        /// <inheritdoc/>
        public IEnumerable<EmployeeReadDto> GetAll()
        {
            using (var context = _contextFactory())
            {
                var repository = new EmployeeRepository(context, _logger);
                return repository.GetAll().ToDtoList();
            }
        }

        /// <inheritdoc/>
        public EmployeeReadDto GetById(int id)
        {
            using (var context = _contextFactory())
            {
                var repository = new EmployeeRepository(context, _logger);
                return repository.GetById(id)?.ToDto();
            }
        }

        /// <inheritdoc/>
        public EmployeeReadDto GetByEmployeeId(string employeeId)
        {
            using (var context = _contextFactory())
            {
                var repository = new EmployeeRepository(context, _logger);
                return repository.GetByEmployeeId(employeeId)?.ToDto();
            }
        }

        /// <inheritdoc/>
        public IEnumerable<EmployeeReadDto> GetByDepartmentId(int departmentId)
        {
            using (var context = _contextFactory())
            {
                var repository = new EmployeeRepository(context, _logger);
                return repository.GetByDepartmentId(departmentId).ToDtoList();
            }
        }

        /// <inheritdoc/>
        public IEnumerable<EmployeeReadDto> GetEngineers()
        {
            using (var context = _contextFactory())
            {
                var repository = new EmployeeRepository(context, _logger);
                return repository.GetEngineers().ToDtoList();
            }
        }

        /// <inheritdoc/>
        public IEnumerable<EmployeeReadDto> GetActiveEmployees()
        {
            using (var context = _contextFactory())
            {
                var repository = new EmployeeRepository(context, _logger);
                return repository.GetActiveEmployees().ToDtoList();
            }
        }

        /// <inheritdoc/>
        public EmployeeReadDto Create(EmployeeReadDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l�إ߭��u�G{EmployeeId}", dto.EmployeeId);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new EmployeeRepository(context, _logger);
                    var entity = dto.ToEntity();
                    var added = repository.Add(entity);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("���u�إߦ��\�G{EmployeeId}�AId={Id}", dto.EmployeeId, added.Id);
                    return added.ToDto();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "���u�إߥ��ѡG{EmployeeId}", dto.EmployeeId);
                    throw;
                }
            }
        }

        /// <inheritdoc/>
        public void Update(EmployeeReadDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l��s���u�GId={Id}", dto.Id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new EmployeeRepository(context, _logger);
                    var existing = repository.GetById(dto.Id);
                    if (existing == null)
                    {
                        throw new InvalidOperationException($"�䤣����u�AId={dto.Id}");
                    }

                    existing.EmployeeId = dto.EmployeeId;
                    existing.EmployeeName = dto.EmployeeName;
                    existing.DepartmentId = dto.DepartmentId;
                    existing.JobTitleId = dto.JobTitleId;
                    existing.IsEngineer = dto.IsEngineer;
                    existing.StatusId = dto.StatusId;
                    existing.StatusChangeAt = dto.StatusChangeAt;
                    existing.Email = dto.Email;

                    repository.Update(existing);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("���u��s���\�GId={Id}", dto.Id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "���u��s���ѡGId={Id}", dto.Id);
                    throw;
                }
            }
        }

        /// <inheritdoc/>
        public void Delete(int id)
        {
            _logger.Information("�}�l�R�����u�GId={Id}", id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new EmployeeRepository(context, _logger);
                    repository.DeleteById(id);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("���u�R�����\�GId={Id}", id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "���u�R�����ѡGId={Id}", id);
                    throw;
                }
            }
        }
    }
}
