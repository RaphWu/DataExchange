using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// WorkOrderEntity �� Fluent API �]�w�C
    /// </summary>
    public class WorkOrderEntityConfiguration : EntityTypeConfiguration<WorkOrderEntity>
    {
        public WorkOrderEntityConfiguration()
        {
            ToTable("WorkOrders");

            HasKey(w => w.Id);

            Property(w => w.WorkOrderNo)
                .IsRequired()
                .HasMaxLength(20);

            Property(w => w.Status)
                .IsRequired();

            Property(w => w.CreationDateTime)
                .IsRequired();

            Property(w => w.Responsible)
                .HasMaxLength(50);

            // WorkOrder -> Machine (�h��@�A�i�� null�A�� Context �ѷ�)
            HasOptional(w => w.Machine)
                .WithMany()
                .HasForeignKey(w => w.MachineId)
                .WillCascadeOnDelete(false);

            // WorkOrder -> Workstation (�h��@�A�i�� null�A�� Context �ѷ�)
            HasOptional(w => w.Workstation)
                .WithMany()
                .HasForeignKey(w => w.WorkstationId)
                .WillCascadeOnDelete(false);

            // WorkOrder -> Creator (�h��@�A����A�� Context �ѷ�)
            HasRequired(w => w.Creator)
                .WithMany()
                .HasForeignKey(w => w.CreatorId)
                .WillCascadeOnDelete(false);

            // WorkOrder -> MaintenanceUnit (�h��@�A�i�� null)
            HasOptional(w => w.MaintenanceUnit)
                .WithMany(mu => mu.WorkOrders)
                .HasForeignKey(w => w.MaintenanceUnitId)
                .WillCascadeOnDelete(false);

            // WorkOrder -> RequestingUnit (�h��@�A�i�� null�A�� Context �ѷ�)
            HasOptional(w => w.RequestingUnit)
                .WithMany()
                .HasForeignKey(w => w.RequestingUnitId)
                .WillCascadeOnDelete(false);
        }
    }
}
