using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MaintenanceRecordEngineer �� Fluent API �]�w�]���@���e�P�u�{�v�������^�C
    /// </summary>
    public class MaintenanceRecordEngineerConfiguration : EntityTypeConfiguration<MaintenanceRecordEngineer>
    {
        public MaintenanceRecordEngineerConfiguration()
        {
            ToTable("MaintenanceRecordEngineers");

            HasKey(mre => new { mre.MaintenanceRecordId, mre.EmployeeId });

            HasRequired(mre => mre.MaintenanceRecord)
                .WithMany(mr => mr.MaintenanceRecordEngineers)
                .HasForeignKey(mre => mre.MaintenanceRecordId)
                .WillCascadeOnDelete(false);

            // Engineer �O�� Context ���ѷӡA�ҥH���ϥ� WithMany
            HasRequired(mre => mre.Engineer)
                .WithMany()
                .HasForeignKey(mre => mre.EmployeeId)
                .WillCascadeOnDelete(false);
        }
    }
}
