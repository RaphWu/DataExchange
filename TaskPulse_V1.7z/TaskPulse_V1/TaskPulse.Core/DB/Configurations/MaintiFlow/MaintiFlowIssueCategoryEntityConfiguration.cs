using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MaintiFlowIssueCategoryEntity �� Fluent API �]�w�C
    /// </summary>
    public class MaintiFlowIssueCategoryEntityConfiguration : EntityTypeConfiguration<MaintiFlowIssueCategoryEntity>
    {
        public MaintiFlowIssueCategoryEntityConfiguration()
        {
            ToTable("MaintiFlowIssueCategories");

            HasKey(ic => ic.Id);

            Property(ic => ic.CategoryName)
                .HasMaxLength(30);
        }
    }
}
