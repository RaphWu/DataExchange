using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MaintenanceRecordEntity �� Fluent API �]�w�C
    /// </summary>
    public class MaintenanceRecordEntityConfiguration : EntityTypeConfiguration<MaintenanceRecordEntity>
    {
        public MaintenanceRecordEntityConfiguration()
        {
            ToTable("MaintenanceRecords");

            HasKey(mr => mr.Id);

            // MaintenanceRecord -> WorkOrder (�h��@�A����)
            HasRequired(mr => mr.WorkOrder)
                .WithMany(wo => wo.MaintenanceRecords)
                .HasForeignKey(mr => mr.WorkOrderId)
                .WillCascadeOnDelete(false);

            // MaintenanceRecord -> IssueCategory (�h��@�A�i�� null)
            HasOptional(mr => mr.IssueCategory)
                .WithMany()
                .HasForeignKey(mr => mr.IssueCategoryId)
                .WillCascadeOnDelete(false);

            // MaintenanceRecord -> FeedbackEmployee (�h��@�A�i�� null�A�� Context �ѷ�)
            HasOptional(mr => mr.FeedbackEmployee)
                .WithMany()
                .HasForeignKey(mr => mr.FeedbackEmployeeId)
                .WillCascadeOnDelete(false);
        }
    }
}
