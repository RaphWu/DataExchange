using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// EmployeeEntity �� Fluent API �]�w�C
    /// </summary>
    public class EmployeeEntityConfiguration : EntityTypeConfiguration<EmployeeEntity>
    {
        public EmployeeEntityConfiguration()
        {
            ToTable("Employees");

            HasKey(e => e.Id);

            Property(e => e.EmployeeId)
                .IsRequired()
                .HasMaxLength(6);

            Property(e => e.EmployeeName)
                .IsRequired()
                .HasMaxLength(20);

            Property(e => e.PasswordHash)
                .HasMaxLength(100);

            Property(e => e.Email)
                .HasMaxLength(100);

            // Employee -> Department (�h��@�A�i�� null)
            HasOptional(e => e.Department)
                .WithMany(d => d.Employees)
                .HasForeignKey(e => e.DepartmentId)
                .WillCascadeOnDelete(false);

            // Employee -> JobTitle (�h��@�A�i�� null)
            HasOptional(e => e.JobTitle)
                .WithMany(j => j.Employees)
                .HasForeignKey(e => e.JobTitleId)
                .WillCascadeOnDelete(false);

            // Employee -> EmployeeStatus (�h��@�A����)
            HasRequired(e => e.Status)
                .WithMany(s => s.Employees)
                .HasForeignKey(e => e.StatusId)
                .WillCascadeOnDelete(false);
        }
    }
}
