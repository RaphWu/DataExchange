using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// EmployeeGroup �� Fluent API �]�w�]���u�P�s�դ������^�C
    /// </summary>
    public class EmployeeGroupConfiguration : EntityTypeConfiguration<EmployeeGroup>
    {
        public EmployeeGroupConfiguration()
        {
            ToTable("EmployeeGroups");

            HasKey(eg => new { eg.EmployeeId, eg.GroupId });

            HasRequired(eg => eg.Employee)
                .WithMany(e => e.EmployeeGroups)
                .HasForeignKey(eg => eg.EmployeeId)
                .WillCascadeOnDelete(false);

            HasRequired(eg => eg.Group)
                .WithMany(g => g.EmployeeGroups)
                .HasForeignKey(eg => eg.GroupId)
                .WillCascadeOnDelete(false);
        }
    }
}
