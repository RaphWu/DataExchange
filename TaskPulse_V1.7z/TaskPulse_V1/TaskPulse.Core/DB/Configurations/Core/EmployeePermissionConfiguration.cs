using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// EmployeePermission �� Fluent API �]�w�]���u�P�v���������^�C
    /// </summary>
    public class EmployeePermissionConfiguration : EntityTypeConfiguration<EmployeePermission>
    {
        public EmployeePermissionConfiguration()
        {
            ToTable("EmployeePermissions");

            HasKey(ep => new { ep.EmployeeId, ep.PermissionId });

            HasRequired(ep => ep.Employee)
                .WithMany(e => e.EmployeePermissions)
                .HasForeignKey(ep => ep.EmployeeId)
                .WillCascadeOnDelete(false);

            HasRequired(ep => ep.Permission)
                .WithMany(p => p.EmployeePermissions)
                .HasForeignKey(ep => ep.PermissionId)
                .WillCascadeOnDelete(false);
        }
    }
}
