using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MachineAssetEntity �� Fluent API �]�w�C
    /// </summary>
    public class MachineAssetEntityConfiguration : EntityTypeConfiguration<MachineAssetEntity>
    {
        public MachineAssetEntityConfiguration()
        {
            ToTable("MachineAssets");

            HasKey(a => a.Id);

            Property(a => a.AssetCode)
                .IsRequired()
                .HasMaxLength(20);

            // MachineAsset -> Machine (�h��@�A���n)
            HasRequired(a => a.Machine)
                .WithMany(m => m.Assets)
                .HasForeignKey(a => a.MachineId)
                .WillCascadeOnDelete(true);
        }
    }
}
