using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MachineTypeEntity �� Fluent API �]�w�C
    /// </summary>
    public class MachineTypeEntityConfiguration : EntityTypeConfiguration<MachineTypeEntity>
    {
        public MachineTypeEntityConfiguration()
        {
            ToTable("MachineTypes");

            HasKey(mt => mt.Id);

            Property(mt => mt.TypeName)
                .HasMaxLength(30);

            // MachineType -> MachineCategory (�h��@�A�i�� null)
            HasOptional(mt => mt.Category)
                .WithMany(mc => mc.MachineTypes)
                .HasForeignKey(mt => mt.CategoryId)
                .WillCascadeOnDelete(false);
        }
    }
}
