using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// WorkstationEntity �� Fluent API �]�w�C
    /// </summary>
    public class WorkstationEntityConfiguration : EntityTypeConfiguration<WorkstationEntity>
    {
        public WorkstationEntityConfiguration()
        {
            ToTable("Workstations");

            HasKey(w => w.Id);

            Property(w => w.WorkstationName)
                .HasMaxLength(20);

            // Workstation -> Model (�h��@�A�i�� null)
            HasOptional(w => w.Model)
                .WithMany(m => m.Workstations)
                .HasForeignKey(w => w.ModelId)
                .WillCascadeOnDelete(false);
        }
    }
}
