using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MachineConditionEntity �� Fluent API �]�w�C
    /// </summary>
    public class MachineConditionConfiguration : EntityTypeConfiguration<MachineConditionEntity>
    {
        public MachineConditionConfiguration()
        {
            ToTable("MachineConditions");

            HasKey(c => c.Id);

            Property(c => c.ConditionName)
                .IsRequired()
                .HasMaxLength(20);
        }
    }
}
