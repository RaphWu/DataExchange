using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// ModelStatusEntity �� Fluent API �]�w�C
    /// </summary>
    public class ModelStatusEntityConfiguration : EntityTypeConfiguration<ModelStatusEntity>
    {
        public ModelStatusEntityConfiguration()
        {
            ToTable("ModelStatuses");

            HasKey(ms => ms.Id);

            Property(ms => ms.Status)
                .HasMaxLength(20);
        }
    }
}
