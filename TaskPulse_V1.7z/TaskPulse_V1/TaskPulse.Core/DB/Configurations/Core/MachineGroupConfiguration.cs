using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MachineGroup �� Fluent API �]�w�]���x�P�s�դ������^�C
    /// </summary>
    public class MachineGroupConfiguration : EntityTypeConfiguration<MachineGroup>
    {
        public MachineGroupConfiguration()
        {
            ToTable("MachineGroups");

            HasKey(mg => new { mg.MachineId, mg.GroupId });

            HasRequired(mg => mg.Machine)
                .WithMany(m => m.MachineGroups)
                .HasForeignKey(mg => mg.MachineId)
                .WillCascadeOnDelete(false);

            HasRequired(mg => mg.Group)
                .WithMany(g => g.MachineGroups)
                .HasForeignKey(mg => mg.GroupId)
                .WillCascadeOnDelete(false);
        }
    }
}
