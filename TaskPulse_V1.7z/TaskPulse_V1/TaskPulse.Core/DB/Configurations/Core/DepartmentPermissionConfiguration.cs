using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// DepartmentPermission �� Fluent API �]�w�]�����P�v���������^�C
    /// </summary>
    public class DepartmentPermissionConfiguration : EntityTypeConfiguration<DepartmentPermission>
    {
        public DepartmentPermissionConfiguration()
        {
            ToTable("DepartmentPermissions");

            HasKey(dp => new { dp.DepartmentId, dp.PermissionId });

            HasRequired(dp => dp.Department)
                .WithMany(d => d.DepartmentPermissions)
                .HasForeignKey(dp => dp.DepartmentId)
                .WillCascadeOnDelete(false);

            HasRequired(dp => dp.Permission)
                .WithMany(p => p.DepartmentPermissions)
                .HasForeignKey(dp => dp.PermissionId)
                .WillCascadeOnDelete(false);
        }
    }
}
