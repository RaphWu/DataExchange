using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MachineCategoryEntity �� Fluent API �]�w�C
    /// </summary>
    public class MachineCategoryEntityConfiguration : EntityTypeConfiguration<MachineCategoryEntity>
    {
        public MachineCategoryEntityConfiguration()
        {
            ToTable("MachineCategories");

            HasKey(mc => mc.Id);

            Property(mc => mc.CategoryName)
                .IsRequired()
                .HasMaxLength(30);
        }
    }
}
