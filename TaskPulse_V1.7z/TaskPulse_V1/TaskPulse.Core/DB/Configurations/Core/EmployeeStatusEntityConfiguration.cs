using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// EmployeeStatusEntity �� Fluent API �]�w�C
    /// </summary>
    public class EmployeeStatusEntityConfiguration : EntityTypeConfiguration<EmployeeStatusEntity>
    {
        public EmployeeStatusEntityConfiguration()
        {
            ToTable("EmployeeStatuses");

            HasKey(s => s.Id);

            Property(s => s.StatusName)
                .IsRequired()
                .HasMaxLength(20);
        }
    }
}
