using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Calin.TaskPulse.Entity.Core;
using Serilog;

namespace Calin.TaskPulse.Core.DB.Repositories
{
    /// <summary>
    /// ���x Repository �����C
    /// </summary>
    public interface IMachineRepository : IRepository<MachineEntity>
    {
        /// <summary>
        /// �ھھ��x�N�X���o���x����C
        /// </summary>
        /// <param name="machineCode">���x�N�X�C</param>
        /// <returns>���������x����C</returns>
        MachineEntity GetByMachineCode(string machineCode);

        /// <summary>
        /// �ھڪ��A ID ���o���x�M��C
        /// </summary>
        /// <param name="conditionId">���A ID�C</param>
        /// <returns>�ŦX���󪺾��x�M��C</returns>
        IEnumerable<MachineEntity> GetByConditionId(int conditionId);

        /// <summary>
        /// �ھڦ�m ID ���o���x�M��C
        /// </summary>
        /// <param name="locationId">��m ID�C</param>
        /// <returns>�ŦX���󪺾��x�M��C</returns>
        IEnumerable<MachineEntity> GetByLocationId(int locationId);

        /// <summary>
        /// ���o�Ҧ��ҥΤ������x�M��C
        /// </summary>
        /// <returns>�ҥΤ������x�M��C</returns>
        IEnumerable<MachineEntity> GetActiveMachines();
    }

    /// <summary>
    /// ���x Repository ��@�C
    /// </summary>
    public class MachineRepository : RepositoryBase<MachineEntity, CoreContext>, IMachineRepository
    {
        /// <summary>
        /// ��l�� <see cref="MachineRepository"/> ���O���s�������C
        /// </summary>
        /// <param name="context">��Ʈw�W�U��C</param>
        /// <param name="logger">�O�����C</param>
        public MachineRepository(CoreContext context, ILogger logger) : base(context, logger)
        {
        }

        /// <inheritdoc/>
        public override IEnumerable<MachineEntity> GetAll()
        {
            return DbSet
                .Include(m => m.MachineName)
                .Include(m => m.MachineType)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Assets)
                .Include(m => m.IssueCategory)
                .Where(m => !m.Disposal)
                .ToList();
        }

        /// <inheritdoc/>
        public override IEnumerable<MachineEntity> GetAllWithDisposal()
        {
            return DbSet
                .Include(m => m.MachineName)
                .Include(m => m.MachineType)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Assets)
                .Include(m => m.IssueCategory)
                .ToList();
        }

        /// <inheritdoc/>
        public override MachineEntity GetById(int id)
        {
            return DbSet
                .Include(m => m.MachineName)
                .Include(m => m.MachineType)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Assets)
                .Include(m => m.IssueCategory)
                .FirstOrDefault(m => m.Id == id);
        }

        /// <inheritdoc/>
        public MachineEntity GetByMachineCode(string machineCode)
        {
            return DbSet
                .Include(m => m.MachineName)
                .Include(m => m.MachineType)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Assets)
                .Include(m => m.IssueCategory)
                .FirstOrDefault(m => m.MachineCode == machineCode);
        }

        /// <inheritdoc/>
        public IEnumerable<MachineEntity> GetByConditionId(int conditionId)
        {
            return DbSet
                .Include(m => m.MachineName)
                .Include(m => m.MachineType)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Assets)
                .Include(m => m.IssueCategory)
                .Where(m => m.ConditionId == conditionId)
                .ToList();
        }

        /// <inheritdoc/>
        public IEnumerable<MachineEntity> GetByLocationId(int locationId)
        {
            return DbSet
                .Include(m => m.MachineName)
                .Include(m => m.MachineType)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Assets)
                .Include(m => m.IssueCategory)
                .Where(m => m.LocationId == locationId)
                .ToList();
        }

        /// <inheritdoc/>
        public IEnumerable<MachineEntity> GetActiveMachines()
        {
            return DbSet
                .Include(m => m.MachineName)
                .Include(m => m.MachineType)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Assets)
                .Include(m => m.IssueCategory)
                .Where(m => !m.Disposal)
                .ToList();
        }
    }
}
