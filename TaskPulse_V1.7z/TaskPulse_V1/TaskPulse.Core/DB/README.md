﻿# TaskPulse Database Module

## 介紹

TaskPulse Database 模組是 `Calin.TaskPulse.Core.DB` 命名空間下負責資料庫操作的子模組。它提供了資料存取層（Repositories）、資料傳輸物件（DTOs）、物件轉換器（Mappers）以及業務服務層（Services），以實現與資料庫的互動和業務邏輯處理。

### 整體架構流程圖

```mermaid
flowchart TB
UI["UI Layer<br/>(Form/Control)"]
Services["Services<br/>(業務服務層)"]
Mappers["Mappers<br/>(物件轉換器)"]
Repositories["Repositories<br/>(資料存取層)"]
Database["Database"]

UI -->|ViewModel| Services
Services -->|"Entity ↔ DTO"| Mappers
Mappers -->|Entity| Repositories
Repositories -->|SQL| Database

Services -.- S1["◄── 業務邏輯"]
Mappers -.- M1["◄── 物件轉換"]
Repositories -.- R1["◄── 資料存取"]
```

## 資料庫操作

位於命名空間 `Calin.TaskPulse.Core.DB`，包含以下內容：

### 設計重點提醒

| 模組 | 職責 | 注意事項 |
| --- | --- | --- |
| **Repository** | 資料存取 | 不處理業務邏輯，僅負責 CRUD |
| **DTO**        | 資料傳輸 | 不包含行為，純資料結構      |
| **Mapper**     | 物件轉換 | 轉換邏輯集中，便於維護      |
| **Service**    | 業務邏輯 | 協調各層，處理驗證與流程     |
| **ViewModel**  | UI 綁定  | 包含 UI 顯示邏輯與資料綁定屬性 |

### Repositories（資料存取層）

#### 說明

Repository 負責封裝資料庫存取邏輯，提供 CRUD 操作的抽象介面，使業務邏輯與資料存取解耦。

#### 使用方法

```csharp
// 定義 Repository 介面
public interface ITaskRepository
{
    Task<TaskEntity> GetByIdAsync(int id);
    Task<IEnumerable<TaskEntity>> GetAllAsync();
    Task<int> InsertAsync(TaskEntity entity);
    Task<bool> UpdateAsync(TaskEntity entity);
    Task<bool> DeleteAsync(int id);
}

// 實作 Repository
public class TaskRepository : ITaskRepository
{
    private readonly IDbConnection _connection;

    public TaskRepository(IDbConnection connection)
    {
        _connection = connection;
    }

    public async Task<TaskEntity> GetByIdAsync(int id)
    {
        const string sql = "SELECT * FROM Tasks WHERE Id = @Id";
        return await _connection.QueryFirstOrDefaultAsync<TaskEntity>(sql, new { Id = id });
    }
}
```

#### 使用情境

```csharp
public class TaskService
{
    private readonly ITaskRepository _taskRepository;

    public TaskService(ITaskRepository taskRepository)
    {
        _taskRepository = taskRepository;
    }

    public async Task<TaskDto> GetTaskAsync(int id)
    {
        var entity = await _taskRepository.GetByIdAsync(id);
        // 轉換為 DTO 回傳
    }
}
```

### DTOs（資料傳輸物件）

#### 說明

DTO 用於在應用層之間傳遞資料，與資料庫實體（Entity）分離，避免直接暴露資料庫結構。

#### 使用方法

```csharp
// 資料庫實體（內部使用）
public class TaskEntity
{
    public int Id { get; set; }
    public string TaskName { get; set; }
    public DateTime CreatedAt { get; set; }
    public int StatusCode { get; set; }
}

// DTO（對外傳輸）
public class TaskDto
{
    public int Id { get; set; }
    public string Name { get; set; }           // 命名更友善
    public string Status { get; set; }         // 轉換為可讀字串
    public string CreatedDate { get; set; }    // 格式化日期
}

// 輸入用 DTO
public class CreateTaskDto
{
    public string Name { get; set; }
    public string Description { get; set; }
}
```

#### 設計原則

| 類型 | 用途 | 範例 |
|------|------|------|
| Entity | 對應資料庫表格 | `TaskEntity` |
| DTO | Service 層傳輸 | `TaskDto` |
| CreateDto | 新增操作輸入 | `CreateTaskDto` |
| UpdateDto | 更新操作輸入 | `UpdateTaskDto` |
| ViewModel | UI 層綁定 | `TaskViewModel` |

### Mappers（物件轉換器）

#### 說明

Mapper 負責 Entity 與 DTO 之間的轉換，集中轉換邏輯，避免散落在各處。

#### 使用方法

```csharp
// 定義 Mapper 介面
public interface ITaskMapper
{
    TaskDto ToDto(TaskEntity entity);
    TaskEntity ToEntity(CreateTaskDto dto);
    IEnumerable<TaskDto> ToDtoList(IEnumerable<TaskEntity> entities);
}

// 實作 Mapper
public class TaskMapper : ITaskMapper
{
    public TaskDto ToDto(TaskEntity entity)
    {
        if (entity == null) return null;

        return new TaskDto
        {
            Id = entity.Id,
            Name = entity.TaskName,
            Status = ConvertStatus(entity.StatusCode),
            CreatedDate = entity.CreatedAt.ToString("yyyy-MM-dd")
        };
    }

    public TaskEntity ToEntity(CreateTaskDto dto)
    {
        return new TaskEntity
        {
            TaskName = dto.Name,
            CreatedAt = DateTime.Now,
            StatusCode = 0
        };
    }

    public IEnumerable<TaskDto> ToDtoList(IEnumerable<TaskEntity> entities)
    {
        return entities.Select(ToDto);
    }

    private string ConvertStatus(int code)
    {
        switch (code)
        {
            case 0: return "待處理";
            case 1: return "進行中";
            case 2: return "已完成";
            default: return "未知";
        }
    }
}
```

### Services（業務服務層）

#### 說明

Service 負責業務邏輯處理，協調 Repository、Mapper 與其他服務，是應用程式的核心。

#### 使用方法

```csharp
// 定義 Service 介面
public interface ITaskService
{
    Task<TaskDto> GetTaskByIdAsync(int id);
    Task<IEnumerable<TaskDto>> GetAllTasksAsync();
    Task<int> CreateTaskAsync(CreateTaskDto dto);
}

// 實作 Service
public class TaskService : ITaskService
{
    private readonly ITaskRepository _repository;
    private readonly ITaskMapper _mapper;
    private readonly ILogger _logger;

    public TaskService(
        ITaskRepository repository,
        ITaskMapper mapper,
        ILogger logger)
    {
        _repository = repository;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<TaskDto> GetTaskByIdAsync(int id)
    {
        _logger.Debug("取得任務 ID: {TaskId}", id);
        
        var entity = await _repository.GetByIdAsync(id);
        return _mapper.ToDto(entity);
    }

    public async Task<int> CreateTaskAsync(CreateTaskDto dto)
    {
        // 業務邏輯驗證
        if (string.IsNullOrWhiteSpace(dto.Name))
        {
            throw new ArgumentException("任務名稱不可為空");
        }

        var entity = _mapper.ToEntity(dto);
        var id = await _repository.InsertAsync(entity);

        using (LogContext.PushProperty("Category", LogCategories.Database))
        {
            _logger.Information("新增任務成功 ID: {TaskId}", id);
        }

        return id;
    }
}
```

### ViewModels（視圖模型）

詳見 `Calin.TaskPulse.Core.ViewModels/README.md`。

### Autofac 註冊範例

```csharp
public class CoreModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        // Repositories
        builder.RegisterType<TaskRepository>()
            .As<ITaskRepository>()
            .InstancePerLifetimeScope();

        // Mappers
        builder.RegisterType<TaskMapper>()
            .As<ITaskMapper>()
            .SingleInstance();

        // Services
        builder.RegisterType<TaskService>()
            .As<ITaskService>()
            .InstancePerLifetimeScope();
    }
}
