/*
MaintiFlow ��Ʈw�W�U��A�]�t�Ҧ� MaintiFlow �Ҳժ�����]�w�C
�ϥ� SQLite + Entity Framework 6 + Code First�C
*/

using System.Data.Entity;
using Calin.TaskPulse.Entity.MaintiFlow;
using SQLite.CodeFirst;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MaintiFlow ��Ʈw�W�U��C
    /// </summary>
    public class MaintiFlowContext : DbContext
    {
        /// <summary>
        /// ��l�� MaintiFlowContext�A�ϥ� App.config ���W�� "MaintiFlowContext" ���s�u�r��C
        /// </summary>
        public MaintiFlowContext() : base("name=MaintiFlowContext")
        {
        }

        #region DbSets

        public DbSet<WorkOrderEntity> WorkOrders { get; set; }
        public DbSet<MaintenanceRecordEntity> MaintenanceRecords { get; set; }
        public DbSet<MaintenanceRecordEngineer> MaintenanceRecordEngineers { get; set; }
        public DbSet<RepairPeriodEntity> RepairPeriods { get; set; }
        public DbSet<MaintenanceUnitEntity> MaintenanceUnits { get; set; }
        public DbSet<MaintiFlowIssueCategoryEntity> IssueCategories { get; set; }

        #endregion

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // SQLite Code First ��l�ƾ�
            var sqliteInitializer = new SqliteCreateDatabaseIfNotExists<MaintiFlowContext>(modelBuilder);
            Database.SetInitializer(sqliteInitializer);

            // �M�ΩҦ� Entity �]�w
            modelBuilder.Configurations.Add(new WorkOrderEntityConfiguration());
            modelBuilder.Configurations.Add(new MaintenanceRecordEntityConfiguration());
            modelBuilder.Configurations.Add(new MaintenanceRecordEngineerConfiguration());
            modelBuilder.Configurations.Add(new RepairPeriodEntityConfiguration());
            modelBuilder.Configurations.Add(new MaintenanceUnitEntityConfiguration());
            modelBuilder.Configurations.Add(new MaintiFlowIssueCategoryEntityConfiguration());

            base.OnModelCreating(modelBuilder);
        }
    }
}
