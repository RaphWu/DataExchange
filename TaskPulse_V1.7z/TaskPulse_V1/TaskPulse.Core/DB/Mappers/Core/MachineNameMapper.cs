using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB.Mappers
{
    /// <summary>
    /// ���� MachineNameEntity �P MachineNameDto �������M�g��k�C
    /// </summary>
    public static class MachineNameMapper
    {
        /// <summary>
        /// �N MachineNameEntity �ഫ�� MachineNameDto�C
        /// </summary>
        /// <param name="entity">�n�ഫ�� MachineNameEntity ��ҡC</param>
        /// <returns>�ഫ�᪺ MachineNameDto ��ҡA�Y��J�� null �h�^�� null�C</returns>
        public static MachineNameDto ToDto(this MachineNameEntity entity)
        {
            if (entity == null) return null;

            return new MachineNameDto
            {
                Id = entity.Id,
                OrderNo = entity.OrderNo,
                ModelName = entity.ModelName,
                TypeId = entity.TypeId,
                TypeName = entity.MachineType?.TypeName
            };
        }

        /// <summary>
        /// �N MachineNameDto �ഫ�� MachineNameEntity�C
        /// </summary>
        /// <param name="dto">�n�ഫ�� MachineNameDto ��ҡC</param>
        /// <returns>�ഫ�᪺ MachineNameEntity ��ҡA�Y��J�� null �h�^�� null�C</returns>
        public static MachineNameEntity ToEntity(this MachineNameDto dto)
        {
            if (dto == null) return null;

            return new MachineNameEntity
            {
                Id = dto.Id,
                OrderNo = dto.OrderNo,
                ModelName = dto.ModelName,
                TypeId = dto.TypeId
            };
        }

        /// <summary>
        /// �N MachineNameEntity ���X�ഫ�� MachineNameDto ���X�C
        /// </summary>
        /// <param name="entities">�n�ഫ�� MachineNameEntity ���X�C</param>
        /// <returns>�ഫ�᪺ MachineNameDto ���X�A�Y��J�� null �h�^�ǪŶ��X�C</returns>
        public static IEnumerable<MachineNameDto> ToDtoList(this IEnumerable<MachineNameEntity> entities)
        {
            return entities?.Select(e => e.ToDto()) ?? Enumerable.Empty<MachineNameDto>();
        }
    }
}
