﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB.Mappers
{
    /// <summary>
    /// 提供將 <see cref="EmployeeEntity"/> 和 <see cref="EmployeeReadDto"/> 之間進行轉換的靜態方法。
    /// </summary>
    public static class EmployeeMapper
    {
        /// <summary>
        /// 將 <see cref="EmployeeEntity"/> 轉換為 <see cref="EmployeeReadDto"/>。
        /// </summary>
        /// <param name="entity">要轉換的 <see cref="EmployeeEntity"/> 實例。</param>
        /// <returns>轉換後的 <see cref="EmployeeReadDto"/> 實例。如果輸入為 null，則返回 null。</returns>
        public static EmployeeReadDto ToDto(this EmployeeEntity entity)
        {
            if (entity == null) return null;

            var employeeId = entity.EmployeeId;
            var departmentName = entity.Department?.DepartmentName;
            var employeeName = entity.EmployeeName;

            return new EmployeeReadDto
            {
                Id = entity.Id,
                EmployeeId = employeeId,
                EmployeeName = employeeName,
                DepartmentId = entity.DepartmentId,
                DepartmentName = departmentName,
                JobTitleId = entity.JobTitleId,
                JobTitleName = entity.JobTitle?.JobTitleName,
                IsEngineer = entity.IsEngineer,
                StatusId = entity.StatusId,
                StatusName = entity.Status?.StatusName,
                StatusChangeAt = entity.StatusChangeAt,
                Email = entity.Email,

                FullName = string.Join(", ", new string[] { employeeId, departmentName, employeeName }),
                CarbonCopyString = string.Join(", ", entity.CarbonCopyRelations.Select(r => r.TargetEmployee.EmployeeName)),
                CarbonCopyList = entity.CarbonCopyRelations.Select(r => r.TargetEmployee.ToDto()).ToList(),
                IsEngineerString = entity.IsEngineer ? "是" : "",
                StatusChangeAtString = entity.StatusChangeAt?.ToString("yyyy/MM/dd") ?? "",
                DepartmentOrderNo = entity.Department?.OrderNo ?? int.MaxValue,
                JobTotleOrderNo = entity.JobTitle?.OrderNo ?? int.MaxValue,
            };
        }

        /// <summary>
        /// 將 <see cref="EmployeeReadDto"/> 轉換為 <see cref="EmployeeEntity"/>。
        /// </summary>
        /// <param name="dto">要轉換的 <see cref="EmployeeReadDto"/> 實例。</param>
        /// <returns>轉換後的 <see cref="EmployeeEntity"/> 實例。如果輸入為 null，則返回 null。</returns>
        public static EmployeeEntity ToEntity(this EmployeeReadDto dto)
        {
            if (dto == null) return null;

            return new EmployeeEntity
            {
                Id = dto.Id,
                EmployeeId = dto.EmployeeId,
                EmployeeName = dto.EmployeeName,
                DepartmentId = dto.DepartmentId,
                JobTitleId = dto.JobTitleId,
                IsEngineer = dto.IsEngineer,
                StatusId = dto.StatusId,
                StatusChangeAt = dto.StatusChangeAt,
                Email = dto.Email
            };
        }

        /// <summary>
        /// 將 <see cref="IEnumerable{EmployeeEntity}"/> 轉換為 <see cref="IEnumerable{EmployeeReadDto}"/>。
        /// </summary>
        /// <param name="entities">要轉換的 <see cref="IEnumerable{EmployeeEntity}"/> 集合。</param>
        /// <returns>轉換後的 <see cref="IEnumerable{EmployeeReadDto}"/> 集合。如果輸入為 null，則返回空集合。</returns>
        public static IEnumerable<EmployeeReadDto> ToDtoList(this IEnumerable<EmployeeEntity> entities)
        {
            return entities?.Select(e => e.ToDto()) ?? Enumerable.Empty<EmployeeReadDto>();
        }
    }
}
