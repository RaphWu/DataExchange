using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB.Mappers
{
    /// <summary>
    /// ���� JobTitleEntity �P JobTitleDto �������ഫ��k�C
    /// </summary>
    public static class JobTitleMapper
    {
        /// <summary>
        /// �N <see cref="JobTitleEntity"/> �ഫ�� <see cref="JobTitleDto"/>�C
        /// </summary>
        /// <param name="entity">�n�ഫ�� <see cref="JobTitleEntity"/> ��ҡC</param>
        /// <returns>�ഫ�᪺ <see cref="JobTitleDto"/> ��ҡF�p�G��J�� null�A�h�^�� null�C</returns>
        public static JobTitleDto ToDto(this JobTitleEntity entity)
        {
            if (entity == null) return null;

            return new JobTitleDto
            {
                Id = entity.Id,
                OrderNo = entity.OrderNo,
                JobTitleName = entity.JobTitleName
            };
        }

        /// <summary>
        /// �N <see cref="JobTitleDto"/> �ഫ�� <see cref="JobTitleEntity"/>�C
        /// </summary>
        /// <param name="dto">�n�ഫ�� <see cref="JobTitleDto"/> ��ҡC</param>
        /// <returns>�ഫ�᪺ <see cref="JobTitleEntity"/> ��ҡF�p�G��J�� null�A�h�^�� null�C</returns>
        public static JobTitleEntity ToEntity(this JobTitleDto dto)
        {
            if (dto == null) return null;

            return new JobTitleEntity
            {
                Id = dto.Id,
                OrderNo = dto.OrderNo,
                JobTitleName = dto.JobTitleName
            };
        }

        /// <summary>
        /// �N <see cref="IEnumerable{JobTitleEntity}"/> �ഫ�� <see cref="IEnumerable{JobTitleDto}"/>�C
        /// </summary>
        /// <param name="entities">�n�ഫ�� <see cref="JobTitleEntity"/> ���X�C</param>
        /// <returns>�ഫ�᪺ <see cref="JobTitleDto"/> ���X�F�p�G��J�� null�A�h�^�ǪŶ��X�C</returns>
        public static IEnumerable<JobTitleDto> ToDtoList(this IEnumerable<JobTitleEntity> entities)
        {
            return entities?.Select(e => e.ToDto()) ?? Enumerable.Empty<JobTitleDto>();
        }
    }
}
