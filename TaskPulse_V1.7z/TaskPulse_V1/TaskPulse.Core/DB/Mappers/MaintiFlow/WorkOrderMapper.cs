﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.DB.Mappers
{
    /// <summary>
    /// 提供 WorkOrderEntity 和 WorkOrderDto 之間的轉換方法。
    /// </summary>
    public static class WorkOrderMapper
    {
        /// <summary>
        /// 將 <see cref="WorkOrderEntity"/> 轉換為 <see cref="WorkOrderDto"/>。
        /// </summary>
        /// <param name="entity">要轉換的 <see cref="WorkOrderEntity"/> 實例。</param>
        /// <returns>轉換後的 <see cref="WorkOrderDto"/> 實例，若輸入為 null 則返回 null。</returns>
        public static WorkOrderDto ToDto(this WorkOrderEntity entity)
        {
            if (entity == null) return null;

            return new WorkOrderDto
            {
                Id = entity.Id,
                WorkOrderNo = entity.WorkOrderNo,
                Status = entity.Status,
                MachineId = entity.MachineId,
                MachineCode = entity.Machine?.MachineCode,
                WorkstationId = entity.WorkstationId,
                WorkstationName = entity.Workstation?.WorkstationName,
                CreatorId = entity.CreatorId,
                CreatorName = entity.Creator?.EmployeeName,
                CreationDateTime = entity.CreationDateTime,
                MaintenanceUnitId = entity.MaintenanceUnitId,
                MaintenanceUnitName = entity.MaintenanceUnit?.UnitName,
                AcceptedTime = entity.AcceptedTime,
                RequestingUnitId = entity.RequestingUnitId,
                RequestingUnitName = entity.RequestingUnit?.DepartmentName,
                Responsible = entity.Responsible,
                MaintenanceRecords = entity.MaintenanceRecords?.Select(r => r.ToDto()).ToList() ?? new List<MaintenanceRecordDto>()
            };
        }

        /// <summary>
        /// 將 <see cref="WorkOrderDto"/> 轉換為 <see cref="WorkOrderEntity"/>。
        /// </summary>
        /// <param name="dto">要轉換的 <see cref="WorkOrderDto"/> 實例。</param>
        /// <returns>轉換後的 <see cref="WorkOrderEntity"/> 實例，若輸入為 null 則返回 null。</returns>
        public static WorkOrderEntity ToEntity(this WorkOrderDto dto)
        {
            if (dto == null) return null;

            return new WorkOrderEntity
            {
                Id = dto.Id,
                WorkOrderNo = dto.WorkOrderNo,
                Status = dto.Status,
                MachineId = dto.MachineId,
                WorkstationId = dto.WorkstationId,
                CreatorId = dto.CreatorId,
                CreationDateTime = dto.CreationDateTime,
                MaintenanceUnitId = dto.MaintenanceUnitId,
                AcceptedTime = dto.AcceptedTime,
                RequestingUnitId = dto.RequestingUnitId,
                Responsible = dto.Responsible
            };
        }

        /// <summary>
        /// 將 <see cref="IEnumerable{WorkOrderEntity}"/> 轉換為 <see cref="IEnumerable{WorkOrderDto}"/>。
        /// </summary>
        /// <param name="entities">要轉換的 <see cref="IEnumerable{WorkOrderEntity}"/> 集合。</param>
        /// <returns>轉換後的 <see cref="IEnumerable{WorkOrderDto}"/> 集合，若輸入為 null 則返回空集合。</returns>
        public static IEnumerable<WorkOrderDto> ToDtoList(this IEnumerable<WorkOrderEntity> entities)
        {
            return entities?.Select(e => e.ToDto()) ?? Enumerable.Empty<WorkOrderDto>();
        }
    }
}
