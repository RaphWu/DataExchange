﻿using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// ProcessBar 顯示的進度條百分比。
    /// </summary>
    public class ProcessBarMessage : ValueChangedMessage<ProcessBarInfo>
    {
        public ProcessBarMessage(ProcessBarInfo info) : base(info) { }
    }
}
