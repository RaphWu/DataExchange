﻿namespace Calin.TaskPulse.Core.Permission
{
    /// <summary>
    /// 登入驗證。
    /// </summary>
    public interface IAuthService
    {
        /********************
         * AD認證服務
         ********************/
        /// <summary>
        /// LDAP伺服器AD認證服務。
        /// </summary>
        /// <param name="userName">使用者名稱。</param>
        /// <param name="password">密碼。</param>
        /// <returns>認證是否通過。</returns>
        bool ActiveDirectoryAsync(string userName, string password);
    }
}
