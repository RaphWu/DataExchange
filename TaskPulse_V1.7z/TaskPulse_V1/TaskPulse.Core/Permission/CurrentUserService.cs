﻿using System;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Services;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Permission
{
    public class CurrentUserService : ICurrentUserService
    {
        private readonly CurrentUserContext _user;
        private readonly IEmployeeService _employee;
        private readonly IPermissionService _permission;

        public CurrentUserService(
            CurrentUserContext currentUserContext,
            IEmployeeService employeeService,
            IPermissionService permissionService)
        {
            _user = currentUserContext;
            _employee = employeeService;
            _permission = permissionService;
        }

        /********************
         * Switch User
         ********************/
        /// <summary>
        /// 切換目前使用者並發送通知。
        /// </summary>
        private void SwitchCurrentUser()
        {
            _user.Permissions = _permission.GetFullPermissions(_user.CurrentUser?.EmployeeId ?? "");
            _ = WeakReferenceMessenger.Default.Send(NotifyCurrentUserChanged.Instance);

            if (_user.CurrentUser != null)
                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{_user.UserName} 已登入。"));
            else
                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("目前沒有使用者登入。"));
        }

        /// <inheritdoc/>
        public void SwitchCurrentUser(EmployeeReadDto employee)
        {
            _user.CurrentUser = _employee.GetById(employee.Id);
            SwitchCurrentUser();
        }

        /// <inheritdoc/>
        public void SwitchCurrentUser(int userId)
        {
            _user.CurrentUser = _employee.GetById(userId);
            SwitchCurrentUser();
        }

        /// <inheritdoc/>
        public void SwitchCurrentUser(string employeeId)
        {
            _user.CurrentUser = _employee.GetByEmployeeId(employeeId);
            SwitchCurrentUser();
        }

        /********************
         * 特定使用者
         ********************/
        /// <inheritdoc/>
        public void SwitchCurrentUserToGuest()
        {
            _user.SetGuest();
            _ = WeakReferenceMessenger.Default.Send(NotifyCurrentUserChanged.Instance);
            _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("目前為訪客權限。"));
        }

        /// <inheritdoc/>
        public void AdminLogin()
        {
            _user.SetAdmin();
            _ = WeakReferenceMessenger.Default.Send(NotifyCurrentUserChanged.Instance);
            _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("歡迎管理員。"));
        }
    }
}
