﻿# ViewModels（視圖模型）

## 介紹

ViewModel 用於 UI 層與 Service 層之間的資料綁定，包含 UI 顯示所需的屬性與格式化邏輯，是 MVVM 模式的核心組件。

```mermaid
flowchart TB
UI["UI Layer<br/>(Form/Control)"]
Services["Services<br/>(業務服務層)"]

UI -->|ViewModel| Services
```

## 說明

### DTO 與 ViewModel 的差異

| 特性 | DTO | ViewModel |
|------|-----|-----------|
| 用途 | Service 層之間傳輸資料 | UI 層資料綁定 |
| 行為 | 純資料，無邏輯 | 可包含顯示邏輯與命令 |
| 通知 | 無 | 實作 `INotifyPropertyChanged` 或<br>以 `CommunityToolkit.Mvvm` 套件實現 |
| 驗證 | 無 | 可包含 UI 驗證邏輯 |

#### 使用方法

```csharp
// ViewModel（UI 綁定用）
public class TaskViewModel : INotifyPropertyChanged
{
    private string _name;
    private string _status;
    private bool _isCompleted;

    public int Id { get; set; }

    public string Name
    {
        get => _name;
        set
        {
            _name = value;
            OnPropertyChanged(nameof(Name));
        }
    }

    public string Status
    {
        get => _status;
        set
        {
            _status = value;
            OnPropertyChanged(nameof(Status));
            OnPropertyChanged(nameof(StatusColor));
        }
    }

    public bool IsCompleted
    {
        get => _isCompleted;
        set
        {
            _isCompleted = value;
            OnPropertyChanged(nameof(IsCompleted));
        }
    }

    // UI 顯示邏輯
    public Color StatusColor
    {
        get
        {
            switch (Status)
            {
                case "已完成": return Color.Green;
                case "進行中": return Color.Orange;
                default: return Color.Gray;
            }
        }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}

// DTO 轉 ViewModel
public static class TaskViewModelExtensions
{
    public static TaskViewModel ToViewModel(this TaskDto dto)
    {
        return new TaskViewModel
        {
            Id = dto.Id,
            Name = dto.Name,
            Status = dto.Status,
            IsCompleted = dto.Status == "已完成"
        };
    }

    public static IEnumerable<TaskViewModel> ToViewModels(this IEnumerable<TaskDto> dtos)
    {
        return dtos.Select(d => d.ToViewModel());
    }
}
```

#### 使用情境

```csharp
public class TaskListForm : Form
{
    private readonly ITaskService _taskService;
    private BindingList<TaskViewModel> _tasks;

    public TaskListForm(ITaskService taskService)
    {
        _taskService = taskService;
    }

    private async void LoadTasks()
    {
        var dtos = await _taskService.GetAllTasksAsync();
        var viewModels = dtos.ToViewModels();
        
        _tasks = new BindingList<TaskViewModel>(viewModels.ToList());
        dataGridView.DataSource = _tasks;
    }
}
```
