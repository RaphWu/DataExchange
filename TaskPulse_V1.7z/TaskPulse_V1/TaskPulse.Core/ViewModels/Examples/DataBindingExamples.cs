/*
 * WinForm DataBinding �ϥνd��
 * ���ɮ׶ȨѰѦҡA�ܽd�p��b WinForm ���ϥ� ViewModel �i�� DataBinding�C
 */

#if DEBUG || OFFLINE
#pragma warning disable CS0649 // ������������쪺ĵ�i
#pragma warning disable CS0169 // �������ϥ���쪺ĵ�i

using System;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.DB.DTOs;

namespace Calin.TaskPulse.Core.ViewModels.Examples
{
    /// <summary>
    /// ���u�M�����d�ҡ]�ȨѰѦҡA���i��������^�C
    /// </summary>
    /// <remarks>
    /// ���d�Үi�ܦp��G
    /// 1. �z�L Autofac �`�J ViewModel
    /// 2. �N BindingList �j�w�� DataGridView
    /// 3. �N��@����j�w��ԲӪ���
    /// 4. �B�z Service �I�s�᪺ ViewModel ��s
    /// </remarks>
    public class EmployeeListFormExample : Form
    {
        private readonly EmployeeViewModel _viewModel;
        private readonly BindingSource _listBindingSource;
        private readonly BindingSource _detailBindingSource;

        // UI ����]��ڱM�פ��� Designer ���͡^
        private DataGridView dgvEmployees;
        private TextBox txtEmployeeId;
        private TextBox txtEmployeeName;
        private TextBox txtEmail;
        private ComboBox cmbDepartment;
        private CheckBox chkIsEngineer;
        private Button btnSave;
        private Button btnNew;
        private Button btnDelete;
        private Button btnRefresh;
        private Label lblStatus;

        /// <summary>
        /// �z�L Autofac �`�J ViewModel�C
        /// </summary>
        public EmployeeListFormExample(EmployeeViewModel viewModel)
        {
            _viewModel = viewModel ?? throw new ArgumentNullException(nameof(viewModel));

            // �إ� BindingSource
            _listBindingSource = new BindingSource();
            _detailBindingSource = new BindingSource();

            InitializeBindings();
            InitializeEventHandlers();
        }

        /// <summary>
        /// ��l�� DataBinding�C
        /// </summary>
        private void InitializeBindings()
        {
            // === �M��j�w ===
            // �N ViewModel �� Employees �j�w�� BindingSource
            _listBindingSource.DataSource = _viewModel.Employees;

            // �N BindingSource �j�w�� DataGridView
            dgvEmployees.DataSource = _listBindingSource;

            // �]�w DataGridView ���
            dgvEmployees.AutoGenerateColumns = false;
            dgvEmployees.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "EmployeeId",
                HeaderText = "�u��",
                Width = 80
            });
            dgvEmployees.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "EmployeeName",
                HeaderText = "�m�W",
                Width = 100
            });
            dgvEmployees.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "DepartmentName",
                HeaderText = "����",
                Width = 120
            });
            dgvEmployees.Columns.Add(new DataGridViewCheckBoxColumn
            {
                DataPropertyName = "IsEngineer",
                HeaderText = "�u�{�v",
                Width = 60
            });

            // === �ԲӪ���j�w ===
            // �N ViewModel �����@����ƨӷ��A�j�w SelectedEmployee
            _detailBindingSource.DataSource = _viewModel;
            _detailBindingSource.DataMember = "SelectedEmployee";

            // �N����j�w�� SelectedEmployee ���ݩ�
            txtEmployeeId.DataBindings.Add("Text", _detailBindingSource, "EmployeeId", true, DataSourceUpdateMode.OnPropertyChanged);
            txtEmployeeName.DataBindings.Add("Text", _detailBindingSource, "EmployeeName", true, DataSourceUpdateMode.OnPropertyChanged);
            txtEmail.DataBindings.Add("Text", _detailBindingSource, "Email", true, DataSourceUpdateMode.OnPropertyChanged);
            chkIsEngineer.DataBindings.Add("Checked", _detailBindingSource, "IsEngineer", true, DataSourceUpdateMode.OnPropertyChanged);

            // === ���A�j�w ===
            // �j�w���~�T��
            lblStatus.DataBindings.Add("Text", _viewModel, "ErrorMessage", true, DataSourceUpdateMode.OnPropertyChanged);

            // �ھ� IsLoading ���A���Ϋ��s
            _viewModel.PropertyChanged += (s, e) =>
            {
                if (e.PropertyName == nameof(EmployeeViewModel.IsLoading))
                {
                    var enabled = !_viewModel.IsLoading;
                    btnSave.Enabled = enabled;
                    btnNew.Enabled = enabled;
                    btnDelete.Enabled = enabled;
                    btnRefresh.Enabled = enabled;
                }
            };
        }

        /// <summary>
        /// ��l�ƨƥ�B�z�C
        /// </summary>
        private void InitializeEventHandlers()
        {
            // DataGridView ����ܧ� -> ��s SelectedEmployee
            dgvEmployees.SelectionChanged += (s, e) =>
            {
                if (dgvEmployees.CurrentRow?.DataBoundItem is EmployeeReadDto dto)
                {
                    _viewModel.SelectedEmployee = dto;
                }
            };

            // �s�W���s
            btnNew.Click += (s, e) =>
            {
                _viewModel.CreateNew();
                _detailBindingSource.ResetBindings(false);
            };

            // �x�s���s
            btnSave.Click += (s, e) =>
            {
                if (_viewModel.SelectedEmployee == null) return;

                if (_viewModel.SelectedEmployee.Id == 0)
                {
                    // �s�W
                    _viewModel.Create(_viewModel.SelectedEmployee);
                }
                else
                {
                    // ��s
                    _viewModel.Update(_viewModel.SelectedEmployee);
                }

                _listBindingSource.ResetBindings(false);
            };

            // �R�����s
            btnDelete.Click += (s, e) =>
            {
                if (_viewModel.SelectedEmployee?.Id > 0)
                {
                    if (MessageBox.Show("�T�w�n�R�������u�H", "�T�{", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        _viewModel.Delete(_viewModel.SelectedEmployee.Id);
                    }
                }
            };

            // ���s��z���s
            btnRefresh.Click += (s, e) =>
            {
                _viewModel.Refresh();
            };
        }

        /// <summary>
        /// ������J�ɸ��J��ơC
        /// </summary>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            _viewModel.LoadActiveEmployees();
        }
    }

    /// <summary>
    /// Autofac �e����l�ƽd�ҡC
    /// </summary>
    public static class AutofacSetupExample
    {
        private static IContainer _container;

        /// <summary>
        /// �b�{���i�J�I��l�� Autofac �e���C
        /// </summary>
        /// <example>
        /// <code>
        /// // Program.cs
        /// static void Main()
        /// {
        ///     // ��l�� Serilog
        ///     Log.Logger = SerilogConfiguration.CreateLogger("logs/taskpulse.log");
        ///     
        ///     // ��l�� Autofac
        ///     AutofacSetupExample.Initialize();
        ///     
        ///     Application.EnableVisualStyles();
        ///     Application.SetCompatibleTextRenderingDefault(false);
        ///     
        ///     // �ϥ� Autofac �ѪR�D����
        ///     using (var scope = AutofacSetupExample.Container.BeginLifetimeScope())
        ///     {
        ///         var mainForm = scope.Resolve&lt;MainForm&gt;();
        ///         Application.Run(mainForm);
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void Initialize()
        {
            var builder = new ContainerBuilder();

            // ���U Core �Ҳ�
            builder.RegisterModule<CoreModule>();

            // ���U Forms�]�p�G�ݭn�^
            // builder.RegisterType<MainForm>().AsSelf();
            // builder.RegisterType<EmployeeListForm>().AsSelf();

            _container = builder.Build();
        }

        /// <summary>
        /// ���o Autofac �e���C
        /// </summary>
        public static IContainer Container => _container;

        /// <summary>
        /// �b���椤�ѪR ViewModel ���d�ҡC
        /// </summary>
        /// <example>
        /// <code>
        /// // �b����غc�l�� OnLoad ��
        /// public partial class EmployeeForm : Form
        /// {
        ///     private readonly EmployeeViewModel _viewModel;
        ///     
        ///     // �z�L�غc�l�`�J�]���ˡ^
        ///     public EmployeeForm(EmployeeViewModel viewModel)
        ///     {
        ///         _viewModel = viewModel;
        ///         InitializeComponent();
        ///     }
        ///     
        ///     // �Φb OnLoad ���ϥ� Service Locator�]�����ˡA�����ɥ��n�^
        ///     protected override void OnLoad(EventArgs e)
        ///     {
        ///         base.OnLoad(e);
        ///         using (var scope = AutofacSetupExample.Container.BeginLifetimeScope())
        ///         {
        ///             var viewModel = scope.Resolve&lt;EmployeeViewModel&gt;();
        ///             // �ϥ� viewModel...
        ///         }
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void ExampleUsage()
        {
            // ����k�Ȩѥܽd�A������کI�s
        }
    }
}

#endif