using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Services;
using Serilog;

namespace Calin.TaskPulse.Core.ViewModels
{
    /// <summary>
    /// ���u ViewModel�A�䴩�浧����P�M�檺 WinForm DataBinding�C
    /// </summary>
    public class EmployeeViewModel : ViewModelBase
    {
        private readonly IEmployeeService _employeeService;
        private readonly ILogger _logger;

        private EmployeeReadDto _selectedEmployee;
        private BindingList<EmployeeReadDto> _employees;
        private bool _isLoading;
        private string _errorMessage;

        /// <summary>
        /// ��l�� EmployeeViewModel�C
        /// </summary>
        /// <param name="employeeService">���u�A�ȡC</param>
        /// <param name="logger">��x�O�����C</param>
        public EmployeeViewModel(IEmployeeService employeeService, ILogger logger)
        {
            _employeeService = employeeService ?? throw new ArgumentNullException(nameof(employeeService));
            _logger = logger?.ForContext<EmployeeViewModel>() ?? Log.Logger.ForContext<EmployeeViewModel>();
            _employees = new BindingList<EmployeeReadDto>();
        }

        #region �ݩ�

        /// <summary>
        /// �ثe��������u�C
        /// </summary>
        public EmployeeReadDto SelectedEmployee
        {
            get => _selectedEmployee;
            set
            {
                if (SetProperty(ref _selectedEmployee, value))
                {
                    _logger.Debug("������u�ܧ�G{EmployeeName}", value?.EmployeeName);
                }
            }
        }

        /// <summary>
        /// ���u�M��]�䴩 DataBinding�^�C
        /// </summary>
        public BindingList<EmployeeReadDto> Employees
        {
            get => _employees;
            private set => SetProperty(ref _employees, value);
        }

        /// <summary>
        /// �O�_���b���J��ơC
        /// </summary>
        public bool IsLoading
        {
            get => _isLoading;
            private set => SetProperty(ref _isLoading, value);
        }

        /// <summary>
        /// ���~�T���C
        /// </summary>
        public string ErrorMessage
        {
            get => _errorMessage;
            private set => SetProperty(ref _errorMessage, value);
        }

        /// <summary>
        /// �O�_�����~�C
        /// </summary>
        public bool HasError => !string.IsNullOrEmpty(ErrorMessage);

        #endregion

        #region �ާ@��k

        /// <summary>
        /// ���J�Ҧ����u�C
        /// </summary>
        public void LoadAll()
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J�Ҧ����u");
                var employees = _employeeService.GetAll().ToList();
                RefreshEmployeeList(employees);
                _logger.Information("���J�����A�@ {Count} �W���u", employees.Count);
            });
        }

        /// <summary>
        /// ���J�b¾���u�C
        /// </summary>
        public void LoadActiveEmployees()
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J�b¾���u");
                var employees = _employeeService.GetActiveEmployees().ToList();
                RefreshEmployeeList(employees);
                _logger.Information("���J�����A�@ {Count} �W�b¾���u", employees.Count);
            });
        }

        /// <summary>
        /// ���J�u�{�v�C
        /// </summary>
        public void LoadEngineers()
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J�u�{�v");
                var employees = _employeeService.GetEngineers().ToList();
                RefreshEmployeeList(employees);
                _logger.Information("���J�����A�@ {Count} �W�u�{�v", employees.Count);
            });
        }

        /// <summary>
        /// �̳������J���u�C
        /// </summary>
        /// <param name="departmentId">���� Id�C</param>
        public void LoadByDepartment(int departmentId)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J���� {DepartmentId} �����u", departmentId);
                var employees = _employeeService.GetByDepartmentId(departmentId).ToList();
                RefreshEmployeeList(employees);
                _logger.Information("���J�����A�@ {Count} �W���u", employees.Count);
            });
        }

        /// <summary>
        /// �� Id ���J���u�C
        /// </summary>
        /// <param name="id">���u�D��C</param>
        public void LoadById(int id)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J���u Id={Id}", id);
                SelectedEmployee = _employeeService.GetById(id);
                if (SelectedEmployee != null)
                {
                    _logger.Information("���J���u���\�G{EmployeeName}", SelectedEmployee.EmployeeName);
                }
                else
                {
                    _logger.Warning("�䤣����u Id={Id}", id);
                }
            });
        }

        /// <summary>
        /// �̤u�����J���u�C
        /// </summary>
        /// <param name="employeeId">�u���C</param>
        public void LoadByEmployeeId(string employeeId)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J���u EmployeeId={EmployeeId}", employeeId);
                SelectedEmployee = _employeeService.GetByEmployeeId(employeeId);
                if (SelectedEmployee != null)
                {
                    _logger.Information("���J���u���\�G{EmployeeName}", SelectedEmployee.EmployeeName);
                }
                else
                {
                    _logger.Warning("�䤣����u EmployeeId={EmployeeId}", employeeId);
                }
            });
        }

        /// <summary>
        /// �s�W���u�C
        /// </summary>
        /// <param name="dto">���u��ơC</param>
        /// <returns>�s�W�᪺���u�C</returns>
        public EmployeeReadDto Create(EmployeeReadDto dto)
        {
            EmployeeReadDto result = null;
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l�s�W���u�G{EmployeeId}", dto.EmployeeId);
                result = _employeeService.Create(dto);
                Employees.Add(result);
                SelectedEmployee = result;
                _logger.Information("�s�W���u���\�GId={Id}", result.Id);
            });
            return result;
        }

        /// <summary>
        /// ��s���u�C
        /// </summary>
        /// <param name="dto">���u��ơC</param>
        public void Update(EmployeeReadDto dto)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l��s���u�GId={Id}", dto.Id);
                _employeeService.Update(dto);

                // ��s�M�椤������
                var index = FindEmployeeIndex(dto.Id);
                if (index >= 0)
                {
                    Employees[index] = dto;
                }
                SelectedEmployee = dto;
                _logger.Information("��s���u���\�GId={Id}", dto.Id);
            });
        }

        /// <summary>
        /// �R�����u�C
        /// </summary>
        /// <param name="id">���u Id�C</param>
        public void Delete(int id)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l�R�����u�GId={Id}", id);
                _employeeService.Delete(id);

                // �q�M�椤����
                var index = FindEmployeeIndex(id);
                if (index >= 0)
                {
                    Employees.RemoveAt(index);
                }

                if (SelectedEmployee?.Id == id)
                {
                    SelectedEmployee = null;
                }
                _logger.Information("�R�����u���\�GId={Id}", id);
            });
        }

        /// <summary>
        /// ���s��z�M��C
        /// </summary>
        public void Refresh()
        {
            LoadAll();
        }

        /// <summary>
        /// �M������C
        /// </summary>
        public void ClearSelection()
        {
            SelectedEmployee = null;
            _logger.Debug("�w�M�����u���");
        }

        /// <summary>
        /// �إ߷s���ťխ��u�]�Ω�s�W�ɡ^�C
        /// </summary>
        public void CreateNew()
        {
            SelectedEmployee = new EmployeeReadDto
            {
                StatusId = 1 // �w�]�b¾
            };
            _logger.Debug("�w�إ߷s���ťխ��u");
        }

        #endregion

        #region �p����k

        private void RefreshEmployeeList(List<EmployeeReadDto> employees)
        {
            Employees.RaiseListChangedEvents = false;
            Employees.Clear();
            foreach (var employee in employees)
            {
                Employees.Add(employee);
            }
            Employees.RaiseListChangedEvents = true;
            Employees.ResetBindings();
        }

        private int FindEmployeeIndex(int id)
        {
            for (int i = 0; i < Employees.Count; i++)
            {
                if (Employees[i].Id == id) return i;
            }
            return -1;
        }

        private void ExecuteWithLoading(Action action)
        {
            IsLoading = true;
            ErrorMessage = null;
            try
            {
                action();
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
                _logger.Error(ex, "�ާ@�o�Ϳ��~");
            }
            finally
            {
                IsLoading = false;
                OnPropertyChanged(nameof(HasError));
            }
        }

        #endregion
    }
}
