﻿using System;
using Autofac;
using Calin.Infrastructure;
using Calin.TaskPulse.Core.DB;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Permission;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Core.Views;

namespace Calin.TaskPulse.Core
{
    /// <summary>
    /// Core 模組的 Autofac 註冊。
    /// </summary>
    public class CoreModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            SplashMessenger.Post("註冊框架模組...");
            builder.RegisterModule<CalinFrameworkModule>();

            SplashMessenger.Post("註冊資料庫服務...");
            builder.RegisterModule<DbModule>();

            SplashMessenger.Post("載入核心模組...");

            // public data
            builder.RegisterType<CoreData>().SingleInstance();
            builder.RegisterType<CurrentUserContext>().SingleInstance();

            // Services
            builder.RegisterType<MemoryCacheService>().SingleInstance();
            builder.RegisterType<AuthService>().As<IAuthService>().SingleInstance();
            builder.RegisterType<PermissionService>().As<IPermissionService>().InstancePerLifetimeScope();
            builder.RegisterType<CurrentUserService>().As<ICurrentUserService>().InstancePerDependency();

            // dialogs (ExternallyOwned)
            builder.RegisterType<LoginControl>().ExternallyOwned();
            builder.RegisterType<CRUD>().ExternallyOwned();
            builder.RegisterType<MultiSelector>().ExternallyOwned();
            //builder.RegisterType<MachineEdit>().ExternallyOwned();
            builder.RegisterType<LoadingDialog>().ExternallyOwned();

            // ViewModels (InstancePerDependency)
            builder.RegisterType<EmployeeViewModel>().AsSelf().InstancePerDependency();
            builder.RegisterType<MachineViewModel>().AsSelf().InstancePerDependency();
            builder.RegisterType<WorkOrderViewModel>().AsSelf().InstancePerDependency();

            // Views (InstancePerLifetimeScope)
            builder.RegisterType<SetupPage>().InstancePerLifetimeScope();
        }
    }
}
