﻿using System.Drawing;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.WinForms
{
    public static class UISettings
    {
        public static readonly Font DefaultFont = new Font("Microsoft JhengHei", 11f);

        public static readonly Font DefaultToolStripFont = new Font("Microsoft JhengHei", 9f);

        public static void ApplyGlobalFont(Control ctrl)
        {
            if (ctrl == null)
            {
                return;
            }

            if (ctrl.Font == Control.DefaultFont)
            {
                ctrl.Font = DefaultFont;
            }

            if (ctrl is ToolStrip toolStrip)
            {
                foreach (ToolStripItem item in toolStrip.Items)
                {
                    if (item.Font == Control.DefaultFont)
                    {
                        item.Font = DefaultFont;
                    }
                }
            }

            if (ctrl is ListView listView && listView.Font == Control.DefaultFont)
            {
                listView.Font = DefaultFont;
            }

            if (ctrl is TreeView treeView)
            {
                if (treeView.Font == Control.DefaultFont)
                {
                    treeView.Font = DefaultFont;
                }

                foreach (TreeNode node in treeView.Nodes)
                {
                    ApplyFontToTreeNode(node);
                }
            }

            if (ctrl is DataGridView dataGridView)
            {
                if (dataGridView.DefaultCellStyle.Font == null || dataGridView.DefaultCellStyle.Font == Control.DefaultFont)
                {
                    dataGridView.DefaultCellStyle.Font = DefaultFont;
                }

                if (dataGridView.ColumnHeadersDefaultCellStyle.Font == null || dataGridView.ColumnHeadersDefaultCellStyle.Font == Control.DefaultFont)
                {
                    dataGridView.ColumnHeadersDefaultCellStyle.Font = DefaultFont;
                }

                if (dataGridView.RowHeadersDefaultCellStyle.Font == null || dataGridView.RowHeadersDefaultCellStyle.Font == Control.DefaultFont)
                {
                    dataGridView.RowHeadersDefaultCellStyle.Font = DefaultFont;
                }

                if (dataGridView.RowsDefaultCellStyle.Font == null || dataGridView.RowsDefaultCellStyle.Font == Control.DefaultFont)
                {
                    dataGridView.RowsDefaultCellStyle.Font = DefaultFont;
                }
            }

            if (ctrl is ListBox listBox && listBox.Font == Control.DefaultFont)
            {
                listBox.Font = DefaultFont;
            }

            if (ctrl is ComboBox comboBox && comboBox.Font == Control.DefaultFont)
            {
                comboBox.Font = DefaultFont;
            }

            if (ctrl is TabControl tabControl && tabControl.Font == Control.DefaultFont)
            {
                tabControl.Font = DefaultFont;
            }

            foreach (Control control in ctrl.Controls)
            {
                ApplyGlobalFont(control);
            }
        }

        private static void ApplyFontToTreeNode(TreeNode node)
        {
            if (node.NodeFont == null || node.NodeFont == Control.DefaultFont)
            {
                node.NodeFont = DefaultFont;
            }

            foreach (TreeNode node2 in node.Nodes)
            {
                ApplyFontToTreeNode(node2);
            }
        }
    }
}
