﻿using System.Windows.Forms;
using Calin.Infrastructure.Navigation;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.SharedUI;

namespace Calin.TaskPulse.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class MainPage : UserControl
    {
        public MainPage(IRegionManager region, INavigationService nav)
        {
            InitializeComponent();

            region.RegisterRegion(nameof(LoginPanel), null);
            nav.NavigateTo<LoginControl>(nameof(LoginPanel), (int)PageCode.Login);

            if (region.GetRegion(nameof(LoginPanel)).ActiveView is UserControl ctl)
            {
                ctl.Dock = DockStyle.None;
                ctl.Anchor = AnchorStyles.None;
            }
        }
    }
}
