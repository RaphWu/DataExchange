﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.Infrastructure.Coordination;
using Calin.Infrastructure.Logging;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Logging;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.MaintiFlow;
using Calin.TaskPulse.MechaTrack;
using Calin.TaskPulse.ToolQuest;
using Calin.TaskPulse.Views;
using Serilog;

namespace Calin.TaskPulse
{
    /// <summary>
    /// 表示應用程式的啟動上下文，負責初始化應用程式並管理其生命週期。
    /// </summary>
    public sealed class AppStartupContext : ApplicationContext
    {
        private readonly CancellationTokenSource _cts = new CancellationTokenSource();
        private readonly SplashScreen _splash;
        private IContainer _container;

        /// <summary>
        /// 初始化 <see cref="ApplicationContext"/> 類別的新執行個體。
        /// </summary>
        public AppStartupContext()
        {
            // 顯示啟動畫面
            _splash = new SplashScreen();
            _splash.AbortClicked += Splash_AbortClicked;
            _splash.Show();
            _splash.Refresh();

            SplashMessenger.Post("程式初始化開始...");
            using (LogContextExtensions.WithSystem())
            {
                Log.Information("TaskPulse 啟動");
            }
            StartInitialization();
        }

        /// <summary>
        /// 開始初始化應用程式的核心邏輯。
        /// </summary>
        private void StartInitialization()
        {
            // 在背景執行緒中初始化應用程式
            _ = Task.Run(() =>
            {
                try
                {
                    // 初始化日誌服務，必須最先執行
                    SplashMessenger.Post("初始化日誌服務...");
                    LoggingBootstrapper.Initialize(new LoggingOptions
                    {
                        LogDirectory = "logs",
                        ApplicationName = "TaskPulse"
                    });

                    // 初始化核心模組
                    InitializeCore(_cts.Token);

                    if (_cts.IsCancellationRequested)
                        return;

                    SplashMessenger.Post("初始化完成，準備啟動主畫面...");
                    Thread.Sleep(1200);

                    // 回到 UI Thread 顯示 MainForm
                    _splash.BeginInvoke(new Action(() =>
                    {
                        var mainForm = _container.Resolve<MainForm>();
                        mainForm.FormClosed += MainForm_FormClosed;

                        MainForm = mainForm;
                        _splash.Close();
                        mainForm.Show();
                        mainForm.Activate();
                    }));
                }
                catch (OperationCanceledException)
                {
                    Log.Information("應用程式初始化已取消!");
                    using (LogContextExtensions.WithSystem())
                    {
                        Log.Information("TaskPulse 由 CancellationTokenSource 結束");
                    }

                    ExitOnUiThread();
                }
                catch (Exception ex)
                {
                    Log.Fatal(ex, "應用程式發生未處理的例外!");
                    using (LogContextExtensions.WithSystem())
                    {
                        Log.Information($"TaskPulse異常結束!\n\n{ex.Message}");
                    }

                    ShowErrorAndExit(ex.Message);
                }
                finally
                {
                    // 關閉日誌系統
                    LoggingBootstrapper.Shutdown();
                }
            }, _cts.Token);
        }

        /// <summary>
        /// 初始化應用程式的核心模組和依賴項。
        /// </summary>
        /// <param name="token">用於取消操作的 <see cref="CancellationToken"/>。</param>
        private void InitializeCore(CancellationToken token)
        {
            token.ThrowIfCancellationRequested();

            // 初始化 DI 容器
            var builder = new ContainerBuilder();
            builder.RegisterType<MainForm>();
            builder.RegisterModule<CoordinationModule>();
            builder.RegisterModule<LoggingModule>();
            builder.RegisterModule<CoreModule>();
            builder.RegisterModule<MainModule>();
            builder.RegisterModule<MaintiFlowModule>();
            builder.RegisterModule<MechaTrackModule>();
            builder.RegisterModule<ToolQuestMoudle>();

            token.ThrowIfCancellationRequested();

            _container = builder.Build();
        }

        /// <summary>
        /// 處理啟動退出事件，並執行應用程式的關閉邏輯。
        /// </summary>
        private void Splash_AbortClicked(object sender, EventArgs e)
        {
            _cts.Cancel(); // 如果初始化還在跑，取消它
            Shutdown();
        }

        /// <summary>
        /// 處理主視窗關閉事件，並執行應用程式的關閉邏輯。
        /// </summary>
        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            using (LogContextExtensions.WithSystem())
            {
                Log.Information("TaskPulse正常結束");
            }

            Shutdown();
        }

        /// <summary>
        /// 關閉應用程式，釋放資源並停止所有操作。
        /// </summary>
        private void Shutdown()
        {
            // 取消初始化或背景 Task
            _cts.Cancel();

            _container?.Dispose();
            LoggingBootstrapper.Shutdown();

            // 解除 Splash
            if (_splash != null && !_splash.IsDisposed)
            {
                _splash.AbortClicked -= Splash_AbortClicked;
                _splash.Close();
                _splash.Dispose();
            }

            // 釋放 CTS
            _cts.Dispose();

            ExitThread();
        }

        /// <summary>
        /// 在 UI 執行緒上退出應用程式。
        /// </summary>
        private void ExitOnUiThread()
        {
            _splash.BeginInvoke(new Action(ExitThread));
        }

#pragma warning disable IDE0060 // 移除未使用的參數
        /// <summary>
        /// 顯示錯誤訊息並退出應用程式。
        /// </summary>
        /// <param name="message">要顯示的錯誤訊息。</param>
        private void ShowErrorAndExit(string message)
        {
            _splash.BeginInvoke(new Action(() =>
            {
                //MessageBox.Show(message, "啟動失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Shutdown();
            }));
        }
#pragma warning restore IDE0060 // 移除未使用的參數
    }
}
