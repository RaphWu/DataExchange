using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Automation.BDaq;

namespace AI_StreamingAI
{
    public partial class StreamingAIForm : Form
    {
        #region fields  
        SimpleGraph m_simpleGraph;
        TimeUnit m_timeUnit;
        double[] m_dataScaled;
        double m_divideValue;
        bool m_isFirstOverRun = true;
        double m_xInc;
        ValueRange m_valueRange;
        #endregion

        public StreamingAIForm()
        {
            InitializeComponent();
        }

        public StreamingAIForm(int deviceNumber)
        {
            InitializeComponent();
            //waveformAiCtrl1.SelectedDevice = new DeviceInformation(deviceNumber);
            waveformAiCtrl1.SelectedDevice = new DeviceInformation("USB-4704,BID#0");
        }

        private void StreamingBufferedAiForm_Load(object sender, EventArgs e)
        {
            //The default device of project is demo device, users can choose other devices according to their needs. 
            if (!waveformAiCtrl1.Initialized)
            {
                MessageBox.Show("No device be selected or device open failed!", "StreamingAI");
                this.Close();
                return;
            }

            //initialize a graph with a picture box control to draw Ai data. 
            m_simpleGraph = new SimpleGraph(pictureBox.Size, pictureBox);

            int chanCount = waveformAiCtrl1.Conversion.ChannelCount;
            int sectionLength = waveformAiCtrl1.Record.SectionLength;
            m_dataScaled = new double[chanCount * sectionLength];

            this.Text = "Streaming AI(" + waveformAiCtrl1.SelectedDevice.Description + ")";

            button_start.Enabled = true;
            button_stop.Enabled = false;
            button_pause.Enabled = false;

            //m_valueRange = waveformAiCtrl1.Channels[waveformAiCtrl1.Conversion.ChannelStart].ValueRange;
            //m_valueRange = ValueRange.V_Neg5To5;
            //m_valueRange = ValueRange.mV_0To100;
            m_valueRange = ValueRange.mV_Neg50To50;

            ConfigureGraph();
            InitListView();
        }

        private void ConfigureGraph()
        {
            m_timeUnit = TimeUnit.Millisecond;
            double conversionRate = waveformAiCtrl1.Conversion.ClockRate;
            double timeInterval = 100.0 * pictureBox.Size.Width / conversionRate;
            while (conversionRate >= 10 * 1000)
            {
                timeInterval *= 1000;
                conversionRate /= 1000;
                --m_timeUnit;
            }

            m_divideValue = timeInterval;
            int divValue = (int)Math.Floor(timeInterval);
            trackBar_div.Maximum = 4 * divValue; // 1 pixel to 4 data points
            trackBar_div.Minimum = (int)Math.Ceiling(1.0 * divValue / 10);
            trackBar_div.Value = divValue;

            m_simpleGraph.XCordTimeDiv = trackBar_div.Value;
            m_simpleGraph.XCordTimeOffset = 0;

            SetXCordRangeLabels();

            MathInterval rangeY;
            ValueUnit unit;
            BDaqApi.AdxGetValueRangeInformation(m_valueRange, 0, null, out rangeY, out unit);

            string[] Y_CordLables = new string[3];
            Helpers.GetYCordRangeLabels(Y_CordLables, rangeY.Max, rangeY.Min, unit);
            label_YCoordinateMax.Text = Y_CordLables[0];
            label_YCoordinateMin.Text = Y_CordLables[1];
            label_YCoordinateMiddle.Text = Y_CordLables[2];

            m_simpleGraph.YCordRangeMax = rangeY.Max;
            m_simpleGraph.YCordRangeMin = rangeY.Min;
            m_simpleGraph.Clear();

        }

        private void InitListView()
        {
            // listview control ,one grid indicates a channel which specials with color.
            listView.Clear();
            listView.FullRowSelect = false;
            listView.Width = 352;
            listView.Height = 43;
            listView.View = View.Details;// Set the view to show details.
            listView.HeaderStyle = ColumnHeaderStyle.None;
            listView.GridLines = true;
            // there are 8 columns for every item.
            for (int i = 0; i < 8; i++)
            {
                listView.Columns.Add("", 43);
            }

            // modify the grid's height with image Indirectly.
            ImageList imgList = new ImageList();
            imgList.ImageSize = new Size(1, 13);//width and height.
            listView.SmallImageList = imgList; //use imgList to modify the height of listView grids.

            // create two ListViewItem objects,so there are 16 grids for listView.
            ListViewItem firstItem;
            ListViewItem secondItem;

            firstItem = new ListViewItem();
            firstItem.UseItemStyleForSubItems = false;
            firstItem.SubItems.Clear();

            secondItem = new ListViewItem();
            secondItem.UseItemStyleForSubItems = false;
            secondItem.SubItems.Clear();

            // format every grid for output.
            firstItem.SubItems[0].Text = "";
            firstItem.SubItems[0].BackColor = m_simpleGraph.Pens[0].Color;
            for (int i = 1; i < 8; i++)
            {

                if (i < waveformAiCtrl1.Conversion.ChannelCount)
                {
                    firstItem.SubItems.Add((""), Color.Black, Color.Honeydew, new Font("SimSun", 10));
                    firstItem.SubItems[i].BackColor = m_simpleGraph.Pens[i].Color;
                }
                else
                {

                    firstItem.SubItems.Add("");
                    firstItem.SubItems[i].BackColor = Color.White;
                }
            }

            if (8 < waveformAiCtrl1.Conversion.ChannelCount)
            {
                secondItem.SubItems[0].Text = "";
                secondItem.SubItems[0].BackColor = m_simpleGraph.Pens[8].Color;
            }
            else
            {
                secondItem.SubItems[0].Text = "";
                secondItem.SubItems[0].BackColor = Color.White;
            }
            for (int i = 9; i < 16; i++)
            {
                if (i < waveformAiCtrl1.Conversion.ChannelCount)
                {
                    secondItem.SubItems.Add((""), Color.Black, Color.Honeydew, new Font("SimSun", 10));
                    secondItem.SubItems[i - 8].BackColor = m_simpleGraph.Pens[i].Color;
                }
                else
                {
                    secondItem.SubItems.Add("");
                    secondItem.SubItems[i - 8].BackColor = Color.White;
                }
            }

            ListViewItem[] list = new ListViewItem[] { firstItem, secondItem };
            listView.Items.AddRange(list);
        }

        private void HandleError(ErrorCode err)
        {
            if ((err >= ErrorCode.ErrorHandleNotValid) && (err != ErrorCode.Success))
            {
                MessageBox.Show("Sorry ! Some errors happened, the error code is: " + err.ToString(), "StreamingAI");
            }
        }

        private void button_start_Click(object sender, EventArgs e)
        {
            ErrorCode err = ErrorCode.Success;

            err = waveformAiCtrl1.Prepare();
            m_xInc = 1.0 / waveformAiCtrl1.Conversion.ClockRate;
            ConfigureGraph();
            if (err == ErrorCode.Success)
            {
                err = waveformAiCtrl1.Start();
            }

            if (err != ErrorCode.Success)
            {
                HandleError(err);
                return;
            }

            button_start.Enabled = false;
            button_pause.Enabled = true;
            button_stop.Enabled = true;
        }

        // This function is used to deal with 'DataReady' Event. 
        // Notice:
        // 1.It is not recommended to process or print too much information in this function,
        // which can easily cause event blockage.
        // 2.In theory, the amount of data argsCount returned by a DataReady should be equal to sectionLen * channelCount.
        // However, in reality, when the dataReady callback function is executed is also affected by system load,
        // so it cannot be guaranteed that the amount of data argsCount in each DataReady is equal to sectionLen * channelCount.
        private void waveformAiCtrl1_DataReady(object sender, BfdAiEventArgs args)
        {
            try
            {
                //The WaveformAiCtrl has been disposed.
                if (waveformAiCtrl1.State == ControlState.Idle)
                {
                    return;
                }
                if (m_dataScaled.Length < args.Count)
                {
                    m_dataScaled = new double[args.Count];
                }

                ErrorCode err = ErrorCode.Success;
                int chanCount = waveformAiCtrl1.Conversion.ChannelCount;
                int sectionLength = waveformAiCtrl1.Record.SectionLength;
                err = waveformAiCtrl1.GetData(args.Count, m_dataScaled);
                if (err != ErrorCode.Success && err != ErrorCode.WarningRecordEnd)
                {
                    HandleError(err);
                    return;
                }
                System.Diagnostics.Debug.WriteLine(args.Count.ToString());
                m_simpleGraph.Chart(m_dataScaled, chanCount, args.Count / chanCount, m_xInc);
            }
            catch (System.Exception) { }
        }

        private void button_pause_Click(object sender, EventArgs e)
        {
            ErrorCode err = ErrorCode.Success;
            err = waveformAiCtrl1.Stop();
            if (err != ErrorCode.Success)
            {
                HandleError(err);
                return;
            }

            button_start.Enabled = true;
            button_pause.Enabled = false;
        }

        private void button_stop_Click(object sender, EventArgs e)
        {
            ErrorCode err = ErrorCode.Success;
            err = waveformAiCtrl1.Stop();
            if (err != ErrorCode.Success)
            {
                HandleError(err);
                return;
            }

            button_start.Enabled = true;
            button_pause.Enabled = false;
            button_stop.Enabled = false;
            trackBar_div.Enabled = true;
            Array.Clear(m_dataScaled, 0, m_dataScaled.Length);
            m_simpleGraph.Clear();
        }

        private void trackBar_div_Scroll(object sender, EventArgs e)
        {
            m_simpleGraph.Div(trackBar_div.Value);
            SetXCordRangeLabels();
        }

        private void SetXCordRangeLabels()
        {
            string[] X_rangeLabels = new string[2];
            Helpers.GetXCordRangeLabels(X_rangeLabels, ((int)(m_simpleGraph.XCordTimeDiv)) * 10, 0, m_timeUnit);
            label_XCoordinateMax.Text = X_rangeLabels[0];
            label_XCoordinateMin.Text = X_rangeLabels[1];
        }

        //Notice: The Overrun and CacheOverflow events indicate there was data loss (could be misaligned, 
        //and discontinuous) during the acquisition. We strongly recommend keeping these events monitored 
        //in your application. Losing these event notifications could lead you to misunderstand the acquisition 
        //status.
        private void waveformAiCtrl1_CacheOverflow(object sender, BfdAiEventArgs e)
        {
            MessageBox.Show("WaveformAiCacheOverflow");
            // Please consider if it's necessary to stop the application in your application when this event is triggered.
            // waveformAiCtrl1->Stop();
        }

        //Notice: The Overrun and CacheOverflow events indicate there was data loss (could be misaligned, 
        //and discontinuous) during the acquisition. We strongly recommend keeping these events monitored 
        //in your application. Losing these event notifications could lead you to misunderstand the acquisition 
        //status.
        private void waveformAiCtrl1_Overrun(object sender, BfdAiEventArgs e)
        {
            if (m_isFirstOverRun)
            {
                MessageBox.Show("WaveformAiOverrun");
                m_isFirstOverRun = false;
            }
            // Please consider if it's necessary to stop the application in your application when this event is triggered.
            // waveformAiCtrl1->Stop();
        }
    }
}