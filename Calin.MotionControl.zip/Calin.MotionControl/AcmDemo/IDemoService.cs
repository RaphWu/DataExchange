﻿using System.ComponentModel;
using Calin.MC.Advantech.Models;

namespace AcmDemo
{
    /// <summary>
    /// ACM Demo 服務介面。
    /// </summary>
    public interface IDemoService
    {
        #region Properties

        /// <summary>
        /// 目前選擇的軸編號。
        /// </summary>
        uint AxisNo { get; set; }

        /// <summary>
        /// 裝置狀態列表 (BindingList 可支援 UI 綁定)。
        /// </summary>
        UiState UiState { get; }

        #endregion Properties

        /// <summary>
        /// 顯示錯誤訊息。
        /// </summary>
        /// <param name="msg">附加訊息。</param>
        void ShowErrMsg(string msg);

    }
}
