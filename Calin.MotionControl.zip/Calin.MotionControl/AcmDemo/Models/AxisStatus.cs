﻿namespace AcmDemo.Models
{
    /// <summary>
    /// 軸狀態。
    /// </summary>
    public class AxisStatus
    {
        /// <summary>
        /// 是否有警報。
        /// </summary>
        public bool Alarm { get; set; }

        /// <summary>
        /// 編碼器 Z 軸信號。
        /// </summary>
        public bool EncoderZ { get; set; }

        /// <summary>
        /// ORG 信號。
        /// </summary>
        public bool ORG { get; set; }

        /// <summary>
        /// 正極限開關信號。
        /// </summary>
        public bool EndLimitPositive { get; set; }

        /// <summary>
        /// 負極限開關信號。
        /// </summary>
        public bool EndLimitNegative { get; set; }
    }
}
