﻿namespace AcmDemo.Models
{
    public class AxisParams
    {
    }
}
