﻿using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;

namespace AcmDemo.Models
{
    /// <summary>
    /// UI 狀態模型。
    /// </summary>
    public class AcmParams : ObservableObject
    {
        /// <summary>
        /// 裝置是否啟用。
        /// </summary>
        public bool DeviceEnable
        {
            get { return _deviceEnable; }
            set { SetProperty(ref _deviceEnable, value); }
        }
        private bool _deviceEnable = false;

        /// <summary>
        /// 目前指定的軸編號。
        /// </summary>
        public uint AxisNo
        {
            get { return _axisNo; }
            set { SetProperty(ref _axisNo, value); }
        }
        private uint _axisNo;

        /// <summary>
        /// 各軸狀態。
        /// </summary>
        public ObservableCollection<AxisStatus> AxisStatuses
        {
            get { return _axisStatuses; }
            set { SetProperty(ref _axisStatuses, value); }
        }
        private ObservableCollection<AxisStatus> _axisStatuses = new ObservableCollection<AxisStatus>();
    }
}
