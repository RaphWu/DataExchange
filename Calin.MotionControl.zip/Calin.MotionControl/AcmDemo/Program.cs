using AcmDemo.Views;
using Autofac;
using Calin.CSharp;
using Calin.MC.Advantech;
using Calin.MC.Advantech.Models;
using Calin.WinForm;

namespace AcmDemo
{
    internal static class Program
    {
        /// <summary>
        /// ���ε{�����D�n�i�J�I�C
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var builder = new ContainerBuilder();

            // services
            builder.RegisterType<DemoService>().As<IDemoService>().SingleInstance();

            // views
            builder.RegisterType<MainForm>().AsSelf().InstancePerDependency();
            builder.RegisterType<MainPanel>().AsSelf().InstancePerDependency();
            builder.RegisterType<ManualPage>().AsSelf().InstancePerDependency();
            builder.RegisterType<HomePage>().AsSelf().InstancePerDependency();
            builder.RegisterType<P2PPage>().AsSelf().InstancePerDependency();

            var advantechModule = new AdvantechModule
            {
                AcmConfig = new AcmConfig { /* Initialize properties */ }
            };
            builder.RegisterModule(advantechModule);
            builder.RegisterModule<CSharpModule>();
            builder.RegisterModule<WinFormModule>();

            var container = builder.Build();

            Application.Run(container.Resolve<MainForm>());
        }
    }
}