﻿namespace AcmDemo
{
    public static class CommonStyle
    {
        public static Color CommonBackColor = Color.White;
        public static Color CommonForeColor = Color.Black;
        public static Color MenuRadioButtonHoverColor = Color.LightSkyBlue;
        public static Color MenuRadioButtonCheckedColor = Color.SandyBrown;

        public static void SetMenuRadioButton(RadioButton radioButton)
        {
            radioButton.BackColor = CommonBackColor;
            radioButton.ForeColor = CommonForeColor;
            radioButton.FlatAppearance.MouseOverBackColor = MenuRadioButtonHoverColor;
            radioButton.FlatAppearance.CheckedBackColor = MenuRadioButtonCheckedColor;
        }
    }
}
