﻿using Calin.MC.Advantech.Contracts;

namespace AcmDemo.Services
{
    /// <summary>
    /// ACM Demo 服務。
    /// </summary>
    public class DemoService : IDemoService
    {
        #region Fields

        private readonly IAcm _acm;

        //private uint _axisNo = 0;

        #endregion Fields

        #region Properties

        //public uint AxisNo { get => _axisNo; set => _axisNo = value; }
        //public AcmParams UiState { get; } = new AcmParams();


        #endregion Properties

        public DemoService(IAcm acm)
        {
            _acm = acm;
        }

        /// <inheritdoc/>
        public void ShowErrMsg(string msg)
        {
            var err = _acm.ErrMessage;
            MessageBox.Show($"{msg}\n\n錯誤碼：0x{err.ErrorCode:X8}\n錯誤訊息：{err.Message}\n詳細資訊：{err.Description}",
                "錯誤",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
