﻿namespace AcmDemo.Contants
{
    public enum PageCode
    {
        MainPanel,
        Manual,
        Home,
        P2P,
    }
}
