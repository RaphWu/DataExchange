﻿using Calin.MC.Advantech.Contracts;

namespace AcmDemo
{
    /// <summary>
    /// ACM Demo 服務。
    /// </summary>
    public class DemoService : IDemoService
    {
        private readonly IAcm _acm;

        public DemoService(IAcm acm)
        {
            _acm = acm;
        }

        /// <inheritdoc/>
        public void ShowErrMsg(string msg)
        {
            _ = MessageBox.Show($"{msg}\n\n錯誤碼：0x{_acm.ErrCode:X8}\n錯誤訊息：{_acm.ErrMessage}\n詳細資訊：{_acm.ErrDetail}\n執行函數：{_acm.ErrCallerName}",
                "錯誤",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
