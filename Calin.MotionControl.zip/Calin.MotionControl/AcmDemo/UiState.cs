﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;

namespace AcmDemo
{
    public class UiState : ObservableObject
    {
        /// <summary>
        /// 裝置是否啟用。
        /// </summary>
        public bool DeviceEnable
        {
            get { return _deviceEnable; }
            set { SetProperty(ref _deviceEnable, value); }
        }
        private bool _deviceEnable = false;
    }
}
