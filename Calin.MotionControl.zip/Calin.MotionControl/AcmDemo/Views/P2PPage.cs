﻿using Calin.WinForm.Navigation;

namespace AcmDemo.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class P2PPage : UserControl
    {
        public P2PPage()
        {
            InitializeComponent();
        }
    }
}
