﻿using AcmDemo.Models;
using AcmDemo.Services;
using Calin.MC.Advantech.Contracts;
using Calin.WinForm.Navigation;

namespace AcmDemo.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class HomePage : UserControl
    {
        #region Fields

        private readonly IDemoService _demoService;
        private readonly IAcm _acm;

        private readonly AcmParams _acmParams;

        private uint _homeMode;
        private uint _direction;
        private uint _switchMode;
        private double _crossDistance;
        private int _ezLevel;
        private int _orgLevel;
        private int _helLevel;

        #endregion Fields

        public HomePage(IDemoService demoService, IAcm acm, AcmParams acmParams)
        {
            InitializeComponent();

            _demoService = demoService;
            _acm = acm;
            _acmParams = acmParams;

            CbDir.SelectedIndex = 0;
            CbHomeMode.SelectedIndex = 0;
            CbSwitchMode.SelectedIndex = 0;
            NumCrossDis.Value = 10000;

            HomePanel.DataBindings.Add(
                "Enabled",
                _acmParams,
                nameof(AcmParams.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
        }

        private void CbDir_SelectedIndexChanged(object sender, EventArgs e)
        {
            _direction = (uint)CbDir.SelectedIndex;
        }

        private void CbHomeMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            _homeMode = (uint)CbHomeMode.SelectedIndex;

            switch (_homeMode)
            {
                case 0:
                    PbHomeMode.Image = Properties.Resources.MODE1_Abs;
                    break;
                case 1:
                    PbHomeMode.Image = Properties.Resources.MODE2_Lmt;
                    break;
                case 2:
                    PbHomeMode.Image = Properties.Resources.MODE3_Ref;
                    break;
                case 3:
                    PbHomeMode.Image = Properties.Resources.MODE4_Abs_Ref;
                    break;
                case 4:
                    PbHomeMode.Image = Properties.Resources.MODE5_Abs_NegRef;
                    break;
                case 5:
                    PbHomeMode.Image = Properties.Resources.MODE6_Lmt_Ref;
                    break;
                case 6:
                    PbHomeMode.Image = Properties.Resources.MODE7_AbsSearch;
                    break;
                case 7:
                    PbHomeMode.Image = Properties.Resources.MODE8_LmtSearch;
                    break;
                case 8:
                    PbHomeMode.Image = Properties.Resources.MODE9_AbsSearch_Ref;
                    break;
                case 9:
                    PbHomeMode.Image = Properties.Resources.MODE10_AbsSearch_NegRef;
                    break;
                case 10:
                    PbHomeMode.Image = Properties.Resources.MODE11_LmtSearch_Ref;
                    break;
                case 11:
                    PbHomeMode.Image = Properties.Resources.MODE12_AbsSearchReFind;
                    break;
                case 12:
                    PbHomeMode.Image = Properties.Resources.MODE13_LmtSearchReFind;
                    break;
                case 13:
                    PbHomeMode.Image = Properties.Resources.MODE14_AbsSearchReFind_Ref;
                    break;
                case 14:
                    PbHomeMode.Image = Properties.Resources.MODE15_AbsSearchReFind_NegRef;
                    break;
                case 15:
                    PbHomeMode.Image = Properties.Resources.MODE16_LmtSearchReFind_Ref;
                    break;
                default:
                    PbHomeMode.Image = null;
                    break;
            }
            LblHomeMode.Text = _acm.GetHomeModeDescription(_homeMode);
        }

        private void RbEzLow_Click(object sender, EventArgs e)
        {
            _ezLevel = 0;
        }

        private void RbEzHigh_Click(object sender, EventArgs e)
        {
            _ezLevel = 1;
        }

        private void RbOrgLow_Click(object sender, EventArgs e)
        {
            _orgLevel = 0;
        }

        private void RbOrgHigh_Click(object sender, EventArgs e)
        {
            _orgLevel = 1;
        }

        private void RbHelLow_Click(object sender, EventArgs e)
        {
            _helLevel = 0;
        }

        private void RbHelHigh_Click(object sender, EventArgs e)
        {
            _helLevel = 1;
        }

        private void CbSwitchMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            _switchMode = (uint)CbSwitchMode.SelectedIndex;
        }

        private void NumCrossDis_ValueChanged(object sender, EventArgs e)
        {
            _crossDistance = (double)NumCrossDis.Value;
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            _acm.AxisStop(_acmParams.AxisNo);
        }

        private void BtnHome_Click(object sender, EventArgs e)
        {
            _acm.AxisHome(
                  _acmParams.AxisNo,
                  _homeMode,
                  _direction,
                  _switchMode,
                  _crossDistance);
        }
    }
}
