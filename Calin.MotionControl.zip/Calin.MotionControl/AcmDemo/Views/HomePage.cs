﻿using System;
using System.Windows.Forms;
using Calin.MC.Advantech.Contracts;
using Calin.WinForm.Navigation;

namespace AcmDemo.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class HomePage : UserControl
    {
        #region Fields

        private readonly IDemoService _demoService;
        private readonly IAcm _acm;

        private int _direction;
        private int _homeMode;
        private int _ezLevel;
        private int _orgLevel;
        private int _helLevel;
        private int _switchMode;
        private double _crossDistance;

        #endregion Fields

        public HomePage(IDemoService demoService, IAcm acm)
        {
            InitializeComponent();

            _demoService = demoService;
            _acm = acm;

            CbDir.SelectedIndex = 0;
            CbHomeMode.SelectedIndex = 0;
            CbSwitchMode.SelectedIndex = 0;
            NumCrossDis.Value = 100;

            HomePanel.DataBindings.Add(
                "Enabled",
                _demoService.UiState,
                nameof(UiState.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
        }

        private void CbDir_SelectedIndexChanged(object sender, EventArgs e)
        {
            _direction = CbDir.SelectedIndex;
        }

        private void CbHomeMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            _homeMode = CbHomeMode.SelectedIndex;

            switch (_homeMode)
            {
                case 0:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE1_Abs");
                    break;
                case 1:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE2_Lmt");
                    break;
                case 2:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE3_Ref");
                    break;
                case 3:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE4_Abs_Ref");
                    break;
                case 4:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE5_Abs_NegRef");
                    break;
                case 5:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE6_Lmt_Ref");
                    break;
                case 6:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE7_AbsSearch");
                    break;
                case 7:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE8_LmtSearch");
                    break;
                case 8:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE9_AbsSearch_Ref");
                    break;
                case 9:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE10_AbsSearch_NegRef");
                    break;
                case 10:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE11_LmtSearch_Ref");
                    break;
                case 11:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE12_AbsSearchReFind");
                    break;
                case 12:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE13_LmtSearchReFind");
                    break;
                case 13:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE14_AbsSearchReFind_Ref");
                    break;
                case 14:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE15_AbsSearchReFind_NegRef");
                    break;
                case 15:
                    PbHomeMode.Image = Resource.GetLocalResource("MODE16_LmtSearchReFind_Ref");
                    break;
            }
        }

        private void RbEzLow_Click(object sender, EventArgs e)
        {
            _ezLevel = 0;
        }

        private void RbEzHigh_Click(object sender, EventArgs e)
        {
            _ezLevel = 1;
        }

        private void RbOrgLow_Click(object sender, EventArgs e)
        {
            _orgLevel = 0;
        }

        private void RbOrgHigh_Click(object sender, EventArgs e)
        {
            _orgLevel = 1;
        }

        private void RbHelLow_Click(object sender, EventArgs e)
        {
            _helLevel = 0;
        }

        private void RbHelHigh_Click(object sender, EventArgs e)
        {
            _helLevel = 1;
        }

        private void CbSwitchMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            _switchMode = CbSwitchMode.SelectedIndex;
        }

        private void NumCrossDis_ValueChanged(object sender, EventArgs e)
        {
            _crossDistance = (double)NumCrossDis.Value;
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            _acm.AxisStop(_demoService.AxisNo);
        }

        private void BtnGo_Click(object sender, EventArgs e)
        {
            //string strTemp;
            //UInt32 Result;
            //UInt32 PropertyVal = new UInt32();
            //double CrossDistance = new double();

            //PropertyVal = (UInt32)comboBoxSwitchMode.SelectedIndex;
            ////Setting the stopping condition of Acm_AxHomeEx
            ////You can also use the old API: Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxHomeExSwitchMode, ref PropertyVal, (uint)Marshal.SizeOf(typeof(UInt32)));
            //Result = Motion.mAcm_SetU32Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxHomeExSwitchMode, PropertyVal);
            //if (Result != (uint)ErrorCode.SUCCESS)
            //{
            //    strTemp = "Set Property-PAR_AxHomeExSwitchMode Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
            //    ShowMessages(strTemp, Result);
            //    return;
            //}
            //CrossDistance = Convert.ToDouble(textBoxCross.Text);
            ////Set the home cross distance (Unit: PPU). This property must be greater than 0. The default value is 10000
            ////You can also use the old API: Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxHomeCrossDistance, ref CrossDistance, (uint)Marshal.SizeOf(typeof(double)));
            //Result = Motion.mAcm_SetF64Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxHomeCrossDistance, CrossDistance);
            //if (Result != (uint)ErrorCode.SUCCESS)
            //{
            //    strTemp = "Set Property-AxHomeCrossDistance Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
            //    ShowMessages(strTemp, Result);
            //    return;
            //}
            ////To command axis to start typical home motion. The 15 types of typical
            ////home motion are composed of extended home
            //Result = Motion.mAcm_AxHome(m_Axishand[CmbAxes.SelectedIndex], (UInt32)comboBoxMode.SelectedIndex, (UInt32)comboBoxDir.SelectedIndex);
            //if (Result != (uint)ErrorCode.SUCCESS)
            //{
            //    strTemp = "AxHome Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
            //    ShowMessages(strTemp, Result);
            //}
            //return;
        }
    }
}
