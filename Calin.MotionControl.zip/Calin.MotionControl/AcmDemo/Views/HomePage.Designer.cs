﻿namespace AcmDemo.Views
{
    partial class HomePage
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.HomePanel = new System.Windows.Forms.GroupBox();
            this.NumCrossDis = new System.Windows.Forms.NumericUpDown();
            this.BtnStop = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.BtnGo = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.CbSwitchMode = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.RbHelHigh = new System.Windows.Forms.RadioButton();
            this.RbHelLow = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.RbOrgHigh = new System.Windows.Forms.RadioButton();
            this.RbOrgLow = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.RbEzLow = new System.Windows.Forms.RadioButton();
            this.RbEzHigh = new System.Windows.Forms.RadioButton();
            this.CbHomeMode = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.CbDir = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.PbHomeMode = new System.Windows.Forms.PictureBox();
            this.HomePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumCrossDis)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbHomeMode)).BeginInit();
            this.SuspendLayout();
            // 
            // HomePanel
            // 
            this.HomePanel.Controls.Add(this.NumCrossDis);
            this.HomePanel.Controls.Add(this.BtnStop);
            this.HomePanel.Controls.Add(this.label10);
            this.HomePanel.Controls.Add(this.BtnGo);
            this.HomePanel.Controls.Add(this.label9);
            this.HomePanel.Controls.Add(this.CbSwitchMode);
            this.HomePanel.Controls.Add(this.label5);
            this.HomePanel.Controls.Add(this.groupBox2);
            this.HomePanel.Controls.Add(this.CbHomeMode);
            this.HomePanel.Controls.Add(this.label4);
            this.HomePanel.Controls.Add(this.CbDir);
            this.HomePanel.Controls.Add(this.label3);
            this.HomePanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.HomePanel.Location = new System.Drawing.Point(15, 10);
            this.HomePanel.Name = "HomePanel";
            this.HomePanel.Size = new System.Drawing.Size(286, 375);
            this.HomePanel.TabIndex = 38;
            this.HomePanel.TabStop = false;
            this.HomePanel.Text = "原點復歸";
            // 
            // NumCrossDis
            // 
            this.NumCrossDis.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumCrossDis.Location = new System.Drawing.Point(91, 304);
            this.NumCrossDis.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NumCrossDis.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumCrossDis.Name = "NumCrossDis";
            this.NumCrossDis.Size = new System.Drawing.Size(120, 23);
            this.NumCrossDis.TabIndex = 42;
            this.NumCrossDis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumCrossDis.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.NumCrossDis.ValueChanged += new System.EventHandler(this.NumCrossDis_ValueChanged);
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(153, 337);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(82, 25);
            this.BtnStop.TabIndex = 39;
            this.BtnStop.Text = "停止";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(216, 307);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 16);
            this.label10.TabIndex = 41;
            this.label10.Text = "PPU";
            // 
            // BtnGo
            // 
            this.BtnGo.Location = new System.Drawing.Point(35, 337);
            this.BtnGo.Name = "BtnGo";
            this.BtnGo.Size = new System.Drawing.Size(82, 25);
            this.BtnGo.TabIndex = 38;
            this.BtnGo.Text = "復歸";
            this.BtnGo.UseVisualStyleBackColor = true;
            this.BtnGo.Click += new System.EventHandler(this.BtnGo_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(33, 306);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 16);
            this.label9.TabIndex = 40;
            this.label9.Text = "跨越距離";
            // 
            // CbSwitchMode
            // 
            this.CbSwitchMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbSwitchMode.FormattingEnabled = true;
            this.CbSwitchMode.Items.AddRange(new object[] {
            "Level On",
            "Level Off",
            "Edge On",
            "Edge Off"});
            this.CbSwitchMode.Location = new System.Drawing.Point(91, 276);
            this.CbSwitchMode.Name = "CbSwitchMode";
            this.CbSwitchMode.Size = new System.Drawing.Size(162, 24);
            this.CbSwitchMode.TabIndex = 39;
            this.CbSwitchMode.SelectedIndexChanged += new System.EventHandler(this.CbSwitchMode_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 280);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 16);
            this.label5.TabIndex = 38;
            this.label5.Text = "停止模式";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox6);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(13, 84);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(255, 186);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "屬性設定";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.RbHelHigh);
            this.groupBox6.Controls.Add(this.RbHelLow);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox6.Location = new System.Drawing.Point(6, 121);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(230, 45);
            this.groupBox6.TabIndex = 39;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "極限信號邏輯";
            // 
            // RbHelHigh
            // 
            this.RbHelHigh.AutoSize = true;
            this.RbHelHigh.Location = new System.Drawing.Point(123, 19);
            this.RbHelHigh.Name = "RbHelHigh";
            this.RbHelHigh.Size = new System.Drawing.Size(85, 20);
            this.RbHelHigh.TabIndex = 40;
            this.RbHelHigh.Text = "高電位觸發";
            this.RbHelHigh.UseVisualStyleBackColor = true;
            this.RbHelHigh.Click += new System.EventHandler(this.RbEzHigh_Click);
            // 
            // RbHelLow
            // 
            this.RbHelLow.AutoSize = true;
            this.RbHelLow.Checked = true;
            this.RbHelLow.Location = new System.Drawing.Point(20, 19);
            this.RbHelLow.Name = "RbHelLow";
            this.RbHelLow.Size = new System.Drawing.Size(85, 20);
            this.RbHelLow.TabIndex = 41;
            this.RbHelLow.TabStop = true;
            this.RbHelLow.Text = "低電位觸發";
            this.RbHelLow.UseVisualStyleBackColor = true;
            this.RbHelLow.Click += new System.EventHandler(this.RbHelLow_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.RbOrgHigh);
            this.groupBox4.Controls.Add(this.RbOrgLow);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox4.Location = new System.Drawing.Point(6, 70);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(230, 45);
            this.groupBox4.TabIndex = 39;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "原點信號邏輯";
            // 
            // RbOrgHigh
            // 
            this.RbOrgHigh.AutoSize = true;
            this.RbOrgHigh.Location = new System.Drawing.Point(123, 19);
            this.RbOrgHigh.Name = "RbOrgHigh";
            this.RbOrgHigh.Size = new System.Drawing.Size(85, 20);
            this.RbOrgHigh.TabIndex = 42;
            this.RbOrgHigh.Text = "高電位觸發";
            this.RbOrgHigh.UseVisualStyleBackColor = true;
            this.RbOrgHigh.Click += new System.EventHandler(this.RbOrgHigh_Click);
            // 
            // RbOrgLow
            // 
            this.RbOrgLow.AutoSize = true;
            this.RbOrgLow.Checked = true;
            this.RbOrgLow.Location = new System.Drawing.Point(20, 19);
            this.RbOrgLow.Name = "RbOrgLow";
            this.RbOrgLow.Size = new System.Drawing.Size(85, 20);
            this.RbOrgLow.TabIndex = 43;
            this.RbOrgLow.TabStop = true;
            this.RbOrgLow.Text = "低電位觸發";
            this.RbOrgLow.UseVisualStyleBackColor = true;
            this.RbOrgLow.Click += new System.EventHandler(this.RbOrgLow_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.RbEzLow);
            this.groupBox3.Controls.Add(this.RbEzHigh);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.Location = new System.Drawing.Point(6, 19);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(230, 45);
            this.groupBox3.TabIndex = 38;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Z信號邏輯";
            // 
            // RbEzLow
            // 
            this.RbEzLow.AutoSize = true;
            this.RbEzLow.Checked = true;
            this.RbEzLow.Location = new System.Drawing.Point(20, 20);
            this.RbEzLow.Name = "RbEzLow";
            this.RbEzLow.Size = new System.Drawing.Size(85, 20);
            this.RbEzLow.TabIndex = 39;
            this.RbEzLow.TabStop = true;
            this.RbEzLow.Text = "低電位觸發";
            this.RbEzLow.UseVisualStyleBackColor = true;
            this.RbEzLow.Click += new System.EventHandler(this.RbEzLow_Click);
            // 
            // RbEzHigh
            // 
            this.RbEzHigh.AutoSize = true;
            this.RbEzHigh.Location = new System.Drawing.Point(123, 20);
            this.RbEzHigh.Name = "RbEzHigh";
            this.RbEzHigh.Size = new System.Drawing.Size(85, 20);
            this.RbEzHigh.TabIndex = 38;
            this.RbEzHigh.Text = "高電位觸發";
            this.RbEzHigh.UseVisualStyleBackColor = true;
            this.RbEzHigh.Click += new System.EventHandler(this.RbEzHigh_Click);
            // 
            // CbHomeMode
            // 
            this.CbHomeMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbHomeMode.FormattingEnabled = true;
            this.CbHomeMode.Items.AddRange(new object[] {
            "MODE1_Abs",
            "MODE2_Lmt",
            "MODE3_Ref",
            "MODE4_Abs_Ref",
            "MODE5_Abs_NegRef",
            "MODE6_Lmt_Ref",
            "MODE7_AbsSearch",
            "MODE8_LmtSearch",
            "MODE9_AbsSearch_Ref",
            "MODE10_AbsSearch_NegRef",
            "MODE11_LmtSearch_Ref",
            "MODE12_AbsSearchReFind",
            "MODE13_LmtSearchReFind",
            "MODE14_AbsSearchReFind_Ref",
            "MODE15_AbsSearchReFind_NegRef",
            "MODE16_LmtSearchReFind_Ref"});
            this.CbHomeMode.Location = new System.Drawing.Point(61, 46);
            this.CbHomeMode.Name = "CbHomeMode";
            this.CbHomeMode.Size = new System.Drawing.Size(207, 24);
            this.CbHomeMode.TabIndex = 23;
            this.CbHomeMode.SelectedIndexChanged += new System.EventHandler(this.CbHomeMode_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 16);
            this.label4.TabIndex = 22;
            this.label4.Text = "模式";
            // 
            // CbDir
            // 
            this.CbDir.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbDir.FormattingEnabled = true;
            this.CbDir.Items.AddRange(new object[] {
            "正方向",
            "負方向"});
            this.CbDir.Location = new System.Drawing.Point(120, 17);
            this.CbDir.Name = "CbDir";
            this.CbDir.Size = new System.Drawing.Size(148, 24);
            this.CbDir.TabIndex = 21;
            this.CbDir.SelectedIndexChanged += new System.EventHandler(this.CbDir_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(86, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 16);
            this.label3.TabIndex = 20;
            this.label3.Text = "方向";
            // 
            // PbHomeMode
            // 
            this.PbHomeMode.Location = new System.Drawing.Point(307, 10);
            this.PbHomeMode.Name = "PbHomeMode";
            this.PbHomeMode.Size = new System.Drawing.Size(400, 400);
            this.PbHomeMode.TabIndex = 39;
            this.PbHomeMode.TabStop = false;
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.PbHomeMode);
            this.Controls.Add(this.HomePanel);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "HomePage";
            this.Size = new System.Drawing.Size(720, 475);
            this.HomePanel.ResumeLayout(false);
            this.HomePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumCrossDis)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbHomeMode)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox HomePanel;
        private Button BtnStop;
        private Label label10;
        private Button BtnGo;
        private Label label9;
        private ComboBox CbSwitchMode;
        private Label label5;
        private GroupBox groupBox2;
        private GroupBox groupBox6;
        private RadioButton RbHelHigh;
        private RadioButton RbHelLow;
        private GroupBox groupBox4;
        private RadioButton RbOrgHigh;
        private RadioButton RbOrgLow;
        private GroupBox groupBox3;
        private RadioButton RbEzLow;
        private RadioButton RbEzHigh;
        private ComboBox CbHomeMode;
        private Label label4;
        private ComboBox CbDir;
        private Label label3;
        private NumericUpDown NumCrossDis;
        private PictureBox PbHomeMode;
    }
}
