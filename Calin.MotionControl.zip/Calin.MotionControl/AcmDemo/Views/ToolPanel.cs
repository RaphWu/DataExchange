﻿using AcmDemo.Exts;
using AcmDemo.Models;
using AcmDemo.Services;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Models;
using Calin.MC.Advantech.Services;
using Calin.WinForm.Navigation;

namespace AcmDemo.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class ToolPanel : Form, INavigationAware
    {
        #region Fields

        private readonly IDemoService _demoService;
        private readonly IAcm _acm;

        private readonly AcmParams _acmParams;

        #endregion Fields

        #region Properties

        public event EventHandler ToolPanelHidden;

        #endregion Properties

        #region INavigationAware

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            if (CbAvailableDevice.Items.Count == 0 && _acm.DeviceCount > 0)
            {
                foreach (var dev in _acm.AvailableDevices)
                    CbAvailableDevice.Items.Add($"{dev.DeviceNum} - {dev.DeviceName}");
            }
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        public bool OnNavigatingFrom(INavigationParameters parameters)
        {
            return true;
        }

        #endregion INavigationAware

        public ToolPanel(IDemoService demoService, IAcm acm, AcmParams acmParams)
        {
            InitializeComponent();

            _demoService = demoService;
            _acm = acm;
            _acmParams = acmParams;

            StatePanel.DataBindings.Add(
                "Enabled",
                _acmParams,
                nameof(AcmParams.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
            DevicePanel.DataBindings.Add(
                "Enabled",
                _acmParams,
                nameof(AcmParams.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
            VelSetupPanel.DataBindings.Add(
                "Enabled",
                _acmParams,
                nameof(AcmParams.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
            LbAxisList.DataBindings.Add(
                "Enabled",
                _acmParams,
                nameof(AcmParams.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
        }

        #region Form Event

        private void MainPanel_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
                ToolPanelHidden?.Invoke(this, EventArgs.Empty);
                return;
            }
        }

        #endregion Form Event

        #region Device & Board

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            if (_acm.IsBoardInit)
            {
                if (!_acm.BoardClose())
                {
                    _demoService.ShowErrMsg($"控制卡關閉失敗！");
                    return;
                }

                LbAxisList.Items.Clear();

                BtnOpenBoard.Enabled = true;
                BtnCloseBoard.Enabled = false;
            }
            else
            {
                MessageBox.Show("控制卡尚未開啟，無需關閉。", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            if (!_acm.BoardOpen())
            {
                _demoService.ShowErrMsg("控制卡開啟失敗！");
                return;
            }

            LbAxisList.Items.Clear();
            for (int axisNo = 1; axisNo <= _acm.AxisCount; axisNo++)
                LbAxisList.Items.Add($"軸 {axisNo}");
            LbAxisList.SelectedIndex = 0;

            _acm.AcmStatusUpdated += AcmStatusUpdated;

            BtnOpenBoard.Enabled = false;
            BtnCloseBoard.Enabled = true;
        }

        private void AcmStatusUpdated(object sender, AcmStatusUpdatedEventArgs e)
        {
            if (_acm.AxisCount > 0)
            {
                // 更新燈號
                if (_acmParams.AxisStatuses.Count > e.AxisNo)
                {
                    var status = _acmParams.AxisStatuses[e.AxisNo];
                    status.Alarm = e.State.IoFlags.HasFlag(AxisIoFlags.ALM);
                    status.EncoderZ = e.State.IoFlags.HasFlag(AxisIoFlags.EZ);
                    status.ORG = e.State.IoFlags.HasFlag(AxisIoFlags.ORG);
                    status.EndLimitPositive = e.State.IoFlags.HasFlag(AxisIoFlags.LMT_Positive);
                    status.EndLimitNegative = e.State.IoFlags.HasFlag(AxisIoFlags.LMT_Negative);

                    PBoxAlm.BackColor = status.Alarm ? CommonStyle.LightOn : CommonStyle.LightOff;
                    PBoxEz.BackColor = status.EncoderZ ? CommonStyle.LightOn : CommonStyle.LightOff;
                    PBoxOrg.BackColor = status.ORG ? CommonStyle.LightOn : CommonStyle.LightOff;
                    PBoxHELPositive.BackColor = status.EndLimitPositive ? CommonStyle.LightOn : CommonStyle.LightOff;
                    PBoxHELNegative.BackColor = status.EndLimitNegative ? CommonStyle.LightOn : CommonStyle.LightOff;
                }
                else
                {
                    PBoxAlm.BackColor = CommonStyle.LightOff;
                    PBoxEz.BackColor = CommonStyle.LightOff;
                    PBoxOrg.BackColor = CommonStyle.LightOff;
                    PBoxHELPositive.BackColor = CommonStyle.LightOff;
                    PBoxHELNegative.BackColor = CommonStyle.LightOff;
                }
            }
        }

        private void BtnServoOn_Click(object sender, EventArgs e)
        {

        }

        #endregion Device & Board

        #region Axis

        private void LbAxisList_SelectedIndexChanged(object sender, EventArgs e)
        {
            _acmParams.AxisNo = (uint)LbAxisList.SelectedIndex;

            //var alarmBinding = new Binding(
            //    "BackColor",
            //    _acmParams,
            //    $"{nameof(AcmParams.AxisStatuses)}[{_acmParams.AxisNo}].{nameof(AxisStatus.Alarm)}",
            //    true,
            //    DataSourceUpdateMode.OnPropertyChanged)
            //{
            //    FormattingEnabled = true
            //};
            //alarmBinding.Format += (sender, e) =>
            //{
            //    try
            //    {
            //        bool alarm = false;
            //        if (e.Value is bool b)
            //            alarm = b;
            //        else if (e.Value != null)
            //            alarm = Convert.ToBoolean(e.Value);
            //        e.Value = alarm ? CommonStyle.LightOn : CommonStyle.LightOff;
            //    }
            //    catch
            //    {
            //        // 如果轉換失敗，回退到深灰色
            //        e.Value = CommonStyle.LightOff;
            //    }
            //};
            //PBoxAlm.DataBindings.Clear();
            //PBoxAlm.DataBindings.Add(alarmBinding);
        }

        #endregion Axis

        #region Configuration File

        private void BtnLoadCfg_Click(object sender, EventArgs e)
        {
            string rootDir = AppDomain.CurrentDomain.BaseDirectory;
            OpenFileDialog ofd = new OpenFileDialog
            {
                Title = "載入研華運動控制卡配置檔",
                Filter = "研華運動控制卡配置檔 (*.cfg)|*.cfg",
                DefaultExt = "cfg",
                InitialDirectory = rootDir,
            };

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                if (!_acm.LoadCfg(ofd.FileName))
                    _demoService.ShowErrMsg("控制卡開啟失敗！");
            }
        }

        #endregion Configuration File

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            _acmParams.DeviceEnable = checkBox1.Checked;

            if (_acmParams.AxisStatuses.Count == 0)
                _acmParams.AxisStatuses.Add(new AxisStatus());

            LbAxisList.Items.Clear();
            LbAxisList.Items.Add($"軸1");
            LbAxisList.SelectedIndex = 0;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            _acmParams.AxisNo = 0;
            PBoxAlm.BackColor = checkBox2.Checked ? CommonStyle.LightOn : CommonStyle.LightOff;
        }
    }
}
