﻿using Calin.MC.Advantech.Contracts;
using Calin.WinForm.Navigation;

namespace AcmDemo.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class ToolPanel : Form, INavigationAware
    {
        #region Fields

        private readonly IDemoService _demoService;
        private readonly IAcm _acm;

        #endregion Fields

        #region INavigationAware

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            if (CbAvailableDevice.Items.Count == 0 && _acm.DeviceCount > 0)
            {
                foreach (var dev in _acm.AvailableDevices)
                    CbAvailableDevice.Items.Add($"{dev.DeviceNum} - {dev.DeviceName}");
            }
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        public bool OnNavigatingFrom(INavigationParameters parameters)
        {
            return true;
        }

        #endregion INavigationAware

        public event EventHandler ToolPanelHidden;

        public ToolPanel(IDemoService demoService, IAcm acm)
        {
            InitializeComponent();

            _demoService = demoService;
            _acm = acm;

            StatePanel.DataBindings.Add(
                "Enabled",
                _demoService.UiState,
                nameof(UiState.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
            DevicePanel.DataBindings.Add(
                "Enabled",
                _demoService.UiState,
                nameof(UiState.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
            VelSetupPanel.DataBindings.Add(
                "Enabled",
                _demoService.UiState,
                nameof(UiState.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
            LbAxisList.DataBindings.Add(
                "Enabled",
                _demoService.UiState,
                nameof(UiState.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
        }

        private void MainPanel_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
                ToolPanelHidden?.Invoke(this, EventArgs.Empty);
                return;
            }
        }

        #region Device & Board

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            if (_acm.IsBoardInit)
            {
                if (!_acm.BoardClose())
                    _demoService.ShowErrMsg($"控制卡關閉失敗！");
            }
            else
            {
                MessageBox.Show("控制卡尚未開啟，無需關閉。", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            if (!_acm.BoardOpen())
                _demoService.ShowErrMsg("控制卡開啟失敗！");
        }

        private void BtnServoOn_Click(object sender, EventArgs e)
        {

        }

        #endregion Device & Board

        #region Configuration File

        private void BtnLoadCfg_Click(object sender, EventArgs e)
        {
            string rootDir = AppDomain.CurrentDomain.BaseDirectory;
            OpenFileDialog ofd = new OpenFileDialog
            {
                Title = "載入研華運動控制卡配置檔",
                Filter = "研華運動控制卡配置檔 (*.cfg)|*.cfg",
                DefaultExt = "cfg",
                InitialDirectory = rootDir,
            };

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                if (!_acm.LoadCfg(ofd.FileName))
                    _demoService.ShowErrMsg("控制卡開啟失敗！");
            }
        }

        #endregion Configuration File

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            _demoService.UiState.DeviceEnable = checkBox1.Checked;
        }
    }
}
