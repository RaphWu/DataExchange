﻿using Calin.MC.Advantech.Contracts;
using Calin.WinForm.Navigation;

namespace AcmDemo.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class MainPanel : UserControl
    {
        private readonly IDemoService _demoService;
        private readonly IAcm _acm;

        public MainPanel(IDemoService demoService, IAcm acm)
        {
            InitializeComponent();

            _demoService = demoService;
            _acm = acm;
        }

        #region Device & Board

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            if (_acm.IsBoardInit)
            {
                if (!_acm.BoardClose())
                    _demoService.ShowErrMsg($"控制卡關閉失敗！");
            }
            else
            {
                MessageBox.Show("控制卡尚未開啟，無需關閉。", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            if (!_acm.BoardOpen())
                _demoService.ShowErrMsg("控制卡開啟失敗！");
        }

        private void BtnServoOn_Click(object sender, EventArgs e)
        {

        }

        #endregion Device & Board

        #region Configuration File

        private void BtnLoadCfg_Click(object sender, EventArgs e)
        {
            string rootDir = AppDomain.CurrentDomain.BaseDirectory;
            OpenFileDialog ofd = new OpenFileDialog
            {
                Title = "載入研華運動控制卡配置檔",
                Filter = "研華運動控制卡配置檔 (*.cfg)|*.cfg",
                DefaultExt = "cfg",
                InitialDirectory = rootDir,
            };

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                if (!_acm.LoadCfg(ofd.FileName))
                    _demoService.ShowErrMsg("控制卡開啟失敗！");
            }
        }

        #endregion Configuration File
    }
}
