﻿namespace AcmDemo.Views
{
    partial class ToolPanel
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.DevicePanel = new System.Windows.Forms.GroupBox();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.CbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnServoOn = new System.Windows.Forms.Button();
            this.VelSetupPanel = new System.Windows.Forms.GroupBox();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.btn_SetParam = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.rdb_Rel = new System.Windows.Forms.RadioButton();
            this.rdb_Abs = new System.Windows.Forms.RadioButton();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.rdb_T = new System.Windows.Forms.RadioButton();
            this.rdb_S = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.LbAxisList = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.StatePanel = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxEZ = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.textBoxCurState = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.DevicePanel.SuspendLayout();
            this.VelSetupPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.StatePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEZ)).BeginInit();
            this.SuspendLayout();
            // 
            // DevicePanel
            // 
            this.DevicePanel.Controls.Add(this.BtnLoadCfg);
            this.DevicePanel.Controls.Add(this.label1);
            this.DevicePanel.Controls.Add(this.CbAvailableDevice);
            this.DevicePanel.Controls.Add(this.BtnOpenBoard);
            this.DevicePanel.Controls.Add(this.BtnCloseBoard);
            this.DevicePanel.Controls.Add(this.BtnServoOn);
            this.DevicePanel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.DevicePanel.Location = new System.Drawing.Point(12, 6);
            this.DevicePanel.Margin = new System.Windows.Forms.Padding(4);
            this.DevicePanel.Name = "DevicePanel";
            this.DevicePanel.Padding = new System.Windows.Forms.Padding(4);
            this.DevicePanel.Size = new System.Drawing.Size(285, 131);
            this.DevicePanel.TabIndex = 46;
            this.DevicePanel.TabStop = false;
            this.DevicePanel.Text = "操作裝置";
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(162, 58);
            this.BtnLoadCfg.Margin = new System.Windows.Forms.Padding(4);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(100, 25);
            this.BtnLoadCfg.TabIndex = 32;
            this.BtnLoadCfg.Text = "載入CFG檔";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            this.BtnLoadCfg.Click += new System.EventHandler(this.BtnLoadCfg_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 13;
            this.label1.Text = "可用裝置";
            // 
            // CbAvailableDevice
            // 
            this.CbAvailableDevice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbAvailableDevice.FormattingEnabled = true;
            this.CbAvailableDevice.Location = new System.Drawing.Point(79, 22);
            this.CbAvailableDevice.Margin = new System.Windows.Forms.Padding(4);
            this.CbAvailableDevice.Name = "CbAvailableDevice";
            this.CbAvailableDevice.Size = new System.Drawing.Size(183, 24);
            this.CbAvailableDevice.TabIndex = 14;
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(22, 58);
            this.BtnOpenBoard.Margin = new System.Windows.Forms.Padding(4);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(100, 25);
            this.BtnOpenBoard.TabIndex = 15;
            this.BtnOpenBoard.Text = "控制卡開啟";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(22, 91);
            this.BtnCloseBoard.Margin = new System.Windows.Forms.Padding(4);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(100, 25);
            this.BtnCloseBoard.TabIndex = 16;
            this.BtnCloseBoard.Text = "控制卡關閉";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnServoOn
            // 
            this.BtnServoOn.Location = new System.Drawing.Point(162, 91);
            this.BtnServoOn.Margin = new System.Windows.Forms.Padding(4);
            this.BtnServoOn.Name = "BtnServoOn";
            this.BtnServoOn.Size = new System.Drawing.Size(100, 25);
            this.BtnServoOn.TabIndex = 17;
            this.BtnServoOn.Text = "Servo On";
            this.BtnServoOn.UseVisualStyleBackColor = true;
            this.BtnServoOn.Click += new System.EventHandler(this.BtnServoOn_Click);
            // 
            // VelSetupPanel
            // 
            this.VelSetupPanel.Controls.Add(this.numericUpDown4);
            this.VelSetupPanel.Controls.Add(this.numericUpDown3);
            this.VelSetupPanel.Controls.Add(this.numericUpDown2);
            this.VelSetupPanel.Controls.Add(this.numericUpDown1);
            this.VelSetupPanel.Controls.Add(this.btn_SetParam);
            this.VelSetupPanel.Controls.Add(this.groupBox10);
            this.VelSetupPanel.Controls.Add(this.groupBox11);
            this.VelSetupPanel.Controls.Add(this.label16);
            this.VelSetupPanel.Controls.Add(this.label17);
            this.VelSetupPanel.Controls.Add(this.label18);
            this.VelSetupPanel.Controls.Add(this.label19);
            this.VelSetupPanel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.VelSetupPanel.Location = new System.Drawing.Point(116, 145);
            this.VelSetupPanel.Margin = new System.Windows.Forms.Padding(4);
            this.VelSetupPanel.Name = "VelSetupPanel";
            this.VelSetupPanel.Padding = new System.Windows.Forms.Padding(4);
            this.VelSetupPanel.Size = new System.Drawing.Size(181, 307);
            this.VelSetupPanel.TabIndex = 47;
            this.VelSetupPanel.TabStop = false;
            this.VelSetupPanel.Text = "速率設定 (PPU/sec)";
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown4.Location = new System.Drawing.Point(72, 26);
            this.numericUpDown4.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.numericUpDown4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown4.TabIndex = 43;
            this.numericUpDown4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown4.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown3.Location = new System.Drawing.Point(72, 57);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.numericUpDown3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown3.TabIndex = 42;
            this.numericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown3.Value = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown2.Location = new System.Drawing.Point(72, 88);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown2.TabIndex = 41;
            this.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown2.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(72, 117);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown1.TabIndex = 40;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // btn_SetParam
            // 
            this.btn_SetParam.Location = new System.Drawing.Point(39, 271);
            this.btn_SetParam.Margin = new System.Windows.Forms.Padding(4);
            this.btn_SetParam.Name = "btn_SetParam";
            this.btn_SetParam.Size = new System.Drawing.Size(100, 25);
            this.btn_SetParam.TabIndex = 39;
            this.btn_SetParam.Text = "設定/取得參數";
            this.btn_SetParam.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.rdb_Rel);
            this.groupBox10.Controls.Add(this.rdb_Abs);
            this.groupBox10.Location = new System.Drawing.Point(8, 210);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(164, 53);
            this.groupBox10.TabIndex = 38;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "移動模式";
            // 
            // rdb_Rel
            // 
            this.rdb_Rel.AutoSize = true;
            this.rdb_Rel.Location = new System.Drawing.Point(88, 17);
            this.rdb_Rel.Margin = new System.Windows.Forms.Padding(4);
            this.rdb_Rel.Name = "rdb_Rel";
            this.rdb_Rel.Size = new System.Drawing.Size(73, 20);
            this.rdb_Rel.TabIndex = 35;
            this.rdb_Rel.Text = "相對位置";
            this.rdb_Rel.UseVisualStyleBackColor = true;
            // 
            // rdb_Abs
            // 
            this.rdb_Abs.AutoSize = true;
            this.rdb_Abs.Checked = true;
            this.rdb_Abs.Location = new System.Drawing.Point(10, 17);
            this.rdb_Abs.Margin = new System.Windows.Forms.Padding(4);
            this.rdb_Abs.Name = "rdb_Abs";
            this.rdb_Abs.Size = new System.Drawing.Size(73, 20);
            this.rdb_Abs.TabIndex = 36;
            this.rdb_Abs.TabStop = true;
            this.rdb_Abs.Text = "絕對位置";
            this.rdb_Abs.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.rdb_T);
            this.groupBox11.Controls.Add(this.rdb_S);
            this.groupBox11.Location = new System.Drawing.Point(8, 149);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(164, 53);
            this.groupBox11.TabIndex = 37;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "速度曲線類型";
            // 
            // rdb_T
            // 
            this.rdb_T.AutoSize = true;
            this.rdb_T.Checked = true;
            this.rdb_T.Location = new System.Drawing.Point(10, 17);
            this.rdb_T.Margin = new System.Windows.Forms.Padding(4);
            this.rdb_T.Name = "rdb_T";
            this.rdb_T.Size = new System.Drawing.Size(68, 20);
            this.rdb_T.TabIndex = 35;
            this.rdb_T.TabStop = true;
            this.rdb_T.Text = "T型曲線";
            this.rdb_T.UseVisualStyleBackColor = true;
            // 
            // rdb_S
            // 
            this.rdb_S.AutoSize = true;
            this.rdb_S.Location = new System.Drawing.Point(88, 17);
            this.rdb_S.Margin = new System.Windows.Forms.Padding(4);
            this.rdb_S.Name = "rdb_S";
            this.rdb_S.Size = new System.Drawing.Size(68, 20);
            this.rdb_S.TabIndex = 36;
            this.rdb_S.Text = "S型曲線";
            this.rdb_S.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(20, 121);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 16);
            this.label16.TabIndex = 32;
            this.label16.Text = "減速度";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 90);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 16);
            this.label17.TabIndex = 30;
            this.label17.Text = "加速度";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 59);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 16);
            this.label18.TabIndex = 28;
            this.label18.Text = "運轉速度";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 28);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 16);
            this.label19.TabIndex = 26;
            this.label19.Text = "起始速度";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LbAxisList
            // 
            this.LbAxisList.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LbAxisList.FormattingEnabled = true;
            this.LbAxisList.ItemHeight = 16;
            this.LbAxisList.Location = new System.Drawing.Point(12, 165);
            this.LbAxisList.Margin = new System.Windows.Forms.Padding(4);
            this.LbAxisList.Name = "LbAxisList";
            this.LbAxisList.Size = new System.Drawing.Size(96, 164);
            this.LbAxisList.TabIndex = 57;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 58;
            this.label2.Text = "軸選擇";
            // 
            // StatePanel
            // 
            this.StatePanel.Controls.Add(this.label3);
            this.StatePanel.Controls.Add(this.pictureBox1);
            this.StatePanel.Controls.Add(this.label15);
            this.StatePanel.Controls.Add(this.label14);
            this.StatePanel.Controls.Add(this.label13);
            this.StatePanel.Controls.Add(this.label12);
            this.StatePanel.Controls.Add(this.pictureBoxNegHEL);
            this.StatePanel.Controls.Add(this.pictureBoxPosHEL);
            this.StatePanel.Controls.Add(this.pictureBoxORG);
            this.StatePanel.Controls.Add(this.pictureBoxEZ);
            this.StatePanel.Controls.Add(this.label20);
            this.StatePanel.Controls.Add(this.BtnResetErr);
            this.StatePanel.Controls.Add(this.textBoxCurState);
            this.StatePanel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.StatePanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.StatePanel.Location = new System.Drawing.Point(305, 6);
            this.StatePanel.Margin = new System.Windows.Forms.Padding(4);
            this.StatePanel.Name = "StatePanel";
            this.StatePanel.Padding = new System.Windows.Forms.Padding(4);
            this.StatePanel.Size = new System.Drawing.Size(201, 291);
            this.StatePanel.TabIndex = 59;
            this.StatePanel.TabStop = false;
            this.StatePanel.Text = "目前狀態";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 72);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 16);
            this.label3.TabIndex = 65;
            this.label3.Text = "Z相信號 (EZ)";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Gray;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(62, 71);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(18, 18);
            this.pictureBox1.TabIndex = 64;
            this.pictureBox1.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(84, 165);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 16);
            this.label15.TabIndex = 63;
            this.label15.Text = "負極限 (EL-)";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(84, 134);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(76, 16);
            this.label14.TabIndex = 62;
            this.label14.Text = "正極限 (EL+)";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(84, 103);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 16);
            this.label13.TabIndex = 61;
            this.label13.Text = "原點 (ORG)";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(84, 41);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 16);
            this.label12.TabIndex = 60;
            this.label12.Text = "警報 (ALM)";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(62, 164);
            this.pictureBoxNegHEL.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(18, 18);
            this.pictureBoxNegHEL.TabIndex = 59;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(62, 133);
            this.pictureBoxPosHEL.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(18, 18);
            this.pictureBoxPosHEL.TabIndex = 58;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(62, 102);
            this.pictureBoxORG.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(18, 18);
            this.pictureBoxORG.TabIndex = 57;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxEZ
            // 
            this.pictureBoxEZ.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxEZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxEZ.Location = new System.Drawing.Point(62, 40);
            this.pictureBoxEZ.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxEZ.Name = "pictureBoxEZ";
            this.pictureBoxEZ.Size = new System.Drawing.Size(18, 18);
            this.pictureBoxEZ.TabIndex = 56;
            this.pictureBoxEZ.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(25, 204);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 16);
            this.label20.TabIndex = 33;
            this.label20.Text = "狀態";
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(55, 254);
            this.BtnResetErr.Margin = new System.Windows.Forms.Padding(4);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(100, 25);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "異常重置";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            // 
            // textBoxCurState
            // 
            this.textBoxCurState.Location = new System.Drawing.Point(22, 223);
            this.textBoxCurState.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxCurState.Name = "textBoxCurState";
            this.textBoxCurState.ReadOnly = true;
            this.textBoxCurState.Size = new System.Drawing.Size(165, 23);
            this.textBoxCurState.TabIndex = 30;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(386, 381);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(86, 20);
            this.checkBox1.TabIndex = 60;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // ToolPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 462);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.StatePanel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.LbAxisList);
            this.Controls.Add(this.VelSetupPanel);
            this.Controls.Add(this.DevicePanel);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ToolPanel";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "主控面板";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainPanel_FormClosing);
            this.DevicePanel.ResumeLayout(false);
            this.DevicePanel.PerformLayout();
            this.VelSetupPanel.ResumeLayout(false);
            this.VelSetupPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.StatePanel.ResumeLayout(false);
            this.StatePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEZ)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox DevicePanel;
        private Button BtnLoadCfg;
        private Label label1;
        private ComboBox CbAvailableDevice;
        private Button BtnOpenBoard;
        private Button BtnCloseBoard;
        private Button BtnServoOn;
        private GroupBox VelSetupPanel;
        private Button btn_SetParam;
        private GroupBox groupBox10;
        public RadioButton rdb_Rel;
        public RadioButton rdb_Abs;
        private GroupBox groupBox11;
        public RadioButton rdb_T;
        public RadioButton rdb_S;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private ListBox LbAxisList;
        private Label label2;
        private GroupBox StatePanel;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private PictureBox pictureBoxNegHEL;
        private PictureBox pictureBoxPosHEL;
        private PictureBox pictureBoxORG;
        private PictureBox pictureBoxEZ;
        private Label label20;
        private Button BtnResetErr;
        private TextBox textBoxCurState;
        private Label label3;
        private PictureBox pictureBox1;
        private NumericUpDown numericUpDown4;
        private NumericUpDown numericUpDown3;
        private NumericUpDown numericUpDown2;
        private NumericUpDown numericUpDown1;
        private CheckBox checkBox1;
    }
}
