﻿namespace AcmDemo.Views
{
    partial class MainPanel
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.CbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnServoOn = new System.Windows.Forms.Button();
            this.groupBox12.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.BtnLoadCfg);
            this.groupBox12.Controls.Add(this.label1);
            this.groupBox12.Controls.Add(this.CbAvailableDevice);
            this.groupBox12.Controls.Add(this.BtnOpenBoard);
            this.groupBox12.Controls.Add(this.BtnCloseBoard);
            this.groupBox12.Controls.Add(this.BtnServoOn);
            this.groupBox12.Location = new System.Drawing.Point(16, 18);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(276, 133);
            this.groupBox12.TabIndex = 46;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "操作裝置";
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(157, 61);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(92, 25);
            this.BtnLoadCfg.TabIndex = 32;
            this.BtnLoadCfg.Text = "載入CFG檔";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            this.BtnLoadCfg.Click += new System.EventHandler(this.BtnLoadCfg_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "可用裝置：";
            // 
            // CbAvailableDevice
            // 
            this.CbAvailableDevice.FormattingEnabled = true;
            this.CbAvailableDevice.Location = new System.Drawing.Point(99, 22);
            this.CbAvailableDevice.Name = "CbAvailableDevice";
            this.CbAvailableDevice.Size = new System.Drawing.Size(150, 20);
            this.CbAvailableDevice.TabIndex = 14;
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(28, 61);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(92, 25);
            this.BtnOpenBoard.TabIndex = 15;
            this.BtnOpenBoard.Text = "控制卡開啟";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(28, 92);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(92, 25);
            this.BtnCloseBoard.TabIndex = 16;
            this.BtnCloseBoard.Text = "控制卡關閉";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnServoOn
            // 
            this.BtnServoOn.Location = new System.Drawing.Point(157, 92);
            this.BtnServoOn.Name = "BtnServoOn";
            this.BtnServoOn.Size = new System.Drawing.Size(92, 25);
            this.BtnServoOn.TabIndex = 17;
            this.BtnServoOn.Text = "Servo On";
            this.BtnServoOn.UseVisualStyleBackColor = true;
            this.BtnServoOn.Click += new System.EventHandler(this.BtnServoOn_Click);
            // 
            // MainPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox12);
            this.Name = "MainPanel";
            this.Size = new System.Drawing.Size(855, 590);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox12;
        private Button BtnLoadCfg;
        private Label label1;
        private ComboBox CbAvailableDevice;
        private Button BtnOpenBoard;
        private Button BtnCloseBoard;
        private Button BtnServoOn;
    }
}
