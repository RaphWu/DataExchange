using AcmDemo.Views;
using Calin.MC.Advantech.Contracts;
using Calin.WinForm.Navigation;

namespace AcmDemo
{
    public partial class MainForm : Form
    {
        #region Fields

        private readonly IRegionManager _region;
        private readonly INavigationService _nav;
        private readonly IDemoService _demoService;
        private readonly IAcm _acm;

        #endregion Fields

        public MainForm(
            IRegionManager regionManager,
            INavigationService navigationService,
            IDemoService demoService,
            IAcm acm)
        {
            InitializeComponent();

            _region = regionManager;
            _nav = navigationService;
            _demoService = demoService;
            _acm = acm;

            CommonStyle.SetMenuRadioButton(MenuMainPanel);
            CommonStyle.SetMenuRadioButton(MenuManual);
            CommonStyle.SetMenuRadioButton(MenuP2P);
            CommonStyle.SetMenuRadioButton(MenuHome);
        }

        #region Form Events

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            _region.RegisterRegion(nameof(ContentPanel), view =>
            {
                ContentPanel.SuspendLayout();
                ContentPanel.Controls.Clear();
                if (view is Control control)
                {
                    control.Dock = DockStyle.Fill;
                    ContentPanel.Controls.Add(control);
                }
                ContentPanel.ResumeLayout();
            });
        }

        #endregion Form Events

        #region Navigation

        private void SwitchPage(PageCode pageCode)
        {
            string regionName = nameof(ContentPanel);
            switch (pageCode)
            {
                case PageCode.MainPanel:
                    _nav.NavigateTo<MainPanel>(regionName, (int)PageCode.MainPanel);
                    break;
                case PageCode.Manual:
                    _nav.NavigateTo<ManualPage>(regionName, (int)PageCode.Manual);
                    break;
                case PageCode.Home:
                    _nav.NavigateTo<HomePage>(regionName, (int)PageCode.Home);
                    break;
                case PageCode.P2P:
                    _nav.NavigateTo<P2PPage>(regionName, (int)PageCode.P2P);
                    break;
                default:
                    throw new NotImplementedException($"�|����@�����N�X {pageCode} �������޿�C");
            }
        }

        #endregion Navigation

        #region Menu Control Events

        private void MenuMainPanel_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.MainPanel);
        }

        private void MenuManual_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Manual);
        }

        private void MenuHome_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Home);
        }

        private void MenuP2P_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.P2P);
        }

        #endregion Menu Control Events

        #region Control Events


        #endregion Control Events
    }
}
