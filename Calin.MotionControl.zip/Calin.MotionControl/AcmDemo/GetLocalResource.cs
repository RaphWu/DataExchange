﻿using AcmDemo.Views;

namespace AcmDemo
{
    public static class Resource
    {
        public static System.Drawing.Image GetLocalResource(string key)
        {
            var rm = new System.ComponentModel.ComponentResourceManager(typeof(HomePage));
            return (System.Drawing.Image)rm.GetObject(key);
        }
    }
}
