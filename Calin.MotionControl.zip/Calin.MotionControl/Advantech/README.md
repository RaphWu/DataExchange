﻿# Calin.MC.Advantech (研華通用運動 ACM) 使用說明

## 簡介

Calin.MC.Advantech 提供與 Advantech ACM (AdvMotAPI) 控制卡互動的封裝服務，包含裝置開啟/關閉、軸操作、群組操作、狀態輪詢與錯誤管理等功能。此套件透過介面分層，方便在應用程式中以 DI 容器（例如 `Autofac`）註冊與解析。

## 目標框架

- .NET Framework 4.8
- .NET 8

## 相依套件

- `Autofac`（用於註冊與解析服務）
- 原廠 C# 庫 `AdvMotAPI.dll`（請安裝 Advantech Common Motion Driver，並將 `AdvMotAPI.dll` 加入專案）

## 安裝與設定

1. 先安裝 Advantech Common Motion Driver（參考官方文件）。
2. 在專案中加入 `AdvMotAPI.dll`（建議放在 `nuget` 或專案資料夾，並將檔案屬性 `複製到輸出目錄` 設為 `一律複製`）。
3. 確認專案已加入 `Autofac` 套件（`Calin.MC.Advantech` 的 csproj 已包含此參考）。

## 重要檔案

- `AdvantechModule`：提供一個 `Autofac` 模組，可直接註冊 `IAcm` 實作。
- `IAcm`：根介面，包含裝置、軸、群組、輪詢與錯誤管理等子介面：
  - `IAcmService_Device`（裝置/控制卡）
  - `IAcmService_Axis`（軸操作）
  - `IAcmService_Group`（群組操作）
  - `IAcmService_Polling`（狀態輪詢）
  - `IAcmService_ErrManager`（錯誤管理）

## 註冊方式（Autofac）

- 使用 `AdvantechModule` 並直接傳入 `AcmConfig`：

  ```csharp
  var builder = new ContainerBuilder();
  var cfg = new Calin.MC.Advantech.Models.AcmConfig
  {
      // 若有需要，於此填入設定（目前類別為空，可擴充）
  };

  builder.RegisterModule(new Calin.MC.Advantech.AdvantechModule { AcmConfig = cfg });

  var container = builder.Build();
  using(var scope = container.BeginLifetimeScope())
  {
      var acm = scope.Resolve<Calin.MC.Advantech.Contracts.IAcm>();
      // 使用 acm
  }
  ```

- 或先註冊 `AcmConfig` 再讓模組從容器解析：

  ```csharp
  var builder = new ContainerBuilder();
  builder.RegisterInstance(new Calin.MC.Advantech.Models.AcmConfig()).SingleInstance();
  builder.RegisterModule(new Calin.MC.Advantech.AdvantechModule());
  var container = builder.Build();
  ```

## 介面與主要功能概覽

- `IAcmService_Device`
  - `uint GetAvailableDevs()`：取得可用裝置列表與數量（請檢查錯誤狀態）。
  - `bool BoardOpen()` / `bool BoardClose()`：開啟或關閉控制卡與其軸。
  - `bool LoadCfg(string filePath)`：載入控制卡設定檔。

- `IAcmService_Axis`
  - `bool AxisStop(uint axisNo)`：停止指定軸（減速停止）。
  - `bool AxisHome(uint axisNo, uint homeMode, uint direction, uint switchMode, double crossDistance)`：原點復歸。
  - `string GetHomeModeDescription(uint homeMode)`：取得原點模式描述。
  - 屬性：`AxisCount`、`RawAxisStates`、`ParsedAxisStates`。

- `IAcmService_Polling`
  - `event EventHandler<AcmStatusUpdatedEventArgs> AcmStatusUpdated`：軸狀態更新事件。
  - `void PollingStart()` / `void PollingStop()`：啟動 / 停止輪詢。輪詢會啟動背景執行緒，讀取原始狀態並解析成友善的旗標結構。

## 使用範例

以下為一般使用流程的範例：

```csharp
// 1. 建置容器並解析 IAcm
var builder = new Autofac.ContainerBuilder();
builder.RegisterModule(new Calin.MC.Advantech.AdvantechModule { AcmConfig = new Calin.MC.Advantech.Models.AcmConfig() });
var container = builder.Build();
var acm = container.Resolve<Calin.MC.Advantech.Contracts.IAcm>();

// 2. 取得可用裝置
uint devCount = acm.GetAvailableDevs();
// 檢查回傳或錯誤屬性（若有）

// 3. 設定欲開啟的裝置編號（若需要）
// 假設欲使用的裝置編號已透過 AcmConfig 或其他方式設定，或直接操作屬性

// 4. 開啟控制卡
if (!acm.BoardOpen())
{
    // 處理錯誤
}

// 5. 訂閱狀態更新事件
acm.AcmStatusUpdated += (s, e) =>
{
    // e.AxisNo, e.State (ParsedAxisState)
    Console.WriteLine($"Axis {e.AxisNo} state: {e.State.AxisState}");
};

// 6. 啟動輪詢（BoardOpen 會自動啟動 PollingStart，視實作而定；若未啟動可呼叫）
acm.PollingStart();

// 7. 控制軸範例：原點、停止
uint axis = 0;
acm.AxisHome(axis, (uint)Advantech.Motion.HomeMode.MODE1_Abs, 1, 0, 10000);
Thread.Sleep(1000);
acm.AxisStop(axis);

// 8. 關閉並釋放
acm.PollingStop();
acm.BoardClose();
```

## 注意事項

- `AdvMotAPI.dll` 為原廠非託管 DLL，使用前請確保驅動與對應版本已安裝並可存取。
- 輪詢會建立背景執行緒，請在應用程式結束或切換控制卡時呼叫 `PollingStop()` 與 `BoardClose()` 以確保資源釋放與執行緒結束。
- `AcmConfig` 目前為空的設定容器，可在未來擴充以放置初始化參數（例如要開啟的裝置編號、輪詢參數等）。

## 授權與版本

套件版本請參見專案檔 `Advantech.csproj` 中的 `<Version>`。
