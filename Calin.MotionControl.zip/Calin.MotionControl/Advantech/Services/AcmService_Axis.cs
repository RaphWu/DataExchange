﻿using System;
using Advantech.Motion;
using Calin.MC.Advantech.Contracts;

namespace Calin.MC.Advantech.Services
{
    // 軸操作
    public partial class AcmService : IAcmService_Axis
    {
        public uint AxisCount => m_AxisCount;

        /// <inheritdoc/>
        public bool AxisStop(uint axisNo)
        {
            if (IsBoardInit)
            {
                ErrCode = Motion.mAcm_AxStopDec(m_AxisHandles[axisNo]);
                return Success;
            }

            return false;
        }


        public bool AxisHome(uint axisNo)
        {
            if (IsBoardInit)
            {
                //ErrCode = Motion.mAcm_AxHomeMove(m_AxisHandles[axisNo]);
                return Success;
            }
            return false;
        }
    }
}
