﻿using System;
using Advantech.Motion;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Services
{
    // 軸操作
    public partial class AcmService : IAcmService_Axis
    {
        #region Fields

        private AcmAxisState[] _rawAxisStates = null; // 軸原始狀態 Snapshot buffer

        private ParsedAxisState[] _parsedAxisStates = null; // 軸解析後狀態

        #endregion Fields

        #region Properties

        public uint AxisCount => m_AxisCount;
        public AcmAxisState[] RawAxisStates => _rawAxisStates;
        public ParsedAxisState[] ParsedAxisStates => _parsedAxisStates;

        #endregion Properties

        #region Methods

        /// <inheritdoc/>
        public bool AxisStop(uint axisNo)
        {
            if (IsBoardInit)
            {
                ErrCode = Motion.mAcm_AxStopDec(m_AxisHandles[axisNo]);
                return !CheckErr($"{nameof(IAcmService_Axis)}.{nameof(AxisStop)}", $"軸{axisNo}減速停止錯誤！");
            }
            return false;
        }

        /// <inheritdoc/>
        public bool AxisHome(
            uint axisNo,
            uint homeMode,
            uint direction,
            uint switchMode,
            double crossDistance)
        {
            if (IsBoardInit)
            {
                // stopping condition
                ErrCode = Motion.mAcm_SetU32Property(m_AxisHandles[axisNo], (uint)PropertyID.PAR_AxHomeExSwitchMode, switchMode);
                if (CheckErr($"{nameof(IAcmService_Axis)}.{nameof(AxisHome)}", $"軸 {axisNo} 屬性 PAR_AxHomeExSwitchMode 設定失敗：{switchMode}！"))
                    return false;

                // home cross distance (Unit: PPU). 須大於 0. 預設值 10000
                ErrCode = Motion.mAcm_SetF64Property(m_AxisHandles[axisNo], (uint)PropertyID.PAR_AxHomeCrossDistance, crossDistance);
                if (CheckErr($"{nameof(IAcmService_Axis)}.{nameof(AxisHome)}", $"軸 {axisNo} 屬性 PAR_AxHomeCrossDistance 設定失敗：{crossDistance}！"))
                    return false;

                // Home動作
                ErrCode = Motion.mAcm_AxHome(m_AxisHandles[axisNo], homeMode, direction);
                if (CheckErr($"{nameof(IAcmService_Axis)}.{nameof(AxisHome)}", $"軸 {axisNo} 原點復歸失敗！\n復歸模式：{(HomeMode)homeMode}\n復歸方向：{direction}"))
                    return false;

                return true;
            }
            return false;
        }

        /// <inheritdoc/>
        public string GetHomeModeDescription(uint homeMode)
        {
            if (Enum.TryParse(homeMode.ToString(), out HomeMode hm))
            {
                return hm switch
                {
                    HomeMode.MODE1_Abs => "Move (Dir) -> Touch ORG -> Stop",
                    HomeMode.MODE2_Lmt => "Move (Dir) -> Touch EL -> Stop",
                    HomeMode.MODE3_Ref => "Move (Dir) -> Touch EZ -> Stop",
                    HomeMode.MODE4_Abs_Ref => "ORG + EZ, Move (Dir) -> Touch ORG -> Stop -> Move (Dir) -> Touch EZ -> Stop",
                    HomeMode.MODE5_Abs_NegRef => "ORG+EZ, Move (Dir) -> Touch ORG -> Stop -> Move (-Dir) -> Touch EZ -> Stop",
                    HomeMode.MODE6_Lmt_Ref => "EL + NegEZ, Move (Dir) -> Touch EL -> Stop -> Move (-Dir) -> Touch EZ -> Stop",
                    HomeMode.MODE7_AbsSearch => "Move (Dir) -> Search ORG -> Stop",
                    HomeMode.MODE8_LmtSearch => "Move (Dir) -> Search EL -> Stop",
                    HomeMode.MODE9_AbsSearch_Ref => "Search ORG + EZ, Move (Dir) -> Search ORG -> Stop -> Move (Dir) -> Touch EZ -> Stop",
                    HomeMode.MODE10_AbsSearch_NegRef => "Search ORG + NegEZ, Move (Dir) -> Search ORG -> Stop -> Move (-Dir) -> Touch EZ -> Stop",
                    HomeMode.MODE11_LmtSearch_Ref => "Search EL + Neg EZ, Move (Dir) -> Search EL -> Stop -> Move (-Dir) -> Touch EZ -> Stop",
                    HomeMode.MODE12_AbsSearchReFind => "Search ORG +Re-find ORG, Move (Dir) -> Search ORG -> Stop -> Move (-Dir) -> Leave ORG (FL) -> Stop -> Move (-Dir) -> Re-find ORG(FL) -> Stop",
                    HomeMode.MODE13_LmtSearchReFind => "Search EL +Refind EL, Move (Dir) -> Search EL -> Stop -> Move (-Dir) -> Leave EL(FL) -> Stop -> Move (-Dir) -> Re-find EL(FL) -> Stop",
                    HomeMode.MODE14_AbsSearchReFind_Ref => "Search ORG +Refind ORG + EZ, Move (Dir) -> Search ORG -> Stop -> Move (-Dir) -> Leave ORG(FL) -> Stop -> Move (-Dir) -> Re-find ORG (FL) -> Stop -> Move (Dir) -> touch EZ -> Stop",
                    HomeMode.MODE15_AbsSearchReFind_NegRef => "Search ORG + Re-find ORG + Neg EZ, Move (Dir) -> Search ORG -> Stop -> Move (-Dir) -> Leave ORG (FL) -> Stop -> Move (-Dir) -> Re-find ORG (FL) -> Stop -> Move (-Dir) -> Touch EZ ->Stop",
                    HomeMode.MODE16_LmtSearchReFind_Ref => "Search EL + Re-find EL + EZ, Move (Dir) - > Search EL -> Stop -> Move (-Dir) -> Leave EL (FL) -> Stop -> Move (-Dir) -> Re-find EL (FL) -> Stop -> Move (-Dir) -> Touch EZ -> Stop",
                    _ => "",
                };
            }
            else
            {
                return "";
            }
        }

        #endregion Methods
    }
}
