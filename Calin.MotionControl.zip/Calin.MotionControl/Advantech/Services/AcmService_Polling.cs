﻿using System;
using System.Diagnostics;
using System.Threading;
using Advantech.Motion;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Services
{
    /// <summary>
    /// 當軸狀態有更新時，供事件傳遞狀態使用。
    /// </summary>
    public sealed class AcmStatusUpdatedEventArgs : EventArgs
    {
        /// <summary>
        /// 軸編號。
        /// </summary>
        public int AxisNo { get; }

        /// <summary>
        /// 軸狀態。
        /// </summary>
        public ParsedAxisState State { get; }

        public AcmStatusUpdatedEventArgs(int axisNo, ParsedAxisState state)
        {
            AxisNo = axisNo;
            State = state;
        }
    }

    // 控制卡狀態讀取/更新服務。
    public partial class AcmService : IAcmService_Polling
    {
        #region Fields

        private Thread _monitoringThread;
        private Thread _parseThread;
        private CancellationTokenSource _pollingCts;

        #endregion Fields

        #region Properties

        public event EventHandler<AcmStatusUpdatedEventArgs>? AcmStatusUpdated;

        #endregion Properties

        #region Methods

        /// <inheritdoc/>
        public void PollingStop()
        {
            _pollingCts?.Cancel();
        }

        /// <inheritdoc/>
        public void PollingStart()
        {
            _pollingCts = new CancellationTokenSource();

            _monitoringThread = new Thread(() => MonitoringProc(_pollingCts.Token));
            _monitoringThread.IsBackground = true;
            _monitoringThread.Priority = ThreadPriority.Highest;
            _monitoringThread.Start();

            _parseThread = new Thread(() => ParseProc(_pollingCts.Token));
            _parseThread.IsBackground = true;
            _parseThread.Priority = ThreadPriority.Normal;
            _parseThread.Start();
        }

        #endregion Methods

        #region Polling Procedures

        /// <summary>
        /// 狀態更新(高頻)。
        /// </summary>
        private void MonitoringProc(CancellationToken token)
        {
            var sw = Stopwatch.StartNew();
            long ticksPerMs = Stopwatch.Frequency / 1000;
            long nextTick = sw.ElapsedTicks;

            while (!token.IsCancellationRequested)
            {
                long now = sw.ElapsedTicks;
                if (now >= nextTick)
                {
                    nextTick += ticksPerMs;

                    for (int axisNo = 0; axisNo < m_AxisCount; axisNo++)
                    {
                        // 軸IO狀態
                        ushort acmAxisState = default;
                        ErrCode = Motion.mAcm_AxGetState(m_AxisHandles[axisNo], ref acmAxisState);
                        if (CheckErr($"{nameof(AcmService)}.{nameof(MonitoringProc)}", $"無法取得軸 {axisNo} 的狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }

                        // 軸運動狀態
                        uint acmMotionStatus = default;
                        ErrCode = Motion.mAcm_AxGetMotionStatus(m_AxisHandles[axisNo], ref acmMotionStatus);
                        if (CheckErr($"{nameof(AcmService)}.{nameof(MonitoringProc)}", $"無法取得軸 {axisNo} 的運動狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }

                        // 軸IO狀態
                        uint acmIoStatus = default;
                        ErrCode = Motion.mAcm_AxGetMotionIO(m_AxisHandles[axisNo], ref acmIoStatus);
                        if (CheckErr($"{nameof(AcmService)}.{nameof(MonitoringProc)}", $"無法取得軸 {axisNo} 的 I/O 狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }

                        var axisState = _rawAxisStates[axisNo];
                        axisState.AxisState = (AxisState)acmAxisState;
                        axisState.MotionStatus = acmMotionStatus;
                        axisState.IoStatus = acmIoStatus;
                        _rawAxisStates[axisNo] = axisState;
                    }

                    // 用於須快速反應的停止條件
                    //if (torque >= TorqueLimit)
                    //{
                    //    EmergencyStop();
                    //}
                }
                else
                {
                    Thread.SpinWait(10);
                }
            }
        }

        /// <summary>
        /// 解析程序。
        /// </summary>
        private void ParseProc(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                for (int axisNo = 0; axisNo < m_AxisCount; axisNo++)
                {
                    var parsedState = _parsedAxisStates[axisNo];

                    // 軸狀態
                    parsedState.StateFlags = (StateFlags)(2 ^ (int)_rawAxisStates[axisNo].AxisState);

                    // 軸運動狀態
                    parsedState.MotionFlags = (MotionStatusFlags)(_rawAxisStates[axisNo].MotionStatus & (uint)(
                        MotionStatusFlags.Stop |
                        MotionStatusFlags.WaitERC |
                        MotionStatusFlags.CorrectBksh |
                        MotionStatusFlags.InFA |
                        MotionStatusFlags.InFL |
                        MotionStatusFlags.InACC |
                        MotionStatusFlags.InFH |
                        MotionStatusFlags.InDEC |
                        MotionStatusFlags.WaitINP));

                    // 軸IO狀態
                    parsedState.IoFlags = (AxisIoFlags)(_rawAxisStates[axisNo].IoStatus & (uint)(
                        AxisIoFlags.RDY |
                        AxisIoFlags.ALM |
                        AxisIoFlags.LMT_Positive |
                        AxisIoFlags.LMT_Negative |
                        AxisIoFlags.ORG |
                        AxisIoFlags.DIR |
                        AxisIoFlags.EMG |
                        AxisIoFlags.PCS |
                        AxisIoFlags.ERC |
                        AxisIoFlags.EZ |
                        AxisIoFlags.CLR |
                        AxisIoFlags.LTC |
                        AxisIoFlags.SD |
                        AxisIoFlags.INP |
                        AxisIoFlags.SVON |
                        AxisIoFlags.ALRM |
                        AxisIoFlags.SLMT_Positive |
                        AxisIoFlags.SLMT_Negative |
                        AxisIoFlags.CMP |
                        AxisIoFlags.CAMDO));

                    if (_parsedAxisStates[axisNo] != parsedState)
                    {
                        _parsedAxisStates[axisNo] = parsedState;
                        AcmStatusUpdated?.Invoke(this, new AcmStatusUpdatedEventArgs(axisNo, parsedState));
                    }
                }

                // 用於一般的停止條件
                //if (torque >= TorqueLimit)
                //{
                //    StopWhenConditions();
                //}

                Thread.Sleep(30);
            }
        }

        #endregion Polling Procedures

        /// <summary>
        /// 緊急停止。
        /// </summary>
        /// <remarks></remarks>
        private void EmergencyStop()
        {
            // 只做停機，不寫 log，不更新 UI
        }

        /// <summary>
        /// 
        /// </summary>
        private void StopWhenConditions()
        {

        }
    }
}
