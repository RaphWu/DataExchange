﻿using System;
using System.Collections.Generic;
using Advantech.Motion;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Services
{
    // 裝置(Device)與控制卡(Board)操作
    // 裝置設定檔操作
    public partial class AcmService : IAcmService_Device
    {
        #region properties

        public uint DeviceCount => m_DeviceCount;
        public List<DeviceInfo> AvailableDevices => m_AvailableDevices;
        public uint DeviceNumber => m_DeviceNum;
        public nint DeviceHandle => m_DeviceHandle;
        public bool IsBoardInit => m_BoardInit;
        public bool IsServoOn => m_ServoOn;

        #endregion properties

        #region methods

        /// <inheritdoc/>
        public uint GetAvailableDevs()
        {
            DEV_LIST[] availableDevices = new DEV_LIST[Motion.MAX_DEVICES];
            ErrCode = (uint)Motion.mAcm_GetAvailableDevs(availableDevices, Motion.MAX_DEVICES, ref m_DeviceCount);
            if (CheckErr($"{nameof(AcmService)}.{nameof(GetAvailableDevs)}", "取得裝置編號及名稱列表失敗！"))
                return 0;

            m_AvailableDevices.Clear();
            for (int i = 0; i < m_DeviceCount; i++)
                m_AvailableDevices.Add(new DeviceInfo()
                {
                    DeviceNum = availableDevices[i].DeviceNum,
                    DeviceName = availableDevices[i].DeviceName,
                    NumofSubDevice = availableDevices[i].NumofSubDevice,
                });
            return m_DeviceCount;
        }

        /// <inheritdoc/>
        public bool BoardClose()
        {
            ushort[] axisState = new ushort[32];
            uint axisNum;

            if (m_BoardInit)
            {
                PollingStop();

                for (axisNum = 0; axisNum < m_AxisCount; axisNum++)
                {
                    // 取得軸的當前狀態
                    ErrCode = Motion.mAcm_AxGetState(m_AxisHandles[axisNum], ref axisState[axisNum]);
                    if (CheckErr($"{nameof(AcmService)}.{nameof(BoardClose)}", $"無法取得軸 {axisNum} 的當前狀態！")) return false;

                    if (axisState[axisNum] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        // 重置座標軸狀態。如果座標軸處於 ErrorStop 狀態，呼叫此函數後，其狀態將變更為 Ready
                        ErrCode = Motion.mAcm_AxResetError(m_AxisHandles[axisNum]);
                        if (CheckErr($"{nameof(AcmService)}.{nameof(BoardClose)}", $"無法重置軸 {axisNum} 的座標軸狀態！")) return false;
                    }

                    // 命令軸減速直至停止
                    ErrCode = Motion.mAcm_AxStopDec(m_AxisHandles[axisNum]);
                    if (CheckErr($"{nameof(AcmService)}.{nameof(BoardClose)}", $"軸 {axisNum} 減速至停的動作失敗！")) return false;
                }

                for (axisNum = 0; axisNum < m_AxisCount; axisNum++)
                {
                    ErrCode = Motion.mAcm_AxClose(ref m_AxisHandles[axisNum]);
                    if (CheckErr($"{nameof(AcmService)}.{nameof(BoardClose)}", $"軸 {axisNum} 關閉失敗！")) return false;
                }
                m_AxisCount = 0;

                ErrCode = Motion.mAcm_DevClose(ref m_DeviceHandle);
                if (CheckErr($"{nameof(AcmService)}.{nameof(BoardClose)}", "裝置關閉失敗！")) return false;

                m_DeviceHandle = IntPtr.Zero;
                m_BoardInit = false;
            }
            return true;
        }

        /// <inheritdoc/>
        public bool BoardOpen()
        {
            ErrCode = Motion.mAcm_DevOpen(m_DeviceNum, ref m_DeviceHandle);
            if (CheckErr($"{nameof(AcmService)}.{nameof(BoardOpen)}", "裝置開啟失敗！"))
                return false;

            ErrCode = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref m_AxisCount);
            if (CheckErr($"{nameof(AcmService)}.{nameof(BoardOpen)}", "無法取得控制卡上的軸數量！"))
                return false;

            if (m_AxisCount == 0)
            {
                SetErr($"{nameof(AcmService)}.{nameof(BoardOpen)}", "控制卡軸數量為 0，無法進行後續操作！");
                return false;
            }

            for (uint axisNum = 0; axisNum < m_AxisCount; axisNum++)
            {
                ErrCode = Motion.mAcm_AxOpen(m_DeviceHandle, (UInt16)axisNum, ref m_AxisHandles[axisNum]);
                if (CheckErr($"{nameof(AcmService)}.{nameof(BoardOpen)}", $"軸 {axisNum} 開啟失敗！"))
                    return false;

                // 設定命令位置及實際位置為 0
                _ = Motion.mAcm_AxSetCmdPosition(m_AxisHandles[axisNum], 0.0);
                _ = Motion.mAcm_AxSetActualPosition(m_AxisHandles[axisNum], 0.0);
            }

            _rawAxisStates = new AcmAxisState[m_AxisCount];
            PollingStart();

            m_BoardInit = true;
            return true;
        }

        /// <inheritdoc/>
        public bool LoadCfg(string filePath)
        {
            if (!m_BoardInit)
                return true;

            ErrCode = Motion.mAcm_DevLoadConfig(m_DeviceHandle, filePath);
            if (CheckErr($"{nameof(AcmService)}.{nameof(BoardClose)}", "裝置Config檔載入失敗！")) return false;

            return true;
        }

        #endregion methods
    }
}
