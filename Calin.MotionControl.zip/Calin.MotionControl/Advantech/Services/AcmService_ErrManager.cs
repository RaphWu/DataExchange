﻿using System.Text;
using Advantech.Motion;
using Calin.MC.Advantech.Contracts;

namespace Calin.MC.Advantech.Services
{
    // 錯誤管理
    public partial class AcmService : IAcmService_ErrManager
    {
        #region fields

        private const int MaxError = 100;
        private StringBuilder _errMsg = new StringBuilder("", MaxError);
        private uint _errCode;
        private string _errDetail = "";
        private string _callerName = "";

        #endregion fields

        #region Properties

        public bool NoError => _errCode == (int)ErrorCode.SUCCESS;
        public bool HasError => _errCode != (int)ErrorCode.SUCCESS;
        public uint ErrCode
        {
            get => _errCode;
            set
            {
                _errCode = value;

                if (value != (int)ErrorCode.SUCCESS)
                {
                    if (!Motion.mAcm_GetErrorMessage(value, _errMsg, MaxError))
                        _errMsg.Clear().Append($"無法取得錯誤代碼 0x{value:8X} 的訊息，請查閱手冊或詢問原廠。");
                    if (_errDetail.Length > 0)
                        _errDetail = "";
                }
                else
                {
                    if (_errMsg.Length > 0)
                        _errMsg.Clear();
                    if (_errDetail.Length > 0)
                        _errDetail = "";
                }
            }
        }
        public string ErrMessage => _errMsg.Length == 0 ? "" : _errMsg.ToString();
        public string ErrDetail => _errDetail;
        public string ErrCallerName => _callerName;

        #endregion Properties

        #region Internal Methods

        /// <summary>
        /// 檢查是否有錯誤發生，並設定詳細資訊。
        /// </summary>
        /// <remarks>注意：只有在有錯誤發生時才會設定呼叫者名稱及錯誤詳細資訊，以避免過多的變數設定動作。</remarks>
        /// <param name="CallerName">呼叫者名稱。</param>
        /// <param name="detailMsg">錯誤詳細資訊。</param>
        /// <returns>是否有錯誤發生。</returns>
        internal bool CheckErr(string CallerName, string detailMsg = "")
        {
            if (HasError)
            {
                _callerName = CallerName + "()";
                _errDetail = detailMsg;
                return true;
            }
            return false;
        }

        /// <summary>
        /// 檢查是否有錯誤發生，並設定詳細資訊。
        /// </summary>
        /// <param name="detailMsg">錯誤詳細資訊。</param>
        /// <returns>是否有錯誤發生。</returns>
        internal bool CheckErr(string detailMsg = "")
        {
            return CheckErr("", detailMsg);
        }

        #endregion Internal Methods









        ///// <summary>
        ///// 錯誤訊息表。
        ///// </summary>
        //internal Dictionary<int, ErrManager> errorMessages = new Dictionary<int, ErrManager>();

        ///// <inheritdoc/>
        //public ErrManager GetErrMessage(int code)
        //{
        //    return errorMessages.TryGetValue(code, out var errMessage)
        //        ? errMessage
        //        : new ErrMessage("查無代碼", $"錯誤訊息表沒有錯誤代碼 0x{code:8X} 的資訊，請查閱手冊。");
        //}

        ///// <summary>
        ///// 設定錯誤訊息表。
        ///// </summary>
        //internal void ConfigErrorMessages()
        //{
        //    errorMessages.Add(0x00000000, new ErrMessage("SUCCESS"));
        //}
    }
}
