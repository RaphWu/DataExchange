﻿using System;

namespace Calin.MC.Advantech.Models
{
    [Flags]
    public enum StateFlags : uint
    {
        STA_AX_DISABLE = 2 ^ 0,
        STA_AX_READY = 2 ^ 1,
        STA_AX_STOPPING = 2 ^ 2,
        STA_AX_ERROR_STOP = 2 ^ 3,
        STA_AX_HOMING = 2 ^ 4,
        STA_AX_PTP_MOT = 2 ^ 5,
        STA_AX_CONTI_MOT = 2 ^ 6,
        STA_AX_SYNC_MOT = 2 ^ 7,
        STA_AX_EXT_JOG = 2 ^ 8,
        STA_AX_EXT_MPG = 2 ^ 9,
        STA_AX_PAUSE = 2 ^ 10,
        STA_AX_BUSY = 2 ^ 11,
        STA_AX_WAIT_DI = 2 ^ 12,
        STA_AX_WAIT_PTP = 2 ^ 13,
        STA_AX_WAIT_VEL = 2 ^ 14,
        STA_AX_EXT_JOG_READY = 2 ^ 15,
    }
}
