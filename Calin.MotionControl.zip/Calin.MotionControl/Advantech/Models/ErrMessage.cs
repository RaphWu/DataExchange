﻿namespace Calin.MC.Advantech.Models
{
    /// <summary>
    /// 錯誤訊息結構。
    /// </summary>
    public struct ErrMessage()
    {
        public ErrMessage(int errCode, string message) : this()
        {
            ErrorCode = errCode;
            Message = message;
            Description = "";
        }

        public ErrMessage(int errCode, string message, string description) : this()
        {
            ErrorCode = errCode;
            Message = message;
            Description = description;
        }

        public int ErrorCode { get; set; }

        /// <summary>
        /// 錯誤訊息。
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// 說明。
        /// </summary>
        public string Description { get; set; }
    }
}
