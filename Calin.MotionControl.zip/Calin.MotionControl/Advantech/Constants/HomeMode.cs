﻿using System.ComponentModel;

namespace Calin.MC.Advantech.Constants
{
    public enum HomeMode
    {
        [Description("Move (Dir) -> Touch ORG -> Stop")]
        MODE1_Abs,

        [Description("Move (Dir) -> Touch EL -> Stop")]
        MODE2_Lmt,

        [Description("Move (Dir) -> Touch EZ -> Stop")]
        MODE3_Ref,

        [Description("ORG + EZ, Move (Dir) -> Touch ORG -> Stop -> Move (Dir) -> Touch EZ -> Stop")]
        MODE4_Abs_Ref,

        [Description("ORG+EZ, Move (Dir) -> Touch ORG -> Stop -> Move (-Dir) -> Touch EZ -> Stop")]
        MODE5_Abs_NegRef,

        [Description("EL + NegEZ, Move (Dir) -> Touch EL -> Stop -> Move (-Dir) -> Touch EZ -> Stop")]
        MODE6_Lmt_Ref,

        [Description("Move (Dir) -> Search ORG -> Stop")]
        MODE7_AbsSearch,

        [Description("Move (Dir) -> Search EL -> Stop")]
        MODE8_LmtSearch,

        [Description("Search ORG + EZ, Move (Dir) -> Search ORG -> Stop -> Move (Dir) -> Touch EZ -> Stop")]
        MODE9_AbsSearch_Ref,

        [Description("Search ORG + NegEZ, Move (Dir) -> Search ORG -> Stop -> Move (-Dir) -> Touch EZ -> Stop")]
        MODE10_AbsSearch_NegRef,

        [Description("Search EL + Neg EZ, Move (Dir) -> Search EL -> Stop -> Move (-Dir) -> Touch EZ -> Stop")]
        MODE11_LmtSearch_Ref,

        [Description("Search ORG +Re-find ORG, Move (Dir) -> Search ORG -> Stop -> Move (-Dir) -> Leave ORG (FL) -> Stop -> Move (-Dir) -> Re-find ORG(FL) -> Stop")]
        MODE12_AbsSearchReFind,

        [Description("Search EL +Refind EL, Move (Dir) -> Search EL -> Stop -> Move (-Dir) -> Leave EL(FL) -> Stop -> Move (-Dir) -> Re-find EL(FL) -> Stop")]
        MODE13_LmtSearchReFind,

        [Description("Search ORG +Refind ORG + EZ, Move (Dir) -> Search ORG -> Stop -> Move (-Dir) -> Leave ORG(FL) -> Stop -> Move (-Dir) -> Re-find ORG (FL) -> Stop -> Move (Dir) -> touch EZ -> Stop")]
        MODE14_AbsSearchReFind_Ref,

        [Description("Search ORG + Re-find ORG + Neg EZ, Move (Dir) -> Search ORG -> Stop -> Move (-Dir) -> Leave ORG (FL) -> Stop -> Move (-Dir) -> Re-find ORG (FL) -> Stop -> Move (-Dir) -> Touch EZ ->Stop")]
        MODE15_AbsSearchReFind_NegRef,

        [Description("Search EL + Re-find EL + EZ, Move (Dir) - > Search EL -> Stop -> Move (-Dir) -> Leave EL (FL) -> Stop -> Move (-Dir) -> Re-find EL (FL) -> Stop -> Move (-Dir) -> Touch EZ -> Stop")]
        MODE16_LmtSearchReFind_Ref,
    }
}
