﻿namespace Calin.MC.Advantech.Contracts
{
    public interface IAcmService_Polling
    {
    }
}
