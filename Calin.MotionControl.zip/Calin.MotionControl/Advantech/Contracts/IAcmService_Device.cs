﻿namespace Calin.MC.Advantech.Contracts
{
    /// <summary>
    /// 裝置操作服務介面。
    /// </summary>
    public interface IAcmService_Device
    {
        #region properties

        /// <summary>
        /// 裝置編號。
        /// </summary>
        uint DeviceNumber { get; }

        /// <summary>
        /// 裝置句柄。
        /// </summary>
        nint DeviceHandle { get; }

        /// <summary>
        /// 控制卡是否初始化。
        /// </summary>
        bool IsBoardInit { get; }

        /// <summary>
        /// 伺服是否開啟。
        /// </summary>
        bool IsServoOn { get; }

        #endregion properties

        #region methods

        /// <summary>
        /// 取得已成功載入驅動裝置的裝置編號和名稱列表。
        /// </summary>
        /// <remarks>呼叫完記得檢查 NoError 或 HasError 屬性。</remarks>
        /// <returns>執行結果是否成功。</returns>
        bool GetAvailableDevs();

        /// <summary>
        /// 關閉控制卡及所含的全部軸。
        /// </summary>
        /// <returns>執行結果是否成功。</returns>
        bool BoardClose();

        /// <summary>
        /// 開啟控制卡及所含的全部軸。
        /// </summary>
        /// <returns>執行結果是否成功。</returns>
        bool BoardOpen();

        /// <summary>
        /// 載入裝置設定檔。
        /// </summary>
        /// <param name="filePath">裝置設定檔路徑及名稱。</param>
        /// <returns>是否載入成功。</returns>
        bool LoadCfg(string filePath);

        #endregion methods
    }
}
