﻿using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Contracts
{
    /// <summary>
    /// 軸操作服務介面。
    /// </summary>
    public interface IAcmService_Axis
    {
        #region Properties

        /// <summary>
        /// 取得軸數量。
        /// </summary>
        uint AxisCount { get; }

        /// <summary>
        /// 各軸狀態。
        /// </summary>
        /// <remarks>此值為高頻 IO 讀值，儘量使用解析後的 ParsedAxisStates。</remarks>
        public AcmAxisState[] RawAxisStates { get; }

        /// <summary>
        /// 各軸解析後狀態。
        /// </summary>
        ParsedAxisState[] ParsedAxisStates { get; }

        #endregion Properties

        #region Methods

        /// <summary>
        /// 軸減速停止。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <returns>動作是否完成。</returns>
        bool AxisStop(uint axisNo);

        /// <summary>
        /// 軸原點復歸。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <param name="homeMode">復歸模式 (模式0 ~ 15)。</param>
        /// <param name="direction">復歸方向 (0:正方向, 1:負方向)。</param>
        /// <param name="switchMode">停止模式 (0:Level On, 1:Level Off, 2:Rising Edge, 3:Falling Edge)。</param>
        /// <param name="crossDistance">跨越距離 (大於0)。</param>
        /// <returns>動作是否完成。</returns>
        bool AxisHome(
            uint axisNo,
            uint homeMode,
            uint direction,
            uint switchMode,
            double crossDistance);

        /// <summary>
        /// 取得原點復歸模式描述。
        /// </summary>
        /// <param name="homeMode">復歸模式 (模式0 ~ 15)。</param>
        /// <returns>描述字符串。</returns>
        string GetHomeModeDescription(uint homeMode);

        #endregion Methods
    }
}
