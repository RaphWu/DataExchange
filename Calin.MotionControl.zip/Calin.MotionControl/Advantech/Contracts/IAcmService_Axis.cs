﻿namespace Calin.MC.Advantech.Contracts
{
    /// <summary>
    /// 軸操作服務介面。
    /// </summary>
    public interface IAcmService_Axis
    {
        /// <summary>
        /// 取得軸數量。
        /// </summary>
        uint AxisCount { get; }

        /// <summary>
        /// 軸減速停止。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <returns>是否成功。</returns>
        bool AxisStop(uint axisNo);

    }
}
