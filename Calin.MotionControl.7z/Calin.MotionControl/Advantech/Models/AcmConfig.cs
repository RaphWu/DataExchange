﻿namespace Calin.MC.Advantech.Models
{
    /// <summary>
    /// Acm 設定。
    /// </summary>
    public class AcmConfig
    {
    }
}
