﻿using System;

namespace Calin.MC.Advantech.Models
{
    [Flags]
    public enum IoFlags : uint
    {
        RDY = 1 << 0,
        ALM = 1 << 1,
        LMT_Positive = 1 << 2,
        LMT_Negative = 1 << 3,
        ORG = 1 << 4,
        DIR = 1 << 5,
        EMG = 1 << 6,
        PCS = 1 << 7,
        ERC = 1 << 8,
        EZ = 1 << 9,
        CLR = 1 << 10,
        LTC = 1 << 11,
        SD = 1 << 12,
        INP = 1 << 13,
        SVON = 1 << 14,
        ALRM = 1 << 15,
        SLMT_Positive = 1 << 16,
        SLMT_Negative = 1 << 17,
        CMP = 1 << 18,
        CAMDO = 1 << 19,
    }
}
