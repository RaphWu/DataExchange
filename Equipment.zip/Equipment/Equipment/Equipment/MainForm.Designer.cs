﻿namespace Equipment
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new Krypton.Toolkit.KryptonManager(this.components);
            this.buttonSpecAny_EquipmentCommissioning = new Krypton.Toolkit.ButtonSpecAny();
            this.buttonSpecAny_ProjectManagement = new Krypton.Toolkit.ButtonSpecAny();
            this.buttonSpecAny_MaintenanceHistory = new Krypton.Toolkit.ButtonSpecAny();
            this.buttonSpecAny_Setting = new Krypton.Toolkit.ButtonSpecAny();
            this.kryptonStatusStrip1 = new Krypton.Toolkit.KryptonStatusStrip();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_Version = new System.Windows.Forms.Label();
            this.kryptonButton3 = new Krypton.Toolkit.KryptonButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.kryptonButton1 = new Krypton.Toolkit.KryptonButton();
            this.kryptonButton2 = new Krypton.Toolkit.KryptonButton();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.kryptonGroupBox1 = new Krypton.Toolkit.KryptonGroupBox();
            this.kryptonLabel2 = new Krypton.Toolkit.KryptonLabel();
            this.kryptonLabel1 = new Krypton.Toolkit.KryptonLabel();
            this.MainMenuMaskedTextBox_Password = new Krypton.Toolkit.KryptonMaskedTextBox();
            this.mainMenuComboBox_User = new System.Windows.Forms.ComboBox();
            this.buttonSpecAny_ClearPassword = new Krypton.Toolkit.ButtonSpecAny();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupBox1.Panel)).BeginInit();
            this.kryptonGroupBox1.Panel.SuspendLayout();
            this.kryptonGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonSpecAny_EquipmentCommissioning
            // 
            this.buttonSpecAny_EquipmentCommissioning.Text = "工具委託";
            this.buttonSpecAny_EquipmentCommissioning.UniqueName = "92563efe8d6449fcba33cc9345c6afd0";
            // 
            // buttonSpecAny_ProjectManagement
            // 
            this.buttonSpecAny_ProjectManagement.AllowInheritText = false;
            this.buttonSpecAny_ProjectManagement.Text = "專案管理";
            this.buttonSpecAny_ProjectManagement.UniqueName = "25f6c3273be540a5b2530c67d97fe08c";
            // 
            // buttonSpecAny_MaintenanceHistory
            // 
            this.buttonSpecAny_MaintenanceHistory.AllowInheritText = false;
            this.buttonSpecAny_MaintenanceHistory.Text = "維護工單";
            this.buttonSpecAny_MaintenanceHistory.UniqueName = "f39981dd34f64f98a4860b290cfd73ef";
            // 
            // buttonSpecAny_Setting
            // 
            this.buttonSpecAny_Setting.Text = "設定";
            this.buttonSpecAny_Setting.UniqueName = "b981652a6292482e82bf665af5be3a70";
            // 
            // kryptonStatusStrip1
            // 
            this.kryptonStatusStrip1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.kryptonStatusStrip1.Location = new System.Drawing.Point(0, 553);
            this.kryptonStatusStrip1.Name = "kryptonStatusStrip1";
            this.kryptonStatusStrip1.ProgressBars = null;
            this.kryptonStatusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.ManagerRenderMode;
            this.kryptonStatusStrip1.Size = new System.Drawing.Size(1304, 22);
            this.kryptonStatusStrip1.TabIndex = 2;
            this.kryptonStatusStrip1.Text = "kryptonStatusStrip1";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label_Version);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 529);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1304, 24);
            this.panel1.TabIndex = 4;
            // 
            // label_Version
            // 
            this.label_Version.AutoSize = true;
            this.label_Version.Dock = System.Windows.Forms.DockStyle.Right;
            this.label_Version.Location = new System.Drawing.Point(1250, 0);
            this.label_Version.Name = "label_Version";
            this.label_Version.Size = new System.Drawing.Size(54, 17);
            this.label_Version.TabIndex = 4;
            this.label_Version.Text = "Version";
            this.label_Version.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // kryptonButton3
            // 
            this.kryptonButton3.Location = new System.Drawing.Point(0, 323);
            this.kryptonButton3.Margin = new System.Windows.Forms.Padding(0);
            this.kryptonButton3.Name = "kryptonButton3";
            this.kryptonButton3.Size = new System.Drawing.Size(250, 120);
            this.kryptonButton3.StateCommon.Border.Rounding = 12F;
            this.kryptonButton3.StateCommon.Border.Width = 2;
            this.kryptonButton3.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.kryptonButton3.TabIndex = 14;
            this.kryptonButton3.TabStop = false;
            this.kryptonButton3.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.kryptonButton3.Values.Text = "維護工單";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 3, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 520F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1304, 529);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.kryptonButton1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.kryptonButton2, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.kryptonButton3, 0, 5);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(254, 7);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 7;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(250, 514);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // kryptonButton1
            // 
            this.kryptonButton1.Location = new System.Drawing.Point(0, 46);
            this.kryptonButton1.Margin = new System.Windows.Forms.Padding(0);
            this.kryptonButton1.Name = "kryptonButton1";
            this.kryptonButton1.Size = new System.Drawing.Size(250, 120);
            this.kryptonButton1.StateCommon.Border.Rounding = 12F;
            this.kryptonButton1.StateCommon.Border.Width = 2;
            this.kryptonButton1.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.kryptonButton1.TabIndex = 14;
            this.kryptonButton1.TabStop = false;
            this.kryptonButton1.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.kryptonButton1.Values.Text = "工具委託";
            // 
            // kryptonButton2
            // 
            this.kryptonButton2.Location = new System.Drawing.Point(0, 186);
            this.kryptonButton2.Margin = new System.Windows.Forms.Padding(0);
            this.kryptonButton2.Name = "kryptonButton2";
            this.kryptonButton2.Size = new System.Drawing.Size(250, 117);
            this.kryptonButton2.StateCommon.Border.Rounding = 12F;
            this.kryptonButton2.StateCommon.Border.Width = 2;
            this.kryptonButton2.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.kryptonButton2.TabIndex = 16;
            this.kryptonButton2.TabStop = false;
            this.kryptonButton2.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.kryptonButton2.Values.Text = "專案管理";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel3.Controls.Add(this.kryptonGroupBox1, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(630, 7);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(420, 514);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // kryptonGroupBox1
            // 
            this.kryptonGroupBox1.CaptionOverlap = 0.3D;
            this.kryptonGroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonGroupBox1.Location = new System.Drawing.Point(3, 112);
            // 
            // kryptonGroupBox1.Panel
            // 
            this.kryptonGroupBox1.Panel.Controls.Add(this.kryptonLabel2);
            this.kryptonGroupBox1.Panel.Controls.Add(this.kryptonLabel1);
            this.kryptonGroupBox1.Panel.Controls.Add(this.MainMenuMaskedTextBox_Password);
            this.kryptonGroupBox1.Panel.Controls.Add(this.mainMenuComboBox_User);
            this.kryptonGroupBox1.Size = new System.Drawing.Size(414, 194);
            this.kryptonGroupBox1.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.kryptonGroupBox1.TabIndex = 11;
            this.kryptonGroupBox1.Values.Heading = "登入";
            // 
            // kryptonLabel2
            // 
            this.kryptonLabel2.Location = new System.Drawing.Point(76, 86);
            this.kryptonLabel2.Name = "kryptonLabel2";
            this.kryptonLabel2.Size = new System.Drawing.Size(52, 30);
            this.kryptonLabel2.StateCommon.ShortText.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.kryptonLabel2.TabIndex = 14;
            this.kryptonLabel2.Values.Text = "密碼";
            // 
            // kryptonLabel1
            // 
            this.kryptonLabel1.Location = new System.Drawing.Point(56, 39);
            this.kryptonLabel1.Name = "kryptonLabel1";
            this.kryptonLabel1.Size = new System.Drawing.Size(72, 30);
            this.kryptonLabel1.StateCommon.ShortText.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.kryptonLabel1.TabIndex = 13;
            this.kryptonLabel1.Values.Text = "使用者";
            // 
            // MainMenuMaskedTextBox_Password
            // 
            this.MainMenuMaskedTextBox_Password.AlwaysActive = false;
            this.MainMenuMaskedTextBox_Password.ButtonSpecs.Add(this.buttonSpecAny_ClearPassword);
            this.MainMenuMaskedTextBox_Password.Location = new System.Drawing.Point(134, 85);
            this.MainMenuMaskedTextBox_Password.Name = "MainMenuMaskedTextBox_Password";
            this.MainMenuMaskedTextBox_Password.PasswordChar = '●';
            this.MainMenuMaskedTextBox_Password.Size = new System.Drawing.Size(213, 32);
            this.MainMenuMaskedTextBox_Password.StateActive.Border.Color1 = System.Drawing.Color.Orange;
            this.MainMenuMaskedTextBox_Password.StateActive.Border.DrawBorders = ((Krypton.Toolkit.PaletteDrawBorders)((((Krypton.Toolkit.PaletteDrawBorders.Top | Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | Krypton.Toolkit.PaletteDrawBorders.Left) 
            | Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.MainMenuMaskedTextBox_Password.StateCommon.Content.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.MainMenuMaskedTextBox_Password.TabIndex = 12;
            this.MainMenuMaskedTextBox_Password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // mainMenuComboBox_User
            // 
            this.mainMenuComboBox_User.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.mainMenuComboBox_User.FormattingEnabled = true;
            this.mainMenuComboBox_User.Location = new System.Drawing.Point(134, 38);
            this.mainMenuComboBox_User.Name = "mainMenuComboBox_User";
            this.mainMenuComboBox_User.Size = new System.Drawing.Size(213, 32);
            this.mainMenuComboBox_User.TabIndex = 9;
            // 
            // buttonSpecAny_ClearPassword
            // 
            this.buttonSpecAny_ClearPassword.ToolTipTitle = "清除密碼";
            this.buttonSpecAny_ClearPassword.Type = Krypton.Toolkit.PaletteButtonSpecStyle.Close;
            this.buttonSpecAny_ClearPassword.UniqueName = "5db584c1616e4b1d83ca740ffb5d8228";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ButtonSpecs.Add(this.buttonSpecAny_EquipmentCommissioning);
            this.ButtonSpecs.Add(this.buttonSpecAny_ProjectManagement);
            this.ButtonSpecs.Add(this.buttonSpecAny_MaintenanceHistory);
            this.ButtonSpecs.Add(this.buttonSpecAny_Setting);
            this.ClientSize = new System.Drawing.Size(1304, 575);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.kryptonStatusStrip1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupBox1.Panel)).EndInit();
            this.kryptonGroupBox1.Panel.ResumeLayout(false);
            this.kryptonGroupBox1.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupBox1)).EndInit();
            this.kryptonGroupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Krypton.Toolkit.KryptonManager kryptonManager;
        private Krypton.Toolkit.ButtonSpecAny buttonSpecAny_EquipmentCommissioning;
        private Krypton.Toolkit.ButtonSpecAny buttonSpecAny_ProjectManagement;
        private Krypton.Toolkit.ButtonSpecAny buttonSpecAny_MaintenanceHistory;
        private Krypton.Toolkit.ButtonSpecAny buttonSpecAny_Setting;
        private Krypton.Toolkit.KryptonStatusStrip kryptonStatusStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_Version;
        private Krypton.Toolkit.KryptonButton kryptonButton3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private Krypton.Toolkit.KryptonButton kryptonButton1;
        private Krypton.Toolkit.KryptonButton kryptonButton2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private Krypton.Toolkit.KryptonGroupBox kryptonGroupBox1;
        private Krypton.Toolkit.KryptonLabel kryptonLabel2;
        private Krypton.Toolkit.KryptonLabel kryptonLabel1;
        private Krypton.Toolkit.KryptonMaskedTextBox MainMenuMaskedTextBox_Password;
        private System.Windows.Forms.ComboBox mainMenuComboBox_User;
        private Krypton.Toolkit.ButtonSpecAny buttonSpecAny_ClearPassword;
    }
}

