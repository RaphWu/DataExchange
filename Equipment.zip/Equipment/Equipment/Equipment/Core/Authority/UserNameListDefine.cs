﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Equipment.Core.Authority
{
    /// <summary>
    /// 使用者名稱列表內容定義。
    /// </summary>
    public class UserNameListDefine
    {
        /// <summary>
        /// 使用者ID。
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 使用者名稱。
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 排序編號。
        /// </summary>
        public int OrderNo { get; set; }
    }
}
