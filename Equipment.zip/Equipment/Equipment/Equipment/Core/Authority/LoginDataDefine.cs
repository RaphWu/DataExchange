﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Equipment.Core.Authority
{
    /// <summary>
    /// 登入對話框交握資料。
    /// </summary>
    public class LoginDataDefine
    {
        /// <summary>
        /// 使用者ID。
        /// </summary>
        public int? UserId { get; set; }

        /// <summary>
        /// 使用者名稱。
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 使用者密碼。
        /// </summary>
        public string Password { get; set; }
    }
}
