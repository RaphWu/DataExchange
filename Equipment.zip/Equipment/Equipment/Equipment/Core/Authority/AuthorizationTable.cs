﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Equipment.Core.Authority
{
    /// <summary>
    /// 權限表。
    /// </summary>
    public class AuthorizationTable : ObservableObject
    {
    }
}
