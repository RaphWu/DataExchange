﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calin.CSharp.Helpers;
using Calin.CSharp.Security;
using Calin.SQLite;
using Newtonsoft.Json;

namespace Equipment.Core.Authority
{
    /// <summary>
    /// 權限管理。
    /// </summary>
    public class AuthorityService : IAuthority
    {
        private static bool _eventNotSubscribed = true;
        private readonly AuthorityData _ad = AuthorityData.Instance;

        /// <summary>
        /// 所有User的授權表。
        /// </summary>
        private static List<AuthorizationDefine> _authorizations = new List<AuthorizationDefine>();

        private System.Timers.Timer InputDetector { get; set; }

        private readonly string _userName_Admin = UserGroup.Admin.ToString();
        private readonly string _userName_Admin_Title = EnumHelper.GetDescription(UserGroup.Admin);
        private readonly string _userName_Operator_Title = EnumHelper.GetDescription(UserGroup.Operator);
        private readonly string _adminPassword = "3E37BDBE31120EEAF5F5227C65E054B4"; // Calin880819
        private readonly string _operatorPassword = "D41D8CD98F00B204E9800998ECF8427E"; // 無密碼
        private readonly string _publickey = "Calin";
        private readonly string _secretkey = "CalinDevelopment";

        /********************
         * ctor
         ********************/
        private readonly IEventAggregator _ea;
        private readonly IPrismMessageBox _prismMessageBox;
        private readonly ICrudDialog _crudDialog;

        public AuthorityService(IEventAggregator ea,
                                IPrismMessageBox prismMessageBox,
                                ICrudDialog crudDialog)
        {
            _ea = ea;
            _prismMessageBox = prismMessageBox;
            _crudDialog = crudDialog;

            // 鍵盤與滑鼠idle偵測
            InputDetector = new System.Timers.Timer();
            InputDetector.AutoReset = false;
            InputDetector.Elapsed += IdleForTooLong;

            if (_eventNotSubscribed)
            {
                _eventNotSubscribed = false;
                _ = _ea.GetEvent<SwitchAuthorityToOperatorEvent>().Subscribe(SwitchAuthorityToOperator, keepSubscriberReferenceAlive: true);
                _ = _ea.GetEvent<ResetInputDetectorTimerEvent>().Subscribe(ResetInputDetectorTimer, true);
            }
        }

        /// <summary>
        /// 模組初始化。
        /// </summary>
        internal void ModuleInit()
        {
            ReadFromDb();
        }

        /********************   
         * Property
         ********************/
        public string OperatorPassword => _operatorPassword;

        /********************
         * Database
         ********************/
        /// <inheritdoc/>
        public bool WriteToDb(bool writeTable, bool writeParam)
        {
            using (var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System))
            {
                if (conn != null)
                {
                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            if (writeTable)
                                conn.Update<List<AuthorizationDefine>>(_authorizations, transaction: tran);
                            if (writeParam)
                                conn.Update<AuthorityParametersDefine>(_ad.Params, transaction: tran);
                            tran.Commit();
                            return true;
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            string errMsg = $"權限資料庫寫入失敗 {DBbase.DbName_System}";
                            Log.Fatal(ex, errMsg);
                            _ = _prismMessageBox.Show(errMsg,
                                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                                      MessageBoxImage.Error);
                        }
                    }
                }
                return false;
            }
        }

        /// <inheritdoc/>
        public bool ReadFromDb()
        {
            using (var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System))
            {
                if (conn != null)
                {
                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            if (!SQLiteHelper.IsTableExist(conn, DB_Authority.TableName_Authority))
                            {
                                SQLiteHelper.CreateTable(conn, DB_Authority.CreateTableSQL_Authority);
                                //conn.Insert(new AuthorityParameters { Id = 1, InputDetectInterval = 5 });
                                string sql = $@"INSERT INTO {DB_Authority.TableName_Authority} (Id, InputDetectInterval) VALUES (@Id, @InputDetectInterval);";
                                conn.Execute(sql, new AuthorityParametersDefine()
                                {
                                    Id = 1,
                                    InputDetectInterval = 5,
                                }, transaction: tran);
                            }
                            _ad.Params = conn.Get<AuthorityParametersDefine>(1, transaction: tran);

                            if (!SQLiteHelper.IsTableExist(conn, DB_Authority.TableName_Authorization))
                            {
                                SQLiteHelper.CreateTable(conn, DB_Authority.CreateTableSQL_Authorization);
                                string sql = $@"INSERT INTO {DB_Authority.TableName_Authorization}
(Id, OrderNo, UserName, Password, Authorization)
VALUES (@Id, @OrderNo, @UserName, @Password, @Authorization);";
                                conn.Execute(sql, new AuthorizationDefine()
                                {
                                    Id = (int)UserGroup.Operator,
                                    OrderNo = (int)UserGroup.Operator,
                                    UserName = GetResource.GetValue<string>("Glorytek.WFSCore", "UserTitle_Operator"),
                                    Password = _operatorPassword,
                                    Authorization = EncryptTableToString(GetDefaultAuthorization(UserGroup.Operator)),
                                }, transaction: tran);
                                //conn.Execute(sql, new AuthorizationDbDefine()
                                //{
                                //    Id = (int)BasicUser.,
                                //    UserName = GetResource.GetValue<string>("Glorytek.WFSCore", "UserTitle_TeamLeader"),
                                //    Password = _emptyPassword,
                                //    Authorization = EncryptAuthorization(GetDefaultAuthorization(_userName_TeamLeader)),
                                //}, transaction: tran);
                                //conn.Execute(sql, new AuthorizationDbDefine()
                                //{
                                //    Id = (int)BasicUser.,
                                //    UserName = GetResource.GetValue<string>("Glorytek.WFSCore", "UserTitle_Engineer"),
                                //    Password = _emptyPassword,
                                //    Authorization = EncryptAuthorization(GetDefaultAuthorization(_userName_Engineer)),
                                //}, transaction: tran);
                                //conn.Execute(sql, new AuthorizationDbDefine()
                                //{
                                //    Id = (int)BasicUser.,
                                //    UserName = GetResource.GetValue<string>("Glorytek.WFSCore", "UserTitle_Manager"),
                                //    Password = _emptyPassword,
                                //    Authorization = EncryptAuthorization(GetDefaultAuthorization(_userName_Manager)),
                                //}, transaction: tran);
                            }

                            _authorizations = conn.GetAll<AuthorizationDefine>(transaction: tran).OrderBy(x => x.OrderNo).ToList();
                            tran.Commit();
                            UpdateUserNameList();
                            return true;
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            string errMsg = "權限資料庫讀取失敗!";
                            _authorizations = new List<AuthorizationDefine>();
                            Log.Fatal(ex, errMsg);
                            _ = _prismMessageBox.Show(errMsg,
                                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                                      MessageBoxImage.Error);
                        }
                    }
                }
                return false;
            }
        }

        /// <summary>
        /// 更新使用者名稱列表。
        /// </summary>
        private void UpdateUserNameList()
        {
            List<UserNameListDefine> unl = new List<UserNameListDefine>();
            foreach (var item in _authorizations.OrderBy(x => x.OrderNo))
                unl.Add(new UserNameListDefine() { Id = item.Id, Name = item.UserName, OrderNo = item.OrderNo });
            _ad.UserNameList = unl;
        }

        /********************
         * 基本資料
         ********************/
        /// <inheritdoc/>
        public bool IsUserIdExist(int userId)
        {
            return _authorizations.Any(x => x.Id == userId);
        }

        /********************
         * 權限操作
         ********************/
        /// <inheritdoc/>
        public void SwitchAuthority(string userName, string password)
        {
            try
            {
                if (_userName_Admin == userName)
                {
                    SwitchAuthority(UserGroup.Admin, password);
                }
                else
                {
                    var user = _authorizations.Find(x => x.UserName == userName);
                    if (user != null)
                    {
                        SwitchAuthority(user.Id, password);
                    }
                    else
                    {
                        throw new AuthorityException($"使用者不存在, {GetResource.GetValue<string>("Caption_UserName")}: {userName}");
                    }
                }
            }
            catch (AuthorityException ae)
            {
                string errTitle = "權限登入錯誤";
                Log.Warning(ae, errTitle);
                _prismMessageBox.Show(ae.Message, errTitle, MessageBoxImage.Error);
            }
        }

        /// <inheritdoc/>
        public void SwitchAuthority(UserGroup basicUser, string password)
        {
            SwitchAuthority((int)basicUser, password);
        }

        /// <inheritdoc/>
        public void SwitchAuthority(int userId, string password)
        {
            try
            {
                if ((int)UserGroup.Admin == userId)
                {
                    // admin
                    if (_adminPassword == password)
                    {
                        _ad.CurrentUserId = userId;
                        _ad.CurrentUserGroup = UserGroup.Admin;
                        _ad.CurrentUserTitle = _userName_Admin_Title;
                        _ad.IsAdmin = true;
                        _ad.IsOperator = false;

                        _ad.CurrentAuthotization = GetDefaultAuthorization(UserGroup.Admin);
                        Log.Information($"{_userName_Admin_Title}登入。");
                    }
                    else
                    {
                        throw new AuthorityException($"密碼錯誤, {GetResource.GetValue<string>("Caption_UserName")}: {userId}");
                    }
                }
                else
                {
                    var currentUser = GetUser(userId);
                    if (currentUser != null)
                    {
                        if (currentUser.Password == password)
                        {
                            string jsonAuthorization = currentUser.Authorization.Decrypt(_publickey, _secretkey);
                            if (jsonAuthorization != string.Empty)
                            {
                                var authorization = JsonConvert.DeserializeObject<AuthorizationTable>(jsonAuthorization);

                                _ad.CurrentUserId = userId;
                                _ad.CurrentUserGroup = UserGroup.Operator;
                                _ad.CurrentUserTitle = currentUser.UserName;
                                _ad.IsAdmin = false;
                                _ad.IsOperator = (int)UserGroup.Operator == userId;

                                _ad.CurrentAuthotization = new AuthorizationTable
                                {
                                    Menu_MainConsole = authorization.Menu_MainConsole,
                                    Menu_PalletParameters = authorization.Menu_PalletParameters,
                                    Menu_StageParameters = authorization.Menu_StageParameters,
                                    Menu_Manual = authorization.Menu_Manual,
                                    Menu_Pallet = authorization.Menu_Pallet,
                                    Menu_WFS_Specification = authorization.Menu_WFS_Specification,
                                    Menu_Tray = authorization.Menu_Tray,

                                    Menu_MachineDatum = authorization.Menu_MachineDatum,
                                    Menu_ClayTable = authorization.Menu_ClayTable,
                                    Menu_Displacement = authorization.Menu_Displacement,
                                    Menu_Stage = authorization.Menu_Stage,
                                    Menu_PalletInstallPoints = authorization.Menu_PalletInstallPoints,
                                    Menu_RepeatabilityTest = authorization.Menu_RepeatabilityTest,
                                    Func_ReportOutput = authorization.Func_ReportOutput,

                                    Menu_BigData = authorization.Menu_BigData,
                                    Report_AbnormalHistory = authorization.Report_AbnormalHistory,
                                    Report_SystemLogger = authorization.Report_SystemLogger,
                                    Report_ExceptionLogger = authorization.Report_ExceptionLogger,
                                    Menu_Product_Switch = authorization.Menu_Product_Switch,
                                    Menu_Product_Manager = authorization.Menu_Product_Manager,
                                    Menu_System = authorization.Menu_System,
                                    Menu_Connection = authorization.Menu_Connection,
                                    Menu_Authority = authorization.Menu_Authority,
                                };
                                Log.Information($"權限管理: {currentUser.UserName} 登入。");
                            }
                            else
                            {
                                throw new Exception("程式內部錯誤：權限資料異常");
                            }
                        }
                        else
                        {
                            throw new AuthorityException($"密碼錯誤, {GetResource.GetValue<string>("Caption_UserName")}: {currentUser.UserName}");
                        }
                    }
                    else
                    {
                        throw new AuthorityException($"{GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_UserNameNotExist")}, {GetResource.GetValue<string>("Caption_UserName")}: {currentUser.UserName}");
                    }
                }
            }
            catch (AuthorityException ae)
            {
                string errTitle = "權限登入錯誤";
                Log.Warning(ae, errTitle);
                _prismMessageBox.Show(ae.Message, errTitle, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                string errTitle = "權限處理異常";
                Log.Fatal(ex, errTitle);
                _prismMessageBox.Show(ex.Message, errTitle, MessageBoxImage.Error);
            }
        }

        /// <inheritdoc/>
        public void SwitchAuthorityToOperator()
        {
            if ((int)UserGroup.Operator != _ad.CurrentUserId)
                SwitchAuthority(UserGroup.Operator, OperatorPassword);
        }

        /// <summary>
        /// 切換權限至作業員(IEventAggregator版本)。
        /// </summary>
        private void SwitchAuthorityToOperator(string _)
        {
            if ((int)UserGroup.Operator != _ad.CurrentUserId)
                SwitchAuthority(UserGroup.Operator, OperatorPassword);
        }

        /// <inheritdoc/>
        public AuthorizationDefine GetUser(int userId)
        {
            try
            {
                var user = _authorizations.Find(x => x.Id == userId);
                if (user == null)
                    throw new Exception("使用者名稱錯誤");

                return user;
            }
            catch (Exception ex)
            {
                string errTitle = GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_System_InternalError");
                Log.Fatal(ex, errTitle);
                _prismMessageBox.Show($"{errTitle}，{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}",
                                      errTitle,
                                      MessageBoxImage.Error);
                return null;
            }
        }

        ///// <inheritdoc/>
        //public string EncryptFromJson(string json) => Encryption.AESEncrypt(json, _publickey, _secretkey);

        ///// <inheritdoc/>
        //public string DecryptToJson(string EncryptedString) => AES.Encrypt(EncryptedString, _publickey, _secretkey);

        /// <inheritdoc/>
        public string EncryptTableToString(AuthorizationTable table)
        {
            try
            {
                string json = JsonConvert.SerializeObject(table);
                if (string.IsNullOrWhiteSpace(json))
                    throw new Exception("權限設定資料錯誤");

                var ad = json.Encrypt(_publickey, _secretkey);
                if (ad == null)
                    throw new Exception("權限設定資料錯誤");

                return ad;
            }
            catch (Exception ex)
            {
                string errTitle = "程式內部錯誤!";
                Log.Fatal(ex, errTitle);
                _prismMessageBox.Show("程式異常，請連繫相關人員！", errTitle, MessageBoxImage.Error);
                return string.Empty;
            }
        }

        /// <inheritdoc/>
        public AuthorizationTable DecryptStringToTable(string encryptedString)
        {
            try
            {
                string json = encryptedString.Decrypt(_publickey, _secretkey);
                if (string.IsNullOrWhiteSpace(json))
                    throw new Exception("權限設定資料錯誤");

                var ad = JsonConvert.DeserializeObject<AuthorizationTable>(json);
                if (ad == null)
                    throw new Exception("權限設定資料錯誤");

                return ad;
            }
            catch (Exception ex)
            {
                string errTitle = "程式內部錯誤!";
                Log.Fatal(ex, errTitle);
                _prismMessageBox.Show("程式異常，請連繫相關人員！", errTitle, MessageBoxImage.Error);
                return null;
            }
        }

        /// <inheritdoc/>
        public bool SetUserAuthorizationTable(int userId, AuthorizationTable table)
        {
            string encryptedString = EncryptTableToString(table);

            if (!string.IsNullOrEmpty(encryptedString))
            {
                //GetUser(userName).Authorization = encryptedString;
                _authorizations.Find(x => x.Id == userId).Authorization = encryptedString;
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <inheritdoc/>
        public AuthorizationTable GetUserAuthorizationTable(int userId)
        {
            return DecryptStringToTable(GetUser(userId).Authorization);
        }

        /// <summary>
        /// 取得預設權限表。
        /// </summary>
        /// <param name="userGroup">參照的使用者。</param>
        /// <returns>權限表。</returns>
        private AuthorizationTable GetDefaultAuthorization(UserGroup userGroup)
        {
            AuthorizationTable ad;
            switch (userGroup)
            {
                case UserGroup.Admin:
                    {
                        ad = new AuthorizationTable
                        {
                            Menu_MainConsole = true,
                            Menu_PalletParameters = true,
                            Menu_StageParameters = true,
                            Menu_Manual = true,
                            Menu_Pallet = true,
                            Menu_WFS_Specification = true,
                            Menu_Tray = true,
                            Menu_MachineDatum = true,
                            Menu_ClayTable = true,
                            Menu_Displacement = true,
                            Menu_Stage = true,
                            Menu_PalletInstallPoints = true,
                            Menu_RepeatabilityTest = true,
                            Func_ReportOutput = true,
                            Menu_BigData = true,
                            Report_AbnormalHistory = true,
                            Report_SystemLogger = true,
                            Report_ExceptionLogger = true,
                            Menu_Product_Switch = true,
                            Menu_Product_Manager = true,
                            Menu_System = true,
                            Menu_Connection = true,
                            Menu_Authority = true,
                        };
                    }
                    break;

                //case _userName_Guest:
                //    {
                //        ad = new AuthorizationDefine
                //        {
                //            Menu_MainConsole = false,
                //            Menu_PalletParameters = false,
                //            Menu_StageParameters = false,
                //            Menu_Manual = false,
                //            Menu_Pallet = false,
                //            Menu_WFS_Specification = false,
                //            Menu_Tray = false,
                //            Menu_MachineDatum = false,
                //            Menu_ClayTable = false,
                //            Menu_Displacement = false,
                //            Menu_Stage = false,
                //            Menu_PalletInstallPoints = false,
                //            Menu_RepeatabilityTest = false,
                //            Func_ReportOutput = false,
                //            Menu_BigData = false,
                //            Report_AbnormalHistory = true,
                //            Report_SystemLogger = false,
                //            Report_ExceptionLogger = false,
                //            Menu_Product_Switch = false,
                //            Menu_Product_Manager = false,
                //            Menu_System = false,
                //            Menu_Connection = false,
                //            Menu_Authority = false,
                //        };
                //        break;
                //    }

                //case _userName_TeamLeader:
                //case _userName_Engineer:
                //case _userName_Manager:

                case UserGroup.Operator:
                    {
                        ad = new AuthorizationTable
                        {
                            Menu_MainConsole = true,
                            Menu_PalletParameters = false,
                            Menu_StageParameters = false,
                            Menu_Manual = true,
                            Menu_Pallet = false,
                            Menu_WFS_Specification = false,
                            Menu_Tray = false,
                            Menu_MachineDatum = false,
                            Menu_ClayTable = false,
                            Menu_Displacement = false,
                            Menu_Stage = false,
                            Menu_PalletInstallPoints = false,
                            Menu_RepeatabilityTest = false,
                            Func_ReportOutput = false,
                            Menu_BigData = false,
                            Report_AbnormalHistory = true,
                            Report_SystemLogger = false,
                            Report_ExceptionLogger = false,
                            Menu_Product_Switch = true,
                            Menu_Product_Manager = false,
                            Menu_System = false,
                            Menu_Connection = false,
                            Menu_Authority = false,
                        };
                    }
                    break;

                default:
                    {
                        ad = new AuthorizationTable
                        {
                            Menu_MainConsole = false,
                            Menu_PalletParameters = false,
                            Menu_StageParameters = false,
                            Menu_Manual = false,
                            Menu_Pallet = false,
                            Menu_WFS_Specification = false,
                            Menu_Tray = false,
                            Menu_MachineDatum = false,
                            Menu_ClayTable = false,
                            Menu_Displacement = false,
                            Menu_Stage = false,
                            Menu_PalletInstallPoints = false,
                            Menu_RepeatabilityTest = false,
                            Func_ReportOutput = false,
                            Menu_BigData = false,
                            Report_AbnormalHistory = false,
                            Report_SystemLogger = false,
                            Report_ExceptionLogger = false,
                            Menu_Product_Switch = false,
                            Menu_Product_Manager = false,
                            Menu_System = false,
                            Menu_Connection = false,
                            Menu_Authority = false,
                        };
                        break;
                    }
            }

            return ad;
        }

        /********************
         * CRUD
         ********************/
        /// <inheritdoc/>
        public void NewUser()
        {
            CrudInfo crudInfo = new CrudInfo()
            {
                Action = CrudAction.Append,
                Title = "新增使用者",
                NewTitle = "使用者名稱",
                NewName = "",
                PasswordTitle = "密碼",
                PasswordMaxLength = 16,
                PasswordWatermark = GetResource.GetValue<string>("Glorytek.WFSComponents", "Login_PasswordDescription"),
                OriginalTitle = "",
                MemoTitle = "",
            };
            CrudInfo result = _crudDialog.ShowDialog(crudInfo);

            if (result.Result == ButtonResult.OK)
            {
                if (_authorizations.Any(x => x.UserName == crudInfo.NewName))
                {
                    _prismMessageBox.Show($"{GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_UserNameExist")}: {crudInfo.NewName}",
                                          MessageBoxImage.Error);
                    return;
                }

                if (_userName_Admin.ToUpper() == crudInfo.NewName.ToUpper())
                {
                    _prismMessageBox.Show($"{GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_UserNameInvalid")}: {crudInfo.NewName}",
                                          MessageBoxImage.Error);
                    return;
                }

                try
                {
                    using (var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System))
                    {
                        if (conn != null)
                        {
                            int nextId = SQLiteHelper.GetMaxValue(conn, DB_Authority.TableName_Authorization, "Id") + 1;
                            int nextOrderNo = SQLiteHelper.GetMaxValue(conn, DB_Authority.TableName_Authorization, "OrderNo") + 1;
                            //if (nextId < 10)
                            //    nextId = 10;

                            using (var tran = conn.BeginTransaction())
                            {
                                try
                                {
                                    string sql = $"INSERT INTO {DB_Authority.TableName_Authorization} (Id, OrderNo, UserName, Password, Authorization) VALUES (@Id, @OrderNo, @UserName, @Password, @Authorization);";
                                    conn.Execute(sql, new AuthorizationDefine()
                                    {
                                        Id = nextId,
                                        OrderNo = nextOrderNo,
                                        UserName = result.NewName,
                                        Password = result.Password,
                                        Authorization = EncryptTableToString(GetDefaultAuthorization(UserGroup.Guest)),
                                    }, transaction: tran);
                                    tran.Commit();
                                }
                                catch
                                {
                                    tran.Rollback();
                                }
                            }

                            ReadFromDb();
                            return;
                        }
                    }
                }
                catch (Exception ex)
                {
                    string errMsg = $"新增使用者異常！{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}";
                    Log.Fatal(ex, errMsg);
                    _prismMessageBox.Show(errMsg,
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                          MessageBoxImage.Error);
                    return;
                }
            }
        }

        /// <inheritdoc/>
        public void ModifyUserName(int userId)
        {
            var user = GetUser(userId);

            CrudInfo crudInfo = new CrudInfo()
            {
                Action = CrudAction.Modify,
                Title = "修改使用者資料",
                OriginalTitle = "原使用者名稱",
                OriginalName = user.UserName,
                NewTitle = "新使用者名稱",
                NewName = "",
                PasswordTitle = "",
                MemoTitle = "",
            };
            CrudInfo result = _crudDialog.ShowDialog(crudInfo);

            if (result.Result == ButtonResult.OK)
            {
                if (_authorizations.Any(x => x.UserName == result.NewName))
                {
                    _prismMessageBox.Show($"{GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_UserNameExist")}: {result.NewName}",
                                          MessageBoxImage.Error);
                    return;
                }

                if (_userName_Admin.ToUpper() == crudInfo.NewName.ToUpper())
                {
                    _prismMessageBox.Show($"{GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_UserNameInvalid")}: {crudInfo.NewName}",
                                          MessageBoxImage.Error);
                    return;
                }

                try
                {
                    using (var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System))
                    {
                        if (conn != null)
                        {
                            using (var tran = conn.BeginTransaction())
                            {
                                try
                                {
                                    user.UserName = result.NewName;
                                    conn.Update<AuthorizationDefine>(user, transaction: tran);
                                    tran.Commit();
                                    UpdateUserNameList();
                                }
                                catch
                                {
                                    tran.Rollback();
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    string errMsg = $"修改使用者資料異常！{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}";
                    Log.Fatal(ex, errMsg);
                    _prismMessageBox.Show(errMsg,
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                          MessageBoxImage.Error);
                }
            }
        }

        /// <inheritdoc/>
        public void ChangePassword(int userId)
        {
            var user = GetUser(userId);

            CrudInfo crudInfo = new CrudInfo()
            {
                Action = CrudAction.Modify,
                Title = "變更使用者密碼",
                OriginalTitle = "使用者名稱",
                OriginalName = user.UserName,
                PasswordTitle = "新密碼",
                PasswordMaxLength = 16,
                PasswordWatermark = GetResource.GetValue<string>("Glorytek.WFSComponents", "Login_PasswordDescription"),
                NewTitle = "",
                MemoTitle = "",
            };
            CrudInfo result = _crudDialog.ShowDialog(crudInfo);

            if (result.Result == ButtonResult.OK)
            {
                try
                {
                    using (var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System))
                    {
                        if (conn != null)
                        {
                            using (var tran = conn.BeginTransaction())
                            {
                                try
                                {
                                    user.Password = result.Password;
                                    conn.Update<AuthorizationDefine>(user, transaction: tran);
                                    tran.Commit();
                                }
                                catch
                                {
                                    tran.Rollback();
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    string errMsg = $"變更使用者密碼異常！{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}";
                    Log.Fatal(ex, errMsg);
                    _prismMessageBox.Show(errMsg,
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                          MessageBoxImage.Error);
                }
            }
        }

        /// <inheritdoc/>
        public void DeleteUser(int userId)
        {
            try
            {
                var user = GetUser(userId);
                if (_prismMessageBox.ShowOKCancel($"確定要刪除使用者嗎？\n使用者名稱： {user.UserName}",
                                                  "動作確認",
                                                  MessageBoxImage.Question,
                                                  "確定刪除",
                                                  "取消") == ButtonResult.OK)
                {
                    using (var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System))
                    {
                        if (conn != null)
                        {
                            using (var tran = conn.BeginTransaction())
                            {
                                try
                                {
                                    _authorizations.RemoveAll(x => x.Id == user.Id);
                                    string sql = $"DELETE FROM {DB_Authority.TableName_Authorization} WHERE Id = @Id";
                                    conn.Execute(sql, new { user.Id }, transaction: tran);
                                    tran.Commit();
                                    UpdateUserNameList();
                                }
                                catch
                                {
                                    tran.Rollback();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string errMsg = $"刪除使用者異常！{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}";
                Log.Fatal(ex, errMsg);
                _prismMessageBox.Show(errMsg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                      MessageBoxImage.Error);
            }
        }

        /********************
         * 輸入裝置idle偵測
         * 設定時間內鍵盤或滑鼠沒有觸發時，切換使用者權限至作業員
         * 註：輸入裝置偵測事件位於 MainWindow.xaml.cs
         ********************/
        /// <summary>
        /// 重設Idel Timer事件。
        /// </summary>
        /// <param name="timerInterval">設定Timer Interval。<br/>設為0: 不執行事件。<br/>小於0: 依資料庫值重設Timer。</param>
        public void ResetInputDetectorTimer(int timerInterval)
        {
            int interval = timerInterval >= 0 ? timerInterval : _ad.Params.InputDetectInterval;
            if (interval > 0)
            {
                InputDetector.Interval = interval * 60000; // 1 min = 60000 ms
                InputDetector.Start();
            }
            else
            {
                InputDetector.Stop();
            }
        }

        /********************
         * OrderNo操作
         ********************/
        /// <inheritdoc/>
        public bool MoveOrderUp(int userId)
        {
            var thisAuthorzation = _authorizations.Find(x => x.Id == userId);
            if (thisAuthorzation != null)
            {
                int thisOrderNo = thisAuthorzation.OrderNo;
                int targetOrderNo = thisOrderNo - 1;
                var targetAuthorzation = _authorizations.Find(x => x.OrderNo == targetOrderNo);

                if (targetAuthorzation != null)
                {
                    (thisAuthorzation.OrderNo, targetAuthorzation.OrderNo)
                        = (targetAuthorzation.OrderNo, thisAuthorzation.OrderNo);
                    ResortOrderNo();
                    return true;
                }
            }
            return false;
        }

        /// <inheritdoc/>
        public bool MoveOrderDown(int userId)
        {
            var thisAuthorzation = _authorizations.Find(x => x.Id == userId);
            if (thisAuthorzation != null)
            {
                int thisOrderNo = thisAuthorzation.OrderNo;
                int targetOrderNo = thisOrderNo + 1;
                var targetAuthorzation = _authorizations.Find(x => x.OrderNo == targetOrderNo);

                if (targetAuthorzation != null)
                {
                    (thisAuthorzation.OrderNo, targetAuthorzation.OrderNo)
                        = (targetAuthorzation.OrderNo, thisAuthorzation.OrderNo);
                    ResortOrderNo();
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 對OrderNo重新排序。
        /// </summary>
        private void ResortOrderNo()
        {
            _authorizations.Sort((x, y) => x.OrderNo.CompareTo(y.OrderNo));
            int orderNo = 0;
            foreach (var au in _authorizations)
                au.OrderNo = ++orderNo;
            WriteToDb(true, false);
            UpdateUserNameList();
        }

        /********************
         * 
         ********************/
        /// <summary>
        /// Timer Event。
        /// </summary>
        private void IdleForTooLong(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (_ad.CurrentUserId != (int)UserGroup.Operator)
                _ea.GetEvent<SwitchAuthorityToOperatorEvent>().Publish("");
        }
    }
}
