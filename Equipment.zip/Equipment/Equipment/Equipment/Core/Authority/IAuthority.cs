﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Equipment.Core.Authority
{
    /// <summary>
    /// 權限管理介面。
    /// </summary>
    public interface IAuthority
    {
        /// <summary>
        /// 回傳作業員的密碼。
        /// </summary>
        string OperatorPassword { get; }

        /********************
         * Database
         ********************/
        /// <summary>
        /// 寫入資料庫。
        /// </summary>
        /// <returns>寫入是否成功？</returns>
        bool WriteToDb(bool writeTable, bool writeParam);

        /// <summary>
        /// 從資料庫讀取資料。
        /// </summary>
        bool ReadFromDb();

        /********************
         * 基本資料
         ********************/
        /// <summary>
        /// 檢查使用者名稱是否存在。
        /// </summary>
        /// <param name="userId">使用者ID。</param>
        bool IsUserIdExist(int userId);

        /********************
         * 參數
         ********************/
        /// <summary>
        /// 重置輸入偵測器的Timer。
        /// </summary>
        /// <param name="timerInterval">重設後的時間間隔(ms)。</param>
        void ResetInputDetectorTimer(int timerInterval);

        /********************
         * 權限操作
         ********************/
        /// <summary>
        /// 使用者及權限切換。
        /// </summary>
        /// <param name="userName">使用者名稱。</param>
        /// <param name="password">密碼。</param>
        void SwitchAuthority(string userName, string password);

        /// <summary>
        /// 使用者及權限切換。
        /// </summary>
        /// <param name="userType">特定使用者群組。</param>
        /// <param name="password">密碼。</param>
        void SwitchAuthority(UserGroup userType, string password);

        /// <summary>
        /// 使用者及權限切換。
        /// </summary>
        /// <param name="userId">使用者ID。</param>
        /// <param name="password">密碼。</param>
        void SwitchAuthority(int userId, string password);

        /// <summary>
        /// 切換權限至作業員。
        /// </summary>
        void SwitchAuthorityToOperator();

        /// <summary>
        /// 取得使用者物件。
        /// </summary>
        /// <param name="userId">使用者ID。</param>
        /// <returns>使用者物件。</returns>
        AuthorizationDefine GetUser(int userId);

        ///// <summary>
        ///// 將權限表JSON字串加密成加密權限表字串
        ///// </summary>
        ///// <param name="json">權限表JSON字串。</param>
        ///// <returns>加密權限表字串。</returns>
        //string EncryptFromJson(string json);

        ///// <summary>
        ///// 將已加密權限表字串解密為JSON字串
        ///// </summary>
        ///// <param name="EncryptedString">加密權限表字串。</param>
        ///// <returns>權限表JSON字串。</returns>
        //string DecryptToJson(string EncryptedString);

        /// <summary>
        /// 將權限表物件加密成加密字串。
        /// </summary>
        /// <param name="table">權限表。</param>
        /// <returns>加密後的權限表字串。</returns>
        string EncryptTableToString(AuthorizationTable table);

        /// <summary>
        /// 將加密字串解密成權限表物件。
        /// </summary>
        /// <param name="EncryptedString">待解密的權限表字串。</param>
        /// <returns>權限表物件。</returns>
        AuthorizationTable DecryptStringToTable(string EncryptedString);

        /// <summary>
        /// 設定UserId的權限表。
        /// </summary>
        /// <param name="userId">使用者ID。</param>
        /// <param name="table">權限表。</param>
        bool SetUserAuthorizationTable(int userId, AuthorizationTable table);

        /// <summary>
        /// 取得UserId的權限表。
        /// </summary>
        /// <param name="userId">使用者ID。</param>
        /// <returns>權限表。</returns>
        AuthorizationTable GetUserAuthorizationTable(int userId);

        /********************
         * CRUD
         ********************/
        /// <summary>
        /// 新增使用者。
        /// </summary>
        void NewUser();

        /// <summary>
        /// 修改使用者名稱。
        /// </summary>
        /// <param name="userId">使用者ID。</param>
        void ModifyUserName(int userId);

        /// <summary>
        /// 變更使用者密碼。
        /// </summary>
        /// <param name="userId">使用者ID。</param>
        void ChangePassword(int userId);

        /// <summary>
        /// 刪除使用者。
        /// </summary>
        /// <param name="userId">使用者ID。</param>
        void DeleteUser(int userId);

        /********************
         * OrderNo操作
         ********************/
        /// <summary>
        /// 將指定ID的User排序往上移。
        /// </summary>
        /// <param name="userId">指定User的ID。</param>
        /// <returns>移動是否完成。</returns>
        bool MoveOrderUp(int userId);

        /// <summary>
        /// 將指定ID的User排序往下移。
        /// </summary>
        /// <param name="userId">指定User的ID。</param>
        /// <returns>移動是否完成。</returns>
        bool MoveOrderDown(int userId);
    }
}
