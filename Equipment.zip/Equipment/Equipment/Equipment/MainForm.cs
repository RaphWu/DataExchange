﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Krypton.Toolkit;

namespace Equipment
{
    public partial class MainForm : KryptonForm
    {
        public MainForm()
        {
            InitializeComponent();

            // KryptonForm
            var form = this;
            form.Text = "xxx";
            form.AllowStatusStripMerge = true;
            kryptonManager.GlobalPaletteMode = PaletteMode.Office2010Silver;

            var assembly = Assembly.GetExecutingAssembly();
            var version = assembly.GetName().Version;
            label_Version.Text = version.ToString();
        }
    }
}
