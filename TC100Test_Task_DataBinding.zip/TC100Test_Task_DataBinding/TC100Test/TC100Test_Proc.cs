﻿using System;
using System.Linq;
using System.Threading;

namespace TC100Test
{
    public partial class TC100Test
    {
        /// <summary>
        /// 更新 Serial Port 選擇器。
        /// </summary>
        private void UpdateSerialPortParamsSelector()
        {
            System.IO.Ports.SerialPort serial = new System.IO.Ports.SerialPort();

            string[] portNameList = System.IO.Ports.SerialPort.GetPortNames();
            Array.Sort(portNameList);
            comboBox_COM.Items.Clear();
            comboBox_COM.Items.AddRange(portNameList);
            comboBox_COM.SelectedIndex = 0;

            comboBox_BaudRate.Items.Clear();
            comboBox_BaudRate.Items.AddRange((new int[] { 2400, 4800, 9600, 19200, 38400, 57600, 115200 }).Cast<object>().ToArray());
            comboBox_BaudRate.SelectedItem = 19200;

            comboBox_Parity.Items.Clear();
            comboBox_Parity.Items.AddRange(Enum.GetValues(typeof(System.IO.Ports.Parity)).Cast<object>().ToArray());
            comboBox_Parity.SelectedItem = System.IO.Ports.Parity.None;

            textBox_DataBits.Text = "8";

            comboBox_StopBits.Items.Clear();
            comboBox_StopBits.Items.AddRange(Enum.GetValues(typeof(System.IO.Ports.StopBits)).Cast<object>().ToArray());
            comboBox_StopBits.SelectedItem = System.IO.Ports.StopBits.One;
        }

        /// <summary>
        /// 畫面更新。
        /// </summary>
        private void ScreenUpdatePolling(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    // 須隨時檢查電動缸是否仍在開啟狀態
                    if (!_tsc.IsOpen)
                    {
                        Disconnct();
                        break;
                    }
                }
                catch (OperationCanceledException)
                {
                    // do nothing for CancellationTokenSource
                }
            }
        }

        //                try
        //                {
        //                    textBox_ServoStatus.InvokeIfRequired(() =>
        //                    {
        //                        string s;

        //                        //textBox_Watchdog.Text = _tsc.WatchdogCounter.ToString();

        //#if DEBUG
        //                        if (_tsc.DebugMessage.Updated)
        //                        {
        //                            label_RequestMessage.Text = _tsc.DebugMessage.RequestFrame;
        //                            label_ResponseMessage.Text = _tsc.DebugMessage.ResponseFrame;
        //                            label_ConsoleMessage.Text = _tsc.DebugMessage.ConsoleMessage;
        //                            label_ErrorMessage.Text = _tsc.DebugMessage.ErrorMessage;
        //                            _tsc.DebugMessage.Updated = false;
        //                        }
        //#endif

        //                        s = _tsc.ServoStatus ? "伺服ON" : "伺服OFF";
        //                        textBox_ServoStatus.Text = s;
        //                        button_ServoSwitch.Text = s;
        //                        textBox_MotorStatus.Text = _tsc.ActionStatus == 0 ? "停止" : _tsc.ActionStatus == 1 ? "動作中" : "異常停止";
        //                        textBox_InpStatus.Text = _tsc.InpStatus == 1 ? "位置已在設定範圍內" : "尚未到達設定範圍內";
        //                        textBox_TrqLmtStatus.Text = _tsc.TrqLmtStatus == 1 ? "已在設定範圍內" : "未到設定範圍內";
        //                        textBox_MotorAlarm.Text = _tsc.GetAlarmStatusMessage(_tsc.AlarmStatus);
        //                        textBox_ErrorStatus.Text = _tsc.GetErrorStatusMessage(_tsc.ErrorStatus);
        //                        textBox_MotorRPM.Text = _tsc.MonRpm.ToString();
        //                        //textBox_MotorSpeed.Text = _tsc.MonSpeed.ToString("0.0");
        //                        textBox_MotorCurrent.Text = _tsc.MonCurrent.ToString("0.0");
        //                        textBox_MotorCommandPos.Text = _tsc.CmdNowPos.ToString("0.00");
        //                        //textBox_MotorCurrentPos.Text = _tsc.EcdPos.ToString("0.00");

        //                        if (_tsc.PortOutStatus.Updated)
        //                        {
        //                            checkBox_PortOut01.Checked = _tsc.PortOutStatus.PortOut01;
        //                            checkBox_PortOut02.Checked = _tsc.PortOutStatus.PortOut02;
        //                            checkBox_PortOut03.Checked = _tsc.PortOutStatus.PortOut03;
        //                            checkBox_PortOut04.Checked = _tsc.PortOutStatus.PortOut04;
        //                            checkBox_PortOut05.Checked = _tsc.PortOutStatus.PortOut05;
        //                            checkBox_PortOut06.Checked = _tsc.PortOutStatus.PortOut06;
        //                            checkBox_PortOut07.Checked = _tsc.PortOutStatus.PortOut07;
        //                            checkBox_PortOut08.Checked = _tsc.PortOutStatus.PortOut08;
        //                            checkBox_PortOut09.Checked = _tsc.PortOutStatus.PortOut09;
        //                            checkBox_PortOut10.Checked = _tsc.PortOutStatus.PortOut10;

        //                            _tsc.PortOutStatus.Updated = false;
        //                        }

        //                        if (_tsc.PortInStatus.Updated)
        //                        {
        //                            checkBox_PortIn01.Checked = _tsc.PortInStatus.PortIn01;
        //                            checkBox_PortIn02.Checked = _tsc.PortInStatus.PortIn02;
        //                            checkBox_PortIn03.Checked = _tsc.PortInStatus.PortIn03;
        //                            checkBox_PortIn04.Checked = _tsc.PortInStatus.PortIn04;
        //                            checkBox_PortIn05.Checked = _tsc.PortInStatus.PortIn05;
        //                            checkBox_PortIn06.Checked = _tsc.PortInStatus.PortIn06;
        //                            checkBox_PortIn07.Checked = _tsc.PortInStatus.PortIn07;
        //                            checkBox_PortIn08.Checked = _tsc.PortInStatus.PortIn08;
        //                            checkBox_PortIn09.Checked = _tsc.PortInStatus.PortIn09;
        //                            checkBox_PortIn10.Checked = _tsc.PortInStatus.PortIn10;
        //                            checkBox_PortIn11.Checked = _tsc.PortInStatus.PortIn11;
        //                            checkBox_PortIn12.Checked = _tsc.PortInStatus.PortIn12;
        //                            checkBox_PortIn13.Checked = _tsc.PortInStatus.PortIn13;
        //                            checkBox_PortIn14.Checked = _tsc.PortInStatus.PortIn14;

        //                            _tsc.PortInStatus.Updated = false;
        //                        }
        //                    });

        //                    Thread.Sleep(20);
        //                    token.ThrowIfCancellationRequested();
        //                }
        //                catch (OperationCanceledException)
        //                {
        //                    // do nothing for CancellationTokenSource
        //                }
        //                catch (Exception ex)
        //                {
        //                    Console.WriteLine(string.Concat("畫面更新輪詢的執行緒異常: ", ex.Message));
        //                }
        //            }
        //        }
    }
}
