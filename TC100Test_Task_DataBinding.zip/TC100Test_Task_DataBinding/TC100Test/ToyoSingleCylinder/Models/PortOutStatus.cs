﻿namespace ToyoSingleCylinder
{
    /// <summary>
    /// 輸出訊號。
    /// </summary>
    public class PortOutStatus : BindableBase
    {
        /// <summary>
        /// 輸出訊號 01。
        /// </summary>
        /// <remarks>ORG-S。</remarks>
        public bool PortOut01
        {
            get { return _PortOut01; }
            set
            {
                if (_PortOut01 != value)
                {
                    _PortOut01 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortOut01;

        /// <summary>
        /// 輸出訊號 02。
        /// </summary>
        /// <remarks>INPOSITION。</remarks>
        public bool PortOut02
        {
            get { return _PortOut02; }
            set
            {
                if (_PortOut02 != value)
                {
                    _PortOut02 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortOut02;

        /// <summary>
        /// 輸出訊號 03。
        /// </summary>
        /// <remarks>READY。</remarks>
        public bool PortOut03
        {
            get { return _PortOut03; }
            set
            {
                if (_PortOut03 != value)
                {
                    _PortOut03 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortOut03;

        /// <summary>
        /// 輸出訊號 04。
        /// </summary>
        /// <remarks>SERVO-S。</remarks>
        public bool PortOut04
        {
            get { return _PortOut04; }
            set
            {
                if (_PortOut04 != value)
                {
                    _PortOut04 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortOut04;

        /// <summary>
        /// 輸出訊號 05。
        /// </summary>
        /// <remarks>PRGSEL0-S。</remarks>
        public bool PortOut05
        {
            get { return _PortOut05; }
            set
            {
                if (_PortOut05 != value)
                {
                    _PortOut05 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortOut05;

        /// <summary>
        /// 輸出訊號 06。
        /// </summary>
        /// <remarks>PRGSEL1-S。</remarks>
        public bool PortOut06
        {
            get { return _PortOut06; }
            set
            {
                if (_PortOut06 != value)
                {
                    _PortOut06 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortOut06;

        /// <summary>
        /// 輸出訊號 07。
        /// </summary>
        /// <remarks>ALARM。</remarks>
        public bool PortOut07
        {
            get { return _PortOut07; }
            set
            {
                if (_PortOut07 != value)
                {
                    _PortOut07 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortOut07;

        /// <summary>
        /// 輸出訊號 08。
        /// </summary>
        /// <remarks>MOVE。</remarks>
        public bool PortOut08
        {
            get { return _PortOut08; }
            set
            {
                if (_PortOut08 != value)
                {
                    _PortOut08 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortOut08;

        /// <summary>
        /// 輸出訊號 09。
        /// </summary>
        /// <remarks>OUT9。</remarks>
        public bool PortOut09
        {
            get { return _PortOut09; }
            set
            {
                if (_PortOut09 != value)
                {
                    _PortOut09 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortOut09;

        /// <summary>
        /// 輸出訊號 10。
        /// </summary>
        /// <remarks>OUT10。</remarks>
        public bool PortOut10
        {
            get { return _PortOut10; }
            set
            {
                if (_PortOut10 != value)
                {
                    _PortOut10 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortOut10;
    }
}