﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO.Ports;
using System.Threading;
using System.Threading.Tasks;

namespace ToyoSingleCylinder
{
    /// <summary>
    /// TOYO電動缸 單缸控制模組。
    /// </summary>
    public partial class ToyoSingleCylinder : BindableBase
    {
        private CancellationTokenSource _cts;
        private SerialPort _sp;
        private CylinderParams _cp;

        //private CylinderStatus _statusCylinder = new CylinderStatus();
        private PortOutStatus _statusPortOut = new PortOutStatus();
        private PortInStatus _statusPortIn = new PortInStatus();
#if DEBUG
        private DebugMessage _debugMessage = new DebugMessage();
#endif

        private ConcurrentQueue<FrameStruct> _highPriorityQueue = new ConcurrentQueue<FrameStruct>(); // 最高優先權指令 Queue
        private ConcurrentQueue<FrameStruct> _retryQueue = new ConcurrentQueue<FrameStruct>(); // 指令重送 Queue
        private ConcurrentQueue<FrameStruct> _requestQueue = new ConcurrentQueue<FrameStruct>(); // 一般指令 Queue

        //private Task _portAccessTask = null; // 負責 SerialPort 存取的執行緒
        private bool _pollingLoopFinished = true;
        private bool _pollingIsRunning = false;
        private bool _serialPortCloseRequest = false;
        private uint _watchdogCounter = 0; // 看門狗計數器
        private System.Timers.Timer _watchdog; // 看門狗計時器
        //private System.Timers.Timer _statusReadingTimer; // 狀態讀取計時器

        private List<string> _errorHistories = null; // 錯誤履歷

        /// <summary>
        /// 請求發送暫停。
        /// </summary>
        /// <remarks>當有指令發送失敗須重送時，此 Flag 會 ON。此時 HighPriorityQueue 仍不會停，但 RequestQueue 會停止發送。</remarks>
        private bool _requestHolding = false;

        #region ctor

        /// <summary>
        /// TOYO 電動缸 (單缸)。
        /// </summary>
        /// <param name="station">站號。</param>
        /// <param name="portName">Serial Port 名稱。</param>
        /// <param name="baudRate">BaudRate 鮑率。</param>
        /// <param name="parity">Parity 同位位元。</param>
        /// <param name="dataBits">DataBits 資料位元。</param>
        /// <param name="stopBits">StopBits 停止位元。</param>
        /// <param name="minStroke">電動缸最小行程。</param>
        /// <param name="maxStroke">電動缸最大行程。</param>
        /// <param name="cts">CancellationTokenSource 物件。請參考 <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.threading.cancellationtokensource">CancellationTokenSource Class</see>。</param>
        public ToyoSingleCylinder(byte station,
                                  string portName,
                                  int baudRate,
                                  Parity parity,
                                  int dataBits,
                                  StopBits stopBits,
                                  double minStroke,
                                  double maxStroke)
        {
            _cp = new CylinderParams()
            {
                Station = station,
                MinStroke = minStroke,
                MaxStroke = maxStroke,
                RetryTimes = 5,
            };

            _sp = new SerialPort()
            {
                PortName = portName,
                BaudRate = baudRate,
                DataBits = dataBits,
                StopBits = stopBits,
                Parity = parity,
                ReadTimeout = 500,
                WriteTimeout = 500,
            };

            InMotion = false;

#if DEBUG
            _debugMessage.ConsoleMessage = "No Message.";
            _debugMessage.ErrorMessage = "No Error!";
#endif
        }

        #endregion

        #region Serial Port Open/Close

        /// <summary>
        /// 關閉電動缸。
        /// </summary>
        public async void ClosePort()
        {
            try
            {
                _serialPortCloseRequest = true;

                while (_pollingIsRunning)
                    await Task.Delay(5);

                if (_cts != null)
                {
                    if (_cts.IsCancellationRequested)
                        _cts.Cancel();
                    _cts.Dispose();
                }

                if (_watchdog != null)
                {
                    _watchdog.Stop();
                    _watchdog.Elapsed -= OnWatchdogElapsed;
                }

                // .net framework 的 ConcurrentQueue 沒有 Clear()，所以改用 new
                //_highPriorityQueue.Clear();
                //_retryQueue.Clear();
                //_requestQueue.Clear();
                _highPriorityQueue = new ConcurrentQueue<FrameStruct>();
                _retryQueue = new ConcurrentQueue<FrameStruct>();
                _requestQueue = new ConcurrentQueue<FrameStruct>();

                //_statusReadingTimer.Stop();
                //_statusReadingTimer.Elapsed -= OnStatusReadingElapsed;

#if DEBUG
                _debugMessage.ConsoleMessage = "正在關閉電動缸，請稍候再連線！";
#endif
                if (_sp.IsOpen)
                    _sp.Close();

                await Task.Delay(500);

#if DEBUG
                _debugMessage.ConsoleMessage = "電動缸已關閉！";
#endif

                _serialPortCloseRequest = false;
            }
            catch (Exception ex)
            {
                string eMsg = String.Concat("Serial Port 關閉異常: ", ex.Message);
                Console.WriteLine(eMsg);
#if DEBUG
                _debugMessage.ErrorMessage = eMsg;
                //_debugMessage.Updated = true;
#endif
            }
            finally
            {
                //NotifyPropertyChanged(nameof(IsOpen));
                NotifyPropertyChanged("IsOpen");
            }
        }

        /// <summary>
        /// 開啟電動缸。
        /// </summary>
        public void OpenPort()
        {
            try
            {
                if (!_sp.IsOpen)
                {
                    if (_cts != null)
                    {
                        if (_cts.IsCancellationRequested)
                            _cts.Cancel();
                        _cts.Dispose();
                    }
                    _cts = new CancellationTokenSource();

                    _sp.Open();
                    if (_sp.IsOpen)
                    {
                        HighPriorityRequest(CallerId.Initializer, ":0110999B0004084C7630315479566702\r\n"); // 開通電動缸權限

                        Task.Factory.StartNew(() =>
                        {
                            PortAccessPolling(_cts.Token);
                        }, _cts.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default);

                        _watchdog = new System.Timers.Timer()
                        {
                            Interval = 1000,
                            AutoReset = true,
                        };
                        _watchdog.Elapsed += OnWatchdogElapsed;
                        _watchdog.Start();

                        //_statusReadingTimer = new System.Timers.Timer()
                        //{
                        //    Interval = 20,
                        //    AutoReset = true,
                        //};
                        //_statusReadingTimer.Elapsed += OnStatusReadingElapsed;
                        ////_statusReadingTimer.Start();
                    }
                }
            }
            catch (Exception ex)
            {
                string eMsg = String.Concat("Serial Port 開啟異常: ", ex.Message);
                Console.WriteLine(eMsg);
#if DEBUG
                _debugMessage.ErrorMessage = eMsg;
                //_debugMessage.Updated = true;
#endif
            }
            finally
            {
                //NotifyPropertyChanged(nameof(IsOpen));
                NotifyPropertyChanged("IsOpen");
            }
        }

        #endregion

    }
}
