﻿using System;
using System.Text;
using System.Threading;

namespace ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {

        private void PortAccessPolling(CancellationToken token)
        {
            bool requestFinished = true; // 訊息幀的處理是否完成
            FrameStruct nextRequest = new FrameStruct();
            int IntervalActionCounter = 0; // 間隔動作的計數器
            int retryCounter = 0; // 指令重送計數器
            DateTime timeMark = DateTime.Now; // 時間標記

            _pollingIsRunning = true;
            while (!_serialPortCloseRequest && !token.IsCancellationRequested)
            {
                _pollingLoopFinished = false;

                /***** 傳送邏輯 *****/
                try
                {
                    if (!_serialPortCloseRequest && requestFinished)
                    {
                        if (_highPriorityQueue.Count > 0 || _retryQueue.Count > 0 || _requestQueue.Count > 0)
                        {
                            //nextRequest = (_highPriorityQueue.Count > 0)
                            //    ? _highPriorityQueue.Dequeue()
                            //    : (_retryQueue.Count > 0)
                            //        ? _retryQueue.Dequeue()
                            //        : _requestQueue.Dequeue();

                            bool dequeueSuccess;
                            if (_highPriorityQueue.Count > 0)
                                dequeueSuccess = _highPriorityQueue.TryDequeue(out nextRequest);
                            else if (_retryQueue.Count > 0)
                                dequeueSuccess = _retryQueue.TryDequeue(out nextRequest);
                            else if (_requestQueue.Count > 0)
                                dequeueSuccess = _requestQueue.TryDequeue(out nextRequest);
                            else
                                dequeueSuccess = false;

                            if (_sp.IsOpen && dequeueSuccess)
                            {
                                //_sps.DiscardInBuffer();
                                _sp.DiscardOutBuffer();
                                _sp.Write(nextRequest.ByteArray, 0, nextRequest.ByteArray.Length);
                                timeMark = DateTime.Now;
                                Thread.Sleep(10);
#if DEBUG
                                _debugMessage.RequestFrame = Encoding.ASCII.GetString(nextRequest.ByteArray);
                                //_debugMessage.Updated = true;
#endif
                                requestFinished = false;
                            }
                        }
                    }

                    token.ThrowIfCancellationRequested();

                    // 檢查是否斷線/空轉
                    if (!requestFinished && _sp.BytesToRead == 0)
                    {
                        TimeSpan ts = DateTime.Now - timeMark;
                        if (ts.TotalMilliseconds > 3000)
                            throw new TimeoutException("接收逾時！");
                    }

                    /***** 接收邏輯 *****/
                    if (!_serialPortCloseRequest && !requestFinished && _sp.BytesToRead > 0)
                    {
                        byte st = 0; // 站號
                        byte fCode = 0xFF; // 功能碼

                        //Task.Delay(300).Wait();
                        //byte[] readBuffer = new byte[_bytesToRead];
                        string responseString = _sp.ReadLine();
                        int bytesToRead = _sp.BytesToRead;

#if DEBUG
                        _debugMessage.ResponseFrame = responseString;
                        //_debugMessage.Updated = true;
#endif

                        bool validation = ValidFrame(responseString);
                        if (validation)
                        {
                            st = Convert.ToByte(responseString.Substring(1, 2), 16);
                            fCode = Convert.ToByte(responseString.Substring(3, 2), 16);
                        }

                        if (validation && fCode < 0x80)
                        {
                            if (!_requestHolding)
                                retryCounter = 0;

                            switch (nextRequest.CallerId)
                            {
                                case CallerId.ReadStatus:
                                    const int head = 7;
                                    ServoStatus = Convert.ToBoolean(Convert.ToInt16(responseString.Substring(head + 0xC * ONE_WORD, ONE_WORD)));
                                    ActionStatus = Convert.ToInt16(responseString.Substring(head + 0x0 * ONE_WORD, ONE_WORD), 16);
                                    InpStatus = Convert.ToInt16(responseString.Substring(head + 0x01 * ONE_WORD, ONE_WORD), 16);
                                    TrqLmtStatus = Convert.ToInt16(responseString.Substring(head + 0x4 * ONE_WORD, ONE_WORD), 16);
                                    AlarmStatus = Convert.ToInt16(responseString.Substring(head + 0x5 * ONE_WORD, ONE_WORD), 16);
                                    ErrorStatus = Convert.ToInt16(responseString.Substring(head + 0xD * ONE_WORD, ONE_WORD), 16);
                                    MonRpm = Convert.ToInt16(responseString.Substring(head + 0x6 * ONE_WORD, ONE_WORD), 16);
                                    //_MonSpeed = Convert.ToInt16(responseString.Substring(head + 0x6 * ONE_WORD, ONE_WORD), 16);
                                    MonCurrent = Convert.ToInt16(responseString.Substring(head + 0x7 * ONE_WORD, ONE_WORD), 16) / 10.0;
                                    CmdNowPos = Convert.ToInt32(responseString.Substring(head + 0x8 * ONE_WORD, TWO_WORD), 16) / 100.0;
                                    EcdPos = Convert.ToInt32(responseString.Substring(head + 0xA * ONE_WORD, TWO_WORD), 16) / 100.0;
                                    //_Updated = true;

                                    requestFinished = true;
                                    break;
                                case CallerId.PortOut:
                                    ushort portOut = Convert.ToUInt16(responseString.Substring(1 + 2 + 2 + 2, 4), 16);
                                    _statusPortOut.PortOut01 = (portOut & 0x0001) != 0;
                                    _statusPortOut.PortOut02 = (portOut & 0x0002) != 0;
                                    _statusPortOut.PortOut03 = (portOut & 0x0004) != 0;
                                    _statusPortOut.PortOut04 = (portOut & 0x0008) != 0;
                                    _statusPortOut.PortOut05 = (portOut & 0x0010) != 0;
                                    _statusPortOut.PortOut06 = (portOut & 0x0020) != 0;
                                    _statusPortOut.PortOut07 = (portOut & 0x0040) != 0;
                                    _statusPortOut.PortOut08 = (portOut & 0x0080) != 0;
                                    _statusPortOut.PortOut09 = (portOut & 0x0100) != 0;
                                    _statusPortOut.PortOut10 = (portOut & 0x0200) != 0;
                                    //_statusPortOut.Updated = true;

                                    requestFinished = true;
                                    break;
                                case CallerId.PortIn:
                                    ushort data = Convert.ToUInt16(responseString.Substring(1 + 2 + 2 + 2, 4), 16);
                                    _statusPortIn.PortIn01 = (data & 0x0001) != 0;
                                    _statusPortIn.PortIn02 = (data & 0x0002) != 0;
                                    _statusPortIn.PortIn03 = (data & 0x0004) != 0;
                                    _statusPortIn.PortIn04 = (data & 0x0008) != 0;
                                    _statusPortIn.PortIn05 = (data & 0x0010) != 0;
                                    _statusPortIn.PortIn06 = (data & 0x0020) != 0;
                                    _statusPortIn.PortIn07 = (data & 0x0040) != 0;
                                    _statusPortIn.PortIn08 = (data & 0x0080) != 0;
                                    _statusPortIn.PortIn09 = (data & 0x0100) != 0;
                                    _statusPortIn.PortIn10 = (data & 0x0200) != 0;
                                    _statusPortIn.PortIn11 = (data & 0x0400) != 0;
                                    _statusPortIn.PortIn12 = (data & 0x0800) != 0;
                                    _statusPortIn.PortIn13 = (data & 0x1000) != 0;
                                    _statusPortIn.PortIn14 = (data & 0x2000) != 0;

                                    requestFinished = true;
                                    break;
                                case CallerId.Command:
                                    requestFinished = true;
                                    break;
                                case CallerId.WatchDog:
                                    if (responseString == ":010302544363\r")
                                    {
                                        requestFinished = true;
                                    }
                                    else
                                    {
                                        ClosePort();
                                        throw new Exception("電動缸斷線！");
                                    }
                                    break;
                                case CallerId.ErrorHistories:

                                    break;
                                case CallerId.Initializer:
                                    if (responseString == ":0110999B0004B7\r")
                                    {
                                        requestFinished = true;
                                    }
                                    else
                                    {
                                        ClosePort();
                                        throw new Exception("權限開通異常！");
                                    }
                                    break;
                                default:
                                    throw new Exception(string.Concat("CallerId錯誤:\n", nextRequest.CallerId, "\nResponse Message: ", responseString));
                            }

                            _requestHolding = false;
                        }
                        else
                        {
                            string msg = string.Concat("CallerID: ", nextRequest.CallerId,
                                                       ", Frame: ", Encoding.ASCII.GetString(nextRequest.ByteArray));
                            if (++retryCounter <= _cp.RetryTimes)
                            {
                                _requestHolding = true;

                                string eMsg = string.Concat("重試第 ", retryCounter, " 次, ", msg);
                                Console.WriteLine(eMsg);
#if DEBUG
                                _debugMessage.ConsoleMessage = eMsg;
                                //_debugMessage.Updated = true;
#endif

                                Thread.Sleep(500);
                                ResendFrame(nextRequest);
                            }
                            else
                            {
                                string eMsg = string.Concat("此指令已被放棄: ", msg);
                                Console.WriteLine(eMsg);
#if DEBUG
                                _debugMessage.ErrorMessage = eMsg;
                                //_debugMessage.Updated = true;
#endif
                                retryCounter = 0;
                            }
                            requestFinished = true;
                        }
                    }

                    token.ThrowIfCancellationRequested();

                    // 狀態讀取
                    if (!_requestHolding)
                    {
                        bool isMatch = false;
                        switch (IntervalActionCounter)
                        {
                            case 0:
                                foreach (var rq in _requestQueue)
                                    if (rq.CallerId == CallerId.ReadStatus)
                                    {
                                        isMatch = true;
                                        break;
                                    }
                                if (!isMatch)
                                    SendRequestFrame(CallerId.ReadStatus, 0x03, 0x1000, 0x0F * 1);
                                break;
                            case 1:
                                foreach (var rq in _requestQueue)
                                    if (rq.CallerId == CallerId.PortOut)
                                    {
                                        isMatch = true;
                                        break;
                                    }
                                if (!isMatch)
                                    SendRequestFrame(CallerId.PortOut, 0x03, 0x1020, 1);
                                break;
                            case 2:
                                foreach (var rq in _requestQueue)
                                    if (rq.CallerId == CallerId.PortIn)
                                    {
                                        isMatch = true;
                                        break;
                                    }
                                if (!isMatch)
                                    SendRequestFrame(CallerId.PortIn, 0x03, 0x1040, 1);
                                break;
                        }

                        if (++IntervalActionCounter > 100)
                            IntervalActionCounter = 0;
                    }
                }
                catch (OperationCanceledException)
                {
                    // do nothing for CancellationTokenSource
                }
                catch (TimeoutException te)
                {
#if DEBUG
                    _debugMessage.ErrorMessage = string.Concat("Timeout逾時: 電動缸斷線或", te.Message);
                    //_debugMessage.Updated = true;
#endif
                    requestFinished = true;
                    ClosePort();
                }
                catch (UnauthorizedAccessException)
                {
                    if (_sp.IsOpen)
                        ClosePort();
                    requestFinished = true;
                }
                catch (InvalidOperationException ioe)
                {
                    Console.WriteLine(ioe.Message);
                    requestFinished = true;
                }
                catch (Exception ex)
                {
                    string eMsg = string.Concat("接收輪詢的執行緒異常: ", ex.Message);
                    Console.WriteLine(eMsg);
#if DEBUG
                    _debugMessage.ErrorMessage = eMsg;
                    //_debugMessage.Updated = true;
#endif
                }
                finally
                {
                    _pollingLoopFinished = true;
                }
            }
            _pollingIsRunning = false;
            _serialPortCloseRequest = false;
        }

        private void OnWatchdogElapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                if (_sp.IsOpen)
                {
                    foreach (var rq in _highPriorityQueue)
                        if (rq.CallerId == CallerId.WatchDog)
                            return;
                    //HighPriorityRequest(CallerId.WatchDog, 01, 0x03, 0x10E0, 1);
                    WatchdogCounter++;
                }
            }
            catch (Exception ex)
            {
                string eMsg = string.Concat("Watchdog異常: ", ex.Message);
                Console.WriteLine(eMsg);
#if DEBUG
                _debugMessage.ErrorMessage = eMsg;
                //_debugMessage.Updated = true;
#endif
            }
        }

        //        private void OnStatusReadingElapsed(object sender, System.Timers.ElapsedEventArgs e)
        //        {
        //            try
        //            {
        //                if (_sp.IsOpen && !_requestHolding)
        //                {
        //                    switch (_statusReadingLoop)
        //                    {
        //                        case 0:
        //                            foreach (var rq in _requestQueue)
        //                                if (rq.CallerId == CallerId.ReadStatus)
        //                                    break;
        //                            SendRequestFrame(CallerId.ReadStatus, 0x03, 0x1000, 0x0F * 1);
        //                            break;
        //                        case 1:
        //                            foreach (var rq in _requestQueue)
        //                                if (rq.CallerId == CallerId.PortOut)
        //                                    break;
        //                            SendRequestFrame(CallerId.PortOut, 0x03, 0x1020, 1);
        //                            break;
        //                        case 2:
        //                            foreach (var rq in _requestQueue)
        //                                if (rq.CallerId == CallerId.PortIn)
        //                                    break;
        //                            SendRequestFrame(CallerId.PortIn, 0x03, 0x1040, 1);
        //                            break;
        //                    }

        //                    if (++_statusReadingLoop > 2)
        //                        _statusReadingLoop = 0;
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                string eMsg = string.Concat("StatusReading Timer 異常: ", ex.Message);
        //                Console.WriteLine(eMsg);
        //#if DEBUG
        //                _debugMessage.ErrorMessage = eMsg;
        //                _debugMessage.Updated = true;
        //#endif
        //            }
        //        }
    }
}
