﻿namespace ToyoSingleCylinder
{
    public enum CallerId
    {
        Initializer,
        Command,
        ReadStatus,
        PortOut,
        PortIn,
        ErrorHistories,

        WatchDog,
    }
}
