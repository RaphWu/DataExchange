﻿using System.Collections.Generic;

namespace ToyoSingleCylinder
{
    /********************
     * 開放給外部的變數與函數
     ********************/
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 電動缸是否準備好接收指令？
        /// </summary>
        /// <returns>true=準備好，false=尚未準備好。</returns>
        public bool Ready()
        {
            return _sp != null && _sp.IsOpen
                    && _ServoStatus
                    && _ActionStatus == 0
                    && _InpStatus == 1
                    && !_InMotion;
        }

        /// <summary>
        /// 電動缸是否開啟中？
        /// </summary>
        public bool IsOpen
        {
            get { return _sp != null && _sp.IsOpen; }
        }

        ///// <summary>
        ///// 電動缸狀態。
        ///// </summary>
        //public CylinderStatus CylinderStatus
        //{
        //    get { return _statusCylinder; }
        //}

        /// <summary>
        /// 輸出訊息。
        /// </summary>
        public PortOutStatus PortOutStatus
        {
            get { return _statusPortOut; }
        }

        /// <summary>
        /// 輸入訊息。
        /// </summary>
        public PortInStatus PortInStatus
        {
            get { return _statusPortIn; }
        }

        /// <summary>
        /// 看門狗計數值。
        /// </summary>
        public uint WatchdogCounter
        {
            get { return _watchdogCounter; }
            internal set
            {
                if (_watchdogCounter != value)
                {
                    _watchdogCounter = value;
                    NotifyPropertyChanged();
                }
            }
        }

        /// <summary>
        /// 取得故障狀態說明。
        /// </summary>
        /// <param name="errorStatus">故障狀態代碼。</param>
        /// <returns>故障狀態說明。</returns>
        public string GetErrorStatusMessage(int errorStatus)
        {
            return GetMessage.GetMessage_ErrorStatus(errorStatus);
        }

        /// <summary>
        /// 取得警報狀態說明。
        /// </summary>
        /// <param name="alarmStatus">警報狀態代碼。</param>
        /// <returns>警報狀態說明。</returns>
        public string GetAlarmStatusMessage(int alarmStatus)
        {
            return GetMessage.GetMessage_AlarmStatus(alarmStatus);
        }

        public List<string> GetErrorHistories()
        {
            return _errorHistories;
        }

#if DEBUG
        /// <summary>
        /// 取得 Debug 用的訊息。
        /// </summary>
        public DebugMessage DebugMessage
        {
            get { return _debugMessage; }
        }
#endif
    }
}
