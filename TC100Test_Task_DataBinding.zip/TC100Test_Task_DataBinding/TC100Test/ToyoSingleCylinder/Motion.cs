﻿using System;
using System.Threading.Tasks;

namespace ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 判斷運動是否已達指定位置。
        /// </summary>
        /// <param name="position">要比對的座標。</param>
        /// <param name="checkTimeOut">是否要檢查逾時？</param>
        /// <returns>true:已達指定位置, false:位置不動超過3秒鐘。</returns>
        private async Task<bool> InPosition(double position, bool checkTimeOut = true)
        {
            DateTime mark = DateTime.Now;
            double lastPos = 0.0;

            while (true)
            {
                if (ActionStatus == 0
                    && InpStatus == 1
                    && Math.Abs(CmdNowPos - position) <= 0.01
                    && Math.Abs(EcdPos - position) <= 0.01)
                    return true;
                else
                { // TODO: 頂住時，馬達狀態是ON/OFF?
                    if (checkTimeOut && Math.Abs(lastPos - EcdPos) < 10.0)
                    {
                        TimeSpan ts = DateTime.Now - mark;
                        if (ts.TotalMilliseconds > 3000)
                            return false;
                    }
                    else
                    {
                        mark = DateTime.Now;
                        lastPos = EcdPos;
                    }
                    await Task.Delay(10);
                }
            }
        }

        /// <summary>
        /// 緊急停止。
        /// </summary>
        public void EmergencyStop()
        {
            HighPriorityRequest(CallerId.Command, 0x06, 0x201E, 9);
        }

        /// <summary>
        /// 減速停止。
        /// </summary>
        public void DeceleratesToStop()
        {
            HighPriorityRequest(CallerId.Command, 0x06, 0x201E, 8);
        }

        /// <summary>
        /// 原點復歸。
        /// </summary>
        public async Task OriginReturn()
        {
            InMotion = true;
            HighPriorityRequest(CallerId.Command, 0x06, 0x201E, 3);
            await InPosition(0.0, checkTimeOut: false);
            InMotion = false;
        }

        /// <summary>
        /// ABS 絕對位置運動。
        /// </summary>
        /// <param name="coordinate">目標位置，單位 mm。</param>
        /// <param name="speed">運動速度，0~100，為最高速度的比例設定值。</param>
        /// <param name="push">推壓，0~1000，為扭力值的比例設定值 x 0.1%。</param>
        /// <returns>true:已達指定位置, false:位置不動超過3秒鐘。</returns>
        public async Task<bool> AbsMove(double coordinate, int speed, double push)
        {
            InMotion = true;

            try
            {
                if (coordinate < _cp.MinStroke || coordinate > _cp.MaxStroke)
                {
                    string eMsg = String.Concat("電動缸移動範圍必須介於 ", _cp.MinStroke, " ~ ", _cp.MaxStroke, " 之間。");
#if DEBUG
                    _debugMessage.ErrorMessage = eMsg;
                    //_debugMessage.Updated = true;
#endif
                    throw new ArgumentOutOfRangeException(eMsg);
                }

                string cmd = string.Concat(":01062014", speed.ToString("X4"));
                SendRequestFrame(CallerId.Command, cmd);

                cmd = string.Concat(":01060400", ((int)(push * 10)).ToString("X4"));
                SendRequestFrame(CallerId.Command, cmd);

                cmd = string.Concat(":01060401", ((int)(push * 10)).ToString("X4"));
                SendRequestFrame(CallerId.Command, cmd);

                cmd = string.Concat(":01102002000204", ((int)(coordinate * 100)).ToString("X8"));
                SendRequestFrame(CallerId.Command, cmd);

                SendRequestFrame(CallerId.Command, ":0106201E0001");

                bool ret = await InPosition(coordinate);
                InMotion = false;
                return ret;
            }
            catch
            {
            }

            InMotion = false;
            return false;
        }

        /// <summary>
        /// INC 相對位置運動。
        /// </summary>
        /// <param name="offset">移動量，單位 mm。</param>
        /// <param name="speed">運動速度，0~100，為最高速度的比例設定值。</param>
        /// <param name="push">推壓，0~1000，為扭力值的比例設定值 x 0.1%。</param>
        /// <returns>true:已達指定位置, false:位置不動超過3秒鐘。</returns>
        public async Task<bool> IncMove(double offset, int speed, double push)
        {
            InMotion = true;

            try
            {
                double currentCoor = EcdPos;
                double targetCoor = currentCoor + offset;

                if (targetCoor < _cp.MinStroke || targetCoor > _cp.MaxStroke)
                {
                    string eMsg = String.Concat("電動缸將會超出可移動範圍，目前位置: ", currentCoor, ", 移動偏移量: ", offset);
#if DEBUG
                    _debugMessage.ErrorMessage = eMsg;
                    //_debugMessage.Updated = true;
#endif
                    throw new ArgumentOutOfRangeException(eMsg);
                }

                string cmd = string.Concat(":01062014", speed.ToString("X4"));
                SendRequestFrame(CallerId.Command, cmd);

                cmd = string.Concat(":01060400", ((int)(push * 10)).ToString("X4"));
                SendRequestFrame(CallerId.Command, cmd);

                cmd = string.Concat(":01060401", ((int)(push * 10)).ToString("X4"));
                SendRequestFrame(CallerId.Command, cmd);

                double targetPos = CmdNowPos + offset;
                cmd = string.Concat(":01102000000204", ((int)(offset * 100)).ToString("X8"));
                SendRequestFrame(CallerId.Command, cmd);

                SendRequestFrame(CallerId.Command, ":0106201E0000");

                bool ret = await InPosition(targetPos);
                InMotion = false;
                return ret;
            }
            catch
            {
            }

            InMotion = false;
            return false;
        }
    }
}
