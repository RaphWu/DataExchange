﻿using System;
using System.Threading.Tasks;
using PermissionTest.Contract;
using Serilog;

namespace PermissionTest.Service
{
    public class ActivityLogService : IActivityLogService
    {
        private readonly ILogger _logger;

        public ActivityLogService()
        {
            _logger = new LoggerConfiguration()
                .WriteTo.File("logs/activity.json", rollingInterval: RollingInterval.Day)
                .Enrich.WithProperty("Application", "WinFormApp")
                .CreateLogger();
        }

        public async Task LogAsync(string userId, string action, string dataJson)
        {
            var logEntry = new
            {
                UserId = userId,
                Action = action,
                Data = dataJson,
                Timestamp = DateTime.UtcNow
            };
            _logger.Information("{@LogEntry}", logEntry);
            await Task.CompletedTask;
        }

        /// <summary>
        /// 方便記錄 UI 操作的函式
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="formName"></param>
        /// <param name="controlName"></param>
        /// <param name="action"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public async Task LogUIActionAsync(int userId, string formName, string controlName, string action, object data = null)
        {
            var logEntry = new
            {
                Timestamp = DateTime.Now,
                UserId = userId,
                Form = formName,
                Control = controlName,
                Action = action,
                Data = data
            };

            Log.Information("{@LogEntry}", logEntry);
            await Task.CompletedTask;
        }
    }
}
