﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using PermissionTest.Contract;
using PermissionTest.Entity;

namespace PermissionTest.Service
{
    public class UserGroupService : IUserGroupService
    {
        private readonly MyDbContext _db;
        private readonly IActivityLogService _logService;
        private readonly IMemoryCache _cache;

        public UserGroupService(MyDbContext db, IActivityLogService logService, IMemoryCache cache)
        {
            _db = db;
            _logService = logService;
            _cache = cache;
        }

        public async Task<UserGroup> CreateAsync(UserGroup group, string currentUserId)
        {
            _db.UserGroups.Add(group);
            await _db.SaveChangesAsync();

            await _logService.LogAsync(currentUserId, "Create UserGroup", new { group.Id, group.Name });
            return group;
        }

        public async Task<UserGroup> UpdateAsync(UserGroup group, string currentUserId)
        {
            var existing = await _db.UserGroups.FindAsync(group.Id);
            if (existing == null) throw new Exception("UserGroup not found");

            existing.Name = group.Name;
            await _db.SaveChangesAsync();

            _cache.RemoveByPrefix("permissions_"); // 更新群組權限後清空所有使用者快取

            await _logService.LogAsync(currentUserId, "Update UserGroup", new { group.Id, group.Name });
            return existing;
        }

        public async Task DeleteAsync(int groupId, string currentUserId)
        {
            var existing = await _db.UserGroups.FindAsync(groupId);
            if (existing == null) throw new Exception("UserGroup not found");

            _db.UserGroups.Remove(existing);
            await _db.SaveChangesAsync();

            _cache.RemoveByPrefix("permissions_");

            await _logService.LogAsync(currentUserId, "Delete UserGroup", new { groupId });
        }

        public Task<UserGroup> GetByIdAsync(int groupId)
        {
            return _db.UserGroups
                .Include(ug => ug.Permissions)
                .Include(ug => ug.Members)
                .FirstOrDefaultAsync(ug => ug.Id == groupId);
        }

        public Task<List<UserGroup>> GetAllAsync()
        {
            return _db.UserGroups
                .Include(ug => ug.Permissions)
                .Include(ug => ug.Members)
                .ToListAsync();
        }

        public async Task AssignUsersAsync(int groupId, List<int> userIds, string currentUserId)
        {
            var group = await _db.UserGroups.Include(ug => ug.Members).FirstOrDefaultAsync(ug => ug.Id == groupId);
            if (group == null) throw new Exception("UserGroup not found");

            group.Members.Clear();
            var users = await _db.Employees.Where(e => userIds.Contains(e.Id)).ToListAsync();
            foreach (var u in users) group.Members.Add(u);

            await _db.SaveChangesAsync();
            _cache.RemoveByPrefix("permissions_");

            await _logService.LogAsync(currentUserId, "Assign Users to Group", new { groupId, userIds });
        }

        public async Task AssignPermissionsAsync(int groupId, List<int> permissionIds, string currentUserId)
        {
            var group = await _db.UserGroups.Include(ug => ug.Permissions).FirstOrDefaultAsync(ug => ug.Id == groupId);
            if (group == null) throw new Exception("UserGroup not found");

            group.Permissions.Clear();
            var perms = await _db.Permissions.Where(p => permissionIds.Contains(p.Id)).ToListAsync();
            foreach (var p in perms) group.Permissions.Add(p);

            await _db.SaveChangesAsync();
            _cache.RemoveByPrefix("permissions_");

            await _logService.LogAsync(currentUserId, "Assign Permissions to Group", new { groupId, permissionIds });
        }
    }
}
