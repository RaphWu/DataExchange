﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Caching.Memory;
using PermissionTest.Contract;


namespace PermissionTest.Service
{
    public class PermissionService : IPermissionService
    {
        private readonly MyDbContext _db;
        private readonly IMemoryCache _cache;
        private readonly TimeSpan _cacheDuration = TimeSpan.FromMinutes(10);

        public PermissionService(MyDbContext db, IMemoryCache cache)
        {
            _db = db;
            _cache = cache;
        }

        /********************
         * UserGroup
         ********************/
        /// <summary>
        /// 檢查使用者對控制項是否有權限
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="controlName"></param>
        /// <returns></returns>
        public bool HasAccess(int userId, string controlName)
        {
            var permissions = GetPermissions(userId);
            return permissions.Contains(controlName);

            //string cacheKey = $"Permissions_{userId}";
            //var permissions = _cache.GetOrCreate(cacheKey, entry =>
            //{
            //    entry.AbsoluteExpirationRelativeToNow = _cacheDuration;
            //    var user = _db.Employees.Include(e => e.Department)
            //                            .ThenInclude(d => d.Permissions)
            //                            .FirstOrDefault(e => e.Id == userId);

            //    var deptPerms = user.Department.Permissions.Select(p => p.ControlName).ToList();

            //    var groupPerms = _db.UserGroups
            //                        .Include(g => g.Permissions)
            //                        .Where(g => g.Members.Any(m => m.Id == userId))
            //                        .SelectMany(g => g.Permissions)
            //                        .Select(p => p.ControlName)
            //                        .ToList();
            //    return deptPerms.Union(groupPerms).ToHashSet();
            //});
            //return permissions.Contains(controlName);

            //// 1. 先檢查部門 RBAC 權限
            //var user = _db.Employees.Include(e => e.Department)
            //                        .ThenInclude(d => d.Permissions)
            //                        .FirstOrDefault(e => e.Id == userId);

            //bool deptHas = user.Department.Permissions.Any(p => p.ControlName == controlName);

            //if (deptHas) return true;

            //// 2. 再檢查 UserGroup 額外權限（ABAC）
            //var groups = _db.UserGroups
            //                .Include(g => g.Permissions)
            //                .Where(g => g.Members.Any(m => m.Id == userId))
            //                .ToList();

            //bool groupHas = groups.Any(g => g.Permissions.Any(p => p.ControlName == controlName));
            //return groupHas;
        }

        /// <summary>
        /// 取得使用者權限來源（部門或使用者群組）
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="controlName"></param>
        /// <returns></returns>
        public string GetPermissionSource(int userId, string controlName)
        {
            string cacheKey = $"PermissionSource_{userId}_{controlName}";
            return _cache.GetOrCreate(cacheKey, entry =>
            {
                entry.AbsoluteExpirationRelativeToNow = _cacheDuration;
                var user = _db.Employees.Include(e => e.Department)
                                        .ThenInclude(d => d.Permissions)
                                        .FirstOrDefault(e => e.Id == userId);

                if (user.Department.Permissions.Any(p => p.ControlName == controlName))
                    return "Department";

                var groups = _db.UserGroups
                                .Include(g => g.Permissions)
                                .Where(g => g.Members.Any(m => m.Id == userId))
                                .ToList();

                if (groups.Any(g => g.Permissions.Any(p => p.ControlName == controlName)))
                    return "UserGroup";

                return "None";
            });

            //var user = _db.Employees.Include(e => e.Department)
            //                        .ThenInclude(d => d.Permissions)
            //                        .FirstOrDefault(e => e.Id == userId);

            //if (user.Department.Permissions.Any(p => p.ControlName == controlName))
            //    return "Department";

            //var groups = _db.UserGroups
            //                .Include(g => g.Permissions)
            //                .Where(g => g.Members.Any(m => m.Id == userId))
            //                .ToList();

            //if (groups.Any(g => g.Permissions.Any(p => p.ControlName == controlName)))
            //    return "UserGroup";

            //return "None";
        }

        // 手動清除使用者權限快取（例如權限更新時）
        public void ClearUserCache(int userId)
        {
            _cache.Remove($"Permissions_{userId}");
        }

        /********************
         * 
         ********************/
        /// <summary>
        /// 從資料庫載入使用者權限
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private HashSet<string> LoadPermissionsFromDb(int userId)
        {
            var user = _db.Employees.Include(e => e.Department)
                                    .ThenInclude(d => d.Permissions)
                                    .FirstOrDefault(e => e.Id == userId);

            var deptPerms = user?.Department?.Permissions.Select(p => p.ControlName).ToList() ?? new List<string>();

            var groupPerms = _db.UserGroups
                                .Include(g => g.Permissions)
                                .Where(g => g.Members.Any(m => m.Id == userId))
                                .SelectMany(g => g.Permissions)
                                .Select(p => p.ControlName)
                                .ToList();

            return deptPerms.Union(groupPerms).ToHashSet();
        }

        /// <summary>
        /// 取得使用者所有權限清單
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public HashSet<string> GetPermissions(int userId)
        {
            string cacheKey = $"Permissions_{userId}";
            if (!_cache.TryGetValue(cacheKey, out HashSet<string> permissions))
            {
                permissions = LoadPermissionsFromDb(userId);
                _cache.Set(cacheKey, permissions, _cacheDuration);
            }
            return permissions;
        }

        ///// <summary>
        ///// 取得使用者所有權限清單
        ///// </summary>
        ///// <param name="userId"></param>
        ///// <returns></returns>
        //public async Task<HashSet<string>> GetUserPermissionsAsync(int userId)
        //{
        //    return _cache.GetOrCreate($"permissions_{userId}", () =>
        //    {
        //        var employee = _db.Employees
        //            .Include("Department.Permissions")
        //            .Include("UserGroups.Permissions")
        //            .FirstOrDefault(e => e.Id == userId);

        //        if (employee == null) return new List<string>();

        //        var deptPerms = employee.Department?.Permissions.Select(p => p.Name).ToList() ?? new List<string>();
        //        var groupPerms = employee.UserGroups
        //            .SelectMany(ug => ug.Permissions)
        //            .Select(p => p.Name)
        //            .ToList();

        //        return deptPerms.Union(groupPerms).Distinct().ToList();
        //    }, TimeSpan.FromMinutes(30));
        //}

        /// <summary>
        /// 當員工權限變動時呼叫
        /// </summary>
        /// <param name="userId"></param>
        public void RefreshUserPermissions(int userId)
        {
            _cache.Remove($"permissions_{userId}");
        }

        /// <summary>
        /// 當部門權限變動時呼叫，刷新該部門所有員工
        /// </summary>
        /// <param name="departmentId"></param>
        public void RefreshDepartmentPermissions(int departmentId)
        {
            var userIds = _db.Employees
                .Where(e => e.DepartmentId == departmentId)
                .Select(e => e.Id)
                .ToList();

            foreach (var id in userIds)
                _cache.Remove($"permissions_{id}");
        }

        /// <summary>
        /// 當 UserGroup 權限變動時呼叫，刷新所有屬於該群組的員工
        /// </summary>
        /// <param name="userGroupId"></param>
        public void RefreshUserGroupPermissions(int userGroupId)
        {
            var userIds = _db.Employees
                .Where(e => e.UserGroups.Any(ug => ug.Id == userGroupId))
                .Select(e => e.Id)
                .ToList();

            foreach (var id in userIds)
                _cache.Remove($"permissions_{id}");
        }
    }
}
