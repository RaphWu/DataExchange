﻿using System.Linq;
using System.Threading.Tasks;
using PermissionTest.Entity;
using PermissionTest.Helper;

namespace PermissionTest.Service
{
    /// <summary>
    /// 登入驗證
    /// </summary>
    public class AuthService
    {
        private readonly MyDbContext _db;
        private readonly ActivityLogService _log;

        public AuthService(MyDbContext db, ActivityLogService activityLogService)
        {
            _db = db;
            _log = activityLogService;
        }

        public Employee Login(string username, string password)
        {
            var emp = _db.Employees.FirstOrDefault(e => e.Name == username);
            if (emp != null && PasswordHelper.VerifyPassword(password, emp.PasswordHash))
                return emp;
            return null;
        }

        public async Task LoginAsync(Employee user)
        {
            // 驗證密碼 PBKDF2
            await _log.LogAsync(user.Id, "Login", new { user.Name });
        }

        public async Task LogoutAsync(Employee user)
        {
            await _log.LogAsync(user.Id, "Logout", new { user.Name });
        }
    }
}
