﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PermissionTest.Contract;
using PermissionTest.Entity;
using PermissionTest.Helper;

namespace PermissionTest.Service
{
    public class EmployeeService : IEmployeeService
    {
        private readonly MyDbContext _db;
        private readonly PermissionService _permissionService;
        private readonly IActivityLogService _logService;

        public EmployeeService(MyDbContext db, PermissionService permissionService, IActivityLogService logService)
        {
            _db = db;
            _permissionService = permissionService;
            _logService = logService;
        }

        public async Task AddEmployeeAsync(string name, string password, string phone, string address, int deptId, int performedByUserId)
        {
            var emp = new Employee
            {
                Name = name,
                PasswordHash = PasswordHelper.HashPassword(password),
                DepartmentId = deptId
            };
            _db.Employees.Add(emp);
            await _db.SaveChangesAsync();

            var profile = new EmployeeProfile
            {
                EmployeeId = emp.Id,
                Phone = phone,
                Address = address
            };
            _db.EmployeeProfiles.Add(profile);
            await _db.SaveChangesAsync();

            //await _logService.LogAsync(performedByUserId, "AddEmployee", JsonConvert.SerializeObject(new { emp.Id, emp.Name }));
            await _logService.LogAsync(currentUserId, "AddEmployee", new { emp.Id, emp.Name });
        }

        public async Task EditEmployeeAsync(Employee emp, int currentUserId)
        {
            _db.Entry(emp).State = EntityState.Modified;
            await _db.SaveChangesAsync();

            await _logService.LogAsync(currentUserId, "EditEmployee", new { emp.Id, emp.Name });
        }

        public async Task DeleteEmployeeAsync(int empId, int currentUserId)
        {
            var emp = await _db.Employees.FindAsync(empId);
            if (emp != null)
            {
                _db.Employees.Remove(emp);
                await _db.SaveChangesAsync();
                await _logService.LogAsync(currentUserId, "DeleteEmployee", new { emp.Id, emp.Name });
            }
        }

        public async Task UpdateEmployeeAsync(Employee emp, int performedByUserId)
        {
            _db.Entry(emp).State = EntityState.Modified;
            await _db.SaveChangesAsync();

            // 刷新該員工快取
            _permissionService.RefreshUserPermissions(emp.Id);

            await _logService.LogAsync(performedByUserId, "UpdateEmployee", JsonConvert.SerializeObject(emp));
        }

        public async Task UpdateDepartmentPermissionsAsync(int departmentId, List<int> permissionIds, int performedByUserId)
        {
            var dept = _db.Departments.Include("Permissions").First(d => d.Id == departmentId);
            dept.Permissions.Clear();
            var perms = _db.Permissions.Where(p => permissionIds.Contains(p.Id)).ToList();
            foreach (var p in perms) dept.Permissions.Add(p);
            await _db.SaveChangesAsync();

            // 刷新該部門所有員工快取
            _permissionService.RefreshDepartmentPermissions(departmentId);

            await _logService.LogAsync(performedByUserId, "UpdateDepartmentPermissions", JsonConvert.SerializeObject(new { DepartmentId = departmentId, Permissions = permissionIds }));
        }

        public async Task UpdateUserGroupPermissionsAsync(int groupId, List<int> permissionIds, int performedByUserId)
        {
            var group = await _db.UserGroups
                .Include(g => g.Permissions)
                .FirstOrDefaultAsync(g => g.Id == groupId);
            group.Permissions.Clear();
            var perms = await _db.Permissions
                .Where(p => permissionIds.Contains(p.Id))
                .ToListAsync();
            foreach (var p in perms)
                group.Permissions.Add(p);
            await _db.SaveChangesAsync();

            // 刷新所有該群組成員的權限快取
            foreach (var member in group.Members)
                _permissionService.RefreshUserPermissions(member.Id);

            await _logService.LogAsync(performedByUserId, "UpdateUserGroupPermissions", JsonConvert.SerializeObject(new { UserGroupId = userGroupId, Permissions = permissionIds }));
        }

        //public async Task UpdateUserGroupPermissionsAsync(int userGroupId, List<int> permissionIds, int performedByUserId)
        //{
        //    var group = _db.UserGroups
        //        .Include("Permissions")
        //        .First(g => g.Id == userGroupId);
        //    group.Permissions.Clear();
        //    var perms = _db.Permissions
        //        .Where(p => permissionIds.Contains(p.Id))
        //        .ToList();
        //    foreach (var p in perms)
        //        group.Permissions.Add(p);
        //    await _db.SaveChangesAsync();

        //    // 刷新該群組所有員工快取
        //    _permissionService.RefreshUserGroupPermissions(userGroupId);

        //    await _logService.LogAsync(performedByUserId, "UpdateUserGroupPermissions", JsonConvert.SerializeObject(new { UserGroupId = userGroupId, Permissions = permissionIds }));
        //}
    }
}
