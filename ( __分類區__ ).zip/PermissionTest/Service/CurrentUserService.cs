﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using PermissionTest.Contract;

namespace PermissionTest.Service
{
    public class CurrentUserService : ICurrentUserService
    {
        private readonly IPermissionService _permissionService;
        private readonly MemoryCacheService _cache;
        private readonly int _userId;
        private readonly string _userName;

        public CurrentUserService(IPermissionService permissionService, MemoryCacheService cache, int userId, string userName)
        {
            _permissionService = permissionService;
            _cache = cache;
            _userId = userId;
            _userName = userName;
        }

        public int UserId => _userId;
        public string UserName => _userName;

        public async Task<List<string>> GetPermissionsAsync()
        {
            return _cache.GetOrCreate($"permissions_{_userId}", () =>
            {
                // 由同步方式取得權限，因為 MemoryCache 不支援 async lambda
                return _permissionService.GetUserPermissionsAsync(_userId).GetAwaiter().GetResult();
            }, TimeSpan.FromMinutes(30));
        }
    }
}
