﻿using System.Data.Entity;
using PermissionTest.Entity;

namespace PermissionTest.Service
{
    public class MyDbContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Permission> Permissions { get; set; }
        public DbSet<UserGroup> UserGroups { get; set; }
        public DbSet<ActivityLog> ActivityLogs { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Employee>()
                .Property(e => e.Name).IsRequired().HasMaxLength(100);
            modelBuilder.Entity<Employee>()
                .Property(e => e.PasswordHash).IsRequired().HasMaxLength(256);
            modelBuilder.Entity<Employee>()
                .Property(e => e.SensitiveData).HasMaxLength(512);
            modelBuilder.Entity<Employee>()
                .HasRequired(e => e.Department)
                .WithMany(d => d.Employees)
                .HasForeignKey(e => e.DepartmentId);
            modelBuilder.Entity<Employee>()
                .HasMany(e => e.UserGroups)
                .WithMany(ug => ug.Members)
                .Map(m => { m.ToTable("EmployeeUserGroups"); m.MapLeftKey("EmployeeId"); m.MapRightKey("UserGroupId"); });

            modelBuilder.Entity<Department>()
                .Property(d => d.Name).IsRequired().HasMaxLength(100);
            modelBuilder.Entity<Department>()
                .HasMany(d => d.Permissions)
                .WithMany(p => p.Departments)
                .Map(m => { m.ToTable("DepartmentPermissions"); m.MapLeftKey("DepartmentId"); m.MapRightKey("PermissionId"); });

            modelBuilder.Entity<Permission>()
                .Property(p => p.Name).IsRequired().HasMaxLength(100);
            modelBuilder.Entity<Permission>()
                .HasMany(p => p.UserGroups)
                .WithMany(ug => ug.Permissions)
                .Map(m => { m.ToTable("UserGroupPermissions"); m.MapLeftKey("PermissionId"); m.MapRightKey("UserGroupId"); });

            modelBuilder.Entity<UserGroup>()
                .Property(ug => ug.Name).IsRequired().HasMaxLength(100);

            //modelBuilder.Entity<ActivityLog>()
            //    .Property(a => a.Action).IsRequired().HasMaxLength(100);
            //modelBuilder.Entity<ActivityLog>()
            //    .Property(a => a.DataJson).IsRequired();
        }
    }
}
