﻿using System;
using System.Runtime.Caching;
using PermissionTest.Contract;

namespace PermissionTest.Service
{
    public class MemoryCacheService : IMemoryCache
    {
        private readonly ObjectCache _cache = MemoryCache.Default;

        public T GetOrCreate<T>(string key, Func<T> factory, TimeSpan? expiration = null)
        {
            if (_cache.Contains(key))
                return (T)_cache[key];

            var value = factory();
            var policy = new CacheItemPolicy
            {
                AbsoluteExpiration = DateTimeOffset.Now.Add(expiration ?? TimeSpan.FromMinutes(30))
            };
            _cache.Set(key, value, policy);
            return value;
        }

        public void Remove(string key)
        {
            if (_cache.Contains(key))
                _cache.Remove(key);
        }

        public void RemoveByPrefix(string prefix)
        {
            foreach (var item in _cache)
            {
                if (item.Key.StartsWith(prefix))
                    _cache.Remove(item.Key);
            }
        }
    }
}
