﻿using System;
using System.Runtime.Caching;
using System.Windows.Forms;
using Autofac;
using Microsoft.Extensions.Caching.Memory;
using PermissionTest.Contract;
using PermissionTest.Service;
using Serilog;
using Serilog.Formatting.Json;

namespace PermissionTest
{
    internal static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var builder = new ContainerBuilder();
            builder.RegisterType<MyDbContext>().InstancePerLifetimeScope();

            //builder.RegisterType<MemoryCacheService>().SingleInstance();
            builder.Register(c => new MemoryCache(new MemoryCacheOptions())).SingleInstance();

            builder.RegisterType<PermissionService>().As<IPermissionService>().InstancePerLifetimeScope();
            builder.RegisterType<ActivityLogService>().As<IActivityLogService>().SingleInstance();
            builder.RegisterType<EmployeeService>().As<IEmployeeService>().InstancePerLifetimeScope();
            builder.RegisterType<AuthService>().SingleInstance();
            builder.RegisterType<CurrentUserService>()
                .WithParameter("userId", 0)
                .WithParameter("userName", "")
                .InstancePerDependency();

            builder.RegisterType<LoginForm>();
            builder.RegisterType<MainForm>();

            var container = builder.Build();

            Log.Logger = new LoggerConfiguration()
                .WriteTo.File(new JsonFormatter(), "logs/log.json")
                .CreateLogger();

            Log.Logger = new LoggerConfiguration()
                .Enrich.FromLogContext()
                .WriteTo.Console(new JsonFormatter())  // JSON 格式輸出到 Console
                .WriteTo.File(new JsonFormatter(), "logs/log-.json", rollingInterval: RollingInterval.Day)
                .CreateLogger();

            using (var scope = container.BeginLifetimeScope())
            {
                var mainForm = scope.Resolve<MainForm>();
                Application.Run(mainForm);
            }
        }
    }
}
