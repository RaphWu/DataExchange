﻿using System;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PermissionTest.Entity;
using PermissionTest.Helper;

namespace PermissionTest.Funcs
{
    public async Task AddEmployeeAsync(string name, string password, string phone, string address, int deptId, int performedByUserId)
    {
        var emp = new Employee
        {
            Name = name,
            PasswordHash = PasswordHelper.HashPassword(password),
            DepartmentId = deptId
        };
        _db.Employees.Add(emp);
        await _db.SaveChangesAsync();

        var profile = new EmployeeProfile
        {
            EmployeeId = emp.Id,
            Phone = phone,
            Address = address
        };
        _db.EmployeeProfiles.Add(profile);
        await _db.SaveChangesAsync();

        await _logService.LogAsync(performedByUserId, "AddEmployee", JsonConvert.SerializeObject(new { emp.Id, emp.Name }));
    }
}
