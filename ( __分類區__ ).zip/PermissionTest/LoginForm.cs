﻿using System;
using System.Windows.Forms;
using Autofac;
using PermissionTest.Service;

namespace PermissionTest
{
    public partial class LoginForm : Form
    {
        private readonly AuthService _authService;

        public LoginForm(AuthService authService)
        {
            InitializeComponent();
            _authService = authService;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var username = txtUsername.Text;
            var password = txtPassword.Text;

            var user = _authService.Login(username, password);
            if (user != null)
            {
                // 登入成功，開啟 MainForm
                var mainForm = Program.Container.Resolve<MainForm>(
                    new NamedParameter("currentUserId", user.Id),
                    new NamedParameter("currentUserName", user.Name)
                );
                mainForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("帳號或密碼錯誤");
            }
        }
    }
}
