﻿using PermissionTest.Contract;

namespace PermissionTest.Helper
{
    public static class PermissionChecker
    {
        public static bool CanAccess(IPermissionService permissionService, string userId, string permission)
        {
            return permissionService.HasPermission(userId, permission);
        }
    }
}
