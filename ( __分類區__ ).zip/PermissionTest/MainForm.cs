﻿using System;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using PermissionTest.Contract;
using PermissionTest.Helper;
using PermissionTest.Logger;

namespace PermissionTest
{
    public partial class MainForm : Form
    {
        private readonly ILifetimeScope _scope;
        private readonly IEmployeeService _employeeService;
        private readonly IPermissionService _permissionService;
        private readonly ICurrentUserService _currentUser;
        private readonly IUserGroupService _groupService;
        private readonly string _currentUserId;

        private readonly UIEventLoggerWithPermission _uiLogger;

        public MainForm(ILifetimeScope lifetimeScope,
                        IEmployeeService employeeService,
                        IPermissionService permissionService,
                        ICurrentUserService currentUserService,
                        IUserGroupService userGroupService,
                        string currentUserId)
        {
            InitializeComponent();

            _scope = lifetimeScope;
            _employeeService = employeeService;
            _permissionService = permissionService;
            _currentUser = currentUserService;
            _groupService = userGroupService;
            _currentUserId = currentUserId;

            // 掛載UI事件監聽器
            _uiLogger = new UIEventLoggerWithPermission(currentUser, permissionService, activityLogService);
            _uiLogger.Attach(this); // 掛載到整個 Form
            //_uiLogger.RefreshPermissions(this); // 當管理員修改權限後，刷新當前表單控制項

            // 權限控制按鈕
            btnAddEmployee.Enabled = PermissionChecker.CanAccess(_permissionService, _currentUserId, "EmployeeCreate");
            btnEditEmployee.Enabled = PermissionChecker.CanAccess(_permissionService, _currentUserId, "EmployeeUpdate");
            btnDeleteEmployee.Enabled = PermissionChecker.CanAccess(_permissionService, _currentUserId, "EmployeeDelete");
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            await RefreshUIPermissionsAsync();
            LoadEmployeeList();
        }

        private async Task RefreshUIPermissionsAsync()
        {
            var perms = await _currentUser.GetPermissionsAsync();

            btnAddEmployee.Enabled = perms.Contains("EmployeeCreate");
            btnEditEmployee.Enabled = perms.Contains("EmployeeUpdate");
            btnDeleteEmployee.Enabled = perms.Contains("EmployeeDelete");

            btnEditDeptPermissions.Enabled = perms.Contains("DepartmentUpdate");
            btnEditGroupPermissions.Enabled = perms.Contains("UserGroupUpdate");
        }

        private void LoadEmployeeList()
        {
            dgvEmployees.DataSource = _employeeService.GetAllEmployees();
        }

        /********************
         * Utility
         ********************/
        private async void LoadGroups()
        {
            var groups = await _groupService.GetAllAsync();
            dgvGroups.DataSource = groups.Select(g => new { g.Id, g.Name }).ToList();
        }

        private void ApplyPermissionsToUI()
        {
            btnAddEmployee.Enabled = PermissionChecker.CanAccess(_permissionService, _currentUserId, "EmployeeCreate");
            btnEditEmployee.Enabled = PermissionChecker.CanAccess(_permissionService, _currentUserId, "EmployeeUpdate");
            btnDeleteEmployee.Enabled = PermissionChecker.CanAccess(_permissionService, _currentUserId, "EmployeeDelete");
            btnManageGroups.Enabled = PermissionChecker.CanAccess(_permissionService, _currentUserId, "UserGroupManage");
        }

        /********************
         * Buttons
         ********************/
        private async void btnAddEmployee_Click(object sender, EventArgs e)
        {
            var empName = txtName.Text;
            var password = txtPassword.Text;
            var phone = txtPhone.Text;
            var address = txtAddress.Text;
            var deptId = (int)cmbDepartments.SelectedValue;

            await _employeeService.AddEmployeeAsync(empName, password, phone, address, deptId, _currentUser.UserId);
            LoadEmployeeList();
            await RefreshUIPermissionsAsync();

            MessageBox.Show("新增成功");
        }

        private async void btnEditEmployee_Click(object sender, EventArgs e)
        {
            var emp = await _employeeService.GetByIdAsync(int.Parse(txtEmpId.Text));
            emp.Name = txtName.Text;
            await _employeeService.UpdateAsync(emp, _currentUserId);
            await RefreshUIPermissionsAsync(); // 立即刷新當前使用者權限
            MessageBox.Show("更新成功");
        }

        private async void btnDeleteEmployee_Click(object sender, EventArgs e)
        {
            await _employeeService.DeleteAsync(int.Parse(txtEmpId.Text), _currentUserId);
            MessageBox.Show("刪除成功");
        }

        private async void btnAssignUsers_Click(object sender, EventArgs e)
        {
            int groupId = int.Parse(txtGroupId.Text);
            var selectedUserIds = dgvEmployees.SelectedRows.Cast<DataGridViewRow>()
                                     .Select(r => (int)r.Cells["Id"].Value).ToList();

            await _groupService.AssignUsersAsync(groupId, selectedUserIds, _currentUserId);
            MessageBox.Show("指派使用者完成");
        }

        private async void btnAssignPermissions_Click(object sender, EventArgs e)
        {
            int groupId = int.Parse(txtGroupId.Text);
            var selectedPermissionIds = dgvPermissions.SelectedRows.Cast<DataGridViewRow>()
                                           .Select(r => (int)r.Cells["Id"].Value).ToList();

            await _groupService.AssignPermissionsAsync(groupId, selectedPermissionIds, _currentUserId);
            MessageBox.Show("指派權限完成");
        }
    }
}
