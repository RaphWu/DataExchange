﻿using System.ComponentModel.DataAnnotations.Schema;
using PermissionTest.Helper;

namespace PermissionTest.Entity
{
    public class EmployeeProfile
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public virtual Employee Employee { get; set; }

        public string EncryptedPhone { get; set; }  // AES 加密
        public string EncryptedAddress { get; set; }

        [NotMapped]
        public string Phone
        {
            get => AESHelper.Decrypt(EncryptedPhone);
            set => EncryptedPhone = AESHelper.Encrypt(value);
        }

        [NotMapped]
        public string Address
        {
            get => AESHelper.Decrypt(EncryptedAddress);
            set => EncryptedAddress = AESHelper.Encrypt(value);
        }
    }
}
