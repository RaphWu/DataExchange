﻿//using System;

//namespace PermissionTest.Entity
//{
//    public class ActivityLog
//    {
//        public int Id { get; set; }
//        public int UserId { get; set; }
//        public string Action { get; set; }
//        public string DataJson { get; set; }
//        public DateTime Timestamp { get; set; }
//    }
//}
