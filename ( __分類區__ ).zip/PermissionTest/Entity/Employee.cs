﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using PermissionTest.Helper;

namespace PermissionTest.Entity
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }

        public virtual Department Department { get; set; }
        public int DepartmentId { get; set; }

        public string PasswordHash { get; set; } // PBKDF2
        public string SensitiveData { get; set; } // AES

        public void SetPassword(string password)
        {
            PasswordHash = PasswordHelper.HashPassword(password);
        }

        public bool VerifyPassword(string password)
        {
            return PasswordHelper.VerifyPassword(password, PasswordHash);
        }

        public void SetSensitiveData(string plainText)
        {
            SensitiveData = AESHelper.Encrypt(plainText);
        }

        public string GetSensitiveData()
        {
            return AESHelper.Decrypt(SensitiveData);
        }

        public virtual ICollection<UserGroup> UserGroups { get; set; } = new HashSet<UserGroup>();
    }
}
