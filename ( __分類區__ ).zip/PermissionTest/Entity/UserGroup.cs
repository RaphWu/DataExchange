﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PermissionTest.Entity
{
    public class UserGroup
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<Employee> Members { get; set; } = new HashSet<Employee>();
        public virtual ICollection<Permission> Permissions { get; set; } = new HashSet<Permission>();
    }
}
