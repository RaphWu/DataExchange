﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PermissionTest.Entity;

namespace PermissionTest.Contract
{
    public interface IEmployeeService
    {
        Task<List<Employee>> GetAllEmployees();
        Task<Employee> GetByIdAsync(int id);
        Task CreateAsync(Employee emp, string performedByUserId);
        Task UpdateAsync(Employee emp, string performedByUserId);
        Task DeleteAsync(int id, string performedByUserId);
    }
}
