﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace PermissionTest.Contract
{
    public interface IPermissionService
    {
        Task<List<string>> GetUserPermissionsAsync(int userId);
    }
}
