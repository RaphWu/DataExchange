﻿using System.Threading.Tasks;

namespace PermissionTest.Contract
{
    /// <summary>
    /// 
    /// </summary>
    /// <remarks><pre>
    /// 登入
    /// _logService.LogAsync(user.Id, "Login", new { Username = user.Name });
    /// 
    /// 新增員工
    /// await _logService.LogAsync(currentUserId, "AddEmployee", new { emp.Id, emp.Name, Phone = phone, Address = address });
    /// 
    /// 編輯員工
    /// await _logService.LogAsync(currentUserId, "EditEmployee", emp);
    /// 
    /// 刪除員工
    /// await _logService.LogAsync(currentUserId, "DeleteEmployee", emp);
    /// </pre></remarks>
    public interface IActivityLogService
    {
        Task LogAsync(string userId, string action, string dataJson);

        Task LogUIActionAsync(int userId, string formName, string controlName, string action, object data = null);
    }
}
