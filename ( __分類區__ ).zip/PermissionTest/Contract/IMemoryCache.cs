﻿using System;

namespace PermissionTest.Contract
{
    public interface IMemoryCache
    {
        T GetOrCreate<T>(string key, Func<T> factory, TimeSpan? expiration = null);

        void Remove(string key);

        void RemoveByPrefix(string prefix);
    }
}
