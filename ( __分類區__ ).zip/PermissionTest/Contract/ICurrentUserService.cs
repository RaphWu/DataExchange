﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace PermissionTest.Contract
{
    public interface ICurrentUserService
    {
        int UserId { get; }
        string UserName { get; }
        Task<List<string>> GetPermissionsAsync();
    }
}
