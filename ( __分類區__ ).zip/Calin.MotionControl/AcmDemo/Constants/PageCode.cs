﻿namespace AcmDemo.Constants
{
    public enum PageCode
    {
        MainPanel,
        Manual,
        Home,
        P2P,
    }
}
