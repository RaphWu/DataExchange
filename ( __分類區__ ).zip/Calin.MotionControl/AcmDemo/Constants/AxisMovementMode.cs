﻿namespace AcmDemo.Constants
{
    public enum AxisMovementMode
    {
        Absolute, Relative
    }
}
