﻿using CommunityToolkit.Mvvm.Messaging.Messages;

namespace AcmDemo.Events
{
    /// <summary>
    /// 軸變更訊息。
    /// </summary>
    public sealed class AxisChangedMessage : ValueChangedMessage<int>
    {
        public AxisChangedMessage(int axisNo) : base(axisNo) { }
    }
}
