﻿using System;

namespace Calin.MC.Advantech.Models
{
    [Flags]
    public enum StateFlags : uint
    {
        STA_AX_DISABLE,
        STA_AX_READY,
        STA_AX_STOPPING,
        STA_AX_ERROR_STOP,
        STA_AX_HOMING,
        STA_AX_PTP_MOT,
        STA_AX_CONTI_MOT,
        STA_AX_SYNC_MOT,
        STA_AX_EXT_JOG,
        STA_AX_EXT_MPG,
        STA_AX_PAUSE,
        STA_AX_BUSY,
        STA_AX_WAIT_DI,
        STA_AX_WAIT_PTP,
        STA_AX_WAIT_VEL,
        STA_AX_EXT_JOG_READY,
    }
}
