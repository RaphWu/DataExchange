﻿using Advantech.Motion;

namespace Calin.MC.Advantech.Models
{
    /// <summary>
    /// 運動狀態資料模型 (Snapshot Buffer)。
    /// </summary>
    public struct RawAxisState
    {
        /// <summary>
        /// 軸命令位置。
        /// </summary>
        public double CmdPosition;

        /// <summary>
        /// 軸實際位置。
        /// </summary>
        public double ActPosition;

        /// <summary>
        /// 軸當前狀態。
        /// </summary>
        public AxisState AxisState;

        /// <summary>
        /// 軸當前運動狀態。
        /// </summary>
        public uint MotionStatus;

        /// <summary>
        /// 軸的運動 I/O 狀態。
        /// </summary>
        public uint IoStatus;
    }
}