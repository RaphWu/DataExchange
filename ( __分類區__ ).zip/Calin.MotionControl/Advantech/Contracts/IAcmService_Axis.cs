﻿using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Contracts
{
    /// <summary>
    /// 軸操作服務介面。
    /// </summary>
    public interface IAcmService_Axis
    {
        #region Properties

        /// <summary>
        /// 取得軸數量。
        /// </summary>
        uint AxisCount { get; }

        /// <summary>
        /// 各軸解析後狀態。
        /// </summary>
        ParsedAxisState[] AxisStates { get; }

        #endregion Properties

        #region Methods

        /// <summary>
        /// 軸減速停止。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <returns>動作是否完成。</returns>
        bool AxisStop(int axisNo);

        /// <summary>
        /// 軸緊急停止。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <returns>動作是否完成。</returns>
        bool AxisStopEmg(int axisNo);

        /// <summary>
        /// 軸原點復歸。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <param name="homeMode">復歸模式 (模式0 ~ 15)。</param>
        /// <param name="direction">復歸方向 (0:正方向, 1:負方向)。</param>
        /// <param name="switchMode">停止模式 (0:Level On, 1:Level Off, 2:Rising Edge, 3:Falling Edge)。</param>
        /// <param name="crossDistance">跨越距離 (大於0)。</param>
        /// <returns>動作是否完成。</returns>
        bool AxisHome(int axisNo, uint homeMode, uint direction, uint switchMode, double crossDistance);

        /// <summary>
        /// 設定軸命令位置。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <param name="position">位置座標。</param>
        /// <returns>設定是否完成。</returns>
        bool SetCmdPosition(int axisNo, double position);

        /// <summary>
        /// 設定軸實際位置。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <param name="position">位置座標。</param>
        /// <returns>設定是否完成。</returns>
        bool SetActPosition(int axisNo, double position);

        #endregion Methods

        #region Axis Parameters

        // VelLow
        /// <summary>
        /// 讀取軸 VelLow。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <returns>IsSuccess:是否讀取成功。<br/>Value:讀取值。</returns>
        (bool IsSuccess, double Value) GetAxisVelLow(int axisNo);

        /// <summary>
        /// 設定軸 VelLow。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <param name="value">VelLow 速度值。</param>
        /// <returns>是否成功設定。</returns>
        bool SetAxisVelLow(int axisNo, double value);

        // VelHigh
        /// <summary>
        /// 讀取軸 VelHigh。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <returns>IsSuccess:是否讀取成功。<br/>Value:讀取值。</returns>
        (bool IsSuccess, double Value) GetAxisVelHigh(int axisNo);

        /// <summary>
        /// 設定軸 VelHigh。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <param name="value">VelHigh 速度值。</param>
        /// <returns>是否成功設定。</returns>
        bool SetAxisVelHigh(int axisNo, double value);

        // Acceleration
        /// <summary>
        /// 讀取軸加速度。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <returns>IsSuccess:是否讀取成功。<br/>Value:讀取值。</returns>
        (bool IsSuccess, double Value) GetAxisAcc(int axisNo);

        /// <summary>
        /// 設定軸加速度。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <param name="value">加速度值。</param>
        /// <returns>是否成功設定。</returns>
        bool SetAxisAcc(int axisNo, double value);

        // Deceleration
        /// <summary>
        /// 讀取軸減速度。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <returns>IsSuccess:是否讀取成功。<br/>Value:讀取值。</returns>
        (bool IsSuccess, double Value) GetAxisDec(int axisNo);

        /// <summary>
        /// 設定軸減速度。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <param name="value">減速度值。</param>
        /// <returns>是否成功設定。</returns>
        bool SetAxisDec(int axisNo, double value);

        // Jerk
        /// <summary>
        /// 讀取軸速度曲線型態。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <returns>IsSuccess:是否讀取成功。<br/>Value:讀取值。</returns>
        (bool IsSuccess, double Value) GetAxisJerk(int axisNo);

        /// <summary>
        /// 設定軸速度曲線型態。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <param name="value">0: T型曲線。<br/>1: S型曲線。</param>
        /// <returns>是否成功設定。</returns>
        bool SetAxisJerk(int axisNo, double value);

        #endregion Axis Parameters

        #region Motion

        /// <summary>
        /// 軸絕對移動。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <param name="position">位置座標。</param>
        /// <returns>動作是否完成。</returns>
        bool MoveAbsolute(int axisNo, double position);

        /// <summary>
        /// 軸相對移動。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <param name="distance">移動距離。</param>
        /// <returns>動作是否完成。</returns>
        bool MoveRelative(int axisNo, double distance);

        #endregion Motion

        #region Helpers

        /// <summary>
        /// 取得原點復歸模式名稱。
        /// </summary>
        /// <param name="homeMode">復歸模式 (模式0 ~ 15)。</param>
        /// <returns>描述字符串。</returns>
        string GetHomeModeName(uint homeMode);

        /// <summary>
        /// 取得原點復歸模式描述。
        /// </summary>
        /// <param name="homeMode">復歸模式 (模式0 ~ 15)。</param>
        /// <returns>描述字符串。</returns>
        string GetHomeModeDescription(uint homeMode);

        #endregion Helpers
    }
}
