﻿namespace Calin.MC.Advantech.Contracts
{
    public interface IAcmService_Manual
    {


        /// <summary>
        /// 設定外部驅動模式。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <param name="extDriveMode">外部驅動模式。<br/>0:Disable<br/>1:Jog<br/>2:MPG</param>
        /// <returns>是否成功設定。</returns>
        bool SetExtDrive(int axisNo, ushort extDriveMode);
    }
}
