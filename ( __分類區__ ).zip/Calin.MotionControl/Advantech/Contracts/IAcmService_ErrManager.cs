﻿namespace Calin.MC.Advantech.Contracts
{
    /// <summary>
    /// Acm 錯誤訊息服務介面。
    /// </summary>
    /// <remarks>使用方法：
    /// <pre><code>
    /// 內部函數呼叫 ACM 函數的返回值直接賦值給 ErrCode 屬性，其它屬性即會自動設定。
    /// 1. NoError 和 HasError 屬性可用於檢查是否發生錯誤。
    /// 2. ErrMessage 屬性可用於取得錯誤訊息。(NoError 時為空字串)
    /// 
    /// 用法範例：
    /// ErrCode = mAcm_Function(...);
    /// if (HasError)
    /// {
    ///     Console.WriteLine($"Error {errManager.ErrCode}: {errManager.ErrMessage}");
    /// }
    /// ```
    /// 外部的應用程式可以這樣使用：
    /// 
    /// </code></pre></remarks>
    public interface IAcmService_ErrManager
    {
        /// <summary>
        /// 無錯誤發生。
        /// </summary>
        bool NoError { get; }

        /// <summary>
        /// 有錯誤發生。
        /// </summary>
        bool HasError { get; }

        /// <summary>
        /// 錯誤代碼。
        /// </summary>
        uint ErrCode { get; internal set; }

        /// <summary>
        /// 錯誤訊息。
        /// </summary>
        string ErrMessage { get; }
    }
}
