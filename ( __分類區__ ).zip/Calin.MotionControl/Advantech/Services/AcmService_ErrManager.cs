﻿using System.Text;
using Advantech.Motion;
using Calin.MC.Advantech.Contracts;

namespace Calin.MC.Advantech.Services
{
    public partial class AcmService : IAcmService_ErrManager
    {
        #region fields

        private const int MaxError = 100;
        private uint _errCode;
        private StringBuilder _errMsg = new StringBuilder("", MaxError);

        #endregion fields

        public bool NoError => _errCode == (int)ErrorCode.SUCCESS;
        public bool HasError => _errCode != (int)ErrorCode.SUCCESS;
        public uint ErrCode
        {
            get => _errCode;
            set
            {
                _errCode = value;

                if (value == (uint)ErrorCode.SUCCESS && _errMsg.Length > 0)
                    _errMsg.Clear();

                if (value != (int)ErrorCode.SUCCESS)
                    if (!Motion.mAcm_GetErrorMessage(value, _errMsg, MaxError))
                        _errMsg.Clear().Append($"無法取得錯誤代碼 0x{value:8X} 的訊息，請查閱手冊或詢問原廠。");
            }
        }
        public string ErrMessage => _errMsg.Length == 0 ? "" : _errMsg.ToString();













        ///// <summary>
        ///// 錯誤訊息表。
        ///// </summary>
        //internal Dictionary<int, ErrManager> errorMessages = new Dictionary<int, ErrManager>();

        ///// <inheritdoc/>
        //public ErrManager GetErrMessage(int code)
        //{
        //    return errorMessages.TryGetValue(code, out var errMessage)
        //        ? errMessage
        //        : new ErrMessage("查無代碼", $"錯誤訊息表沒有錯誤代碼 0x{code:8X} 的資訊，請查閱手冊。");
        //}

        ///// <summary>
        ///// 設定錯誤訊息表。
        ///// </summary>
        //internal void ConfigErrorMessages()
        //{
        //    errorMessages.Add(0x00000000, new ErrMessage("SUCCESS"));
        //}
    }
}
