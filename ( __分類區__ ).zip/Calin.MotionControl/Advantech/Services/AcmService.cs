﻿using Advantech.Motion;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Services
{
    /// <summary>
    /// Advantech ACM 服務。
    /// </summary>
    public partial class AcmService : IAcm
    {
        #region fields

        /********************
         * devices
         ********************/
        /// <summary>
        /// 設備編號。
        /// </summary>
        private uint m_DeviceNum = 0;

        /// <summary>
        /// 設備句柄。
        /// </summary>
        private nint m_DeviceHandle = 0;

        private uint m_DeviceCount = 0; // 有效設備數量
        private DEV_LIST[] m_AvailableDevices = new DEV_LIST[Motion.MAX_DEVICES]; // 有效設備列表

        /********************
         * axises
         ********************/
        /// <summary>
        /// 有效軸數量。
        /// </summary>
        private uint m_AxisCount = 0;

        /// <summary>
        /// 各軸句柄。
        /// </summary>
        private nint[] m_AxisHandles = new nint[32];

        #endregion fields

        public AcmService(AcmConfig acmConfig)
        {
        }


        public void StopMotion()
        {

        }
    }
}
