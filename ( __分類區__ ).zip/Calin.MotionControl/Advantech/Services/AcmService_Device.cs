﻿using System;
using Advantech.Motion;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Services
{
    // 設備操作
    public partial class AcmService : IAcmService_Device
    {
        /// <inheritdoc/>
        public void GetAvailableDevs()
        {
            ErrCode = (uint)Motion.mAcm_GetAvailableDevs(m_AvailableDevices, Motion.MAX_DEVICES, ref m_DeviceCount);
        }

        public void DeviceOpen()
        {
            ErrCode = Motion.mAcm_DevOpen(m_DeviceNum, ref m_DeviceHandle);
        }

    }
}
