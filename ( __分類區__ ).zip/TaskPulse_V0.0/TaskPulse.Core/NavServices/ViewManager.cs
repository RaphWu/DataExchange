﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Autofac;

namespace Calin.TaskPulse.Core.NavServices
{
    public class ViewManager : IViewManager
    {
        private readonly ILifetimeScope _rootScope;
        private readonly Dictionary<Type, ILifetimeScope> _aliveScopes = new Dictionary<Type, ILifetimeScope>();

        public ViewManager(ILifetimeScope rootScope)
        {
            _rootScope = rootScope;
        }

        public object Resolve(Type viewType, bool alive = false)
        {
            if (!alive)
            {
                var tempScope = _rootScope.BeginLifetimeScope();
                var tempView = tempScope.Resolve(viewType);

                if (tempView is Form form)
                {
                    form.FormClosed += (s, e) =>
                    {
                        tempScope.Dispose();
                    };
                }
                else if (tempView is IDisposable)
                {
                    // 若不是 Form，但有 IDisposable，也可註冊釋放
                    // → 呼叫端用完後 Dispose view 時，scope 同步 Dispose
                    // （這邊保守做法是 scope 推遲到 GC 處理）
                    // 如果你有非 Form 的 View 想用事件自動 Dispose，可擴充這裡
                }

                return tempView;
            }

            if (_aliveScopes.TryGetValue(viewType, out var scope))
                return scope.Resolve(viewType);

            var childScope = _rootScope.BeginLifetimeScope();
            var view = childScope.Resolve(viewType);
            _aliveScopes[viewType] = childScope;
            return view;
        }

        public TView Resolve<TView>(bool alive = false) where TView : class
        {
            return (TView)Resolve(typeof(TView), alive);
        }

        public void Release(Type viewType)
        {
            if (_aliveScopes.TryGetValue(viewType, out var scope))
            {
                scope.Dispose();
                _aliveScopes.Remove(viewType);
            }
        }

        public void Release<TView>() where TView : class
        {
            Release(typeof(TView));
        }
    }
}
