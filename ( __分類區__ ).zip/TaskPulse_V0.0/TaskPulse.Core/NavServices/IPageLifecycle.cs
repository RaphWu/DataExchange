//using System.Threading.Tasks;

//namespace Calin.TaskPulse.Core.NavServices
//{
//    public interface IPageLifecycle
//    {
//        Task OnPageShown();
//        Task OnPageHidden();
//    }
//}