﻿using System;
using System.Configuration;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Helper;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Sunny.UI;

namespace Calin.TaskPulse.Core.SharedUI
{
    public partial class LoginControl : UserControl
    {
        private readonly ILifetimeScope _scope;
        private readonly ILogService _log;
        private readonly ICurrentUserService _currentUser;

        //public string[] NameList = new string[0];

        public LoginControl(ILifetimeScope lifetimeScope,
                            ILogService logService,
                            ICurrentUserService currentUserService,
                            CoreData coreData)
        {
            InitializeComponent();
            _scope = lifetimeScope;
            _log = logService;
            _currentUser = currentUserService;

            var _nameList = coreData.Employees.Select(e => new ListViewModel()
            {
                IdString = e.EmployeeId,
                Name = e.FullName
            }).ToList();
            uiComboBox_UserName.DataSource = _nameList;
            uiComboBox_UserName.DisplayMember = "Name";
            uiComboBox_UserName.ValueMember = "IdString";

            CommonStyles.SetButton(Button_Login);
            CommonStyles.SetButton(Button_Cancel, isCancel: true);
        }

        private async void Button_Login_Click(object sender, EventArgs e)
        {
            var adminUser = ConfigurationManager.AppSettings["AdminUser"];
            var appEncryptedPassword = ConfigurationManager.AppSettings["AdminPassword"];
            var appPassword = AESHelper.Decrypt(appEncryptedPassword);
            var password = uiTextBox_Password.Text.Trim();
            var employeeId = uiComboBox_UserName.SelectedValue != null
                ? uiComboBox_UserName.SelectedValue.ToString()
                : uiComboBox_UserName.Text.Trim();

            if (!string.IsNullOrEmpty(employeeId))
            {
                if (employeeId.ToLower() == adminUser.ToLower())
                {
                    if (password == appPassword)
                    {
                        _currentUser.AdminLogin();
                        await _log.LoginAsync("", "管理員登入", $"登入時間: {DateTime.Now}");
                        return;
                    }
                    else
                    {
                        await _log.LoginAsync("", "管理員登入錯誤", $"嘗試時間: {DateTime.Now}");
                    }
                }
                else
                {
                    var auth = _scope.Resolve<IAuthService>();
                    if (await auth.ActiveDirectoryAsync(employeeId, password))
                    {
                        _currentUser.SwitchCurrentUser(employeeId);
                        Console.WriteLine("LDAP驗證成功");
                        await _log.LoginAsync(employeeId, "登入成功", "");
                        return;
                    }
                    else
                    {
                        Console.WriteLine("使用者不存在於系統中");
                        await _log.LoginAsync(employeeId, "登入失敗", "使用者不存在於系統中");
                    }
                }
            }
            else
            {
                Console.WriteLine("User輸入空白。");
                await _log.LoginAsync(employeeId, "登入失敗", "User輸入空白");
            }
            _currentUser.SwitchCurrentUserToGuest();
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            //DialogResult = DialogResult.Cancel;
            //this.Close();
        }

        private void uiTextBox_Password_ButtonClick(object sender, EventArgs e)
        {
            uiTextBox_Password.Text = "";
        }
    }
}
