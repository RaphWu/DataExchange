﻿namespace Calin.TaskPulse.Core.Views
{
    partial class MachineEdit
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label_Remark = new Sunny.UI.UILabel();
            this.tbRemark = new Sunny.UI.UIRichTextBox();
            this.label_Connected = new Sunny.UI.UILabel();
            this.label_Disposal = new Sunny.UI.UILabel();
            this.tbAssets = new Sunny.UI.UIRichTextBox();
            this.label_SerialNumber = new Sunny.UI.UILabel();
            this.label_Barcode = new Sunny.UI.UILabel();
            this.tbSerialNumber = new Sunny.UI.UITextBox();
            this.label_Assets = new Sunny.UI.UILabel();
            this.tbBarcode = new Sunny.UI.UITextBox();
            this.label_Location = new Sunny.UI.UILabel();
            this.label_Brand = new Sunny.UI.UILabel();
            this.label_Condition = new Sunny.UI.UILabel();
            this.label_Type = new Sunny.UI.UILabel();
            this.label_Category = new Sunny.UI.UILabel();
            this.label_MachineId = new Sunny.UI.UILabel();
            this.tbMaincheId = new Sunny.UI.UITextBox();
            this.btnOK = new Sunny.UI.UISymbolButton();
            this.btnCancel = new Sunny.UI.UISymbolButton();
            this.cbCategory = new Sunny.UI.UIComboBox();
            this.cbType = new Sunny.UI.UIComboBox();
            this.cbCondition = new Sunny.UI.UIComboBox();
            this.cbBrand = new Sunny.UI.UIComboBox();
            this.cbLocation = new Sunny.UI.UIComboBox();
            this.cbConnected = new Sunny.UI.UIComboBox();
            this.cbDisposal = new Sunny.UI.UIComboBox();
            this.cbModelName = new Sunny.UI.UIComboBox();
            this.Label_ModelName = new Sunny.UI.UILabel();
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.tbWorkstations = new Sunny.UI.UIRichTextBox();
            this.btnWorkstation = new Sunny.UI.UISymbolButton();
            this.SuspendLayout();
            // 
            // label_Remark
            // 
            this.label_Remark.BackColor = System.Drawing.Color.Transparent;
            this.label_Remark.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Remark.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Remark.Location = new System.Drawing.Point(629, 52);
            this.label_Remark.Margin = new System.Windows.Forms.Padding(0);
            this.label_Remark.Name = "label_Remark";
            this.label_Remark.Size = new System.Drawing.Size(48, 29);
            this.label_Remark.TabIndex = 66;
            this.label_Remark.Text = "備註";
            this.label_Remark.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbRemark
            // 
            this.tbRemark.FillColor = System.Drawing.Color.White;
            this.tbRemark.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tbRemark.Location = new System.Drawing.Point(681, 52);
            this.tbRemark.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbRemark.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbRemark.Name = "tbRemark";
            this.tbRemark.Padding = new System.Windows.Forms.Padding(2);
            this.tbRemark.ShowText = false;
            this.tbRemark.Size = new System.Drawing.Size(200, 291);
            this.tbRemark.TabIndex = 1;
            this.tbRemark.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_Connected
            // 
            this.label_Connected.BackColor = System.Drawing.Color.Transparent;
            this.label_Connected.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Connected.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Connected.Location = new System.Drawing.Point(346, 314);
            this.label_Connected.Margin = new System.Windows.Forms.Padding(0);
            this.label_Connected.Name = "label_Connected";
            this.label_Connected.Size = new System.Drawing.Size(55, 29);
            this.label_Connected.TabIndex = 65;
            this.label_Connected.Text = "連網";
            this.label_Connected.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Disposal
            // 
            this.label_Disposal.BackColor = System.Drawing.Color.Transparent;
            this.label_Disposal.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Disposal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Disposal.Location = new System.Drawing.Point(346, 353);
            this.label_Disposal.Margin = new System.Windows.Forms.Padding(0);
            this.label_Disposal.Name = "label_Disposal";
            this.label_Disposal.Size = new System.Drawing.Size(55, 29);
            this.label_Disposal.TabIndex = 63;
            this.label_Disposal.Text = "處置";
            this.label_Disposal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbAssets
            // 
            this.tbAssets.FillColor = System.Drawing.Color.White;
            this.tbAssets.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tbAssets.Location = new System.Drawing.Point(405, 169);
            this.tbAssets.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbAssets.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbAssets.Name = "tbAssets";
            this.tbAssets.Padding = new System.Windows.Forms.Padding(2);
            this.tbAssets.ShowText = false;
            this.tbAssets.Size = new System.Drawing.Size(200, 57);
            this.tbAssets.TabIndex = 2;
            this.tbAssets.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_SerialNumber
            // 
            this.label_SerialNumber.BackColor = System.Drawing.Color.Transparent;
            this.label_SerialNumber.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_SerialNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_SerialNumber.Location = new System.Drawing.Point(346, 236);
            this.label_SerialNumber.Margin = new System.Windows.Forms.Padding(0);
            this.label_SerialNumber.Name = "label_SerialNumber";
            this.label_SerialNumber.Size = new System.Drawing.Size(55, 29);
            this.label_SerialNumber.TabIndex = 59;
            this.label_SerialNumber.Text = "序號";
            this.label_SerialNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Barcode
            // 
            this.label_Barcode.BackColor = System.Drawing.Color.Transparent;
            this.label_Barcode.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Barcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Barcode.Location = new System.Drawing.Point(346, 275);
            this.label_Barcode.Margin = new System.Windows.Forms.Padding(0);
            this.label_Barcode.Name = "label_Barcode";
            this.label_Barcode.Size = new System.Drawing.Size(55, 29);
            this.label_Barcode.TabIndex = 57;
            this.label_Barcode.Text = "條碼";
            this.label_Barcode.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbSerialNumber
            // 
            this.tbSerialNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSerialNumber.FillDisableColor = System.Drawing.Color.White;
            this.tbSerialNumber.FillReadOnlyColor = System.Drawing.Color.White;
            this.tbSerialNumber.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tbSerialNumber.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.tbSerialNumber.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.tbSerialNumber.Location = new System.Drawing.Point(405, 236);
            this.tbSerialNumber.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbSerialNumber.MinimumSize = new System.Drawing.Size(1, 16);
            this.tbSerialNumber.Name = "tbSerialNumber";
            this.tbSerialNumber.Padding = new System.Windows.Forms.Padding(5);
            this.tbSerialNumber.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.tbSerialNumber.ShowText = false;
            this.tbSerialNumber.Size = new System.Drawing.Size(200, 29);
            this.tbSerialNumber.TabIndex = 3;
            this.tbSerialNumber.TabStop = false;
            this.tbSerialNumber.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.tbSerialNumber.Watermark = "";
            // 
            // label_Assets
            // 
            this.label_Assets.BackColor = System.Drawing.Color.Transparent;
            this.label_Assets.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Assets.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Assets.Location = new System.Drawing.Point(346, 169);
            this.label_Assets.Margin = new System.Windows.Forms.Padding(0);
            this.label_Assets.Name = "label_Assets";
            this.label_Assets.Size = new System.Drawing.Size(55, 57);
            this.label_Assets.TabIndex = 55;
            this.label_Assets.Text = "資產\r\n編號";
            this.label_Assets.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // tbBarcode
            // 
            this.tbBarcode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbBarcode.FillDisableColor = System.Drawing.Color.White;
            this.tbBarcode.FillReadOnlyColor = System.Drawing.Color.White;
            this.tbBarcode.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tbBarcode.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.tbBarcode.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.tbBarcode.Location = new System.Drawing.Point(405, 275);
            this.tbBarcode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbBarcode.MinimumSize = new System.Drawing.Size(1, 16);
            this.tbBarcode.Name = "tbBarcode";
            this.tbBarcode.Padding = new System.Windows.Forms.Padding(5);
            this.tbBarcode.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.tbBarcode.ShowText = false;
            this.tbBarcode.Size = new System.Drawing.Size(200, 29);
            this.tbBarcode.TabIndex = 4;
            this.tbBarcode.TabStop = false;
            this.tbBarcode.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.tbBarcode.Watermark = "";
            // 
            // label_Location
            // 
            this.label_Location.BackColor = System.Drawing.Color.Transparent;
            this.label_Location.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Location.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Location.Location = new System.Drawing.Point(346, 130);
            this.label_Location.Margin = new System.Windows.Forms.Padding(0);
            this.label_Location.Name = "label_Location";
            this.label_Location.Size = new System.Drawing.Size(55, 29);
            this.label_Location.TabIndex = 54;
            this.label_Location.Text = "位置";
            this.label_Location.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Brand
            // 
            this.label_Brand.BackColor = System.Drawing.Color.Transparent;
            this.label_Brand.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Brand.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Brand.Location = new System.Drawing.Point(346, 91);
            this.label_Brand.Margin = new System.Windows.Forms.Padding(0);
            this.label_Brand.Name = "label_Brand";
            this.label_Brand.Size = new System.Drawing.Size(55, 29);
            this.label_Brand.TabIndex = 52;
            this.label_Brand.Text = "廠牌";
            this.label_Brand.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Condition
            // 
            this.label_Condition.BackColor = System.Drawing.Color.Transparent;
            this.label_Condition.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Condition.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Condition.Location = new System.Drawing.Point(346, 52);
            this.label_Condition.Margin = new System.Windows.Forms.Padding(0);
            this.label_Condition.Name = "label_Condition";
            this.label_Condition.Size = new System.Drawing.Size(55, 29);
            this.label_Condition.TabIndex = 50;
            this.label_Condition.Text = "狀態";
            this.label_Condition.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Type
            // 
            this.label_Type.BackColor = System.Drawing.Color.Transparent;
            this.label_Type.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Type.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Type.Location = new System.Drawing.Point(14, 130);
            this.label_Type.Margin = new System.Windows.Forms.Padding(0);
            this.label_Type.Name = "label_Type";
            this.label_Type.Size = new System.Drawing.Size(59, 29);
            this.label_Type.TabIndex = 48;
            this.label_Type.Text = "設備別";
            this.label_Type.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Category
            // 
            this.label_Category.BackColor = System.Drawing.Color.Transparent;
            this.label_Category.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Category.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Category.Location = new System.Drawing.Point(14, 91);
            this.label_Category.Margin = new System.Windows.Forms.Padding(0);
            this.label_Category.Name = "label_Category";
            this.label_Category.Size = new System.Drawing.Size(59, 29);
            this.label_Category.TabIndex = 46;
            this.label_Category.Text = "分類";
            this.label_Category.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_MachineId
            // 
            this.label_MachineId.BackColor = System.Drawing.Color.Transparent;
            this.label_MachineId.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_MachineId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_MachineId.Location = new System.Drawing.Point(14, 52);
            this.label_MachineId.Margin = new System.Windows.Forms.Padding(0);
            this.label_MachineId.Name = "label_MachineId";
            this.label_MachineId.Size = new System.Drawing.Size(59, 29);
            this.label_MachineId.TabIndex = 44;
            this.label_MachineId.Text = "編號";
            this.label_MachineId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbMaincheId
            // 
            this.tbMaincheId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbMaincheId.FillDisableColor = System.Drawing.SystemColors.Control;
            this.tbMaincheId.FillReadOnlyColor = System.Drawing.SystemColors.Control;
            this.tbMaincheId.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tbMaincheId.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.tbMaincheId.ForeReadOnlyColor = System.Drawing.SystemColors.ControlText;
            this.tbMaincheId.Location = new System.Drawing.Point(78, 52);
            this.tbMaincheId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbMaincheId.MinimumSize = new System.Drawing.Size(1, 16);
            this.tbMaincheId.Name = "tbMaincheId";
            this.tbMaincheId.Padding = new System.Windows.Forms.Padding(5);
            this.tbMaincheId.ReadOnly = true;
            this.tbMaincheId.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.tbMaincheId.ShowText = false;
            this.tbMaincheId.Size = new System.Drawing.Size(235, 29);
            this.tbMaincheId.TabIndex = 43;
            this.tbMaincheId.TabStop = false;
            this.tbMaincheId.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.tbMaincheId.Watermark = "";
            // 
            // btnOK
            // 
            this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOK.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnOK.Location = new System.Drawing.Point(646, 365);
            this.btnOK.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnOK.Name = "btnOK";
            this.btnOK.Radius = 10;
            this.btnOK.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnOK.Size = new System.Drawing.Size(107, 40);
            this.btnOK.TabIndex = 68;
            this.btnOK.Text = "確定";
            this.btnOK.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnCancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnCancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnCancel.Location = new System.Drawing.Point(772, 365);
            this.btnCancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Radius = 10;
            this.btnCancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnCancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnCancel.Size = new System.Drawing.Size(107, 40);
            this.btnCancel.Style = Sunny.UI.UIStyle.Custom;
            this.btnCancel.Symbol = 361453;
            this.btnCancel.TabIndex = 67;
            this.btnCancel.Text = "取消";
            this.btnCancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // cbCategory
            // 
            this.cbCategory.DataSource = null;
            this.cbCategory.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.cbCategory.FillColor = System.Drawing.Color.White;
            this.cbCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.cbCategory.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.cbCategory.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.cbCategory.Location = new System.Drawing.Point(78, 91);
            this.cbCategory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbCategory.MinimumSize = new System.Drawing.Size(63, 0);
            this.cbCategory.Name = "cbCategory";
            this.cbCategory.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.cbCategory.Size = new System.Drawing.Size(235, 29);
            this.cbCategory.SymbolSize = 24;
            this.cbCategory.TabIndex = 69;
            this.cbCategory.Text = "uiComboBox1";
            this.cbCategory.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbCategory.Watermark = "";
            this.cbCategory.SelectedIndexChanged += new System.EventHandler(this.cbCategory_SelectedIndexChanged);
            // 
            // cbType
            // 
            this.cbType.DataSource = null;
            this.cbType.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.cbType.FillColor = System.Drawing.Color.White;
            this.cbType.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.cbType.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.cbType.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.cbType.Location = new System.Drawing.Point(78, 130);
            this.cbType.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbType.MinimumSize = new System.Drawing.Size(63, 0);
            this.cbType.Name = "cbType";
            this.cbType.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.cbType.Size = new System.Drawing.Size(235, 29);
            this.cbType.SymbolSize = 24;
            this.cbType.TabIndex = 70;
            this.cbType.Text = "uiComboBox2";
            this.cbType.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbType.Watermark = "";
            this.cbType.SelectedIndexChanged += new System.EventHandler(this.cbType_SelectedIndexChanged);
            // 
            // cbCondition
            // 
            this.cbCondition.DataSource = null;
            this.cbCondition.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.cbCondition.FillColor = System.Drawing.Color.White;
            this.cbCondition.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.cbCondition.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.cbCondition.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.cbCondition.Location = new System.Drawing.Point(405, 52);
            this.cbCondition.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbCondition.MinimumSize = new System.Drawing.Size(63, 0);
            this.cbCondition.Name = "cbCondition";
            this.cbCondition.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.cbCondition.Size = new System.Drawing.Size(200, 29);
            this.cbCondition.SymbolSize = 24;
            this.cbCondition.TabIndex = 71;
            this.cbCondition.Text = "uiComboBox3";
            this.cbCondition.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbCondition.Watermark = "";
            // 
            // cbBrand
            // 
            this.cbBrand.DataSource = null;
            this.cbBrand.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.cbBrand.FillColor = System.Drawing.Color.White;
            this.cbBrand.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.cbBrand.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.cbBrand.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.cbBrand.Location = new System.Drawing.Point(405, 91);
            this.cbBrand.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbBrand.MinimumSize = new System.Drawing.Size(63, 0);
            this.cbBrand.Name = "cbBrand";
            this.cbBrand.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.cbBrand.Size = new System.Drawing.Size(200, 29);
            this.cbBrand.SymbolSize = 24;
            this.cbBrand.TabIndex = 71;
            this.cbBrand.Text = "uiComboBox4";
            this.cbBrand.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbBrand.Watermark = "";
            // 
            // cbLocation
            // 
            this.cbLocation.DataSource = null;
            this.cbLocation.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.cbLocation.FillColor = System.Drawing.Color.White;
            this.cbLocation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.cbLocation.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.cbLocation.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.cbLocation.Location = new System.Drawing.Point(405, 130);
            this.cbLocation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbLocation.MinimumSize = new System.Drawing.Size(63, 0);
            this.cbLocation.Name = "cbLocation";
            this.cbLocation.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.cbLocation.Size = new System.Drawing.Size(200, 29);
            this.cbLocation.SymbolSize = 24;
            this.cbLocation.TabIndex = 71;
            this.cbLocation.Text = "uiComboBox5";
            this.cbLocation.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbLocation.Watermark = "";
            // 
            // cbConnected
            // 
            this.cbConnected.DataSource = null;
            this.cbConnected.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.cbConnected.FillColor = System.Drawing.Color.White;
            this.cbConnected.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.cbConnected.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.cbConnected.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.cbConnected.Location = new System.Drawing.Point(405, 314);
            this.cbConnected.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbConnected.MinimumSize = new System.Drawing.Size(63, 0);
            this.cbConnected.Name = "cbConnected";
            this.cbConnected.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.cbConnected.Size = new System.Drawing.Size(200, 29);
            this.cbConnected.SymbolSize = 24;
            this.cbConnected.TabIndex = 71;
            this.cbConnected.Text = "uiComboBox6";
            this.cbConnected.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbConnected.Watermark = "";
            // 
            // cbDisposal
            // 
            this.cbDisposal.DataSource = null;
            this.cbDisposal.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.cbDisposal.FillColor = System.Drawing.Color.White;
            this.cbDisposal.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.cbDisposal.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.cbDisposal.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.cbDisposal.Location = new System.Drawing.Point(405, 353);
            this.cbDisposal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbDisposal.MinimumSize = new System.Drawing.Size(63, 0);
            this.cbDisposal.Name = "cbDisposal";
            this.cbDisposal.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.cbDisposal.Size = new System.Drawing.Size(200, 29);
            this.cbDisposal.SymbolSize = 24;
            this.cbDisposal.TabIndex = 71;
            this.cbDisposal.Text = "uiComboBox7";
            this.cbDisposal.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbDisposal.Watermark = "";
            // 
            // cbModelName
            // 
            this.cbModelName.DataSource = null;
            this.cbModelName.FillColor = System.Drawing.Color.White;
            this.cbModelName.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.cbModelName.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.cbModelName.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.cbModelName.Location = new System.Drawing.Point(78, 169);
            this.cbModelName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbModelName.MinimumSize = new System.Drawing.Size(63, 0);
            this.cbModelName.Name = "cbModelName";
            this.cbModelName.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.cbModelName.Size = new System.Drawing.Size(235, 29);
            this.cbModelName.SymbolSize = 24;
            this.cbModelName.TabIndex = 73;
            this.cbModelName.Text = "uiComboBox3";
            this.cbModelName.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbModelName.Watermark = "";
            // 
            // Label_ModelName
            // 
            this.Label_ModelName.BackColor = System.Drawing.Color.Transparent;
            this.Label_ModelName.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_ModelName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_ModelName.Location = new System.Drawing.Point(14, 169);
            this.Label_ModelName.Margin = new System.Windows.Forms.Padding(0);
            this.Label_ModelName.Name = "Label_ModelName";
            this.Label_ModelName.Size = new System.Drawing.Size(59, 29);
            this.Label_ModelName.TabIndex = 72;
            this.Label_ModelName.Text = "型號";
            this.Label_ModelName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel1
            // 
            this.uiLabel1.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel1.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel1.Location = new System.Drawing.Point(26, 208);
            this.uiLabel1.Margin = new System.Windows.Forms.Padding(0);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(48, 29);
            this.uiLabel1.TabIndex = 75;
            this.uiLabel1.Text = "工站";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel1.Visible = false;
            // 
            // tbWorkstations
            // 
            this.tbWorkstations.FillColor = System.Drawing.Color.White;
            this.tbWorkstations.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tbWorkstations.Location = new System.Drawing.Point(78, 208);
            this.tbWorkstations.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbWorkstations.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbWorkstations.Name = "tbWorkstations";
            this.tbWorkstations.Padding = new System.Windows.Forms.Padding(2);
            this.tbWorkstations.ReadOnly = true;
            this.tbWorkstations.ShowText = false;
            this.tbWorkstations.Size = new System.Drawing.Size(235, 174);
            this.tbWorkstations.TabIndex = 63;
            this.tbWorkstations.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.tbWorkstations.Visible = false;
            // 
            // btnWorkstation
            // 
            this.btnWorkstation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWorkstation.Font = new System.Drawing.Font("Tahoma", 11F);
            this.btnWorkstation.Location = new System.Drawing.Point(282, 210);
            this.btnWorkstation.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnWorkstation.Name = "btnWorkstation";
            this.btnWorkstation.Size = new System.Drawing.Size(29, 29);
            this.btnWorkstation.Symbol = 61761;
            this.btnWorkstation.SymbolOffset = new System.Drawing.Point(1, 1);
            this.btnWorkstation.TabIndex = 76;
            this.btnWorkstation.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnWorkstation.Visible = false;
            this.btnWorkstation.Click += new System.EventHandler(this.btnWorkstation_Click);
            // 
            // MachineEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(910, 422);
            this.ControlBox = false;
            this.Controls.Add(this.btnWorkstation);
            this.Controls.Add(this.tbWorkstations);
            this.Controls.Add(this.uiLabel1);
            this.Controls.Add(this.cbModelName);
            this.Controls.Add(this.Label_ModelName);
            this.Controls.Add(this.cbDisposal);
            this.Controls.Add(this.cbConnected);
            this.Controls.Add(this.cbLocation);
            this.Controls.Add(this.cbBrand);
            this.Controls.Add(this.cbCondition);
            this.Controls.Add(this.cbType);
            this.Controls.Add(this.cbCategory);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.label_Remark);
            this.Controls.Add(this.tbRemark);
            this.Controls.Add(this.label_Connected);
            this.Controls.Add(this.label_Disposal);
            this.Controls.Add(this.tbAssets);
            this.Controls.Add(this.label_SerialNumber);
            this.Controls.Add(this.label_Barcode);
            this.Controls.Add(this.tbSerialNumber);
            this.Controls.Add(this.label_Assets);
            this.Controls.Add(this.tbBarcode);
            this.Controls.Add(this.label_Location);
            this.Controls.Add(this.label_Brand);
            this.Controls.Add(this.label_Condition);
            this.Controls.Add(this.label_Type);
            this.Controls.Add(this.label_Category);
            this.Controls.Add(this.label_MachineId);
            this.Controls.Add(this.tbMaincheId);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MachineEdit";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 599, 401);
            this.Load += new System.EventHandler(this.MachineEdit_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UILabel label_Remark;
        private Sunny.UI.UIRichTextBox tbRemark;
        private Sunny.UI.UILabel label_Connected;
        private Sunny.UI.UILabel label_Disposal;
        private Sunny.UI.UIRichTextBox tbAssets;
        private Sunny.UI.UILabel label_SerialNumber;
        private Sunny.UI.UILabel label_Barcode;
        private Sunny.UI.UITextBox tbSerialNumber;
        private Sunny.UI.UILabel label_Assets;
        private Sunny.UI.UITextBox tbBarcode;
        private Sunny.UI.UILabel label_Location;
        private Sunny.UI.UILabel label_Brand;
        private Sunny.UI.UILabel label_Condition;
        private Sunny.UI.UILabel label_Type;
        private Sunny.UI.UILabel label_Category;
        private Sunny.UI.UILabel label_MachineId;
        private Sunny.UI.UITextBox tbMaincheId;
        private Sunny.UI.UISymbolButton btnOK;
        private Sunny.UI.UISymbolButton btnCancel;
        private Sunny.UI.UIComboBox cbCategory;
        private Sunny.UI.UIComboBox cbType;
        private Sunny.UI.UIComboBox cbCondition;
        private Sunny.UI.UIComboBox cbBrand;
        private Sunny.UI.UIComboBox cbLocation;
        private Sunny.UI.UIComboBox cbConnected;
        private Sunny.UI.UIComboBox cbDisposal;
        private Sunny.UI.UIComboBox cbModelName;
        private Sunny.UI.UILabel Label_ModelName;
        private Sunny.UI.UILabel uiLabel1;
        private Sunny.UI.UIRichTextBox tbWorkstations;
        private Sunny.UI.UISymbolButton btnWorkstation;
    }
}
