﻿using System;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Services
{
    public interface IEntityCacheManager
    {
        bool EmployeeAvailable { get; }
        DateTime EmployeeUpdatedTime { get; }

        bool MachineAvailable { get; }
        DateTime MachineUpdatedTime { get; }

        bool ModelNoAvailable { get; }
        DateTime ModelNoUpdatedTime { get; }

        bool WorkstationAvailable { get; }
        DateTime WorkstationUpdatedTime { get; }

        bool TaskOrderAvailable { get; }
        DateTime TaskOrderUpdatedTime { get; }

        void RequestEmployeeUpdate();
        void NotifyEmployeeUpdated();
        Task WaitForEmployeeAvailableAsync();
        void RequestMachineUpdate();
        void NotifyMachineUpdated();
        Task WaitForMachineAvailableAsync();
        void RequestModelNoUpdate();
        void NotifyModelNoUpdated();
        Task WaitForModelNoAvailableAsync();
        void RequestWorkstationUpdate();
        void NotifyWorkstationUpdated();
        Task WaitForWorkstationAvailableAsync();
        void RequestTaskOrderUpdate();
        void NotifyTaskOrderUpdated();
        Task WaitForTaskOrderAvailableAsync();
    }
}
