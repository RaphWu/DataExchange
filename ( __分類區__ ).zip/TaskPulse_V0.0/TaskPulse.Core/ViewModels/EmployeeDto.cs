﻿//namespace Calin.TaskPulse.Core.ViewModels
//{
//    public class EmployeeDto
//    {
//        public string Id { get; set; }
//        public string Name { get; set; }
//        public string Password { get; set; }
//        public int DepartmentId { get; set; }
//        public int TitleId { get; set; }
//        public string Email { get; set; } = "";
//        public bool IsEngineer { get; set; } = false;
//        public int StatusId { get; set; }
//        public string Permission { get; set; } = "";
//    }
//}
