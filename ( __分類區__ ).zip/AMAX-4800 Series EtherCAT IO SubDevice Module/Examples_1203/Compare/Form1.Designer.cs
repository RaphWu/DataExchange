namespace Compare
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBoxDeviceOperate = new System.Windows.Forms.GroupBox();
            this.buttonServoOn = new System.Windows.Forms.Button();
            this.buttonLoadConfig = new System.Windows.Forms.Button();
            this.buttonCloseBoard = new System.Windows.Forms.Button();
            this.buttonOpenBoard = new System.Windows.Forms.Button();
            this.comboBoxAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.dataGridViewStateAndPotion = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.buttonSetCnt = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageSingleCompare = new System.Windows.Forms.TabPage();
            this.comboBoxScAxisnumb = new System.Windows.Forms.ComboBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.radioButtonSAMRel = new System.Windows.Forms.RadioButton();
            this.radioButtonSAMAbs = new System.Windows.Forms.RadioButton();
            this.textBoxSACCmptableNextCmpData = new System.Windows.Forms.TextBox();
            this.textBoxSingleAxisMotionEndPoint = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.buttonSingleAxisStop = new System.Windows.Forms.Button();
            this.buttonSingleAxisSpeedSet = new System.Windows.Forms.Button();
            this.buttonSingleAxisMove = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.listBoxSCCompareTable = new System.Windows.Forms.ListBox();
            this.buttonSCCompareTableSetTable = new System.Windows.Forms.Button();
            this.buttonSCCompareTableAdd = new System.Windows.Forms.Button();
            this.buttonSCCompareTableClear = new System.Windows.Forms.Button();
            this.textBoxSCCompareTablePoint = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.buttonSingleCmpDelete = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.buttonSCSinglePointCmpSet = new System.Windows.Forms.Button();
            this.textBoxSCSinglePointCmpPoint = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.textBoxScCmpAutoInterval = new System.Windows.Forms.TextBox();
            this.textBoxScCmpAutoEnd = new System.Windows.Forms.TextBox();
            this.textBoxScCmpAutoStart = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.buttonSACCmpAutoSet = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBoxScCmpMethod = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBoxSCCmpSrc = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxAxisCmpPulseWidth = new System.Windows.Forms.TextBox();
            this.comboBoxAxisCmpPulseLogic = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBoxAxisTrigPulseMode = new System.Windows.Forms.ComboBox();
            this.buttonSCSet = new System.Windows.Forms.Button();
            this.tabPageMulitCompare = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.buttonGpClear = new System.Windows.Forms.Button();
            this.dataGridViewGp = new System.Windows.Forms.DataGridView();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnCMove = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonAddtogp = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.radioButtonRel = new System.Windows.Forms.RadioButton();
            this.radioButtonAbs = new System.Windows.Forms.RadioButton();
            this.buttonSetSpeed = new System.Windows.Forms.Button();
            this.comboBoxAxInGp = new System.Windows.Forms.ComboBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBoxCompareTablePoint = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBoxMCCompareTableAxis = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.listBoxCmpData = new System.Windows.Forms.ListBox();
            this.btn_SetTable = new System.Windows.Forms.Button();
            this.btn_Add = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.comboBoxSPCAxis = new System.Windows.Forms.ComboBox();
            this.textBoxSPCPoint = new System.Windows.Forms.TextBox();
            this.buttonSPCSet = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBoxCmpautoEnd = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBoxCmpAutoAxis = new System.Windows.Forms.ComboBox();
            this.textBoxCmpAutoStart = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.buttonCmpAutoSet = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxCmpautoInterval = new System.Windows.Forms.TextBox();
            this.groupBoxSingleComparePara = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxAxisMultiCmpDeviation = new System.Windows.Forms.TextBox();
            this.ButtonAxisComPareSet = new System.Windows.Forms.Button();
            this.comboBoxSrc = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBoxAxisNub = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBoxMultiComparePara = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.checkedListBoxMultiCmpOutChannel = new System.Windows.Forms.CheckedListBox();
            this.checkedListBoxMulAxCompareEn = new System.Windows.Forms.CheckedListBox();
            this.buttonCMPDO = new System.Windows.Forms.Button();
            this.ButtonMultiCompareSet = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxMulAxCmpPulseWidth = new System.Windows.Forms.TextBox();
            this.comboBoxMultiTrigAutoEmptyEn = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxMultiCmpPulseLogic = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxMultiTrigPulseMode = new System.Windows.Forms.ComboBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBoxDeviceOperate.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStateAndPotion)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPageSingleCompare.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.panel12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPageMulitCompare.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGp)).BeginInit();
            this.panel17.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBoxSingleComparePara.SuspendLayout();
            this.groupBoxMultiComparePara.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxDeviceOperate
            // 
            this.groupBoxDeviceOperate.Controls.Add(this.buttonServoOn);
            this.groupBoxDeviceOperate.Controls.Add(this.buttonLoadConfig);
            this.groupBoxDeviceOperate.Controls.Add(this.buttonCloseBoard);
            this.groupBoxDeviceOperate.Controls.Add(this.buttonOpenBoard);
            this.groupBoxDeviceOperate.Controls.Add(this.comboBoxAvailableDevice);
            this.groupBoxDeviceOperate.Controls.Add(this.label1);
            this.groupBoxDeviceOperate.Location = new System.Drawing.Point(12, 12);
            this.groupBoxDeviceOperate.Name = "groupBoxDeviceOperate";
            this.groupBoxDeviceOperate.Size = new System.Drawing.Size(305, 166);
            this.groupBoxDeviceOperate.TabIndex = 1;
            this.groupBoxDeviceOperate.TabStop = false;
            this.groupBoxDeviceOperate.Text = "Device Operate";
            // 
            // buttonServoOn
            // 
            this.buttonServoOn.Location = new System.Drawing.Point(183, 114);
            this.buttonServoOn.Name = "buttonServoOn";
            this.buttonServoOn.Size = new System.Drawing.Size(86, 23);
            this.buttonServoOn.TabIndex = 20;
            this.buttonServoOn.Text = "ServoOn";
            this.buttonServoOn.UseVisualStyleBackColor = true;
            this.buttonServoOn.Click += new System.EventHandler(this.buttonServoOn_Click);
            // 
            // buttonLoadConfig
            // 
            this.buttonLoadConfig.Location = new System.Drawing.Point(36, 114);
            this.buttonLoadConfig.Name = "buttonLoadConfig";
            this.buttonLoadConfig.Size = new System.Drawing.Size(82, 23);
            this.buttonLoadConfig.TabIndex = 19;
            this.buttonLoadConfig.Text = "Load Config";
            this.buttonLoadConfig.UseVisualStyleBackColor = true;
            this.buttonLoadConfig.Click += new System.EventHandler(this.buttonLoadConfig_Click);
            // 
            // buttonCloseBoard
            // 
            this.buttonCloseBoard.Location = new System.Drawing.Point(183, 73);
            this.buttonCloseBoard.Name = "buttonCloseBoard";
            this.buttonCloseBoard.Size = new System.Drawing.Size(86, 23);
            this.buttonCloseBoard.TabIndex = 18;
            this.buttonCloseBoard.Text = "Close Board";
            this.buttonCloseBoard.UseVisualStyleBackColor = true;
            this.buttonCloseBoard.Click += new System.EventHandler(this.buttonCloseBoard_Click);
            // 
            // buttonOpenBoard
            // 
            this.buttonOpenBoard.Location = new System.Drawing.Point(36, 73);
            this.buttonOpenBoard.Name = "buttonOpenBoard";
            this.buttonOpenBoard.Size = new System.Drawing.Size(82, 23);
            this.buttonOpenBoard.TabIndex = 17;
            this.buttonOpenBoard.Text = "Open Board";
            this.buttonOpenBoard.UseVisualStyleBackColor = true;
            this.buttonOpenBoard.Click += new System.EventHandler(this.buttonOpenBoard_Click);
            // 
            // comboBoxAvailableDevice
            // 
            this.comboBoxAvailableDevice.FormattingEnabled = true;
            this.comboBoxAvailableDevice.Location = new System.Drawing.Point(147, 24);
            this.comboBoxAvailableDevice.Name = "comboBoxAvailableDevice";
            this.comboBoxAvailableDevice.Size = new System.Drawing.Size(121, 20);
            this.comboBoxAvailableDevice.TabIndex = 16;
            this.comboBoxAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.comboBoxAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 12);
            this.label1.TabIndex = 15;
            this.label1.Text = "Available device:";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.dataGridViewStateAndPotion);
            this.groupBox9.Controls.Add(this.BtnResetErr);
            this.groupBox9.Controls.Add(this.buttonSetCnt);
            this.groupBox9.Location = new System.Drawing.Point(323, 12);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(429, 166);
            this.groupBox9.TabIndex = 86;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "State And Position";
            // 
            // dataGridViewStateAndPotion
            // 
            this.dataGridViewStateAndPotion.AllowUserToAddRows = false;
            this.dataGridViewStateAndPotion.AllowUserToDeleteRows = false;
            this.dataGridViewStateAndPotion.AllowUserToResizeColumns = false;
            this.dataGridViewStateAndPotion.AllowUserToResizeRows = false;
            this.dataGridViewStateAndPotion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStateAndPotion.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column4,
            this.Column3,
            this.Column7,
            this.Column8,
            this.Column10,
            this.Column9,
            this.Column12});
            this.dataGridViewStateAndPotion.Location = new System.Drawing.Point(10, 20);
            this.dataGridViewStateAndPotion.Name = "dataGridViewStateAndPotion";
            this.dataGridViewStateAndPotion.ReadOnly = true;
            this.dataGridViewStateAndPotion.RowHeadersVisible = false;
            this.dataGridViewStateAndPotion.RowTemplate.Height = 23;
            this.dataGridViewStateAndPotion.Size = new System.Drawing.Size(413, 112);
            this.dataGridViewStateAndPotion.TabIndex = 105;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.FillWeight = 110F;
            this.Column1.HeaderText = "Axis";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.FillWeight = 120F;
            this.Column2.HeaderText = "CmdPos";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.FillWeight = 120F;
            this.Column4.HeaderText = "ActPos";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.FillWeight = 200F;
            this.Column3.HeaderText = "State";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column7.FillWeight = 96.12748F;
            this.Column7.HeaderText = "ALM";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column8.FillWeight = 96.12748F;
            this.Column8.HeaderText = "ORG";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column10
            // 
            this.Column10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column10.FillWeight = 96.12748F;
            this.Column10.HeaderText = "+HEL";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column9.FillWeight = 96.12748F;
            this.Column9.HeaderText = "-HEL";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "CMP";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 30;
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(308, 134);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(99, 26);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "Reset Error";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            this.BtnResetErr.Click += new System.EventHandler(this.BtnResetErr_Click);
            // 
            // buttonSetCnt
            // 
            this.buttonSetCnt.Location = new System.Drawing.Point(197, 134);
            this.buttonSetCnt.Name = "buttonSetCnt";
            this.buttonSetCnt.Size = new System.Drawing.Size(105, 26);
            this.buttonSetCnt.TabIndex = 31;
            this.buttonSetCnt.Text = "Reset Counter";
            this.buttonSetCnt.UseVisualStyleBackColor = true;
            this.buttonSetCnt.Click += new System.EventHandler(this.buttonSetCnt_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageSingleCompare);
            this.tabControl1.Controls.Add(this.tabPageMulitCompare);
            this.tabControl1.Location = new System.Drawing.Point(12, 184);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(740, 669);
            this.tabControl1.TabIndex = 87;
            this.tabControl1.Click += new System.EventHandler(this.buttonSingleAxisStop_Click);
            // 
            // tabPageSingleCompare
            // 
            this.tabPageSingleCompare.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageSingleCompare.Controls.Add(this.comboBoxScAxisnumb);
            this.tabPageSingleCompare.Controls.Add(this.groupBox14);
            this.tabPageSingleCompare.Controls.Add(this.label16);
            this.tabPageSingleCompare.Controls.Add(this.groupBox13);
            this.tabPageSingleCompare.Controls.Add(this.groupBox12);
            this.tabPageSingleCompare.Controls.Add(this.groupBox11);
            this.tabPageSingleCompare.Controls.Add(this.groupBox4);
            this.tabPageSingleCompare.Location = new System.Drawing.Point(4, 22);
            this.tabPageSingleCompare.Name = "tabPageSingleCompare";
            this.tabPageSingleCompare.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSingleCompare.Size = new System.Drawing.Size(732, 643);
            this.tabPageSingleCompare.TabIndex = 1;
            this.tabPageSingleCompare.Text = "Single-Axis Compare";
            // 
            // comboBoxScAxisnumb
            // 
            this.comboBoxScAxisnumb.FormattingEnabled = true;
            this.comboBoxScAxisnumb.Location = new System.Drawing.Point(163, 14);
            this.comboBoxScAxisnumb.Name = "comboBoxScAxisnumb";
            this.comboBoxScAxisnumb.Size = new System.Drawing.Size(118, 20);
            this.comboBoxScAxisnumb.TabIndex = 75;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.label24);
            this.groupBox14.Controls.Add(this.panel12);
            this.groupBox14.Controls.Add(this.textBoxSACCmptableNextCmpData);
            this.groupBox14.Controls.Add(this.textBoxSingleAxisMotionEndPoint);
            this.groupBox14.Controls.Add(this.label27);
            this.groupBox14.Controls.Add(this.buttonSingleAxisStop);
            this.groupBox14.Controls.Add(this.buttonSingleAxisSpeedSet);
            this.groupBox14.Controls.Add(this.buttonSingleAxisMove);
            this.groupBox14.Location = new System.Drawing.Point(313, 307);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(420, 139);
            this.groupBox14.TabIndex = 89;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Single Axis Motion";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(220, 25);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(97, 12);
            this.label24.TabIndex = 109;
            this.label24.Text = "Next Compare Data";
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.radioButtonSAMRel);
            this.panel12.Controls.Add(this.radioButtonSAMAbs);
            this.panel12.Location = new System.Drawing.Point(14, 49);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(150, 42);
            this.panel12.TabIndex = 120;
            // 
            // radioButtonSAMRel
            // 
            this.radioButtonSAMRel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonSAMRel.AutoSize = true;
            this.radioButtonSAMRel.Location = new System.Drawing.Point(91, 15);
            this.radioButtonSAMRel.Name = "radioButtonSAMRel";
            this.radioButtonSAMRel.Size = new System.Drawing.Size(39, 16);
            this.radioButtonSAMRel.TabIndex = 42;
            this.radioButtonSAMRel.Text = "Rel";
            this.radioButtonSAMRel.UseVisualStyleBackColor = true;
            // 
            // radioButtonSAMAbs
            // 
            this.radioButtonSAMAbs.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonSAMAbs.AutoSize = true;
            this.radioButtonSAMAbs.Checked = true;
            this.radioButtonSAMAbs.Location = new System.Drawing.Point(16, 15);
            this.radioButtonSAMAbs.Name = "radioButtonSAMAbs";
            this.radioButtonSAMAbs.Size = new System.Drawing.Size(41, 16);
            this.radioButtonSAMAbs.TabIndex = 41;
            this.radioButtonSAMAbs.TabStop = true;
            this.radioButtonSAMAbs.Text = "Abs";
            this.radioButtonSAMAbs.UseVisualStyleBackColor = true;
            // 
            // textBoxSACCmptableNextCmpData
            // 
            this.textBoxSACCmptableNextCmpData.Location = new System.Drawing.Point(333, 22);
            this.textBoxSACCmptableNextCmpData.Name = "textBoxSACCmptableNextCmpData";
            this.textBoxSACCmptableNextCmpData.ReadOnly = true;
            this.textBoxSACCmptableNextCmpData.Size = new System.Drawing.Size(74, 22);
            this.textBoxSACCmptableNextCmpData.TabIndex = 108;
            this.textBoxSACCmptableNextCmpData.Text = "10000";
            // 
            // textBoxSingleAxisMotionEndPoint
            // 
            this.textBoxSingleAxisMotionEndPoint.Location = new System.Drawing.Point(77, 22);
            this.textBoxSingleAxisMotionEndPoint.Name = "textBoxSingleAxisMotionEndPoint";
            this.textBoxSingleAxisMotionEndPoint.Size = new System.Drawing.Size(87, 22);
            this.textBoxSingleAxisMotionEndPoint.TabIndex = 119;
            this.textBoxSingleAxisMotionEndPoint.Text = "5000";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(12, 25);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(51, 12);
            this.label27.TabIndex = 116;
            this.label27.Text = "End point";
            // 
            // buttonSingleAxisStop
            // 
            this.buttonSingleAxisStop.Location = new System.Drawing.Point(332, 97);
            this.buttonSingleAxisStop.Name = "buttonSingleAxisStop";
            this.buttonSingleAxisStop.Size = new System.Drawing.Size(75, 23);
            this.buttonSingleAxisStop.TabIndex = 114;
            this.buttonSingleAxisStop.Text = "Stop";
            this.buttonSingleAxisStop.UseVisualStyleBackColor = true;
            this.buttonSingleAxisStop.Click += new System.EventHandler(this.buttonSingleAxisStop_Click);
            // 
            // buttonSingleAxisSpeedSet
            // 
            this.buttonSingleAxisSpeedSet.Location = new System.Drawing.Point(12, 108);
            this.buttonSingleAxisSpeedSet.Name = "buttonSingleAxisSpeedSet";
            this.buttonSingleAxisSpeedSet.Size = new System.Drawing.Size(75, 23);
            this.buttonSingleAxisSpeedSet.TabIndex = 115;
            this.buttonSingleAxisSpeedSet.Text = "SetSpeed";
            this.buttonSingleAxisSpeedSet.UseVisualStyleBackColor = true;
            this.buttonSingleAxisSpeedSet.Click += new System.EventHandler(this.buttonSingleAxisSpeedSet_Click);
            // 
            // buttonSingleAxisMove
            // 
            this.buttonSingleAxisMove.Location = new System.Drawing.Point(332, 68);
            this.buttonSingleAxisMove.Name = "buttonSingleAxisMove";
            this.buttonSingleAxisMove.Size = new System.Drawing.Size(75, 23);
            this.buttonSingleAxisMove.TabIndex = 113;
            this.buttonSingleAxisMove.Text = "Move";
            this.buttonSingleAxisMove.UseVisualStyleBackColor = true;
            this.buttonSingleAxisMove.Click += new System.EventHandler(this.buttonSingleAxisMove_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(37, 17);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 12);
            this.label16.TabIndex = 74;
            this.label16.Text = "Operate Axis";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.listBoxSCCompareTable);
            this.groupBox13.Controls.Add(this.buttonSCCompareTableSetTable);
            this.groupBox13.Controls.Add(this.buttonSCCompareTableAdd);
            this.groupBox13.Controls.Add(this.buttonSCCompareTableClear);
            this.groupBox13.Controls.Add(this.textBoxSCCompareTablePoint);
            this.groupBox13.Controls.Add(this.label13);
            this.groupBox13.Controls.Add(this.buttonSingleCmpDelete);
            this.groupBox13.Controls.Add(this.label39);
            this.groupBox13.Location = new System.Drawing.Point(313, 177);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(420, 121);
            this.groupBox13.TabIndex = 86;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Compare Table";
            // 
            // listBoxSCCompareTable
            // 
            this.listBoxSCCompareTable.FormattingEnabled = true;
            this.listBoxSCCompareTable.ItemHeight = 12;
            this.listBoxSCCompareTable.Location = new System.Drawing.Point(6, 34);
            this.listBoxSCCompareTable.Name = "listBoxSCCompareTable";
            this.listBoxSCCompareTable.Size = new System.Drawing.Size(122, 76);
            this.listBoxSCCompareTable.TabIndex = 107;
            // 
            // buttonSCCompareTableSetTable
            // 
            this.buttonSCCompareTableSetTable.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonSCCompareTableSetTable.Location = new System.Drawing.Point(332, 85);
            this.buttonSCCompareTableSetTable.Name = "buttonSCCompareTableSetTable";
            this.buttonSCCompareTableSetTable.Size = new System.Drawing.Size(75, 23);
            this.buttonSCCompareTableSetTable.TabIndex = 106;
            this.buttonSCCompareTableSetTable.Text = "Set Table";
            this.buttonSCCompareTableSetTable.UseVisualStyleBackColor = true;
            this.buttonSCCompareTableSetTable.Click += new System.EventHandler(this.buttonSCCompareTableSetTable_Click);
            // 
            // buttonSCCompareTableAdd
            // 
            this.buttonSCCompareTableAdd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonSCCompareTableAdd.Location = new System.Drawing.Point(146, 54);
            this.buttonSCCompareTableAdd.Name = "buttonSCCompareTableAdd";
            this.buttonSCCompareTableAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonSCCompareTableAdd.TabIndex = 104;
            this.buttonSCCompareTableAdd.Text = "Add";
            this.buttonSCCompareTableAdd.UseVisualStyleBackColor = true;
            this.buttonSCCompareTableAdd.Click += new System.EventHandler(this.buttonSCCompareTableAdd_Click);
            // 
            // buttonSCCompareTableClear
            // 
            this.buttonSCCompareTableClear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonSCCompareTableClear.Location = new System.Drawing.Point(146, 85);
            this.buttonSCCompareTableClear.Name = "buttonSCCompareTableClear";
            this.buttonSCCompareTableClear.Size = new System.Drawing.Size(75, 23);
            this.buttonSCCompareTableClear.TabIndex = 105;
            this.buttonSCCompareTableClear.Text = "Clear";
            this.buttonSCCompareTableClear.UseVisualStyleBackColor = true;
            this.buttonSCCompareTableClear.Click += new System.EventHandler(this.buttonSCCompareTableClear_Click);
            // 
            // textBoxSCCompareTablePoint
            // 
            this.textBoxSCCompareTablePoint.Location = new System.Drawing.Point(184, 27);
            this.textBoxSCCompareTablePoint.Name = "textBoxSCCompareTablePoint";
            this.textBoxSCCompareTablePoint.Size = new System.Drawing.Size(64, 22);
            this.textBoxSCCompareTablePoint.TabIndex = 103;
            this.textBoxSCCompareTablePoint.Text = "5000";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(143, 30);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 101;
            this.label13.Text = "point";
            // 
            // buttonSingleCmpDelete
            // 
            this.buttonSingleCmpDelete.Location = new System.Drawing.Point(227, 54);
            this.buttonSingleCmpDelete.Name = "buttonSingleCmpDelete";
            this.buttonSingleCmpDelete.Size = new System.Drawing.Size(75, 23);
            this.buttonSingleCmpDelete.TabIndex = 44;
            this.buttonSingleCmpDelete.Text = "Delete";
            this.buttonSingleCmpDelete.UseVisualStyleBackColor = true;
            this.buttonSingleCmpDelete.Click += new System.EventHandler(this.buttonSingleCmpDelete_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(12, 18);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(75, 12);
            this.label39.TabIndex = 100;
            this.label39.Tag = "1";
            this.label39.Text = "Compare Point";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.buttonSCSinglePointCmpSet);
            this.groupBox12.Controls.Add(this.textBoxSCSinglePointCmpPoint);
            this.groupBox12.Controls.Add(this.label36);
            this.groupBox12.Location = new System.Drawing.Point(313, 121);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(420, 49);
            this.groupBox12.TabIndex = 85;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Compare Point";
            // 
            // buttonSCSinglePointCmpSet
            // 
            this.buttonSCSinglePointCmpSet.Location = new System.Drawing.Point(332, 18);
            this.buttonSCSinglePointCmpSet.Name = "buttonSCSinglePointCmpSet";
            this.buttonSCSinglePointCmpSet.Size = new System.Drawing.Size(75, 23);
            this.buttonSCSinglePointCmpSet.TabIndex = 6;
            this.buttonSCSinglePointCmpSet.Text = "Set";
            this.buttonSCSinglePointCmpSet.UseVisualStyleBackColor = true;
            this.buttonSCSinglePointCmpSet.Click += new System.EventHandler(this.buttonSCSinglePointCmpSet_Click);
            // 
            // textBoxSCSinglePointCmpPoint
            // 
            this.textBoxSCSinglePointCmpPoint.Location = new System.Drawing.Point(53, 20);
            this.textBoxSCSinglePointCmpPoint.Name = "textBoxSCSinglePointCmpPoint";
            this.textBoxSCSinglePointCmpPoint.Size = new System.Drawing.Size(72, 22);
            this.textBoxSCSinglePointCmpPoint.TabIndex = 5;
            this.textBoxSCSinglePointCmpPoint.Text = "5000";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(12, 23);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 12);
            this.label36.TabIndex = 2;
            this.label36.Text = "point";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.textBoxScCmpAutoInterval);
            this.groupBox11.Controls.Add(this.textBoxScCmpAutoEnd);
            this.groupBox11.Controls.Add(this.textBoxScCmpAutoStart);
            this.groupBox11.Controls.Add(this.label29);
            this.groupBox11.Controls.Add(this.label30);
            this.groupBox11.Controls.Add(this.label34);
            this.groupBox11.Controls.Add(this.buttonSACCmpAutoSet);
            this.groupBox11.Controls.Add(this.label35);
            this.groupBox11.Location = new System.Drawing.Point(313, 39);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(420, 76);
            this.groupBox11.TabIndex = 84;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Compare Auto";
            // 
            // textBoxScCmpAutoInterval
            // 
            this.textBoxScCmpAutoInterval.Location = new System.Drawing.Point(332, 16);
            this.textBoxScCmpAutoInterval.Name = "textBoxScCmpAutoInterval";
            this.textBoxScCmpAutoInterval.Size = new System.Drawing.Size(71, 22);
            this.textBoxScCmpAutoInterval.TabIndex = 38;
            this.textBoxScCmpAutoInterval.Text = "100";
            // 
            // textBoxScCmpAutoEnd
            // 
            this.textBoxScCmpAutoEnd.Location = new System.Drawing.Point(184, 16);
            this.textBoxScCmpAutoEnd.Name = "textBoxScCmpAutoEnd";
            this.textBoxScCmpAutoEnd.Size = new System.Drawing.Size(74, 22);
            this.textBoxScCmpAutoEnd.TabIndex = 37;
            this.textBoxScCmpAutoEnd.Text = "10000";
            // 
            // textBoxScCmpAutoStart
            // 
            this.textBoxScCmpAutoStart.Location = new System.Drawing.Point(54, 16);
            this.textBoxScCmpAutoStart.Name = "textBoxScCmpAutoStart";
            this.textBoxScCmpAutoStart.Size = new System.Drawing.Size(71, 22);
            this.textBoxScCmpAutoStart.TabIndex = 36;
            this.textBoxScCmpAutoStart.Text = "100";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(149, 19);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(27, 12);
            this.label29.TabIndex = 21;
            this.label29.Text = "End:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(150, 19);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(27, 12);
            this.label30.TabIndex = 21;
            this.label30.Text = "End:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(9, 19);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(29, 12);
            this.label34.TabIndex = 19;
            this.label34.Text = "Start:";
            // 
            // buttonSACCmpAutoSet
            // 
            this.buttonSACCmpAutoSet.Location = new System.Drawing.Point(332, 46);
            this.buttonSACCmpAutoSet.Name = "buttonSACCmpAutoSet";
            this.buttonSACCmpAutoSet.Size = new System.Drawing.Size(75, 23);
            this.buttonSACCmpAutoSet.TabIndex = 35;
            this.buttonSACCmpAutoSet.Text = "Set";
            this.buttonSACCmpAutoSet.UseVisualStyleBackColor = true;
            this.buttonSACCmpAutoSet.Click += new System.EventHandler(this.buttonSACCmpAutoSet_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(274, 20);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(44, 12);
            this.label35.TabIndex = 23;
            this.label35.Text = "Interval:";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox4.Controls.Add(this.comboBoxScCmpMethod);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.comboBoxSCCmpSrc);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.textBoxAxisCmpPulseWidth);
            this.groupBox4.Controls.Add(this.comboBoxAxisCmpPulseLogic);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.comboBoxAxisTrigPulseMode);
            this.groupBox4.Controls.Add(this.buttonSCSet);
            this.groupBox4.Location = new System.Drawing.Point(6, 39);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(298, 259);
            this.groupBox4.TabIndex = 83;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Single-Axis Compare Parameters";
            // 
            // comboBoxScCmpMethod
            // 
            this.comboBoxScCmpMethod.FormattingEnabled = true;
            this.comboBoxScCmpMethod.Location = new System.Drawing.Point(156, 172);
            this.comboBoxScCmpMethod.Name = "comboBoxScCmpMethod";
            this.comboBoxScCmpMethod.Size = new System.Drawing.Size(119, 20);
            this.comboBoxScCmpMethod.TabIndex = 98;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(22, 176);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 12);
            this.label15.TabIndex = 97;
            this.label15.Text = "Compare Method";
            // 
            // comboBoxSCCmpSrc
            // 
            this.comboBoxSCCmpSrc.FormattingEnabled = true;
            this.comboBoxSCCmpSrc.Location = new System.Drawing.Point(157, 138);
            this.comboBoxSCCmpSrc.Name = "comboBoxSCCmpSrc";
            this.comboBoxSCCmpSrc.Size = new System.Drawing.Size(118, 20);
            this.comboBoxSCCmpSrc.TabIndex = 96;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(23, 142);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 12);
            this.label10.TabIndex = 95;
            this.label10.Text = "Compare Source";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(24, 104);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 12);
            this.label11.TabIndex = 93;
            this.label11.Text = "Comare Pulse Width";
            // 
            // textBoxAxisCmpPulseWidth
            // 
            this.textBoxAxisCmpPulseWidth.Location = new System.Drawing.Point(156, 100);
            this.textBoxAxisCmpPulseWidth.Name = "textBoxAxisCmpPulseWidth";
            this.textBoxAxisCmpPulseWidth.Size = new System.Drawing.Size(119, 22);
            this.textBoxAxisCmpPulseWidth.TabIndex = 94;
            this.textBoxAxisCmpPulseWidth.Text = "5";
            // 
            // comboBoxAxisCmpPulseLogic
            // 
            this.comboBoxAxisCmpPulseLogic.FormattingEnabled = true;
            this.comboBoxAxisCmpPulseLogic.Location = new System.Drawing.Point(156, 62);
            this.comboBoxAxisCmpPulseLogic.Name = "comboBoxAxisCmpPulseLogic";
            this.comboBoxAxisCmpPulseLogic.Size = new System.Drawing.Size(121, 20);
            this.comboBoxAxisCmpPulseLogic.TabIndex = 92;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(20, 66);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(105, 12);
            this.label19.TabIndex = 91;
            this.label19.Text = "Compare Pulse Logic";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(20, 33);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(105, 12);
            this.label20.TabIndex = 90;
            this.label20.Text = "Compare Pulse Mode";
            // 
            // comboBoxAxisTrigPulseMode
            // 
            this.comboBoxAxisTrigPulseMode.FormattingEnabled = true;
            this.comboBoxAxisTrigPulseMode.Location = new System.Drawing.Point(156, 30);
            this.comboBoxAxisTrigPulseMode.Name = "comboBoxAxisTrigPulseMode";
            this.comboBoxAxisTrigPulseMode.Size = new System.Drawing.Size(121, 20);
            this.comboBoxAxisTrigPulseMode.TabIndex = 89;
            // 
            // buttonSCSet
            // 
            this.buttonSCSet.Location = new System.Drawing.Point(200, 213);
            this.buttonSCSet.Name = "buttonSCSet";
            this.buttonSCSet.Size = new System.Drawing.Size(75, 23);
            this.buttonSCSet.TabIndex = 78;
            this.buttonSCSet.Text = "Set";
            this.buttonSCSet.UseVisualStyleBackColor = true;
            this.buttonSCSet.Click += new System.EventHandler(this.buttonSCSet_Click);
            // 
            // tabPageMulitCompare
            // 
            this.tabPageMulitCompare.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageMulitCompare.Controls.Add(this.groupBox10);
            this.tabPageMulitCompare.Controls.Add(this.groupBox8);
            this.tabPageMulitCompare.Controls.Add(this.groupBox6);
            this.tabPageMulitCompare.Controls.Add(this.groupBox2);
            this.tabPageMulitCompare.Controls.Add(this.groupBoxSingleComparePara);
            this.tabPageMulitCompare.Controls.Add(this.groupBoxMultiComparePara);
            this.tabPageMulitCompare.Location = new System.Drawing.Point(4, 22);
            this.tabPageMulitCompare.Name = "tabPageMulitCompare";
            this.tabPageMulitCompare.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageMulitCompare.Size = new System.Drawing.Size(732, 643);
            this.tabPageMulitCompare.TabIndex = 0;
            this.tabPageMulitCompare.Text = "Multi-Compare";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.buttonGpClear);
            this.groupBox10.Controls.Add(this.dataGridViewGp);
            this.groupBox10.Controls.Add(this.BtnStop);
            this.groupBox10.Controls.Add(this.BtnCMove);
            this.groupBox10.Controls.Add(this.label3);
            this.groupBox10.Controls.Add(this.buttonAddtogp);
            this.groupBox10.Controls.Add(this.panel17);
            this.groupBox10.Controls.Add(this.buttonSetSpeed);
            this.groupBox10.Controls.Add(this.comboBoxAxInGp);
            this.groupBox10.Location = new System.Drawing.Point(312, 299);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(420, 172);
            this.groupBox10.TabIndex = 89;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Group Motion";
            // 
            // buttonGpClear
            // 
            this.buttonGpClear.Location = new System.Drawing.Point(231, 41);
            this.buttonGpClear.Name = "buttonGpClear";
            this.buttonGpClear.Size = new System.Drawing.Size(64, 22);
            this.buttonGpClear.TabIndex = 112;
            this.buttonGpClear.Text = "Clear";
            this.buttonGpClear.UseVisualStyleBackColor = true;
            this.buttonGpClear.Click += new System.EventHandler(this.buttonGpClear_Click);
            // 
            // dataGridViewGp
            // 
            this.dataGridViewGp.AllowUserToAddRows = false;
            this.dataGridViewGp.AllowUserToDeleteRows = false;
            this.dataGridViewGp.AllowUserToResizeColumns = false;
            this.dataGridViewGp.AllowUserToResizeRows = false;
            this.dataGridViewGp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column6,
            this.Column11});
            this.dataGridViewGp.Location = new System.Drawing.Point(20, 43);
            this.dataGridViewGp.Name = "dataGridViewGp";
            this.dataGridViewGp.RowHeadersVisible = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gray;
            this.dataGridViewGp.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewGp.RowTemplate.Height = 23;
            this.dataGridViewGp.Size = new System.Drawing.Size(205, 114);
            this.dataGridViewGp.TabIndex = 89;
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column5.FillWeight = 40F;
            this.Column5.HeaderText = "Axis";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column6.FillWeight = 60F;
            this.Column6.HeaderText = "End Postion";
            this.Column6.Name = "Column6";
            // 
            // Column11
            // 
            this.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column11.FillWeight = 60F;
            this.Column11.HeaderText = "Next CompareData";
            this.Column11.Name = "Column11";
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(322, 134);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(75, 23);
            this.BtnStop.TabIndex = 28;
            this.BtnStop.Text = "Stop";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.buttonSingleAxisStop_Click);
            // 
            // BtnCMove
            // 
            this.BtnCMove.Location = new System.Drawing.Point(322, 105);
            this.BtnCMove.Name = "BtnCMove";
            this.BtnCMove.Size = new System.Drawing.Size(75, 23);
            this.BtnCMove.TabIndex = 14;
            this.BtnCMove.Text = "Move";
            this.BtnCMove.UseVisualStyleBackColor = true;
            this.BtnCMove.Click += new System.EventHandler(this.BtnCMove_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 12);
            this.label3.TabIndex = 111;
            this.label3.Text = "Axis";
            // 
            // buttonAddtogp
            // 
            this.buttonAddtogp.Location = new System.Drawing.Point(231, 13);
            this.buttonAddtogp.Name = "buttonAddtogp";
            this.buttonAddtogp.Size = new System.Drawing.Size(64, 22);
            this.buttonAddtogp.TabIndex = 109;
            this.buttonAddtogp.Text = "AddtoGP";
            this.buttonAddtogp.UseVisualStyleBackColor = true;
            this.buttonAddtogp.Click += new System.EventHandler(this.buttonAddtogp_Click);
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.radioButtonRel);
            this.panel17.Controls.Add(this.radioButtonAbs);
            this.panel17.Location = new System.Drawing.Point(301, 41);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(96, 27);
            this.panel17.TabIndex = 86;
            // 
            // radioButtonRel
            // 
            this.radioButtonRel.AutoSize = true;
            this.radioButtonRel.Location = new System.Drawing.Point(52, 7);
            this.radioButtonRel.Name = "radioButtonRel";
            this.radioButtonRel.Size = new System.Drawing.Size(39, 16);
            this.radioButtonRel.TabIndex = 42;
            this.radioButtonRel.Text = "Rel";
            this.radioButtonRel.UseVisualStyleBackColor = true;
            // 
            // radioButtonAbs
            // 
            this.radioButtonAbs.AutoSize = true;
            this.radioButtonAbs.Checked = true;
            this.radioButtonAbs.Location = new System.Drawing.Point(9, 7);
            this.radioButtonAbs.Name = "radioButtonAbs";
            this.radioButtonAbs.Size = new System.Drawing.Size(41, 16);
            this.radioButtonAbs.TabIndex = 41;
            this.radioButtonAbs.TabStop = true;
            this.radioButtonAbs.Text = "Abs";
            this.radioButtonAbs.UseVisualStyleBackColor = true;
            // 
            // buttonSetSpeed
            // 
            this.buttonSetSpeed.Location = new System.Drawing.Point(322, 74);
            this.buttonSetSpeed.Name = "buttonSetSpeed";
            this.buttonSetSpeed.Size = new System.Drawing.Size(75, 23);
            this.buttonSetSpeed.TabIndex = 84;
            this.buttonSetSpeed.Text = "SetSpeed";
            this.buttonSetSpeed.UseVisualStyleBackColor = true;
            this.buttonSetSpeed.Click += new System.EventHandler(this.buttonSetSpeed_Click);
            // 
            // comboBoxAxInGp
            // 
            this.comboBoxAxInGp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxAxInGp.FormattingEnabled = true;
            this.comboBoxAxInGp.Location = new System.Drawing.Point(56, 17);
            this.comboBoxAxInGp.Name = "comboBoxAxInGp";
            this.comboBoxAxInGp.Size = new System.Drawing.Size(83, 20);
            this.comboBoxAxInGp.TabIndex = 110;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.textBoxCompareTablePoint);
            this.groupBox8.Controls.Add(this.label9);
            this.groupBox8.Controls.Add(this.comboBoxMCCompareTableAxis);
            this.groupBox8.Controls.Add(this.label26);
            this.groupBox8.Controls.Add(this.btn_Delete);
            this.groupBox8.Controls.Add(this.listBoxCmpData);
            this.groupBox8.Controls.Add(this.btn_SetTable);
            this.groupBox8.Controls.Add(this.btn_Add);
            this.groupBox8.Controls.Add(this.label33);
            this.groupBox8.Controls.Add(this.btn_Clear);
            this.groupBox8.Location = new System.Drawing.Point(312, 142);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(420, 150);
            this.groupBox8.TabIndex = 85;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Compare Table";
            // 
            // textBoxCompareTablePoint
            // 
            this.textBoxCompareTablePoint.Location = new System.Drawing.Point(203, 20);
            this.textBoxCompareTablePoint.Name = "textBoxCompareTablePoint";
            this.textBoxCompareTablePoint.Size = new System.Drawing.Size(74, 22);
            this.textBoxCompareTablePoint.TabIndex = 105;
            this.textBoxCompareTablePoint.Text = "5000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(159, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 104;
            this.label9.Text = "point";
            // 
            // comboBoxMCCompareTableAxis
            // 
            this.comboBoxMCCompareTableAxis.FormattingEnabled = true;
            this.comboBoxMCCompareTableAxis.Location = new System.Drawing.Point(61, 20);
            this.comboBoxMCCompareTableAxis.Name = "comboBoxMCCompareTableAxis";
            this.comboBoxMCCompareTableAxis.Size = new System.Drawing.Size(71, 20);
            this.comboBoxMCCompareTableAxis.TabIndex = 103;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(21, 25);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(26, 12);
            this.label26.TabIndex = 102;
            this.label26.Text = "Axis";
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(146, 88);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(64, 23);
            this.btn_Delete.TabIndex = 44;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // listBoxCmpData
            // 
            this.listBoxCmpData.FormattingEnabled = true;
            this.listBoxCmpData.ItemHeight = 12;
            this.listBoxCmpData.Location = new System.Drawing.Point(14, 59);
            this.listBoxCmpData.Name = "listBoxCmpData";
            this.listBoxCmpData.Size = new System.Drawing.Size(120, 88);
            this.listBoxCmpData.TabIndex = 38;
            // 
            // btn_SetTable
            // 
            this.btn_SetTable.Location = new System.Drawing.Point(322, 115);
            this.btn_SetTable.Name = "btn_SetTable";
            this.btn_SetTable.Size = new System.Drawing.Size(75, 23);
            this.btn_SetTable.TabIndex = 46;
            this.btn_SetTable.Text = "Set Table";
            this.btn_SetTable.UseVisualStyleBackColor = true;
            this.btn_SetTable.Click += new System.EventHandler(this.btn_SetTable_Click);
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(146, 59);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(64, 23);
            this.btn_Add.TabIndex = 43;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(12, 44);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(75, 12);
            this.label33.TabIndex = 100;
            this.label33.Tag = "1";
            this.label33.Text = "Compare Point";
            // 
            // btn_Clear
            // 
            this.btn_Clear.Location = new System.Drawing.Point(146, 117);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(64, 23);
            this.btn_Clear.TabIndex = 45;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.UseVisualStyleBackColor = true;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.comboBoxSPCAxis);
            this.groupBox6.Controls.Add(this.textBoxSPCPoint);
            this.groupBox6.Controls.Add(this.buttonSPCSet);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Location = new System.Drawing.Point(312, 87);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(420, 49);
            this.groupBox6.TabIndex = 84;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Compare Point";
            // 
            // comboBoxSPCAxis
            // 
            this.comboBoxSPCAxis.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxSPCAxis.FormattingEnabled = true;
            this.comboBoxSPCAxis.Location = new System.Drawing.Point(61, 18);
            this.comboBoxSPCAxis.Name = "comboBoxSPCAxis";
            this.comboBoxSPCAxis.Size = new System.Drawing.Size(71, 20);
            this.comboBoxSPCAxis.TabIndex = 17;
            // 
            // textBoxSPCPoint
            // 
            this.textBoxSPCPoint.Location = new System.Drawing.Point(203, 18);
            this.textBoxSPCPoint.Name = "textBoxSPCPoint";
            this.textBoxSPCPoint.Size = new System.Drawing.Size(74, 22);
            this.textBoxSPCPoint.TabIndex = 3;
            this.textBoxSPCPoint.Text = "5000";
            // 
            // buttonSPCSet
            // 
            this.buttonSPCSet.Location = new System.Drawing.Point(322, 18);
            this.buttonSPCSet.Name = "buttonSPCSet";
            this.buttonSPCSet.Size = new System.Drawing.Size(75, 23);
            this.buttonSPCSet.TabIndex = 4;
            this.buttonSPCSet.Text = "Set";
            this.buttonSPCSet.UseVisualStyleBackColor = true;
            this.buttonSPCSet.Click += new System.EventHandler(this.buttonSPCSet_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(160, 22);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(29, 12);
            this.label21.TabIndex = 2;
            this.label21.Text = "point";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(21, 22);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(26, 12);
            this.label18.TabIndex = 0;
            this.label18.Text = "Axis";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.textBoxCmpautoEnd);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.comboBoxCmpAutoAxis);
            this.groupBox2.Controls.Add(this.textBoxCmpAutoStart);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.buttonCmpAutoSet);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.textBoxCmpautoInterval);
            this.groupBox2.Location = new System.Drawing.Point(310, 7);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(420, 76);
            this.groupBox2.TabIndex = 83;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Compare Auto";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(162, 52);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(27, 12);
            this.label28.TabIndex = 21;
            this.label28.Text = "End:";
            // 
            // textBoxCmpautoEnd
            // 
            this.textBoxCmpautoEnd.Location = new System.Drawing.Point(205, 48);
            this.textBoxCmpautoEnd.Name = "textBoxCmpautoEnd";
            this.textBoxCmpautoEnd.Size = new System.Drawing.Size(71, 22);
            this.textBoxCmpautoEnd.TabIndex = 22;
            this.textBoxCmpautoEnd.Text = "10000";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 19;
            this.label8.Text = "Start:";
            // 
            // comboBoxCmpAutoAxis
            // 
            this.comboBoxCmpAutoAxis.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxCmpAutoAxis.FormattingEnabled = true;
            this.comboBoxCmpAutoAxis.Location = new System.Drawing.Point(63, 20);
            this.comboBoxCmpAutoAxis.Name = "comboBoxCmpAutoAxis";
            this.comboBoxCmpAutoAxis.Size = new System.Drawing.Size(71, 20);
            this.comboBoxCmpAutoAxis.TabIndex = 37;
            // 
            // textBoxCmpAutoStart
            // 
            this.textBoxCmpAutoStart.Location = new System.Drawing.Point(63, 48);
            this.textBoxCmpAutoStart.Name = "textBoxCmpAutoStart";
            this.textBoxCmpAutoStart.Size = new System.Drawing.Size(71, 22);
            this.textBoxCmpAutoStart.TabIndex = 20;
            this.textBoxCmpAutoStart.Text = "100";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(23, 20);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(26, 12);
            this.label22.TabIndex = 36;
            this.label22.Text = "Axis";
            // 
            // buttonCmpAutoSet
            // 
            this.buttonCmpAutoSet.Location = new System.Drawing.Point(324, 41);
            this.buttonCmpAutoSet.Name = "buttonCmpAutoSet";
            this.buttonCmpAutoSet.Size = new System.Drawing.Size(75, 23);
            this.buttonCmpAutoSet.TabIndex = 35;
            this.buttonCmpAutoSet.Text = "Set";
            this.buttonCmpAutoSet.UseVisualStyleBackColor = true;
            this.buttonCmpAutoSet.Click += new System.EventHandler(this.buttonCmpAutoSet_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(143, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 12);
            this.label4.TabIndex = 23;
            this.label4.Text = "Interval:";
            // 
            // textBoxCmpautoInterval
            // 
            this.textBoxCmpautoInterval.Location = new System.Drawing.Point(205, 20);
            this.textBoxCmpautoInterval.Name = "textBoxCmpautoInterval";
            this.textBoxCmpautoInterval.Size = new System.Drawing.Size(71, 22);
            this.textBoxCmpautoInterval.TabIndex = 24;
            this.textBoxCmpautoInterval.Text = "100";
            // 
            // groupBoxSingleComparePara
            // 
            this.groupBoxSingleComparePara.Controls.Add(this.label14);
            this.groupBoxSingleComparePara.Controls.Add(this.textBoxAxisMultiCmpDeviation);
            this.groupBoxSingleComparePara.Controls.Add(this.ButtonAxisComPareSet);
            this.groupBoxSingleComparePara.Controls.Add(this.comboBoxSrc);
            this.groupBoxSingleComparePara.Controls.Add(this.label23);
            this.groupBoxSingleComparePara.Controls.Add(this.comboBoxAxisNub);
            this.groupBoxSingleComparePara.Controls.Add(this.label17);
            this.groupBoxSingleComparePara.Location = new System.Drawing.Point(6, 298);
            this.groupBoxSingleComparePara.Name = "groupBoxSingleComparePara";
            this.groupBoxSingleComparePara.Size = new System.Drawing.Size(295, 173);
            this.groupBoxSingleComparePara.TabIndex = 82;
            this.groupBoxSingleComparePara.TabStop = false;
            this.groupBoxSingleComparePara.Text = "Single-Axis Compare Parameters";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(43, 111);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 12);
            this.label14.TabIndex = 93;
            this.label14.Text = "Deviation";
            // 
            // textBoxAxisMultiCmpDeviation
            // 
            this.textBoxAxisMultiCmpDeviation.Location = new System.Drawing.Point(159, 108);
            this.textBoxAxisMultiCmpDeviation.Name = "textBoxAxisMultiCmpDeviation";
            this.textBoxAxisMultiCmpDeviation.Size = new System.Drawing.Size(121, 22);
            this.textBoxAxisMultiCmpDeviation.TabIndex = 94;
            this.textBoxAxisMultiCmpDeviation.Text = "10";
            // 
            // ButtonAxisComPareSet
            // 
            this.ButtonAxisComPareSet.Location = new System.Drawing.Point(200, 135);
            this.ButtonAxisComPareSet.Name = "ButtonAxisComPareSet";
            this.ButtonAxisComPareSet.Size = new System.Drawing.Size(75, 23);
            this.ButtonAxisComPareSet.TabIndex = 92;
            this.ButtonAxisComPareSet.Text = "Set";
            this.ButtonAxisComPareSet.UseVisualStyleBackColor = true;
            this.ButtonAxisComPareSet.Click += new System.EventHandler(this.ButtonAxisComPareSet_Click);
            // 
            // comboBoxSrc
            // 
            this.comboBoxSrc.FormattingEnabled = true;
            this.comboBoxSrc.Location = new System.Drawing.Point(159, 75);
            this.comboBoxSrc.Name = "comboBoxSrc";
            this.comboBoxSrc.Size = new System.Drawing.Size(121, 20);
            this.comboBoxSrc.TabIndex = 91;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(52, 80);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(20, 12);
            this.label23.TabIndex = 90;
            this.label23.Text = "Src";
            // 
            // comboBoxAxisNub
            // 
            this.comboBoxAxisNub.FormattingEnabled = true;
            this.comboBoxAxisNub.Location = new System.Drawing.Point(159, 42);
            this.comboBoxAxisNub.Name = "comboBoxAxisNub";
            this.comboBoxAxisNub.Size = new System.Drawing.Size(123, 20);
            this.comboBoxAxisNub.TabIndex = 87;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(52, 42);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(26, 12);
            this.label17.TabIndex = 84;
            this.label17.Text = "Axis";
            // 
            // groupBoxMultiComparePara
            // 
            this.groupBoxMultiComparePara.Controls.Add(this.label7);
            this.groupBoxMultiComparePara.Controls.Add(this.label5);
            this.groupBoxMultiComparePara.Controls.Add(this.checkedListBoxMultiCmpOutChannel);
            this.groupBoxMultiComparePara.Controls.Add(this.checkedListBoxMulAxCompareEn);
            this.groupBoxMultiComparePara.Controls.Add(this.buttonCMPDO);
            this.groupBoxMultiComparePara.Controls.Add(this.ButtonMultiCompareSet);
            this.groupBoxMultiComparePara.Controls.Add(this.label12);
            this.groupBoxMultiComparePara.Controls.Add(this.textBoxMulAxCmpPulseWidth);
            this.groupBoxMultiComparePara.Controls.Add(this.comboBoxMultiTrigAutoEmptyEn);
            this.groupBoxMultiComparePara.Controls.Add(this.label6);
            this.groupBoxMultiComparePara.Controls.Add(this.comboBoxMultiCmpPulseLogic);
            this.groupBoxMultiComparePara.Controls.Add(this.label25);
            this.groupBoxMultiComparePara.Controls.Add(this.label2);
            this.groupBoxMultiComparePara.Controls.Add(this.comboBoxMultiTrigPulseMode);
            this.groupBoxMultiComparePara.Location = new System.Drawing.Point(6, 7);
            this.groupBoxMultiComparePara.Name = "groupBoxMultiComparePara";
            this.groupBoxMultiComparePara.Size = new System.Drawing.Size(295, 285);
            this.groupBoxMultiComparePara.TabIndex = 2;
            this.groupBoxMultiComparePara.TabStop = false;
            this.groupBoxMultiComparePara.Text = "Multi-Compare Parameters";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(157, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 12);
            this.label7.TabIndex = 104;
            this.label7.Text = "Multi-Cmp Out Channel";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 12);
            this.label5.TabIndex = 103;
            this.label5.Text = "Operate Axes";
            // 
            // checkedListBoxMultiCmpOutChannel
            // 
            this.checkedListBoxMultiCmpOutChannel.FormattingEnabled = true;
            this.checkedListBoxMultiCmpOutChannel.Location = new System.Drawing.Point(156, 30);
            this.checkedListBoxMultiCmpOutChannel.Name = "checkedListBoxMultiCmpOutChannel";
            this.checkedListBoxMultiCmpOutChannel.Size = new System.Drawing.Size(124, 72);
            this.checkedListBoxMultiCmpOutChannel.TabIndex = 102;
            // 
            // checkedListBoxMulAxCompareEn
            // 
            this.checkedListBoxMulAxCompareEn.FormattingEnabled = true;
            this.checkedListBoxMulAxCompareEn.Location = new System.Drawing.Point(13, 30);
            this.checkedListBoxMulAxCompareEn.Name = "checkedListBoxMulAxCompareEn";
            this.checkedListBoxMulAxCompareEn.Size = new System.Drawing.Size(120, 72);
            this.checkedListBoxMulAxCompareEn.TabIndex = 101;
            // 
            // buttonCMPDO
            // 
            this.buttonCMPDO.Location = new System.Drawing.Point(35, 251);
            this.buttonCMPDO.Name = "buttonCMPDO";
            this.buttonCMPDO.Size = new System.Drawing.Size(75, 22);
            this.buttonCMPDO.TabIndex = 100;
            this.buttonCMPDO.Text = "CmpDO";
            this.buttonCMPDO.UseVisualStyleBackColor = true;
            this.buttonCMPDO.Click += new System.EventHandler(this.buttonCMPDO_Click);
            // 
            // ButtonMultiCompareSet
            // 
            this.ButtonMultiCompareSet.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ButtonMultiCompareSet.AutoSize = true;
            this.ButtonMultiCompareSet.Location = new System.Drawing.Point(203, 252);
            this.ButtonMultiCompareSet.Name = "ButtonMultiCompareSet";
            this.ButtonMultiCompareSet.Size = new System.Drawing.Size(75, 22);
            this.ButtonMultiCompareSet.TabIndex = 99;
            this.ButtonMultiCompareSet.Text = "Set";
            this.ButtonMultiCompareSet.UseVisualStyleBackColor = true;
            this.ButtonMultiCompareSet.Click += new System.EventHandler(this.ButtonMultiCompareSet_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 219);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 12);
            this.label12.TabIndex = 97;
            this.label12.Text = "Multi-Cmp Pulse Width";
            // 
            // textBoxMulAxCmpPulseWidth
            // 
            this.textBoxMulAxCmpPulseWidth.Location = new System.Drawing.Point(159, 215);
            this.textBoxMulAxCmpPulseWidth.Name = "textBoxMulAxCmpPulseWidth";
            this.textBoxMulAxCmpPulseWidth.Size = new System.Drawing.Size(123, 22);
            this.textBoxMulAxCmpPulseWidth.TabIndex = 98;
            this.textBoxMulAxCmpPulseWidth.Text = "1000";
            // 
            // comboBoxMultiTrigAutoEmptyEn
            // 
            this.comboBoxMultiTrigAutoEmptyEn.FormattingEnabled = true;
            this.comboBoxMultiTrigAutoEmptyEn.Location = new System.Drawing.Point(159, 186);
            this.comboBoxMultiTrigAutoEmptyEn.Name = "comboBoxMultiTrigAutoEmptyEn";
            this.comboBoxMultiTrigAutoEmptyEn.Size = new System.Drawing.Size(121, 20);
            this.comboBoxMultiTrigAutoEmptyEn.TabIndex = 96;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 189);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 12);
            this.label6.TabIndex = 95;
            this.label6.Text = "Multi-Cmp Auto Empty En";
            // 
            // comboBoxMultiCmpPulseLogic
            // 
            this.comboBoxMultiCmpPulseLogic.FormattingEnabled = true;
            this.comboBoxMultiCmpPulseLogic.Location = new System.Drawing.Point(159, 157);
            this.comboBoxMultiCmpPulseLogic.Name = "comboBoxMultiCmpPulseLogic";
            this.comboBoxMultiCmpPulseLogic.Size = new System.Drawing.Size(121, 20);
            this.comboBoxMultiCmpPulseLogic.TabIndex = 94;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(11, 160);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(114, 12);
            this.label25.TabIndex = 93;
            this.label25.Text = "Multi-Cmp Pulse Logic";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 12);
            this.label2.TabIndex = 92;
            this.label2.Text = "Multi-Cmp Pulse Mode";
            // 
            // comboBoxMultiTrigPulseMode
            // 
            this.comboBoxMultiTrigPulseMode.FormattingEnabled = true;
            this.comboBoxMultiTrigPulseMode.Location = new System.Drawing.Point(159, 128);
            this.comboBoxMultiTrigPulseMode.Name = "comboBoxMultiTrigPulseMode";
            this.comboBoxMultiTrigPulseMode.Size = new System.Drawing.Size(121, 20);
            this.comboBoxMultiTrigPulseMode.TabIndex = 91;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 681);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBoxDeviceOperate);
            this.Name = "Form1";
            this.Text = "Compare";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxDeviceOperate.ResumeLayout(false);
            this.groupBoxDeviceOperate.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStateAndPotion)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPageSingleCompare.ResumeLayout(false);
            this.tabPageSingleCompare.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPageMulitCompare.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGp)).EndInit();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBoxSingleComparePara.ResumeLayout(false);
            this.groupBoxSingleComparePara.PerformLayout();
            this.groupBoxMultiComparePara.ResumeLayout(false);
            this.groupBoxMultiComparePara.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxDeviceOperate;
        private System.Windows.Forms.Button buttonServoOn;
        private System.Windows.Forms.Button buttonLoadConfig;
        private System.Windows.Forms.Button buttonCloseBoard;
        private System.Windows.Forms.Button buttonOpenBoard;
        private System.Windows.Forms.ComboBox comboBoxAvailableDevice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.DataGridView dataGridViewStateAndPotion;
        private System.Windows.Forms.Button BtnResetErr;
        private System.Windows.Forms.Button buttonSetCnt;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageSingleCompare;
        private System.Windows.Forms.ComboBox comboBoxScAxisnumb;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.RadioButton radioButtonSAMRel;
        private System.Windows.Forms.RadioButton radioButtonSAMAbs;
        private System.Windows.Forms.TextBox textBoxSingleAxisMotionEndPoint;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button buttonSingleAxisStop;
        private System.Windows.Forms.Button buttonSingleAxisSpeedSet;
        private System.Windows.Forms.Button buttonSingleAxisMove;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ListBox listBoxSCCompareTable;
        private System.Windows.Forms.Button buttonSCCompareTableSetTable;
        private System.Windows.Forms.Button buttonSCCompareTableAdd;
        private System.Windows.Forms.Button buttonSCCompareTableClear;
        private System.Windows.Forms.TextBox textBoxSCCompareTablePoint;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button buttonSingleCmpDelete;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button buttonSCSinglePointCmpSet;
        private System.Windows.Forms.TextBox textBoxSCSinglePointCmpPoint;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox textBoxScCmpAutoInterval;
        private System.Windows.Forms.TextBox textBoxScCmpAutoEnd;
        private System.Windows.Forms.TextBox textBoxScCmpAutoStart;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button buttonSACCmpAutoSet;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox comboBoxScCmpMethod;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBoxSCCmpSrc;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxAxisCmpPulseWidth;
        private System.Windows.Forms.ComboBox comboBoxAxisCmpPulseLogic;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBoxAxisTrigPulseMode;
        private System.Windows.Forms.Button buttonSCSet;
        private System.Windows.Forms.TabPage tabPageMulitCompare;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button buttonGpClear;
        private System.Windows.Forms.DataGridView dataGridViewGp;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Button BtnCMove;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonAddtogp;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.RadioButton radioButtonRel;
        private System.Windows.Forms.RadioButton radioButtonAbs;
        private System.Windows.Forms.Button buttonSetSpeed;
        private System.Windows.Forms.ComboBox comboBoxAxInGp;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBoxCompareTablePoint;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBoxMCCompareTableAxis;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.ListBox listBoxCmpData;
        private System.Windows.Forms.Button btn_SetTable;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox comboBoxSPCAxis;
        private System.Windows.Forms.TextBox textBoxSPCPoint;
        private System.Windows.Forms.Button buttonSPCSet;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBoxCmpautoEnd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBoxCmpAutoAxis;
        private System.Windows.Forms.TextBox textBoxCmpAutoStart;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button buttonCmpAutoSet;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxCmpautoInterval;
        private System.Windows.Forms.GroupBox groupBoxSingleComparePara;
        private System.Windows.Forms.Button ButtonAxisComPareSet;
        private System.Windows.Forms.ComboBox comboBoxSrc;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboBoxAxisNub;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBoxMultiComparePara;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckedListBox checkedListBoxMultiCmpOutChannel;
        private System.Windows.Forms.CheckedListBox checkedListBoxMulAxCompareEn;
        private System.Windows.Forms.Button buttonCMPDO;
        private System.Windows.Forms.Button ButtonMultiCompareSet;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxMulAxCmpPulseWidth;
        private System.Windows.Forms.ComboBox comboBoxMultiTrigAutoEmptyEn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxMultiCmpPulseLogic;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxMultiTrigPulseMode;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxAxisMultiCmpDeviation;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBoxSACCmptableNextCmpData;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
    }
}

