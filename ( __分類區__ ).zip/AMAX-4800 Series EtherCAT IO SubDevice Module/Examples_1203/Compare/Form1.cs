using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;

namespace Compare
{
    public partial class Form1 : Form
    {
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[64];
        IntPtr m_GpHand = IntPtr.Zero;
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        uint[] AxEnableEvtArray = new uint[64];
        uint[] GpEnableEvt = new uint[64];
        uint AxCountInGp = 0;
        bool CmpDoFlag = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            comboBoxAvailableDevice.Items.Clear();
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot��Perhaps the opposite 
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, (uint)Result);
                return;
            }

            //If you want to get the device number of fixed equipment��you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            for (int i = 0; i < deviceCount; i++)
            {
                comboBoxAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                comboBoxAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
        }

        private void buttonOpenBoard_Click(object sender, EventArgs e)
        {
            uint Result;
            int i = 0;
			uint retry = 0, SlaveOnRing0 = 0, SlaveOnRing1 = 0;
            bool rescan = false;
            uint[] slaveDevs = new uint[16];
            uint AxesPerDev = 0;
            string strTemp;
            if (m_bInit == true)
            {
                return;
            }
            //Get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            do
            {
                Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Device Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);                    
                    retry++;
                    rescan = true;
                    if (retry > 10)
                        return;
                    System.Threading.Thread.Sleep(1000);
                }
                else
                {
					//User must check the slave count on each ring match the actual connection.
					//We recommend using following code that was marked to check connection status.
					//The example expect there is one slave on Motion ring and user does not connect any slave on IO ring.
					rescan = false;
					/*Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R0, ref SlaveOnRing0);
					Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R1, ref SlaveOnRing1);
					if (SlaveOnRing0 != 1 || SlaveOnRing1 != 0)
					{
						strTemp = "Retrieved the slave states do not match the actual connection.";
						ShowMessages(strTemp, Result);
						Motion.mAcm_DevReOpen(m_DeviceHandle);
						Motion.mAcm_DevClose(ref m_DeviceHandle);
						System.Threading.Thread.Sleep(1000);
						retry = 0;
						rescan = true;
					}*/
                }
            } while (rescan == true);

            //Get axis number of this device.
            //if you device is fixed(for example: PCI-1245),You can not get FT_DevAxesCount property value
            //This step is not necessary
            //You can also use the old API: Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev, ref BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get Axis Number Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }

            m_ulAxisCount = AxesPerDev;
            for (i = 0; i < m_ulAxisCount; i++)
            {
                //Open every Axis and get the each Axis Handle
                //And Initial property for each Axis 		
                //Open Axis 
                //Add Axis number to combobox and dataGridViewState
                Result = Motion.mAcm_AxOpen(m_DeviceHandle, (UInt16)i, ref m_Axishand[i]);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Axis Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }


                dataGridViewStateAndPotion.Rows.Add();
                dataGridViewStateAndPotion.Rows[i].Cells[0].Value = i.ToString() + "-" + "Axis";

                dataGridViewGp.Rows.Add();
                dataGridViewGp.Rows[i].Cells[0].Value = i.ToString() + "-" + "Axis";
                dataGridViewGp.Rows[i].Cells[1].Value = 0;

                comboBoxAxisNub.Items.Add(i.ToString() + "-" + "Axis");
                comboBoxAxisNub.SelectedIndex = 0;

                comboBoxAxInGp.Items.Add(i.ToString() + "-" + "Axis");
                comboBoxAxInGp.SelectedIndex = 0;

                comboBoxScAxisnumb.Items.Add(i.ToString() + "-" + "Axis");
                comboBoxScAxisnumb.SelectedIndex = 0;

                comboBoxCmpAutoAxis.Items.Add(i.ToString() + "-" + "Axis");
                comboBoxCmpAutoAxis.SelectedIndex = 0;

                comboBoxSPCAxis.Items.Add(i.ToString() + "-" + "Axis");
                comboBoxSPCAxis.SelectedIndex = 0;

                comboBoxMCCompareTableAxis.Items.Add(i.ToString() + "-" + "Axis");
                comboBoxMCCompareTableAxis.SelectedIndex = 0;

                checkedListBoxMulAxCompareEn.Items.Add(i.ToString() + "-" + "Axis");
                checkedListBoxMultiCmpOutChannel.Items.Add(i.ToString() + "-" + "Axis");

            }
            ComboboxInit();
            comboBoxAxisNub.SelectedIndex = 0;
            m_bInit = true;
            timer1.Enabled = true;
        }

        //Get the error message according to error code returned from API
        private void ShowMessages(string DetailMessage, uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            Boolean re = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
            string ErrorMessage = "";
            if (re)
                ErrorMessage = ErrorMsg.ToString();
            MessageBox.Show(DetailMessage + "\r\nError Message:" + ErrorMessage, "Compare", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        //Add content to combobox 
        private void ComboboxInit()
        {

            //Compara parameter : AxCmpSrc
            comboBoxSrc.Items.Clear();
            comboBoxSCCmpSrc.Items.Clear();
            for (int i = 0; i < 2; i++)
            {
                comboBoxSrc.Items.Add((CmpSource)i);
                comboBoxSCCmpSrc.Items.Add((CmpSource)i);
            }
            comboBoxSrc.SelectedIndex = 0;
            comboBoxSCCmpSrc.SelectedIndex = 0;

            //Compara parameter : AxCmpMethod
            comboBoxScCmpMethod.Items.Clear();
            for (int i = 0; i < 4; i++)
            {
                comboBoxScCmpMethod.Items.Add(((CmpMethod)i));
            }
            comboBoxScCmpMethod.SelectedIndex = 0;
           
            //Compara parameter : MultiTrigPulseMode
            comboBoxMultiTrigPulseMode.Items.Clear();
            comboBoxAxisTrigPulseMode.Items.Clear();
            for (int i = 0; i < 2; i++)
            {
                comboBoxMultiTrigPulseMode.Items.Add((CmpPulseMode)i);
                comboBoxAxisTrigPulseMode.Items.Add((CmpPulseMode)i);
            }
            comboBoxMultiTrigPulseMode.SelectedIndex = 0;
            comboBoxAxisTrigPulseMode.SelectedIndex = 0;


            //Compara parameter : MultiCmpPulseLogic
            comboBoxAxisCmpPulseLogic.Items.Clear();
            comboBoxMultiCmpPulseLogic.Items.Clear();
            for (int i = 0; i < 2; i++)
            {
                comboBoxMultiCmpPulseLogic.Items.Add((CmpPulseLogic)i);
                comboBoxAxisCmpPulseLogic.Items.Add((CmpPulseLogic)i);
            }
            comboBoxAxisCmpPulseLogic.SelectedIndex = 1;
            comboBoxMultiCmpPulseLogic.SelectedIndex = 1;

            //Compara parameter : MultiTrigAutoEmptyEn
            comboBoxMultiTrigAutoEmptyEn.Items.Clear();
            comboBoxMultiTrigAutoEmptyEn.Items.Add("Not");
            comboBoxMultiTrigAutoEmptyEn.Items.Add("Clear");
            comboBoxMultiTrigAutoEmptyEn.SelectedIndex = 0;
        }

        private void buttonCloseBoard_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();
        }

        private void CloseBoardOrForm()
        {
            UInt16[] usAxisState = new UInt16[64];
            uint AxisNum;
            //Stop Every Axes
            if (m_bInit == true)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Get the axis's current state
                    Motion.mAcm_AxGetState(m_Axishand[AxisNum], ref usAxisState[AxisNum]);
                    if (usAxisState[AxisNum] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        // Reset the axis' state. If the axis is in ErrorStop state, the state will be changed to Ready after calling this function
                        Motion.mAcm_AxResetError(m_Axishand[AxisNum]);
                    }
                    //To command axis to decelerate to stop.
                    Motion.mAcm_AxStopDec(m_Axishand[AxisNum]);
                }
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Close Axes
                    Motion.mAcm_AxClose(ref m_Axishand[AxisNum]);
                }
                //Remove the Group 
                RemoveGp();
                AntiInit();

            }
        }

        private void AntiInit()
        {
            m_ulAxisCount = 0;
            //Close Device
            Motion.mAcm_DevClose(ref m_DeviceHandle);
            timer1.Enabled = false;
            m_bInit = false;
            //Clear every combobox,checklistbox and datagridview.
            foreach (TabPage page in tabControl1.TabPages)
            {
                foreach (Control clt in page.Controls)
                {
                    if (clt is ComboBox)
                    {
                        ((ComboBox)clt).Items.Clear();
                        ((ComboBox)clt).Text = "";
                    }
                    else if (clt is GroupBox)
                    {
                        foreach (Control clt1 in clt.Controls)
                        {
                            if (clt1 is ComboBox)
                            {
                                ((ComboBox)clt1).Items.Clear();
                                ((ComboBox)clt1).Text = "";
                            }
                            else if (clt1 is CheckedListBox)
                            {
                                ((CheckedListBox)clt1).Items.Clear();
                            }
                            else if (clt1 is DataGridView)
                            {
                                ((DataGridView)clt1).Rows.Clear();
                            }
                        }
                    }
                }
                
            }
            dataGridViewStateAndPotion.Rows.Clear();

        }
        // Remove Group
        public void RemoveGp()
        {
            uint Result;
            Result = Motion.mAcm_GpClose(ref m_GpHand);
            m_GpHand = IntPtr.Zero;
            dataGridViewGp.Rows.Clear();
            AxCountInGp = 0;
        }

        private void buttonServoOn_Click(object sender, EventArgs e)
        {
            uint AxisNum;
            uint Result;
            string strTemp;
            //Check the servoOno flag to decide if turn on or turn off the ServoOn output.
            if (m_bInit != true)
            {
                return;
            }
            if (m_bServoOn == false)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver ON,1: On
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 1);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo On Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = true;
                    buttonServoOn.Text = "Servo Off";
                }
            }
            else
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver OFF,0: Off
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 0);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo Off Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = false;
                    buttonServoOn.Text = "Servo On";
                }
            }
        }

        private void buttonSCSet_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            uint PropertyVal;
            PropertyVal = (uint)comboBoxAxisTrigPulseMode.SelectedIndex;
            //set compare PulseMode.
            //You can also use the old API: Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyIDCFG_AxCmpPulseMode,ref PropertyVal,BufferLength)
            // UInt32  BufferLength;
            //BufferLength =4; buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.CFG_AxCmpPulseMode, PropertyVal);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set Property-CFG_AxCmpPulseMode Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }

            PropertyVal = (uint)comboBoxAxisCmpPulseLogic.SelectedIndex;
            //set compare PulseLogic.
            //You can also use the old API: Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyIDCFG_AxCmpPulseLogic,ref PropertyVal,BufferLength)
            // UInt32  BufferLength;
            //BufferLength =4; buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.CFG_AxCmpPulseLogic, PropertyVal);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set Property-CFG_AxCmpPulseLogic Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }

            //set compare PulseWidth.
            //You can also use the old API: Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyIDCFG_CFG_AxCmpPulseWidth,ref PropertyVal,BufferLength)
            // UInt32  BufferLength;
            //BufferLength =4; buffer size for the property
          /*  Result = Motion.mAcm_SetU32Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.CFG_AxCmpPulseWidthEx, Convert.ToUInt32(textBoxAxisCmpPulseWidth.Text));
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set Property-CFG_CFG_AxCmpPulseWidth Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
*/
            PropertyVal = (uint)comboBoxSCCmpSrc.SelectedIndex;
            //set compare source.
            //You can also use the old API: Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxCmpSrc,ref PropertyVal,BufferLength)
            // UInt32  BufferLength;
            //BufferLength =4; buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.CFG_AxCmpSrc, PropertyVal);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set Property-CFG_AxCmpSrc Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            PropertyVal = (uint)comboBoxScCmpMethod.SelectedIndex;
            //Set compare method
            //You can also use the old API: Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxCmpMethod,ref PropertyVal,BufferLength)
            // UInt32  BufferLength;
            //BufferLength =4; buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.CFG_AxCmpMethod, PropertyVal);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set Property-AxCmpMethod Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }

            PropertyVal = 1;
            //Enable/disable axis compare function.
            //You can also use the old API: Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxCmpEnable,ref PropertyVal,BufferLength)
            // UInt32  BufferLength;
            //BufferLength =4; buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.CFG_AxCmpEnable, PropertyVal);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set Property-AxCmpEnable Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }

        private void buttonSACCmpAutoSet_Click(object sender, EventArgs e)
        {
            double Start, End, Interval;
            uint Result;
            string strTemp;
            Start = Convert.ToDouble(textBoxScCmpAutoStart.Text);
            End = Convert.ToDouble(textBoxScCmpAutoEnd.Text);
            Interval = Convert.ToDouble(textBoxScCmpAutoInterval.Text);
            //	Set compare data for the specified axis
            Result = Motion.mAcm_AxSetCmpAuto(m_Axishand[comboBoxScAxisnumb.SelectedIndex], Start, End, Interval);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "AxSetCmpAuto Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
        }

        private void buttonSCSinglePointCmpSet_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            //	Set just one compare data for the specified axis
            Result = Motion.mAcm_AxSetCmpData(m_Axishand[comboBoxScAxisnumb.SelectedIndex], Convert.ToDouble(textBoxSCSinglePointCmpPoint.Text));
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "AxSetCmpData Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
        }

        private void buttonSCCompareTableAdd_Click(object sender, EventArgs e)
        {
            //Add Compare data to the listbox
            for (int i = 0; i < listBoxSCCompareTable.Items.Count; i++)
            {
                if (textBoxSCCompareTablePoint.Text == listBoxSCCompareTable.Items[i].ToString())
                    return;
            }
                listBoxSCCompareTable.Items.Add(textBoxSCCompareTablePoint.Text);
        }

        private void buttonSingleCmpDelete_Click(object sender, EventArgs e)
        {
            //Remove selecteditem in listbox
            if (listBoxSCCompareTable.SelectedItem != null)
                listBoxSCCompareTable.Items.Remove(listBoxSCCompareTable.SelectedItem);
        }

        private void buttonSCCompareTableClear_Click(object sender, EventArgs e)
        {
            //Clear the listbox
            listBoxSCCompareTable.Items.Clear();
        }

        private void buttonSCCompareTableSetTable_Click(object sender, EventArgs e)
        {
            uint Result;
            int ArrayCount = listBoxSCCompareTable.Items.Count;
            string strTemp;
            double[] TableArray = new double[ArrayCount];
            if (m_bInit != true)
            {
                return;
            }
            try
            {
                for (int i = 0; i < ArrayCount; i++)
                {
                    //Get compare data from listbox
                    TableArray[i] = Convert.ToDouble(listBoxSCCompareTable.Items[i]);
                }
            }
            catch (System.Exception)
            {
                MessageBox.Show("Invalid Input Parameters.", "Compare", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
                return;
            }
            //Set compare data  for the specified axis
            Result = Motion.mAcm_AxSetCmpTable(m_Axishand[comboBoxScAxisnumb.SelectedIndex], TableArray, ArrayCount);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set Compare Table Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
        }

        private void buttonSingleAxisSpeedSet_Click(object sender, EventArgs e)
        {
            uint Result;
            double AxVelLow;
            double AxVelHigh;
            double AxAcc;
            double AxDec;
            double AxJerk;
            string strTemp;
            FormAxisParam AxisParam = new FormAxisParam();
            if (m_bInit)
            {
                GetAxisVelParam(AxisParam); //get axis velocity param
                if (AxisParam.ShowDialog() == DialogResult.OK)
                {
                    AxVelLow = Convert.ToDouble(AxisParam.textBoxVelL.Text);
                    //Set low velocity (start velocity) of this axis (Unit: PPU/S).
                    //This property value must be smaller than or equal to PAR_AxVelHigh
                    //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxVelLow, ref AxVelLow, BufferLength);
                    // UInt32  BufferLength;
                    //BufferLength =8; buffer size for the property
                    Result = Motion.mAcm_SetF64Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.PAR_AxVelLow, AxVelLow);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set low velocity failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    AxVelHigh = Convert.ToDouble(AxisParam.textBoxVelH.Text);
                    // Set high velocity (driving velocity) of this axis (Unit: PPU/s).
                    //This property value must be smaller than CFG_AxMaxVel and greater than PAR_AxVelLow
                    //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxVelHigh,ref AxVelHigh,BufferLength)
                    // UInt32  BufferLength;
                    //BufferLength =8; buffer size for the property
                    Result = Motion.mAcm_SetF64Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.PAR_AxVelHigh, AxVelHigh);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set high velocity failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    AxAcc = Convert.ToDouble(AxisParam.textBoxAcc.Text);
                    // Set acceleration of this axis (Unit: PPU/s2).
                    //This property value must be smaller than or equal to CFG_AxMaxAcc
                    //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxAcc,ref AxAcc,BufferLength)
                    // UInt32  BufferLength;
                    //BufferLength =8; buffer size for the property
                    Result = Motion.mAcm_SetF64Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.PAR_AxAcc, AxAcc);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set acceleration failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    AxDec = Convert.ToDouble(AxisParam.textBoxDec.Text);
                    //Set deceleration of this axis (Unit: PPU/s2).
                    //This property value must be smaller than or equal to CFG_AxMaxDec
                    //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxDcc,ref AxDec,BufferLength)
                    // UInt32  BufferLength;
                    //BufferLength =8; buffer size for the property
                    Result = Motion.mAcm_SetF64Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.PAR_AxDec, AxDec);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set deceleration failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    if (AxisParam.rdb_T.Checked)
                    {
                        AxJerk = 0;
                    }
                    else
                    {
                        AxJerk = 1;
                    }
                    //Set the type of velocity profile: t-curve or s-curve
                    //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxJerk,ref AxJerk,BufferLength)
                    // UInt32  BufferLength;
                    //BufferLength =8; buffer size for the property
                    Result = Motion.mAcm_SetF64Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.PAR_AxJerk, AxJerk);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set the type of velocity profile failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
            }
        }

        private void buttonSingleAxisMove_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            if (m_bInit)
            {
                if (radioButtonSAMRel.Checked)
                {
                    //Start single axis's relative position motion.
                    Result = Motion.mAcm_AxMoveRel(m_Axishand[comboBoxScAxisnumb.SelectedIndex], Convert.ToDouble(textBoxSingleAxisMotionEndPoint.Text));
                }
                else
                {
                    //Start single axis's absolute position motion.
                    Result = Motion.mAcm_AxMoveAbs(m_Axishand[comboBoxScAxisnumb.SelectedIndex], Convert.ToDouble(textBoxSingleAxisMotionEndPoint.Text));
                }
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "PTP Move Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
        }

        private void buttonSingleAxisStop_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            if (m_bInit)
            {
                //To command axis to decelerate to stop.
                for (int i = 0; i < m_ulAxisCount; i++)
                {
                    Result = Motion.mAcm_AxStopDec(m_Axishand[i]);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Axis To decelerate Stop Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
                return;
            }
        }

        private void buttonCMPDO_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            //Check the CmpDo flag to decide if turn on or turn off .
            if (CmpDoFlag == false)
            {
                Result = Motion.mAcm_DevMultiTrigSetCmpDO(m_DeviceHandle, 1);
                CmpDoFlag = true;
            }
            else
            {
                Result = Motion.mAcm_DevMultiTrigSetCmpDO(m_DeviceHandle, 0);
                CmpDoFlag = false;
            }
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set DevMultiTrigSetCmpDO failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }

        private void ButtonMultiCompareSet_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            uint MulAxEn = 0;
            uint MultiCmpOutChannel = 0;
            uint MultiTrigPulseMode;
            uint MultiCmpPulseLogic;
            uint MultiTrigAutoEmptyEn;
            uint MultiCmpPulseWidth;
            // Get the checked axis for compare
            for (int i = 0; i < checkedListBoxMulAxCompareEn.Items.Count; i++)
            {
                if (checkedListBoxMulAxCompareEn.GetItemChecked(i))
                {
                    MulAxEn += ((uint)1 << i);
                }
            }
            //Set the CompareEnable of Axis  1:enable 0:disable
            Result = Motion.mAcm_SetU32Property(m_DeviceHandle, (uint)PropertyID.CFG_DevMultiCmpAxisEnable, MulAxEn);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_DevMultiCmpAxisEnable Property  failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            // Get the checked axis for output
            for (int i = 0; i < checkedListBoxMultiCmpOutChannel.Items.Count; i++)
            {
                if (checkedListBoxMultiCmpOutChannel.GetItemChecked(i))
                {
                    MultiCmpOutChannel += ((uint)1 << i);
                }
            }
            //Set MulAxis Compare Out Channel,0: dis��1��en 
            Result = Motion.mAcm_SetU32Property(m_DeviceHandle, (uint)PropertyID.CFG_DevMultiCmpOutChannel, MultiCmpOutChannel);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_DevMultiCmpOutChannel Property  failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }

            MultiTrigPulseMode = (uint)comboBoxMultiTrigPulseMode.SelectedIndex;
            //Set MulAxis Trig Pulse Mode
            Result = Motion.mAcm_SetU32Property(m_DeviceHandle, (uint)PropertyID.CFG_DevMultiTrigPulseMode, MultiTrigPulseMode);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_DevMultiTrigPulseMode Property  failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }


            MultiCmpPulseLogic = (uint)comboBoxMultiCmpPulseLogic.SelectedIndex;
            //Set MulAxis Compare Pulse Logic
            Result = Motion.mAcm_SetU32Property(m_DeviceHandle, (uint)PropertyID.CFG_DevMultiCmpPulseLogic, MultiCmpPulseLogic);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_DevMultiCmpPulseLogic Property  failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            //Clear the Compare data or not after complete compare
            MultiTrigAutoEmptyEn = (uint)comboBoxMultiTrigAutoEmptyEn.SelectedIndex;
            Result = Motion.mAcm_SetU32Property(m_DeviceHandle, (uint)PropertyID.CFG_DevMultiTrigAutoEmptyEn, MultiTrigAutoEmptyEn);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_DevMultiTrigAutoEmptyEn Property  failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }

            MultiCmpPulseWidth = Convert.ToUInt32(textBoxMulAxCmpPulseWidth.Text);
            //Set MulAxis Compare Pulse Width
            Result = Motion.mAcm_SetU32Property(m_DeviceHandle, (uint)PropertyID.CFG_DevMultiCmpPulseWidth, MultiCmpPulseWidth);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_DevMultiCmpPulseWidth Property  failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }

        private void ButtonAxisComPareSet_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            uint PropertyVal;

            PropertyVal = (UInt32)comboBoxSrc.SelectedIndex;
            //set compare source.
            //You can also use the old API: Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxCmpSrc,ref PropertyVal,BufferLength)
            // UInt32  BufferLength;
            //BufferLength =4; buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_Axishand[comboBoxAxisNub.SelectedIndex], (uint)PropertyID.CFG_AxCmpSrc, PropertyVal);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set Property-CFG_AxCmpSrc Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }

            PropertyVal = Convert.ToUInt32(textBoxAxisMultiCmpDeviation.Text);
            //Set MulAxis Compare Deviation
            //You can also use the old API: Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxisMultiCmpDeviation,ref PropertyVal,BufferLength)
            // UInt32  BufferLength;
            //BufferLength =4; buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_Axishand[comboBoxAxisNub.SelectedIndex], (uint)PropertyID.CFG_AxMultiCmpDeviation, PropertyVal);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_AxisMultiCmpDeviation Property  failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }

        private void buttonSetCnt_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            ////Reset the axis' state. If the axis is in ErrorStop state, the state will
            //be changed to Ready after calling this function.
            for (int i = 0; i < m_ulAxisCount; i++)
            {
                if (m_bInit == true)
                {
                    //Set command position for the specified axis
                    Result = Motion.mAcm_AxSetCmdPosition(m_Axishand[i], 0);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set axis's command position failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    Result = Motion.mAcm_AxSetActualPosition(m_Axishand[i], 0);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set axis's actual position failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
            }
        }

        private void BtnResetErr_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            //Reset the axis' state. If the axis is in ErrorStop state, the state will
            //be changed to Ready after calling this function.
            Result = Motion.mAcm_AxResetError(m_Axishand[comboBoxAxisNub.SelectedIndex]);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Reset axis's error failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }

        private void buttonCmpAutoSet_Click(object sender, EventArgs e)
        {
            double Start, End, Interval;
            uint Result;
            string strTemp;
            Start = Convert.ToDouble(textBoxCmpAutoStart.Text);
            End = Convert.ToDouble(textBoxCmpautoEnd.Text);
            Interval = Convert.ToDouble(textBoxCmpautoInterval.Text);
            //	Set compare data for the specified axis
            Result = Motion.mAcm_AxSetCmpAuto(m_Axishand[comboBoxCmpAutoAxis.SelectedIndex], Start, End, Interval);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "AxSetCmpAuto Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
        }

        private void buttonSPCSet_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            // Set compare data
            Result = Motion.mAcm_AxSetCmpData(m_Axishand[comboBoxSPCAxis.SelectedIndex], Convert.ToDouble(textBoxSPCPoint.Text));
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "AxSetCmpData Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            //Add the compare data to the listbox and the same data can not be add
            string Name;
            Name = comboBoxMCCompareTableAxis.SelectedItem + ":" + textBoxCompareTablePoint.Text;
            for (int i = 0; i < listBoxCmpData.Items.Count; i++)
            {
                if (listBoxCmpData.Items[i].ToString() == Name)
                {
                    return;
                }
            }
            listBoxCmpData.Items.Add(Name);
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (listBoxCmpData.SelectedItem != null)
                listBoxCmpData.Items.Remove(listBoxCmpData.SelectedItem);
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            listBoxCmpData.Items.Clear();
        }

        private void btn_SetTable_Click(object sender, EventArgs e)
        {
            uint Result = 0;
            string strTemp;
            string[] temp;
            string[] CmpData = new string[m_ulAxisCount];
            List<double>[] AxisCompareTable = new List<double>[m_ulAxisCount];
            //Get the compare data from listbox 
            for (uint AxisIndex = 0; AxisIndex < m_ulAxisCount; AxisIndex++)
            { 
                AxisCompareTable[AxisIndex] = new List<double>();
                for (int i = 0; i < listBoxCmpData.Items.Count; i++)
                {
                    temp = listBoxCmpData.Items[i].ToString().Split(':');
                    if (temp[0] == AxisIndex.ToString() + "-" + "Axis")
                    {
                        AxisCompareTable[AxisIndex].Add(Convert.ToDouble(temp[1]));
                    }
                }
            }
			Result = Motion.mAcm_SetU32Property(m_DeviceHandle, (uint)PropertyID.CFG_DevMultiTrigFifoWriteEnable, 1);
			if (Result != (uint)ErrorCode.SUCCESS)
			{
				strTemp = "Set Property-CFG_DevMultiTrigFifoWriteEnable Enable Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
			}
            // Set the compare data 
            for (int i = 0; i < m_ulAxisCount; i++)
            {
                if (AxisCompareTable[i].Count != 0)
                {
                    Result = Motion.mAcm_AxSetCmpTable(m_Axishand[i], AxisCompareTable[i].ToArray(), AxisCompareTable[i].Count);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set Compare Table Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                    }
                }
            }
			Result = Motion.mAcm_SetU32Property(m_DeviceHandle, (uint)PropertyID.CFG_DevMultiTrigFifoWriteEnable, 0);
			if (Result != (uint)ErrorCode.SUCCESS)
			{
				strTemp = "Set Property-CFG_DevMultiTrigFifoWriteEnable Disable Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
			}



        }


        private void buttonAddtogp_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            //Add Axis to group
            if (dataGridViewGp.Rows[comboBoxAxInGp.SelectedIndex].DefaultCellStyle.BackColor == Color.White)
            {
                return;
            }
            dataGridViewGp.Rows[comboBoxAxInGp.SelectedIndex].DefaultCellStyle.BackColor = Color.White;
            dataGridViewGp.Rows[comboBoxAxInGp.SelectedIndex].ReadOnly = false;
            AxCountInGp++;
            Result = Motion.mAcm_GpAddAxis(ref m_GpHand, m_Axishand[comboBoxAxInGp.SelectedIndex]);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Add Axis To Group Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }

        private void buttonGpClear_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            // delete group
            for (int i = 0; i < dataGridViewGp.Rows.Count; i++)
            {
                if (dataGridViewGp.Rows[i].DefaultCellStyle.BackColor == Color.White)
                {
                    dataGridViewGp.Rows[i].DefaultCellStyle.BackColor = Color.Gray;
                    Result = Motion.mAcm_GpRemAxis(m_GpHand, m_Axishand[i]);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Add Axis To Group Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
            }
            AxCountInGp = 0;
        }

        private void buttonSetSpeed_Click(object sender, EventArgs e)
        {
            FormGpParam GpParam = new FormGpParam();
            UInt32 Result;
            double GpVelLow;
            double GpVelHigh;
            double GpAcc;
            double GpDec;
            double GpJerk;
            string strTemp;
            //Set group speed
            if (m_bInit)
            {
                GetGroupVelocityParam(GpParam); //get Group velocity param
                if (GpParam.ShowDialog() == DialogResult.OK)
                {
                    GpVelLow = Convert.ToDouble(GpParam.textBoxVelL.Text);
                    // Set low velocity (start velocity) of this group (Unit: PPU/s). 
                    // This property value must be smaller than or equal to Par_GpVelHigh .
                    // The default value is the first added axis' PAR_AxVelLow
                    //You  can also use the old API:Motion.mAcm_SetProperty(m_GpHand,(uint)PropertyID.PAR_GpVelLow,ref GpVelLow,BufferLength)
                    //uint BufferLength;
                    //BufferLength =8; buffer size for the property
                    Result = Motion.mAcm_SetF64Property(m_GpHand, (uint)PropertyID.PAR_GpVelLow, GpVelLow);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set low velocity failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    GpVelHigh = Convert.ToDouble(GpParam.textBoxVelH.Text);
                    //Set high velocity (driving velocity) of this group (Unit: PPU/s).
                    //This property value must be smaller than first added axis'
                    //CFG_AxMaxVel and greater than Par_GpVelLow. The default value is the first added axis' PAR_AxVelHigh
                    //You  can also use the old API:Motion.mAcm_SetProperty(m_GpHand,(uint)PropertyID.PAR_GpVelHigh,ref  GpVelHigh,BufferLength)
                    //uint BufferLength;
                    //BufferLength =8; buffer size for the property
                    Result = Motion.mAcm_SetF64Property(m_GpHand, (uint)PropertyID.PAR_GpVelHigh, GpVelHigh);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set high velocity failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    GpAcc = Convert.ToDouble(GpParam.textBoxAcc.Text);
                    //Set acceleration of this group (Unit: PPU/s2). This property value
                    //must be smaller than or equal to first added axis' CFG_AxMaxAcc.
                    //The default value is the first added axis' PAR_AxAcc.    
                    //You  can also use the old API:Motion.mAcm_SetProperty(m_GpHand,(uint)PropertyID.PAR_GpAcc,ref GpAcc,BufferLength)
                    //uint BufferLength;
                    //BufferLength =8; buffer size for the property
                    Result = Motion.mAcm_SetF64Property(m_GpHand, (uint)PropertyID.PAR_GpAcc, GpAcc);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set acceleration failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    GpDec = Convert.ToDouble(GpParam.textBoxDec.Text);
                    //Set deceleration of this group (Unit: PPU/s2). This property value
                    //must be smaller than or equal to first added axis' CFG_AxMaxDec.
                    //The default value is the first added axis' PAR_AxDec
                    //You  can also use the old API:Motion.mAcm_SetProperty(m_GpHand,(uint)PropertyID.PAR_GpDec,ref GpDec,BufferLength)
                    //uint BufferLength;
                    //BufferLength =8; buffer size for the property
                    Result = Motion.mAcm_SetF64Property(m_GpHand, (uint)PropertyID.PAR_GpDec, GpDec);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set deceleration failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    if (GpParam.rdb_T.Checked)
                    {
                        GpJerk = 0;
                    }
                    else
                    {
                        GpJerk = 1;
                    }
                    //Set the type of velocity profile: t-curve or s-curve
                    //You  can also use the old API:Motion.mAcm_SetProperty(m_GpHand,(uint)PropertyID.PAR_GpJerk,ref GpJerk,BufferLength)
                    //uint BufferLength;
                    //BufferLength =8; buffer size for the property
                    Result = Motion.mAcm_SetF64Property(m_GpHand, (uint)PropertyID.PAR_GpJerk, GpJerk);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set the type of velocity profile failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
            }
        }

        private void BtnCMove_Click(object sender, EventArgs e)
        {
            uint Result;
            uint AxisNum = new uint();
            string strTemp;
            AxisNum = AxCountInGp;
            double[] EndArray = new double[AxCountInGp];
            //Get speed data from  dataGridViewGp
            for (int i = 0; i < m_ulAxisCount; i++)
            {
                if (dataGridViewGp.Rows[i].DefaultCellStyle.BackColor == Color.White)
                {
                    EndArray[i] = Convert.ToDouble(dataGridViewGp.Rows[i].Cells[2].Value);
                }
               
            }
            if (radioButtonRel.Checked)
                //Command group to execute relative line interpolation
                Result = Motion.mAcm_GpMoveLinearRel(m_GpHand, EndArray, ref AxisNum);
            else
                //Command group to execute absolute line interpolation
                Result = Motion.mAcm_GpMoveLinearAbs(m_GpHand, EndArray, ref AxisNum);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Move Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
            return;
        }

        private void GetGroupVelocityParam(FormGpParam formgroupparamset)
        {
            UInt32 Result;
            double GpVelLow = 0;
            double GpVelHigh = 0;
            double GpAcc = 0;
            double GpDec = 0;
            string strTemp;
            // FormGroupParamSet formgroupparamset = new FormGroupParamSet();
            // Get low velocity (start velocity) of this group (Unit: PPU/s). 
            //You can also use the old API:  Motion.mAcm_GetProperty(m_GpHand,(uint)PropertyID.PAR_GpVelLow, ref GpVelLow,ref BufferLen);
            //uint BufferLength;
            //BufferLength =8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_GpHand, (uint)PropertyID.PAR_GpVelLow, ref GpVelLow);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get PAR_GpVelLow Property Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            formgroupparamset.textBoxVelL.Text = Convert.ToString(GpVelLow);
            // Get high velocity (driving velocity) of this group (Unit: PPU/s).
            //You can also use the old API:  Motion.mAcm_GetProperty(m_GpHand,(uint)PropertyID.PAR_GpVelHigh, ref GpVelHigh,ref BufferLen);
            //uint BufferLength;
            //BufferLength =8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_GpHand, (uint)PropertyID.PAR_GpVelHigh, ref GpVelHigh);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get PAR_GpVelHigh Property Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            formgroupparamset.textBoxVelH.Text = Convert.ToString(GpVelHigh);
            //Get acceleration of this group (Unit: PPU/s2).
            //You can also use the old API:  Motion.mAcm_GetProperty(m_GpHand,(uint)PropertyID.PAR_GpAcc, ref GpAcc,ref BufferLen);
            //uint BufferLength;
            //BufferLength =8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_GpHand, (uint)PropertyID.PAR_GpAcc, ref GpAcc);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get PAR_GpAcc Property Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            formgroupparamset.textBoxAcc.Text = Convert.ToString(GpAcc);
            //Get deceleration of this group (Unit: PPU/s2).
            //You can also use the old API:  Motion.mAcm_GetProperty(m_GpHand,(uint)PropertyID.PAR_GpAcc, ref GpDec,ref BufferLen);
            //uint BufferLength;
            //BufferLength =8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_GpHand, (uint)PropertyID.PAR_GpAcc, ref GpDec);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get PAR_GpAcc Property Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            formgroupparamset.textBoxDec.Text = Convert.ToString(GpDec);
        }

        private void GetAxisVelParam(FormAxisParam formaxisparam)
        {
            double axvellow = new double();
            double axvelhigh = new double();
            double axacc = new double();
            double axdec = new double();
            UInt32 Result;
            string strTemp = "";
            //Get low velocity (start velocity) of this axis (Unit: PPU/S).
            //You can also use the old API:  Acm_GetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxVelLow, ref axvellow,ref BufferLength);
            // uint BufferLength;
            // BufferLength = 8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.PAR_AxVelLow, ref axvellow);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get low velocity failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            formaxisparam.textBoxVelL.Text = Convert.ToString(axvellow);
            //get high velocity (driving velocity) of this axis (Unit: PPU/s).
            //You can also use the old API:  Acm_GetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxVelHigh, ref axvelhigh,ref BufferLength);
            // uint BufferLength;
            // BufferLength = 8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.PAR_AxVelHigh, ref axvelhigh);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get High velocity failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            formaxisparam.textBoxVelH.Text = Convert.ToString(axvelhigh);
            //get acceleration of this axis (Unit: PPU/s2).
            //You can also use the old API:  Acm_GetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxAcc, ref axacc,ref BufferLength);
            // uint BufferLength;
            // BufferLength = 8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.PAR_AxAcc, ref axacc);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get acceleration  failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            formaxisparam.textBoxAcc.Text = Convert.ToString(axacc);
            //get deceleration of this axis (Unit: PPU/s2).
            //You can also use the old API: Motion.mAcm_GetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxDec, ref axdec, ref BufferLength);
            // uint BufferLength;
            // BufferLength = 8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_Axishand[comboBoxScAxisnumb.SelectedIndex], (uint)PropertyID.PAR_AxDec, ref axdec);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get deceleration  failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            formaxisparam.textBoxDec.Text = Convert.ToString(axdec);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (m_bInit)
            {
                GetPostion();
                GetAxisState();
                GetMotionIOStatus();
                GetCompareData();
            }
        }

        private void GetPostion()
        {
            double CmdPos = new double();
            double ActPos = new double();
            //Get current command position of every axis
            //Get current actual position of every axis
            for (int i = 0; i < m_ulAxisCount; i++)
            {
                Motion.mAcm_AxGetCmdPosition(m_Axishand[i], ref CmdPos);
                dataGridViewStateAndPotion.Rows[i].Cells[1].Value = CmdPos.ToString();

                Motion.mAcm_AxGetActualPosition(m_Axishand[i], ref ActPos);
                dataGridViewStateAndPotion.Rows[i].Cells[2].Value = ActPos.ToString();
            }
        }

        private void GetAxisState()
        {
            UInt16 AxState = new UInt16();
            UInt32 Result;
            //Get the state of every axis
            for (int i = 0; i < m_ulAxisCount; i++)
            {
                Result = Motion.mAcm_AxGetState(m_Axishand[i], ref AxState);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    dataGridViewStateAndPotion.Rows[i].Cells[3].Value = ((AxisState)AxState).ToString();
                }
            }

        }

        private void GetMotionIOStatus()
        {
            uint Result;
            uint IOStatus = 0;
            byte Dobit = 0 ;
            //get the IO state of every axis
            for (int i = 0; i < m_ulAxisCount; i++)
            {
                Result = Motion.mAcm_AxGetMotionIO(m_Axishand[i], ref IOStatus);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ALM) > 0)//ALM
                    {
                        dataGridViewStateAndPotion.Rows[i].Cells[4].Style.BackColor = Color.Red;
                    }
                    else
                    {
                        dataGridViewStateAndPotion.Rows[i].Cells[4].Style.BackColor = Color.Gray;
                    }


                    if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ORG) > 0)//ORG
                    {
                        dataGridViewStateAndPotion.Rows[i].Cells[5].Style.BackColor = Color.Red;
                    }
                    else
                    {
                        dataGridViewStateAndPotion.Rows[i].Cells[5].Style.BackColor = Color.Gray;
                    }

                    if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTP) > 0)//+EL
                    {
                        dataGridViewStateAndPotion.Rows[i].Cells[6].Style.BackColor = Color.Red;
                    }
                    else
                    {
                        dataGridViewStateAndPotion.Rows[i].Cells[6].Style.BackColor = Color.Gray;
                    }

                    if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTN) > 0)//-EL
                    {
                        dataGridViewStateAndPotion.Rows[i].Cells[7].Style.BackColor = Color.Red;
                    }
                    else
                    {
                        dataGridViewStateAndPotion.Rows[i].Cells[7].Style.BackColor = Color.Gray;
                    }
                }
                Result = Motion.mAcm_AxDoGetBit(m_Axishand[i],5, ref Dobit);          
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    if (Dobit  > 0)
                    {
                        dataGridViewStateAndPotion.Rows[i].Cells[8].Style.BackColor = Color.Red;
                    }
                    else
                    {
                        dataGridViewStateAndPotion.Rows[i].Cells[8].Style.BackColor = Color.Gray;
                    }

                }
            }
        }

        private void GetCompareData()
        {
            uint Result;
            double CurCmpData = 0;
            //Get compare data of axis
            Result = Motion.mAcm_AxGetCmpData(m_Axishand[comboBoxScAxisnumb.SelectedIndex], ref CurCmpData);
            if (Result == (uint)ErrorCode.SUCCESS)
            {
                textBoxSACCmptableNextCmpData.Text = Convert.ToString(CurCmpData);
            }

            for (int i = 0; i < m_ulAxisCount; i++)
            {

                if (checkedListBoxMulAxCompareEn.GetItemChecked(i))
                {
                    Result = Motion.mAcm_AxGetCmpData(m_Axishand[i], ref CurCmpData);
                    if (Result == (uint)ErrorCode.SUCCESS)
                    {
                        dataGridViewGp.Rows[i].Cells[2].Value = Convert.ToString(CurCmpData);
                    }
                }
                else
                {
                    dataGridViewGp.Rows[i].Cells[2].Value = " ";
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseBoardOrForm();
        }

        private void buttonLoadConfig_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            this.openFileDialog1.FileName = ".cfg";
            if (openFileDialog1.ShowDialog() != DialogResult.OK)
                return;
            //Set all configurations for the device according to the loaded file
            Result = Motion.mAcm_DevLoadConfig(m_DeviceHandle, openFileDialog1.FileName);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Load Config Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }		 
        }

        private void comboBoxAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[comboBoxAvailableDevice.SelectedIndex].DeviceNum;
        }
    }
}