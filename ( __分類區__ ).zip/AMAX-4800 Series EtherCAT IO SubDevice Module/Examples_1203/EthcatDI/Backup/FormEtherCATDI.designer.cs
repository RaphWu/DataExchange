﻿using Advantech.Motion;
namespace EthcatDI
{
    partial class FormEtherCATDI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEtherCATDI));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_CloseBoard = new System.Windows.Forms.Button();
            this.btn_OpenBoard = new System.Windows.Forms.Button();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_DISetup = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.pn_DO = new System.Windows.Forms.Panel();
            this.pn_DIValue = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.hideConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imageDOList = new System.Windows.Forms.ImageList(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.pn_DO.SuspendLayout();
            this.panel10.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_CloseBoard);
            this.panel1.Controls.Add(this.btn_OpenBoard);
            this.panel1.Controls.Add(this.CmbAvailableDevice);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btn_DISetup);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // btn_CloseBoard
            // 
            resources.ApplyResources(this.btn_CloseBoard, "btn_CloseBoard");
            this.btn_CloseBoard.Name = "btn_CloseBoard";
            this.btn_CloseBoard.UseVisualStyleBackColor = true;
            this.btn_CloseBoard.Click += new System.EventHandler(this.btn_CloseBoard_Click);
            // 
            // btn_OpenBoard
            // 
            resources.ApplyResources(this.btn_OpenBoard, "btn_OpenBoard");
            this.btn_OpenBoard.Name = "btn_OpenBoard";
            this.btn_OpenBoard.UseVisualStyleBackColor = true;
            this.btn_OpenBoard.Click += new System.EventHandler(this.btn_OpenBoard_Click);
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            resources.ApplyResources(this.CmbAvailableDevice, "CmbAvailableDevice");
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // btn_DISetup
            // 
            resources.ApplyResources(this.btn_DISetup, "btn_DISetup");
            this.btn_DISetup.Name = "btn_DISetup";
            this.btn_DISetup.UseVisualStyleBackColor = true;
            this.btn_DISetup.Click += new System.EventHandler(this.btn_DISetup_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel6);
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            // 
            // panel6
            // 
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Controls.Add(this.pn_DO);
            this.panel6.Name = "panel6";
            // 
            // panel9
            // 
            resources.ApplyResources(this.panel9, "panel9");
            this.panel9.Name = "panel9";
            // 
            // pn_DO
            // 
            this.pn_DO.Controls.Add(this.pn_DIValue);
            this.pn_DO.Controls.Add(this.panel10);
            resources.ApplyResources(this.pn_DO, "pn_DO");
            this.pn_DO.Name = "pn_DO";
            // 
            // pn_DIValue
            // 
            resources.ApplyResources(this.pn_DIValue, "pn_DIValue");
            this.pn_DIValue.Name = "pn_DIValue";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label50);
            this.panel10.Controls.Add(this.label51);
            this.panel10.Controls.Add(this.label56);
            this.panel10.Controls.Add(this.label57);
            this.panel10.Controls.Add(this.label58);
            this.panel10.Controls.Add(this.label59);
            resources.ApplyResources(this.panel10, "panel10");
            this.panel10.Name = "panel10";
            // 
            // label50
            // 
            resources.ApplyResources(this.label50, "label50");
            this.label50.Name = "label50";
            // 
            // label51
            // 
            resources.ApplyResources(this.label51, "label51");
            this.label51.Name = "label51";
            // 
            // label56
            // 
            resources.ApplyResources(this.label56, "label56");
            this.label56.Name = "label56";
            // 
            // label57
            // 
            resources.ApplyResources(this.label57, "label57");
            this.label57.Name = "label57";
            // 
            // label58
            // 
            resources.ApplyResources(this.label58, "label58");
            this.label58.Name = "label58";
            // 
            // label59
            // 
            resources.ApplyResources(this.label59, "label59");
            this.label59.Name = "label59";
            // 
            // panel5
            // 
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hideConfigurationToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            resources.ApplyResources(this.contextMenuStrip1, "contextMenuStrip1");
            // 
            // hideConfigurationToolStripMenuItem
            // 
            this.hideConfigurationToolStripMenuItem.Name = "hideConfigurationToolStripMenuItem";
            resources.ApplyResources(this.hideConfigurationToolStripMenuItem, "hideConfigurationToolStripMenuItem");
            // 
            // imageDOList
            // 
            this.imageDOList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageDOList.ImageStream")));
            this.imageDOList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageDOList.Images.SetKeyName(0, "DO_Off_32.png");
            this.imageDOList.Images.SetKeyName(1, "Do_On_32.png");
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openConfigFileDialog";
            // 
            // FormEtherCATDI
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "FormEtherCATDI";
            this.Load += new System.EventHandler(this.FormDigitalOutput_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.pn_DO.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        bool m_bInit = false;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hideConfigurationToolStripMenuItem;
        private System.Windows.Forms.ImageList imageDOList;
        private System.Windows.Forms.Button btn_DISetup;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel pn_DO;
        private System.Windows.Forms.Panel pn_DIValue;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Button btn_CloseBoard;
        private System.Windows.Forms.Button btn_OpenBoard;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
    }
}