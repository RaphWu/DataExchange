﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;

namespace EthcatDI
{
    public partial class FormEtherCATDISetup : Form
    {
        public FormEtherCATDISetup()
        {
            InitializeComponent();
        }

        private uint DIChanNum = 0;
        private IntPtr m_Devhand = IntPtr.Zero;
        public FormEtherCATDISetup(uint m_DIChanNum)
        {
            InitializeComponent();
            DIChanNum = m_DIChanNum;
            m_Devhand = GlobalVar.m_DeviceHandle;
        }

        private void FormDigitalInputSetup_Load(object sender, EventArgs e)
        {
            for (uint i = 0; i < DIChanNum; i++)
            {
                cmb_ChanIndex.Items.Add(i.ToString());
            }

            if (DIChanNum > 0)
                cmb_ChanIndex.SelectedIndex = 0;

            RefreshDISetup(true);
        }

        private void btn_Apply_Click(object sender, EventArgs e)
        {
            uint Ret = 0;
            double m_DiInvet = 0;
            double m_DiFilterLow = 0;
            double m_DiFilterHigh = 0;
            string ErrorMessage = "";
            m_DiFilterLow = Convert.ToDouble(txb_FilterLow.Text);
            m_DiFilterHigh = Convert.ToDouble(txb_FilterHigh.Text);
            txb_FilterHigh.Enabled = true;
            txb_FilterLow.Enabled = true;

        
           
            if(cb_Invert.Checked)
            {
                m_DiInvet = 1;
            }
            else
            {
                m_DiInvet = 0;
            }
            //Set PropertyID
            Ret = Motion.mAcm_SetChannelProperty(m_Devhand,(uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqDiInvertEnable, m_DiInvet);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + cmb_ChanIndex.SelectedIndex.ToString() + " Set DiInvert Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }

            Ret = Motion.mAcm_SetChannelProperty(m_Devhand,(uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqDiLowFilter, m_DiFilterLow);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + cmb_ChanIndex.SelectedIndex.ToString() + " Set DiFilterLow Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }

            Ret = Motion.mAcm_SetChannelProperty(m_Devhand,(uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqDiHighFilter, m_DiFilterHigh);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + cmb_ChanIndex.SelectedIndex.ToString() + " Set DiFilterHigh Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
        

            RefreshDISetup(false) ;
        }

        private void cmb_ChanIndex_SelectedIndexChanged(object sender, EventArgs e)
        {
            uint Ret = 0;
            double m_DiInvet = 0;
            double m_DiFilterLow = 0;
            double m_DiFilterHigh = 0;
            string ErrorMessage = "";
            txb_FilterHigh.Enabled = true;
            txb_FilterLow.Enabled = true;
            cb_Invert.Enabled = true;
            btn_Apply.Enabled = true;

            //Get PropertyID
            Ret = Motion.mAcm_GetChannelProperty(m_Devhand, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqDiInvertEnable, ref m_DiInvet);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                if (Ret == (uint)ErrorCode.EC_PropertyNotSupported)
                {
                    cb_Invert.Enabled = false;
                    btn_Apply.Enabled = false;
                }
                else
                {
                    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                    MessageBox.Show("Channel " + Convert.ToString(cmb_ChanIndex.SelectedIndex) + " Get DiInvert Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    //return;
                }
            }
            else
            {
                if (m_DiInvet == 1)
                {
                    cb_Invert.Checked = true;
                }
                else
                {
                    cb_Invert.Checked = false;
                }
            }
            Ret = Motion.mAcm_GetChannelProperty(m_Devhand, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqDiLowFilter, ref m_DiFilterLow);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                if (Ret == (uint)ErrorCode.EC_PropertyNotSupported)
                {
                    txb_FilterLow.Text = "Not supported";
                    txb_FilterLow.Enabled = false;
                }
                else
                {
                    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                    MessageBox.Show("Channel " + Convert.ToString(cmb_ChanIndex.SelectedIndex) + " Get DiFilterLow Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    //return;
                }
            }
            else
            {
                txb_FilterLow.Text = m_DiFilterLow.ToString();
            }
            Ret = Motion.mAcm_GetChannelProperty(m_Devhand, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqDiHighFilter, ref m_DiFilterHigh);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                if (Ret == (uint)ErrorCode.EC_PropertyNotSupported)
                {
                    txb_FilterHigh.Text = "Not supported";
                    txb_FilterHigh.Enabled = false;
                }
                else
                {
                    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                    MessageBox.Show("Channel " + Convert.ToString(cmb_ChanIndex.SelectedIndex) + " Get DiFilterHigh Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    //return;
                }
            }
            else
            {
                txb_FilterHigh.Text = m_DiFilterHigh.ToString();
            }
            
           
            
        }

        private void RefreshDISetup(bool IsInitial)
        {
            string[] subItems = new string[3];

            uint Ret = 0;
            double m_DiInvet = 0;
            double m_DiFilterLow = 0;
            double m_DiFilterHigh = 0;
            string ErrorMessage = "";

            lv_DISetup.BeginUpdate();
            for (int i = 0; i < DIChanNum; i++)
            {
                Ret = Motion.mAcm_GetChannelProperty(m_Devhand,(uint)i, (uint)PropertyID.CFG_CH_DaqDiInvertEnable, ref m_DiInvet);
                ////This step can check whether result is true.It's not necessary.
                //if (Ret != (uint)ErrorCode.SUCCESS)
                //{
                //    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                //    MessageBox.Show("Channel " + i.ToString() + " Get DiInvert Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                //    //return;
                //}

                Ret = Motion.mAcm_GetChannelProperty(m_Devhand, (uint)i, (uint)PropertyID.CFG_CH_DaqDiLowFilter, ref m_DiFilterLow);
                //if (Ret != (uint)ErrorCode.SUCCESS)
                //{
                //    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                //    MessageBox.Show("Channel " + i.ToString() + " Get DiFilterLow Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                //    //return;
                //}

                Ret = Motion.mAcm_GetChannelProperty(m_Devhand, (uint)i, (uint)PropertyID.CFG_CH_DaqDiHighFilter, ref m_DiFilterHigh);
                //if (Ret != (uint)ErrorCode.SUCCESS)
                //{
                //    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                //    MessageBox.Show("Channel " + i.ToString() + " Get DiFilterHigh Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage,"EthcatDI" , MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                //    //return;
                //}


                subItems[0] = "CH-" + i.ToString();
                subItems[1] = m_DiFilterLow.ToString();
                subItems[2] = m_DiFilterHigh.ToString();
                if (IsInitial)
                {
                    ListViewItem lvi = new ListViewItem(subItems);
                    lv_DISetup.Items.Add(lvi);
                }
                else
                {
                    lv_DISetup.Items[i].SubItems[1].Text = subItems[1];
                    lv_DISetup.Items[i].SubItems[2].Text = subItems[2];
                }
                if (m_DiInvet == 1)
                {
                    lv_DISetup.Items[i].Checked = true;
                }
                else
                {
                    lv_DISetup.Items[i].Checked = false;
                }
            }
            lv_DISetup.EndUpdate();

        }

        private void lv_DISetup_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            uint Ret = 0;
            double m_PreDiInvert = 0;
            double m_DiInvert = 0;
            string ErrorMessage = "";

            if (e.Index != -1)
            {
                if (lv_DISetup.Items[e.Index].Checked)
                {
                    m_DiInvert = 0;
                }
                else
                {
                    m_DiInvert = 1;
                }
                Ret = Motion.mAcm_GetChannelProperty(m_Devhand, (uint)e.Index, (uint)PropertyID.CFG_CH_DaqDiInvertEnable, ref m_PreDiInvert);
                if (Ret != (uint)ErrorCode.SUCCESS)
                {
                    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                    MessageBox.Show("Channel " + e.Index.ToString() + " Get DiInvert Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    return;
                }
                if (m_DiInvert != m_PreDiInvert)
                {
                    Ret = Motion.mAcm_SetChannelProperty(m_Devhand, (uint)e.Index, (uint)PropertyID.CFG_CH_DaqDiInvertEnable, m_DiInvert);
                    if (Ret != (uint)ErrorCode.SUCCESS)
                    {
                        e.NewValue = e.CurrentValue;
                        ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                        MessageBox.Show("Channel " + e.Index.ToString() + " Set DiInvert Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                        return;
                    }
                }
            }
        }

      

    }
}