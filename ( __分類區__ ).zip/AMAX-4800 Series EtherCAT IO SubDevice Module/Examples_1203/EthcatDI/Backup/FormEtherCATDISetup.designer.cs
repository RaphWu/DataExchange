﻿namespace EthcatDI
{
    partial class FormEtherCATDISetup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEtherCATDISetup));
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txb_FilterHigh = new System.Windows.Forms.TextBox();
            this.txb_FilterLow = new System.Windows.Forms.TextBox();
            this.cb_Invert = new System.Windows.Forms.CheckBox();
            this.btn_Apply = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmb_ChanIndex = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lv_DISetup = new System.Windows.Forms.ListView();
            this.col_Channel = new System.Windows.Forms.ColumnHeader();
            this.col_FilterLow = new System.Windows.Forms.ColumnHeader();
            this.col_FilterOut = new System.Windows.Forms.ColumnHeader();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox1);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txb_FilterHigh);
            this.groupBox1.Controls.Add(this.txb_FilterLow);
            this.groupBox1.Controls.Add(this.cb_Invert);
            this.groupBox1.Controls.Add(this.btn_Apply);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cmb_ChanIndex);
            this.groupBox1.Controls.Add(this.label1);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // txb_FilterHigh
            // 
            resources.ApplyResources(this.txb_FilterHigh, "txb_FilterHigh");
            this.txb_FilterHigh.Name = "txb_FilterHigh";
            // 
            // txb_FilterLow
            // 
            resources.ApplyResources(this.txb_FilterLow, "txb_FilterLow");
            this.txb_FilterLow.Name = "txb_FilterLow";
            // 
            // cb_Invert
            // 
            resources.ApplyResources(this.cb_Invert, "cb_Invert");
            this.cb_Invert.Name = "cb_Invert";
            this.cb_Invert.UseVisualStyleBackColor = true;
            // 
            // btn_Apply
            // 
            resources.ApplyResources(this.btn_Apply, "btn_Apply");
            this.btn_Apply.Name = "btn_Apply";
            this.btn_Apply.UseVisualStyleBackColor = true;
            this.btn_Apply.Click += new System.EventHandler(this.btn_Apply_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // cmb_ChanIndex
            // 
            this.cmb_ChanIndex.FormattingEnabled = true;
            resources.ApplyResources(this.cmb_ChanIndex, "cmb_ChanIndex");
            this.cmb_ChanIndex.Name = "cmb_ChanIndex";
            this.cmb_ChanIndex.SelectedIndexChanged += new System.EventHandler(this.cmb_ChanIndex_SelectedIndexChanged);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lv_DISetup);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // lv_DISetup
            // 
            this.lv_DISetup.CheckBoxes = true;
            this.lv_DISetup.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_Channel,
            this.col_FilterLow,
            this.col_FilterOut});
            resources.ApplyResources(this.lv_DISetup, "lv_DISetup");
            this.lv_DISetup.FullRowSelect = true;
            this.lv_DISetup.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lv_DISetup.Name = "lv_DISetup";
            this.lv_DISetup.UseCompatibleStateImageBehavior = false;
            this.lv_DISetup.View = System.Windows.Forms.View.Details;
            this.lv_DISetup.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.lv_DISetup_ItemCheck);
            // 
            // col_Channel
            // 
            resources.ApplyResources(this.col_Channel, "col_Channel");
            // 
            // col_FilterLow
            // 
            resources.ApplyResources(this.col_FilterLow, "col_FilterLow");
            // 
            // col_FilterOut
            // 
            resources.ApplyResources(this.col_FilterOut, "col_FilterOut");
            // 
            // panel5
            // 
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            // 
            // FormEtherCATDISetup
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormEtherCATDISetup";
            this.Load += new System.EventHandler(this.FormDigitalInputSetup_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txb_FilterHigh;
        private System.Windows.Forms.TextBox txb_FilterLow;
        private System.Windows.Forms.CheckBox cb_Invert;
        private System.Windows.Forms.Button btn_Apply;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmb_ChanIndex;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ListView lv_DISetup;
        private System.Windows.Forms.ColumnHeader col_Channel;
        private System.Windows.Forms.ColumnHeader col_FilterLow;
        private System.Windows.Forms.ColumnHeader col_FilterOut;



    }
}