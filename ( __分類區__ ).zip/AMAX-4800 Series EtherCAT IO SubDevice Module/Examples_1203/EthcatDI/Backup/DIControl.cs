﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
//using System.Data;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;

namespace EthcatDI
{
    public partial class DIControl : UserControl
    {
        public DIControl()
        {
            InitializeComponent();
            DILedArray[0] = pbox_DI0;
            DILedArray[1] = pbox_DI1;
            DILedArray[2] = pbox_DI2;
            DILedArray[3] = pbox_DI3;
            DILedArray[4] = pbox_DI4;
            DILedArray[5] = pbox_DI5;
            DILedArray[6] = pbox_DI6;
            DILedArray[7] = pbox_DI7;

            for (int i = 0; i < 8; i++)
            {
                ((PictureBox)DILedArray[i]).Image = imageDIList.Images[0];
            }
        }
        object[] DILedArray = new object[8];//LedArray for 8DI Status

        private void DIControl_Load(object sender, EventArgs e)
        {
        }

        private ushort m_PortNo = 0;
        public ushort PortNo
        {
            get
            {
                return m_PortNo;
            }
            set
            {
                m_PortNo = value;
                lbl_DIPortNo.Text = m_PortNo.ToString();
            }
        }

        private IntPtr m_DeviceHandle = IntPtr.Zero;
        public IntPtr DeviceHandle
        {
            get
            {
                return m_DeviceHandle;
            }
            set
            {
                m_DeviceHandle = value;
            }
        }

        private int m_InvalidBitCount = 0;
        public int InvalidBitCount
        {
            get 
            {
                return m_InvalidBitCount;
            }

            set 
            {
                m_InvalidBitCount = value;
                int valid = DILedArray.Length - m_InvalidBitCount;
                for (int i = 0; i < valid; i++)
                    ((PictureBox)DILedArray[i]).Image = imageDIList.Images[0];
                for (int i = valid; i < DILedArray.Length; i++)
                    ((PictureBox)DILedArray[i]).Image = imageDIList.Images[2];
            }
        }

        private string m_SourceToolTip = "";
        public string SourceToolTip
        {
            get
            {
                return m_SourceToolTip;
            }
            set
            {
                m_SourceToolTip = value;
                foreach (Control ctrl in Controls)
                {
                    toolTip_DI.SetToolTip(ctrl, m_SourceToolTip);
                    foreach (Control c in ctrl.Controls)
                        toolTip_DI.SetToolTip(c, m_SourceToolTip);
                }
                toolTip_DI.SetToolTip(this, m_SourceToolTip);
            }
        }

        public void RefreshValue()
        {
            if(DeviceHandle!=IntPtr.Zero)
            {
                byte DiStatus = 0;
                uint Result = Motion.mAcm_DaqDiGetByte(DeviceHandle, m_PortNo, ref DiStatus);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    for (int i = 0; i < 8 - m_InvalidBitCount; i++)
                    {
                        if (((DiStatus >> i) & 0x01) == 1)
                        {
                            ((PictureBox)DILedArray[i]).Image = imageDIList.Images[1];
                        }
                        else
                        {
                            ((PictureBox)DILedArray[i]).Image = imageDIList.Images[0];
                        }
                    }
                    lbl_DIHex.Text = DiStatus.ToString("x");  //Hex Value
                }
            }
        }
    }
}
