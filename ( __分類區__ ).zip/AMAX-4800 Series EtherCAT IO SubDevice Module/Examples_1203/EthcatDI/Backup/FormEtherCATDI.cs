﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;
using System.Diagnostics;
namespace EthcatDI
{
    public partial class FormEtherCATDI : Form
    {
        public FormEtherCATDI()
        {
            InitializeComponent();
           // VersionIsOk = GetDevCfgDllDrvVer();
        }
        Boolean VersionIsOk = false;
        private IntPtr m_DeviceHandle = IntPtr.Zero;
        private uint DIChanNum = 0;
        DIControl[] diControl;     

        private void FormDigitalOutput_Load(object sender, EventArgs e)
        {

            int Result;
            uint Ret;
            string strTemp;
            //Get Driver Version Number, this step is not necessary
            string ErrorMessage;
          //  if (VersionIsOk == false)
         //   {
                //  return;
          //  }
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot，Perhaps the opposite
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ErrorMessage = GlobalVar.GetErrorMessage((uint)Result);
                MessageBox.Show(strTemp + "\r\nError Message:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //If you want to get the device number of fixed equipment，you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
            
        }

        private void InitialDIChannel()
        {
            uint DIPortNumber = DIChanNum / 8;
            diControl = new DIControl[DIPortNumber];
            pn_DIValue.SuspendLayout();
            for (uint i = 0; i < DIPortNumber; i++)
            {
                diControl[i] = new DIControl();
                diControl[i].Name = "diControl" + i.ToString();
                diControl[i].PortNo = (ushort)i;
                diControl[i].DeviceHandle = m_DeviceHandle;
                diControl[i].Left = 0;
                if (i == 0)
                {
                    diControl[i].Top = 0;
                }
                else
                {
                    diControl[i].Top = (int)i * diControl[i].Height;
                }
                pn_DIValue.Controls.Add(diControl[i]);
            }
            pn_DIValue.ResumeLayout();
        }
        public void RefreshDIValue()
        {
            uint DIPortNumber = DIChanNum / 8;
            for (uint i = 0; i < DIPortNumber; i++)
            {
                if (diControl[i] != null)
                {
                    diControl[i].RefreshValue();
                }
            }
        }
       

        private void btn_OpenBoard_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            uint retry = 0, SlaveOnRing0 = 0, SlaveOnRing1 = 0;
            bool rescan = false;
            string strTemp;
            string ErrorMessage;
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            do
            {
                Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Device Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ErrorMessage = GlobalVar.GetErrorMessage(Result);
                    MessageBox.Show(strTemp + "\r\nError Message:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    retry++;
                    rescan = true;
                    if (retry > 10)
                        return;
                    System.Threading.Thread.Sleep(1000);
                }
                else
                {
					//User must check the slave count on each ring match the actual connection.
					//We recommend using following code that was marked to check connection status.
					//The example expect there is one slave on Motion ring and user does not connect any slave on IO ring.
					rescan = false;
					/*Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R0, ref SlaveOnRing0);
					Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R1, ref SlaveOnRing1);
					if (SlaveOnRing0 != 1 || SlaveOnRing1 != 0)
					{
						MessageBox.Show("Retrieved the slave states do not match the actual connection.", "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error);
						Motion.mAcm_DevReOpen(m_DeviceHandle);
						Motion.mAcm_DevClose(ref m_DeviceHandle);
						System.Threading.Thread.Sleep(1000);
						retry = 0;
						rescan = true;
					}*/
                }
            } while (rescan == true); 
            ulong dDevType;
            dDevType = (DeviceNum & 0xff000000) >> 24;
            GlobalVar.m_DeviceHandle = m_DeviceHandle;
            pn_DIValue.Controls.Clear();
            if (dDevType == (ulong)DevTypeID.EtherCAT)
            {
                this.OpenConfigFile.FileName = "";
                if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                    return;
                Result = Motion.mAcm_LoadENI( m_DeviceHandle, OpenConfigFile.FileName);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Load ENI Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ErrorMessage = GlobalVar.GetErrorMessage(Result);
                    MessageBox.Show(ErrorMessage + "\r\nError Message:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }                
            }
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DaqDiMaxChan, ref  DIChanNum);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get Property FT_DaqDiMaxChan Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ErrorMessage = GlobalVar.GetErrorMessage(Result);
                MessageBox.Show(ErrorMessage + "\r\nError Message:" + ErrorMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            InitialDIChannel();
            m_bInit = true;
            timer1.Enabled = true;
        }

        private void btn_CloseBoard_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();//Close Board
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }
        
        //User-defined API to close board
        private void CloseBoardOrForm()
        {
            if (m_bInit)
            {
                //Close a device
                pn_DIValue.Controls.Clear();
                Motion.mAcm_DevClose(ref GlobalVar.m_DeviceHandle);
                timer1.Enabled = false;
                m_bInit = false;

            }
        }
        //get the device number of fixed equipment
        private UInt32 GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID)
        {
            return (UInt32)(DevType << 24 | BoardID << 12 | MasterRingNo << 8 | SlaveBoardID);
        }
        private Boolean GetDevCfgDllDrvVer()
        {
            string fileName = "";
            FileVersionInfo myFileVersionInfo;
            string FileVersion = "";
            fileName = Environment.SystemDirectory + "\\ADVMOT.dll";//SystemDirectory指System32 
            myFileVersionInfo = FileVersionInfo.GetVersionInfo(fileName);
            FileVersion = myFileVersionInfo.FileVersion;
            string DetailMessage;
            string[] strSplit = FileVersion.Split(',');
            if (Convert.ToUInt16(strSplit[0]) < 2)
            {
                DetailMessage = "The Driver Version  Is Too Low" + "\r\nYou can update the driver through the driver installation package ";
                DetailMessage = DetailMessage + "\r\nThe Current Driver Version Number is " + FileVersion;
                DetailMessage = DetailMessage + "\r\nYou need to update the driver to 2.0.0.0 version and above";
                MessageBox.Show(DetailMessage, "EthcatDI", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            RefreshDIValue();
        }

        private void btn_DISetup_Click(object sender, EventArgs e)
        {
            FormEtherCATDISetup frmDISetup = new FormEtherCATDISetup(DIChanNum);
            DialogResult ret = frmDISetup.ShowDialog();
        }
    }
}