﻿namespace EthcatDI
{
    partial class DIControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DIControl));
            this.gpLow = new System.Windows.Forms.GroupBox();
            this.pbox_DI0 = new System.Windows.Forms.PictureBox();
            this.pbox_DI1 = new System.Windows.Forms.PictureBox();
            this.pbox_DI2 = new System.Windows.Forms.PictureBox();
            this.pbox_DI3 = new System.Windows.Forms.PictureBox();
            this.gpHi = new System.Windows.Forms.GroupBox();
            this.pbox_DI4 = new System.Windows.Forms.PictureBox();
            this.pbox_DI5 = new System.Windows.Forms.PictureBox();
            this.pbox_DI6 = new System.Windows.Forms.PictureBox();
            this.pbox_DI7 = new System.Windows.Forms.PictureBox();
            this.panel_DIHex = new System.Windows.Forms.Panel();
            this.lbl_DIHex = new System.Windows.Forms.Label();
            this.panel_DIPortNO = new System.Windows.Forms.Panel();
            this.lbl_DIPortNo = new System.Windows.Forms.Label();
            this.imageDIList = new System.Windows.Forms.ImageList(this.components);
            this.imageDIList1 = new System.Windows.Forms.ImageList(this.components);
            this.toolTip_DI = new System.Windows.Forms.ToolTip(this.components);
            this.gpLow.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI3)).BeginInit();
            this.gpHi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI7)).BeginInit();
            this.panel_DIHex.SuspendLayout();
            this.panel_DIPortNO.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpLow
            // 
            this.gpLow.Controls.Add(this.pbox_DI0);
            this.gpLow.Controls.Add(this.pbox_DI1);
            this.gpLow.Controls.Add(this.pbox_DI2);
            this.gpLow.Controls.Add(this.pbox_DI3);
            this.gpLow.Location = new System.Drawing.Point(227, 1);
            this.gpLow.Name = "gpLow";
            this.gpLow.Size = new System.Drawing.Size(155, 42);
            this.gpLow.TabIndex = 20;
            this.gpLow.TabStop = false;
            // 
            // pbox_DI0
            // 
            this.pbox_DI0.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DI0.Location = new System.Drawing.Point(121, 12);
            this.pbox_DI0.Name = "pbox_DI0";
            this.pbox_DI0.Size = new System.Drawing.Size(25, 25);
            this.pbox_DI0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DI0.TabIndex = 13;
            this.pbox_DI0.TabStop = false;
            this.pbox_DI0.Tag = "";
            // 
            // pbox_DI1
            // 
            this.pbox_DI1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DI1.Location = new System.Drawing.Point(84, 12);
            this.pbox_DI1.Name = "pbox_DI1";
            this.pbox_DI1.Size = new System.Drawing.Size(25, 25);
            this.pbox_DI1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DI1.TabIndex = 14;
            this.pbox_DI1.TabStop = false;
            this.pbox_DI1.Tag = "";
            // 
            // pbox_DI2
            // 
            this.pbox_DI2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DI2.Location = new System.Drawing.Point(47, 12);
            this.pbox_DI2.Name = "pbox_DI2";
            this.pbox_DI2.Size = new System.Drawing.Size(25, 25);
            this.pbox_DI2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DI2.TabIndex = 12;
            this.pbox_DI2.TabStop = false;
            this.pbox_DI2.Tag = "";
            // 
            // pbox_DI3
            // 
            this.pbox_DI3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DI3.Location = new System.Drawing.Point(10, 12);
            this.pbox_DI3.Name = "pbox_DI3";
            this.pbox_DI3.Size = new System.Drawing.Size(25, 25);
            this.pbox_DI3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DI3.TabIndex = 11;
            this.pbox_DI3.TabStop = false;
            this.pbox_DI3.Tag = "";
            // 
            // gpHi
            // 
            this.gpHi.Controls.Add(this.pbox_DI4);
            this.gpHi.Controls.Add(this.pbox_DI5);
            this.gpHi.Controls.Add(this.pbox_DI6);
            this.gpHi.Controls.Add(this.pbox_DI7);
            this.gpHi.Location = new System.Drawing.Point(59, 1);
            this.gpHi.Name = "gpHi";
            this.gpHi.Size = new System.Drawing.Size(155, 42);
            this.gpHi.TabIndex = 19;
            this.gpHi.TabStop = false;
            // 
            // pbox_DI4
            // 
            this.pbox_DI4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DI4.Location = new System.Drawing.Point(121, 12);
            this.pbox_DI4.Name = "pbox_DI4";
            this.pbox_DI4.Size = new System.Drawing.Size(25, 25);
            this.pbox_DI4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DI4.TabIndex = 13;
            this.pbox_DI4.TabStop = false;
            this.pbox_DI4.Tag = "";
            // 
            // pbox_DI5
            // 
            this.pbox_DI5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DI5.Location = new System.Drawing.Point(84, 12);
            this.pbox_DI5.Name = "pbox_DI5";
            this.pbox_DI5.Size = new System.Drawing.Size(25, 25);
            this.pbox_DI5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DI5.TabIndex = 14;
            this.pbox_DI5.TabStop = false;
            this.pbox_DI5.Tag = "";
            // 
            // pbox_DI6
            // 
            this.pbox_DI6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DI6.Location = new System.Drawing.Point(47, 12);
            this.pbox_DI6.Name = "pbox_DI6";
            this.pbox_DI6.Size = new System.Drawing.Size(25, 25);
            this.pbox_DI6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DI6.TabIndex = 12;
            this.pbox_DI6.TabStop = false;
            this.pbox_DI6.Tag = "";
            // 
            // pbox_DI7
            // 
            this.pbox_DI7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DI7.Location = new System.Drawing.Point(10, 12);
            this.pbox_DI7.Name = "pbox_DI7";
            this.pbox_DI7.Size = new System.Drawing.Size(25, 25);
            this.pbox_DI7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DI7.TabIndex = 11;
            this.pbox_DI7.TabStop = false;
            this.pbox_DI7.Tag = "";
            // 
            // panel_DIHex
            // 
            this.panel_DIHex.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_DIHex.Controls.Add(this.lbl_DIHex);
            this.panel_DIHex.Location = new System.Drawing.Point(402, 8);
            this.panel_DIHex.Name = "panel_DIHex";
            this.panel_DIHex.Size = new System.Drawing.Size(32, 32);
            this.panel_DIHex.TabIndex = 18;
            // 
            // lbl_DIHex
            // 
            this.lbl_DIHex.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_DIHex.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_DIHex.Location = new System.Drawing.Point(0, 0);
            this.lbl_DIHex.Name = "lbl_DIHex";
            this.lbl_DIHex.Size = new System.Drawing.Size(28, 28);
            this.lbl_DIHex.TabIndex = 0;
            this.lbl_DIHex.Text = "0";
            this.lbl_DIHex.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_DIPortNO
            // 
            this.panel_DIPortNO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_DIPortNO.Controls.Add(this.lbl_DIPortNo);
            this.panel_DIPortNO.Location = new System.Drawing.Point(10, 8);
            this.panel_DIPortNO.Name = "panel_DIPortNO";
            this.panel_DIPortNO.Size = new System.Drawing.Size(32, 32);
            this.panel_DIPortNO.TabIndex = 17;
            // 
            // lbl_DIPortNo
            // 
            this.lbl_DIPortNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_DIPortNo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_DIPortNo.Location = new System.Drawing.Point(0, 0);
            this.lbl_DIPortNo.Name = "lbl_DIPortNo";
            this.lbl_DIPortNo.Size = new System.Drawing.Size(28, 28);
            this.lbl_DIPortNo.TabIndex = 0;
            this.lbl_DIPortNo.Text = "0";
            this.lbl_DIPortNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // imageDIList
            // 
            this.imageDIList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageDIList.ImageStream")));
            this.imageDIList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageDIList.Images.SetKeyName(0, "DI_Off_32.png");
            this.imageDIList.Images.SetKeyName(1, "DI_On_32.png");
            this.imageDIList.Images.SetKeyName(2, "disable.bmp");
            // 
            // imageDIList1
            // 
            this.imageDIList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageDIList1.ImageStream")));
            this.imageDIList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageDIList1.Images.SetKeyName(0, "Green.png");
            this.imageDIList1.Images.SetKeyName(1, "DarkGreen.png");
            // 
            // toolTip_DI
            // 
            this.toolTip_DI.UseFading = false;
            // 
            // DIControl
            // 
            this.Controls.Add(this.gpLow);
            this.Controls.Add(this.gpHi);
            this.Controls.Add(this.panel_DIHex);
            this.Controls.Add(this.panel_DIPortNO);
            this.Name = "DIControl";
            this.Size = new System.Drawing.Size(440, 42);
            this.Load += new System.EventHandler(this.DIControl_Load);
            this.gpLow.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI3)).EndInit();
            this.gpHi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DI7)).EndInit();
            this.panel_DIHex.ResumeLayout(false);
            this.panel_DIPortNO.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbox_DI0;
        private System.Windows.Forms.PictureBox pbox_DI1;
        private System.Windows.Forms.PictureBox pbox_DI2;
        private System.Windows.Forms.PictureBox pbox_DI3;
        private System.Windows.Forms.PictureBox pbox_DI4;
        private System.Windows.Forms.PictureBox pbox_DI5;
        private System.Windows.Forms.PictureBox pbox_DI6;
        private System.Windows.Forms.PictureBox pbox_DI7;
        private System.Windows.Forms.Panel panel_DIHex;
        private System.Windows.Forms.Label lbl_DIHex;
        private System.Windows.Forms.Panel panel_DIPortNO;
        private System.Windows.Forms.Label lbl_DIPortNo;
        private System.Windows.Forms.ImageList imageDIList;
        private System.Windows.Forms.ImageList imageDIList1;
        private System.Windows.Forms.ToolTip toolTip_DI;
        public System.Windows.Forms.GroupBox gpLow;
        public System.Windows.Forms.GroupBox gpHi;
    }
}
