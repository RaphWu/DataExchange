﻿namespace GMSystem
{
    partial class FormPpoint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.SaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.panel6 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txb_PointID = new System.Windows.Forms.TextBox();
            this.btn_SetPoint = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.txb_sPoint_R = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txb_sPoint_Z = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txb_sPoint_Y = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txb_sPoint_X = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btn_SavePoint = new System.Windows.Forms.Button();
            this.btn_ResetPoint = new System.Windows.Forms.Button();
            this.btn_LoadPoint = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dgv_Point = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Point)).BeginInit();
            this.SuspendLayout();
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openFileDialog1";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.groupBox3);
            this.panel6.Controls.Add(this.btn_SavePoint);
            this.panel6.Controls.Add(this.btn_ResetPoint);
            this.panel6.Controls.Add(this.btn_LoadPoint);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(330, 184);
            this.panel6.TabIndex = 34;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txb_PointID);
            this.groupBox3.Controls.Add(this.btn_SetPoint);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.txb_sPoint_R);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.txb_sPoint_Z);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.txb_sPoint_Y);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.txb_sPoint_X);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(13, 42);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(303, 129);
            this.groupBox3.TabIndex = 36;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Set Point";
            // 
            // txb_PointID
            // 
            this.txb_PointID.Location = new System.Drawing.Point(200, 46);
            this.txb_PointID.Name = "txb_PointID";
            this.txb_PointID.Size = new System.Drawing.Size(81, 21);
            this.txb_PointID.TabIndex = 11;
            this.txb_PointID.Text = "0";
            this.txb_PointID.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_SetPoint
            // 
            this.btn_SetPoint.Location = new System.Drawing.Point(200, 99);
            this.btn_SetPoint.Name = "btn_SetPoint";
            this.btn_SetPoint.Size = new System.Drawing.Size(81, 23);
            this.btn_SetPoint.TabIndex = 10;
            this.btn_SetPoint.Text = "Set";
            this.btn_SetPoint.UseVisualStyleBackColor = true;
            this.btn_SetPoint.Click += new System.EventHandler(this.btn_SetPoint_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(216, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 8;
            this.label15.Text = "Point ID";
            // 
            // txb_sPoint_R
            // 
            this.txb_sPoint_R.Location = new System.Drawing.Point(42, 100);
            this.txb_sPoint_R.Name = "txb_sPoint_R";
            this.txb_sPoint_R.Size = new System.Drawing.Size(124, 21);
            this.txb_sPoint_R.TabIndex = 7;
            this.txb_sPoint_R.Text = "0";
            this.txb_sPoint_R.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(19, 104);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(17, 12);
            this.label14.TabIndex = 6;
            this.label14.Text = "R:";
            // 
            // txb_sPoint_Z
            // 
            this.txb_sPoint_Z.Location = new System.Drawing.Point(42, 73);
            this.txb_sPoint_Z.Name = "txb_sPoint_Z";
            this.txb_sPoint_Z.Size = new System.Drawing.Size(124, 21);
            this.txb_sPoint_Z.TabIndex = 5;
            this.txb_sPoint_Z.Text = "0";
            this.txb_sPoint_Z.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 77);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 12);
            this.label13.TabIndex = 4;
            this.label13.Text = "Z:";
            // 
            // txb_sPoint_Y
            // 
            this.txb_sPoint_Y.Location = new System.Drawing.Point(42, 46);
            this.txb_sPoint_Y.Name = "txb_sPoint_Y";
            this.txb_sPoint_Y.Size = new System.Drawing.Size(124, 21);
            this.txb_sPoint_Y.TabIndex = 3;
            this.txb_sPoint_Y.Text = "0";
            this.txb_sPoint_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(19, 50);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 12);
            this.label12.TabIndex = 2;
            this.label12.Text = "Y:";
            // 
            // txb_sPoint_X
            // 
            this.txb_sPoint_X.Location = new System.Drawing.Point(42, 19);
            this.txb_sPoint_X.Name = "txb_sPoint_X";
            this.txb_sPoint_X.Size = new System.Drawing.Size(124, 21);
            this.txb_sPoint_X.TabIndex = 1;
            this.txb_sPoint_X.Text = "0";
            this.txb_sPoint_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(17, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "X:";
            // 
            // btn_SavePoint
            // 
            this.btn_SavePoint.Location = new System.Drawing.Point(114, 13);
            this.btn_SavePoint.Name = "btn_SavePoint";
            this.btn_SavePoint.Size = new System.Drawing.Size(101, 23);
            this.btn_SavePoint.TabIndex = 35;
            this.btn_SavePoint.Text = "Save Point";
            this.btn_SavePoint.UseVisualStyleBackColor = true;
            this.btn_SavePoint.Click += new System.EventHandler(this.btn_SavePoint_Click);
            // 
            // btn_ResetPoint
            // 
            this.btn_ResetPoint.Location = new System.Drawing.Point(215, 12);
            this.btn_ResetPoint.Name = "btn_ResetPoint";
            this.btn_ResetPoint.Size = new System.Drawing.Size(101, 23);
            this.btn_ResetPoint.TabIndex = 34;
            this.btn_ResetPoint.Text = "Reset Point";
            this.btn_ResetPoint.UseVisualStyleBackColor = true;
            this.btn_ResetPoint.Click += new System.EventHandler(this.btn_ResetPoint_Click);
            // 
            // btn_LoadPoint
            // 
            this.btn_LoadPoint.Location = new System.Drawing.Point(13, 13);
            this.btn_LoadPoint.Name = "btn_LoadPoint";
            this.btn_LoadPoint.Size = new System.Drawing.Size(101, 23);
            this.btn_LoadPoint.TabIndex = 33;
            this.btn_LoadPoint.Text = "Load Point";
            this.btn_LoadPoint.UseVisualStyleBackColor = true;
            this.btn_LoadPoint.Click += new System.EventHandler(this.btn_LoadPoint_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 184);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(330, 219);
            this.panel1.TabIndex = 35;
            // 
            // panel5
            // 
            this.panel5.AutoScroll = true;
            this.panel5.Controls.Add(this.dgv_Point);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(14, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(301, 205);
            this.panel5.TabIndex = 3;
            // 
            // dgv_Point
            // 
            this.dgv_Point.AllowUserToAddRows = false;
            this.dgv_Point.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Point.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Point.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Point.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dgv_Point.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_Point.Location = new System.Drawing.Point(0, 0);
            this.dgv_Point.Name = "dgv_Point";
            this.dgv_Point.ReadOnly = true;
            this.dgv_Point.RowHeadersWidth = 20;
            this.dgv_Point.RowTemplate.Height = 23;
            this.dgv_Point.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Point.Size = new System.Drawing.Size(301, 205);
            this.dgv_Point.TabIndex = 37;
            this.dgv_Point.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Point_CellClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Point";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 60;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "Value";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(14, 205);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(301, 14);
            this.panel4.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(315, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(15, 219);
            this.panel3.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(14, 219);
            this.panel2.TabIndex = 0;
            // 
            // FormPpoint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 403);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel6);
            this.Name = "FormPpoint";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "P Point Operation";
            this.TopMost = true;
            this.panel6.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Point)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.SaveFileDialog SaveFileDialog;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txb_PointID;
        private System.Windows.Forms.Button btn_SetPoint;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txb_sPoint_R;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txb_sPoint_Z;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txb_sPoint_Y;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txb_sPoint_X;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btn_SavePoint;
        private System.Windows.Forms.Button btn_ResetPoint;
        private System.Windows.Forms.Button btn_LoadPoint;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dgv_Point;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
    }
}