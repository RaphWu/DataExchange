﻿namespace Path
{
    partial class Helix
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txb_Agl2 = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.txb_Agl1 = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.txb_End8 = new System.Windows.Forms.TextBox();
            this.Label28 = new System.Windows.Forms.Label();
            this.txb_End7 = new System.Windows.Forms.TextBox();
            this.Label27 = new System.Windows.Forms.Label();
            this.txb_End6 = new System.Windows.Forms.TextBox();
            this.Label26 = new System.Windows.Forms.Label();
            this.txb_End5 = new System.Windows.Forms.TextBox();
            this.Label25 = new System.Windows.Forms.Label();
            this.txb_End4 = new System.Windows.Forms.TextBox();
            this.Label24 = new System.Windows.Forms.Label();
            this.txb_Cen3 = new System.Windows.Forms.TextBox();
            this.Label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButtonCW = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.txb_End3 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txb_End2 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txb_End1 = new System.Windows.Forms.TextBox();
            this.txb_Cen2 = new System.Windows.Forms.TextBox();
            this.txb_Cen1 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_OK
            // 
            this.btn_OK.Location = new System.Drawing.Point(130, 242);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_OK.TabIndex = 57;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(267, 242);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 58;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txb_Agl2);
            this.groupBox8.Controls.Add(this.Label3);
            this.groupBox8.Controls.Add(this.txb_Agl1);
            this.groupBox8.Controls.Add(this.Label1);
            this.groupBox8.Controls.Add(this.txb_End8);
            this.groupBox8.Controls.Add(this.Label28);
            this.groupBox8.Controls.Add(this.txb_End7);
            this.groupBox8.Controls.Add(this.Label27);
            this.groupBox8.Controls.Add(this.txb_End6);
            this.groupBox8.Controls.Add(this.Label26);
            this.groupBox8.Controls.Add(this.txb_End5);
            this.groupBox8.Controls.Add(this.Label25);
            this.groupBox8.Controls.Add(this.txb_End4);
            this.groupBox8.Controls.Add(this.Label24);
            this.groupBox8.Controls.Add(this.txb_Cen3);
            this.groupBox8.Controls.Add(this.Label23);
            this.groupBox8.Controls.Add(this.label20);
            this.groupBox8.Controls.Add(this.radioButton1);
            this.groupBox8.Controls.Add(this.radioButtonCW);
            this.groupBox8.Controls.Add(this.label2);
            this.groupBox8.Controls.Add(this.txb_End3);
            this.groupBox8.Controls.Add(this.label7);
            this.groupBox8.Controls.Add(this.txb_End2);
            this.groupBox8.Controls.Add(this.label19);
            this.groupBox8.Controls.Add(this.txb_End1);
            this.groupBox8.Controls.Add(this.txb_Cen2);
            this.groupBox8.Controls.Add(this.txb_Cen1);
            this.groupBox8.Controls.Add(this.label21);
            this.groupBox8.Controls.Add(this.label22);
            this.groupBox8.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox8.Location = new System.Drawing.Point(21, 17);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(473, 203);
            this.groupBox8.TabIndex = 62;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Spiral Path";
            // 
            // txb_Agl2
            // 
            this.txb_Agl2.Location = new System.Drawing.Point(203, 133);
            this.txb_Agl2.Name = "txb_Agl2";
            this.txb_Agl2.Size = new System.Drawing.Size(100, 21);
            this.txb_Agl2.TabIndex = 72;
            this.txb_Agl2.Text = "90";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(165, 138);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(35, 12);
            this.Label3.TabIndex = 71;
            this.Label3.Text = "Agl2:";
            // 
            // txb_Agl1
            // 
            this.txb_Agl1.Location = new System.Drawing.Point(55, 133);
            this.txb_Agl1.Name = "txb_Agl1";
            this.txb_Agl1.Size = new System.Drawing.Size(100, 21);
            this.txb_Agl1.TabIndex = 70;
            this.txb_Agl1.Text = "90";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(18, 140);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(35, 12);
            this.Label1.TabIndex = 69;
            this.Label1.Text = "Agl1:";
            // 
            // txb_End8
            // 
            this.txb_End8.Location = new System.Drawing.Point(202, 105);
            this.txb_End8.Name = "txb_End8";
            this.txb_End8.Size = new System.Drawing.Size(100, 21);
            this.txb_End8.TabIndex = 68;
            this.txb_End8.Text = "1000";
            // 
            // Label28
            // 
            this.Label28.AutoSize = true;
            this.Label28.Location = new System.Drawing.Point(165, 112);
            this.Label28.Name = "Label28";
            this.Label28.Size = new System.Drawing.Size(35, 12);
            this.Label28.TabIndex = 67;
            this.Label28.Text = "End8:";
            // 
            // txb_End7
            // 
            this.txb_End7.Location = new System.Drawing.Point(55, 106);
            this.txb_End7.Name = "txb_End7";
            this.txb_End7.Size = new System.Drawing.Size(100, 21);
            this.txb_End7.TabIndex = 66;
            this.txb_End7.Text = "1000";
            // 
            // Label27
            // 
            this.Label27.AutoSize = true;
            this.Label27.Location = new System.Drawing.Point(18, 112);
            this.Label27.Name = "Label27";
            this.Label27.Size = new System.Drawing.Size(35, 12);
            this.Label27.TabIndex = 65;
            this.Label27.Text = "End7:";
            // 
            // txb_End6
            // 
            this.txb_End6.Location = new System.Drawing.Point(353, 78);
            this.txb_End6.Name = "txb_End6";
            this.txb_End6.Size = new System.Drawing.Size(100, 21);
            this.txb_End6.TabIndex = 64;
            this.txb_End6.Text = "1000";
            // 
            // Label26
            // 
            this.Label26.AutoSize = true;
            this.Label26.Location = new System.Drawing.Point(317, 83);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(35, 12);
            this.Label26.TabIndex = 63;
            this.Label26.Text = "End6:";
            // 
            // txb_End5
            // 
            this.txb_End5.Location = new System.Drawing.Point(202, 78);
            this.txb_End5.Name = "txb_End5";
            this.txb_End5.Size = new System.Drawing.Size(100, 21);
            this.txb_End5.TabIndex = 62;
            this.txb_End5.Text = "1000";
            // 
            // Label25
            // 
            this.Label25.AutoSize = true;
            this.Label25.Location = new System.Drawing.Point(166, 84);
            this.Label25.Name = "Label25";
            this.Label25.Size = new System.Drawing.Size(35, 12);
            this.Label25.TabIndex = 61;
            this.Label25.Text = "End5:";
            // 
            // txb_End4
            // 
            this.txb_End4.Location = new System.Drawing.Point(55, 79);
            this.txb_End4.Name = "txb_End4";
            this.txb_End4.Size = new System.Drawing.Size(100, 21);
            this.txb_End4.TabIndex = 60;
            this.txb_End4.Text = "1000";
            // 
            // Label24
            // 
            this.Label24.AutoSize = true;
            this.Label24.Location = new System.Drawing.Point(18, 85);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(35, 12);
            this.Label24.TabIndex = 59;
            this.Label24.Text = "End4:";
            // 
            // txb_Cen3
            // 
            this.txb_Cen3.Location = new System.Drawing.Point(353, 25);
            this.txb_Cen3.Name = "txb_Cen3";
            this.txb_Cen3.Size = new System.Drawing.Size(100, 21);
            this.txb_Cen3.TabIndex = 58;
            this.txb_Cen3.Text = "0";
            // 
            // Label23
            // 
            this.Label23.AutoSize = true;
            this.Label23.Location = new System.Drawing.Point(317, 31);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(35, 12);
            this.Label23.TabIndex = 57;
            this.Label23.Text = "Cen3:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(14, 172);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(89, 12);
            this.label20.TabIndex = 56;
            this.label20.Text = "Arc Direction:";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(182, 172);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(41, 16);
            this.radioButton1.TabIndex = 55;
            this.radioButton1.Text = "CCW";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButtonCW
            // 
            this.radioButtonCW.AutoSize = true;
            this.radioButtonCW.Checked = true;
            this.radioButtonCW.Location = new System.Drawing.Point(109, 170);
            this.radioButtonCW.Name = "radioButtonCW";
            this.radioButtonCW.Size = new System.Drawing.Size(35, 16);
            this.radioButtonCW.TabIndex = 54;
            this.radioButtonCW.TabStop = true;
            this.radioButtonCW.Text = "CW";
            this.radioButtonCW.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(317, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 53;
            this.label2.Text = "End3:";
            // 
            // txb_End3
            // 
            this.txb_End3.Location = new System.Drawing.Point(353, 52);
            this.txb_End3.Name = "txb_End3";
            this.txb_End3.Size = new System.Drawing.Size(100, 21);
            this.txb_End3.TabIndex = 52;
            this.txb_End3.Text = "1000";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(166, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 12);
            this.label7.TabIndex = 51;
            this.label7.Text = "End2:";
            // 
            // txb_End2
            // 
            this.txb_End2.Location = new System.Drawing.Point(202, 52);
            this.txb_End2.Name = "txb_End2";
            this.txb_End2.Size = new System.Drawing.Size(100, 21);
            this.txb_End2.TabIndex = 50;
            this.txb_End2.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(18, 59);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 12);
            this.label19.TabIndex = 48;
            this.label19.Text = "End1:";
            // 
            // txb_End1
            // 
            this.txb_End1.Location = new System.Drawing.Point(55, 52);
            this.txb_End1.Name = "txb_End1";
            this.txb_End1.Size = new System.Drawing.Size(100, 21);
            this.txb_End1.TabIndex = 49;
            this.txb_End1.Text = "16000";
            // 
            // txb_Cen2
            // 
            this.txb_Cen2.Location = new System.Drawing.Point(202, 25);
            this.txb_Cen2.Name = "txb_Cen2";
            this.txb_Cen2.Size = new System.Drawing.Size(100, 21);
            this.txb_Cen2.TabIndex = 47;
            this.txb_Cen2.Text = "0";
            // 
            // txb_Cen1
            // 
            this.txb_Cen1.Location = new System.Drawing.Point(55, 25);
            this.txb_Cen1.Name = "txb_Cen1";
            this.txb_Cen1.Size = new System.Drawing.Size(100, 21);
            this.txb_Cen1.TabIndex = 44;
            this.txb_Cen1.Text = "8000";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(165, 31);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(35, 12);
            this.label21.TabIndex = 46;
            this.label21.Text = "Cen2:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(19, 31);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(35, 12);
            this.label22.TabIndex = 45;
            this.label22.Text = "Cen1:";
            // 
            // Helix
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 274);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_OK);
            this.Name = "Helix";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Helix";
            this.Load += new System.EventHandler(this.Helix_Load);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.GroupBox groupBox8;
        internal System.Windows.Forms.TextBox txb_Agl2;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox txb_Agl1;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox txb_End8;
        internal System.Windows.Forms.Label Label28;
        internal System.Windows.Forms.TextBox txb_End7;
        internal System.Windows.Forms.Label Label27;
        internal System.Windows.Forms.TextBox txb_End6;
        internal System.Windows.Forms.Label Label26;
        internal System.Windows.Forms.TextBox txb_End5;
        internal System.Windows.Forms.Label Label25;
        internal System.Windows.Forms.TextBox txb_End4;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.TextBox txb_Cen3;
        private System.Windows.Forms.Label Label23;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RadioButton radioButton1;
        public System.Windows.Forms.RadioButton radioButtonCW;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox txb_End3;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox txb_End2;
        private System.Windows.Forms.Label label19;
        public System.Windows.Forms.TextBox txb_End1;
        public System.Windows.Forms.TextBox txb_Cen2;
        public System.Windows.Forms.TextBox txb_Cen1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
    }
}