using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Path
{
    public partial class FormAddLine : Form
    {
        public FormAddLine()
        {
            InitializeComponent();
        }

        private void FormAddLine_Load(object sender, EventArgs e)
        {
            this.AcceptButton = this.btn_OK;
            this.CancelButton = this.btn_Cancel;
            this.btn_OK.DialogResult = DialogResult.OK;
            this.btn_Cancel.DialogResult = DialogResult.Cancel;
            BtnClearEnd_Click(sender, e);
        }

        private void BtnSetEnd_Click(object sender, EventArgs e)
        {
            if (EndPointNum < 32)
            {
                EndArray[EndPointNum] = Convert.ToDouble(textBoxEnd.Text);
                listBoxEndPoints.Items.Add(textBoxEnd.Text);
                EndPointNum++;
            }
        }

        private void BtnClearEnd_Click(object sender, EventArgs e)
        {
            for (uint i = 0; i < 32; i++)
            {
                EndArray[i] = 0;
            }
            listBoxEndPoints.Items.Clear();
            EndPointNum = 0;
        }
    }
}