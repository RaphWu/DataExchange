﻿namespace Path
{
    partial class Arc
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txb_Agl = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxCen2 = new System.Windows.Forms.TextBox();
            this.textBoxEnd2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxEnd1 = new System.Windows.Forms.TextBox();
            this.textBoxCen1 = new System.Windows.Forms.TextBox();
            this.radioButtonCCW = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.radioButtonCW = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_OK
            // 
            this.btn_OK.Location = new System.Drawing.Point(54, 184);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_OK.TabIndex = 50;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(219, 184);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 51;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txb_Agl);
            this.groupBox5.Controls.Add(this.Label1);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.textBoxCen2);
            this.groupBox5.Controls.Add(this.textBoxEnd2);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.textBoxEnd1);
            this.groupBox5.Controls.Add(this.textBoxCen1);
            this.groupBox5.Controls.Add(this.radioButtonCCW);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.radioButtonCW);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox5.Location = new System.Drawing.Point(25, 15);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(315, 152);
            this.groupBox5.TabIndex = 52;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Arc Path";
            // 
            // txb_Agl
            // 
            this.txb_Agl.Location = new System.Drawing.Point(58, 82);
            this.txb_Agl.Name = "txb_Agl";
            this.txb_Agl.Size = new System.Drawing.Size(93, 21);
            this.txb_Agl.TabIndex = 50;
            this.txb_Agl.Text = "90";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(23, 84);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(29, 12);
            this.Label1.TabIndex = 50;
            this.Label1.Text = "Agl:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(159, 52);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 12);
            this.label12.TabIndex = 15;
            this.label12.Text = "End2:";
            // 
            // textBoxCen2
            // 
            this.textBoxCen2.Location = new System.Drawing.Point(59, 54);
            this.textBoxCen2.Name = "textBoxCen2";
            this.textBoxCen2.Size = new System.Drawing.Size(92, 21);
            this.textBoxCen2.TabIndex = 14;
            this.textBoxCen2.Text = "0";
            // 
            // textBoxEnd2
            // 
            this.textBoxEnd2.Location = new System.Drawing.Point(196, 53);
            this.textBoxEnd2.Name = "textBoxEnd2";
            this.textBoxEnd2.Size = new System.Drawing.Size(99, 21);
            this.textBoxEnd2.TabIndex = 16;
            this.textBoxEnd2.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 120);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 12);
            this.label9.TabIndex = 50;
            this.label9.Text = "Arc Direction:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(159, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 12);
            this.label13.TabIndex = 13;
            this.label13.Text = "End1:";
            // 
            // textBoxEnd1
            // 
            this.textBoxEnd1.Location = new System.Drawing.Point(196, 24);
            this.textBoxEnd1.Name = "textBoxEnd1";
            this.textBoxEnd1.Size = new System.Drawing.Size(99, 21);
            this.textBoxEnd1.TabIndex = 14;
            this.textBoxEnd1.Text = "16000";
            // 
            // textBoxCen1
            // 
            this.textBoxCen1.Location = new System.Drawing.Point(59, 25);
            this.textBoxCen1.Name = "textBoxCen1";
            this.textBoxCen1.Size = new System.Drawing.Size(92, 21);
            this.textBoxCen1.TabIndex = 11;
            this.textBoxCen1.Text = "8000";
            // 
            // radioButtonCCW
            // 
            this.radioButtonCCW.AutoSize = true;
            this.radioButtonCCW.Location = new System.Drawing.Point(185, 118);
            this.radioButtonCCW.Name = "radioButtonCCW";
            this.radioButtonCCW.Size = new System.Drawing.Size(41, 16);
            this.radioButtonCCW.TabIndex = 9;
            this.radioButtonCCW.Text = "CCW";
            this.radioButtonCCW.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 12);
            this.label10.TabIndex = 13;
            this.label10.Text = "Cen2:";
            // 
            // radioButtonCW
            // 
            this.radioButtonCW.AutoSize = true;
            this.radioButtonCW.Checked = true;
            this.radioButtonCW.Location = new System.Drawing.Point(122, 118);
            this.radioButtonCW.Name = "radioButtonCW";
            this.radioButtonCW.Size = new System.Drawing.Size(35, 16);
            this.radioButtonCW.TabIndex = 8;
            this.radioButtonCW.TabStop = true;
            this.radioButtonCW.Text = "CW";
            this.radioButtonCW.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(20, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 12);
            this.label11.TabIndex = 12;
            this.label11.Text = "Cen1:";
            // 
            // Arc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 230);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_OK);
            this.Name = "Arc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Arc";
            this.Load += new System.EventHandler(this.Arc_Load);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.GroupBox groupBox5;
        internal System.Windows.Forms.TextBox txb_Agl;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Label label12;
        public System.Windows.Forms.TextBox textBoxCen2;
        public System.Windows.Forms.TextBox textBoxEnd2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        public System.Windows.Forms.TextBox textBoxEnd1;
        public System.Windows.Forms.TextBox textBoxCen1;
        public System.Windows.Forms.RadioButton radioButtonCCW;
        private System.Windows.Forms.Label label10;
        public System.Windows.Forms.RadioButton radioButtonCW;
        private System.Windows.Forms.Label label11;
    }
}