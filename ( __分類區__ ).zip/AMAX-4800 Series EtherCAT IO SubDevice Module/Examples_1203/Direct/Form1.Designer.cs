﻿using Advantech.Motion;//Common Motion API
using System;
namespace Direct
{
    partial class Form1
    {         
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.listBoxEndPoint = new System.Windows.Forms.ListBox();
            this.BtnClearEnd = new System.Windows.Forms.Button();
            this.BtnSetEnd = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxEnd = new System.Windows.Forms.TextBox();
            this.cbx_Axes = new System.Windows.Forms.CheckedListBox();
            this.label74 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.rdo_Rel = new System.Windows.Forms.RadioButton();
            this.rdo_Abs = new System.Windows.Forms.RadioButton();
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnMove = new System.Windows.Forms.Button();
            this.BtnResetCounter = new System.Windows.Forms.Button();
            this.textBoxGpState = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.label7 = new System.Windows.Forms.Label();
            this.dgv_Position = new System.Windows.Forms.DataGridView();
            this.Axis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CommandPosition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_AxisState = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.buttonLoadCfg = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Position)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_AxisState)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.cbx_Axes);
            this.groupBox1.Controls.Add(this.label74);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.BtnStop);
            this.groupBox1.Controls.Add(this.BtnMove);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox1.Location = new System.Drawing.Point(16, 141);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(351, 283);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Direct Interpolation Operation";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.listBoxEndPoint);
            this.groupBox2.Controls.Add(this.BtnClearEnd);
            this.groupBox2.Controls.Add(this.BtnSetEnd);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.textBoxEnd);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox2.Location = new System.Drawing.Point(123, 20);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(217, 159);
            this.groupBox2.TabIndex = 66;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "End";
            // 
            // listBoxEndPoint
            // 
            this.listBoxEndPoint.BackColor = System.Drawing.SystemColors.Control;
            this.listBoxEndPoint.FormattingEnabled = true;
            this.listBoxEndPoint.ItemHeight = 12;
            this.listBoxEndPoint.Location = new System.Drawing.Point(11, 20);
            this.listBoxEndPoint.Name = "listBoxEndPoint";
            this.listBoxEndPoint.Size = new System.Drawing.Size(98, 124);
            this.listBoxEndPoint.TabIndex = 42;
            // 
            // BtnClearEnd
            // 
            this.BtnClearEnd.Location = new System.Drawing.Point(124, 115);
            this.BtnClearEnd.Name = "BtnClearEnd";
            this.BtnClearEnd.Size = new System.Drawing.Size(75, 29);
            this.BtnClearEnd.TabIndex = 12;
            this.BtnClearEnd.Text = "Clear";
            this.BtnClearEnd.UseVisualStyleBackColor = true;
            this.BtnClearEnd.Click += new System.EventHandler(this.BtnClearEnd_Click);
            // 
            // BtnSetEnd
            // 
            this.BtnSetEnd.Location = new System.Drawing.Point(124, 78);
            this.BtnSetEnd.Name = "BtnSetEnd";
            this.BtnSetEnd.Size = new System.Drawing.Size(75, 29);
            this.BtnSetEnd.TabIndex = 9;
            this.BtnSetEnd.Text = "Add End";
            this.BtnSetEnd.UseVisualStyleBackColor = true;
            this.BtnSetEnd.Click += new System.EventHandler(this.BtnSetEnd_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(119, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "EndPoint:";
            // 
            // textBoxEnd
            // 
            this.textBoxEnd.Location = new System.Drawing.Point(118, 44);
            this.textBoxEnd.Name = "textBoxEnd";
            this.textBoxEnd.Size = new System.Drawing.Size(88, 22);
            this.textBoxEnd.TabIndex = 11;
            this.textBoxEnd.Text = "10000";
            // 
            // cbx_Axes
            // 
            this.cbx_Axes.CheckOnClick = true;
            this.cbx_Axes.FormattingEnabled = true;
            this.cbx_Axes.Location = new System.Drawing.Point(11, 41);
            this.cbx_Axes.Name = "cbx_Axes";
            this.cbx_Axes.Size = new System.Drawing.Size(100, 123);
            this.cbx_Axes.TabIndex = 65;
            this.cbx_Axes.SelectedIndexChanged += new System.EventHandler(this.cbx_Axes_SelectedIndexChanged);
            // 
            // label74
            // 
            this.label74.Location = new System.Drawing.Point(9, 20);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(95, 14);
            this.label74.TabIndex = 64;
            this.label74.Text = "Operation Axes:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.rdo_Rel);
            this.groupBox4.Controls.Add(this.rdo_Abs);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox4.Location = new System.Drawing.Point(11, 193);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(329, 47);
            this.groupBox4.TabIndex = 63;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Movement Mode";
            // 
            // rdo_Rel
            // 
            this.rdo_Rel.AutoSize = true;
            this.rdo_Rel.Checked = true;
            this.rdo_Rel.Location = new System.Drawing.Point(226, 20);
            this.rdo_Rel.Name = "rdo_Rel";
            this.rdo_Rel.Size = new System.Drawing.Size(61, 16);
            this.rdo_Rel.TabIndex = 7;
            this.rdo_Rel.TabStop = true;
            this.rdo_Rel.Text = "Relative";
            this.rdo_Rel.UseVisualStyleBackColor = true;
            // 
            // rdo_Abs
            // 
            this.rdo_Abs.AutoSize = true;
            this.rdo_Abs.Location = new System.Drawing.Point(42, 20);
            this.rdo_Abs.Name = "rdo_Abs";
            this.rdo_Abs.Size = new System.Drawing.Size(64, 16);
            this.rdo_Abs.TabIndex = 6;
            this.rdo_Abs.Text = "Absolute";
            this.rdo_Abs.UseVisualStyleBackColor = true;
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(222, 252);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(86, 25);
            this.BtnStop.TabIndex = 9;
            this.BtnStop.Text = "Stop";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // BtnMove
            // 
            this.BtnMove.Location = new System.Drawing.Point(71, 252);
            this.BtnMove.Name = "BtnMove";
            this.BtnMove.Size = new System.Drawing.Size(83, 25);
            this.BtnMove.TabIndex = 8;
            this.BtnMove.Text = "Move";
            this.BtnMove.UseVisualStyleBackColor = true;
            this.BtnMove.Click += new System.EventHandler(this.BtnMove_Click);
            // 
            // BtnResetCounter
            // 
            this.BtnResetCounter.Location = new System.Drawing.Point(415, 241);
            this.BtnResetCounter.Name = "BtnResetCounter";
            this.BtnResetCounter.Size = new System.Drawing.Size(105, 25);
            this.BtnResetCounter.TabIndex = 15;
            this.BtnResetCounter.Text = "Reset Counter";
            this.BtnResetCounter.UseVisualStyleBackColor = true;
            this.BtnResetCounter.Click += new System.EventHandler(this.BtnResetCounter_Click);
            // 
            // textBoxGpState
            // 
            this.textBoxGpState.Location = new System.Drawing.Point(542, 281);
            this.textBoxGpState.Name = "textBoxGpState";
            this.textBoxGpState.ReadOnly = true;
            this.textBoxGpState.Size = new System.Drawing.Size(152, 22);
            this.textBoxGpState.TabIndex = 17;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(461, 286);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 12);
            this.label13.TabIndex = 16;
            this.label13.Text = "Group State:";
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(591, 241);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(105, 25);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "Reset Error";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            this.BtnResetErr.Click += new System.EventHandler(this.BtnResetErr_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openConfigFileDialog";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(386, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 12);
            this.label7.TabIndex = 17;
            this.label7.Text = "Position:";
            // 
            // dgv_Position
            // 
            this.dgv_Position.AllowUserToAddRows = false;
            this.dgv_Position.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Position.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Position.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Position.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Axis,
            this.CommandPosition});
            this.dgv_Position.Location = new System.Drawing.Point(384, 27);
            this.dgv_Position.Name = "dgv_Position";
            this.dgv_Position.ReadOnly = true;
            this.dgv_Position.RowHeadersVisible = false;
            this.dgv_Position.RowHeadersWidth = 10;
            this.dgv_Position.RowTemplate.Height = 23;
            this.dgv_Position.Size = new System.Drawing.Size(163, 203);
            this.dgv_Position.TabIndex = 18;
            // 
            // Axis
            // 
            this.Axis.HeaderText = "Axis";
            this.Axis.Name = "Axis";
            this.Axis.ReadOnly = true;
            this.Axis.Width = 60;
            // 
            // CommandPosition
            // 
            this.CommandPosition.HeaderText = "Cmd Position";
            this.CommandPosition.Name = "CommandPosition";
            this.CommandPosition.ReadOnly = true;
            // 
            // dgv_AxisState
            // 
            this.dgv_AxisState.AllowUserToAddRows = false;
            this.dgv_AxisState.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_AxisState.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_AxisState.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_AxisState.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dgv_AxisState.Location = new System.Drawing.Point(562, 27);
            this.dgv_AxisState.Name = "dgv_AxisState";
            this.dgv_AxisState.ReadOnly = true;
            this.dgv_AxisState.RowHeadersVisible = false;
            this.dgv_AxisState.RowHeadersWidth = 10;
            this.dgv_AxisState.RowTemplate.Height = 23;
            this.dgv_AxisState.Size = new System.Drawing.Size(163, 203);
            this.dgv_AxisState.TabIndex = 19;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Axis";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 60;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "State";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(563, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 12);
            this.label8.TabIndex = 20;
            this.label8.Text = "Axis State:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.buttonLoadCfg);
            this.groupBox6.Controls.Add(this.BtnServo);
            this.groupBox6.Controls.Add(this.BtnCloseBoard);
            this.groupBox6.Controls.Add(this.BtnOpenBoard);
            this.groupBox6.Controls.Add(this.CmbAvailableDevice);
            this.groupBox6.Controls.Add(this.label1);
            this.groupBox6.Location = new System.Drawing.Point(16, 13);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(351, 116);
            this.groupBox6.TabIndex = 21;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Device Operate";
            // 
            // buttonLoadCfg
            // 
            this.buttonLoadCfg.Location = new System.Drawing.Point(66, 79);
            this.buttonLoadCfg.Name = "buttonLoadCfg";
            this.buttonLoadCfg.Size = new System.Drawing.Size(88, 25);
            this.buttonLoadCfg.TabIndex = 31;
            this.buttonLoadCfg.Text = "Load Config";
            this.buttonLoadCfg.UseVisualStyleBackColor = true;
            this.buttonLoadCfg.Click += new System.EventHandler(this.buttonLoadCfg_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(203, 79);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(88, 25);
            this.BtnServo.TabIndex = 17;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(203, 48);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(88, 25);
            this.BtnCloseBoard.TabIndex = 16;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(66, 48);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(88, 25);
            this.BtnOpenBoard.TabIndex = 15;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(133, 21);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(174, 20);
            this.CmbAvailableDevice.TabIndex = 14;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "Available device:";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.CmbAxes);
            this.groupBox13.Controls.Add(this.label3);
            this.groupBox13.Controls.Add(this.label2);
            this.groupBox13.Controls.Add(this.label11);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Controls.Add(this.label20);
            this.groupBox13.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox13.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox13.Controls.Add(this.pictureBoxORG);
            this.groupBox13.Controls.Add(this.pictureBoxALM);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(386, 313);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(337, 111);
            this.groupBox13.TabIndex = 57;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Axis Signal Status";
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(129, 26);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(163, 20);
            this.CmbAxes.TabIndex = 30;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 12);
            this.label3.TabIndex = 29;
            this.label3.Text = "Operation Axis:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(255, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 12);
            this.label2.TabIndex = 28;
            this.label2.Text = "-HEL:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(171, 68);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 12);
            this.label11.TabIndex = 27;
            this.label11.Text = "+HEL:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(94, 68);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(32, 12);
            this.label19.TabIndex = 26;
            this.label19.Text = "ORG:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(13, 68);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(33, 12);
            this.label20.TabIndex = 25;
            this.label20.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(297, 63);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(212, 63);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(130, 63);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(47, 63);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(743, 443);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dgv_AxisState);
            this.Controls.Add(this.textBoxGpState);
            this.Controls.Add(this.dgv_Position);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.BtnResetErr);
            this.Controls.Add(this.BtnResetCounter);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Direct";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Position)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_AxisState)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnMove;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Button BtnResetCounter;
        private System.Windows.Forms.TextBox textBoxGpState;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button BtnResetErr;

        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum=0;
        IntPtr m_DeviceHandle;
        IntPtr[] m_Axishand = new IntPtr[64];
        IntPtr m_GpHand = IntPtr.Zero;
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.CheckedListBox cbx_Axes;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rdo_Rel;
        private System.Windows.Forms.RadioButton rdo_Abs;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgv_Position;
        private System.Windows.Forms.DataGridView dgv_AxisState;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox listBoxEndPoint;
        private System.Windows.Forms.Button BtnClearEnd;
        private System.Windows.Forms.Button BtnSetEnd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxEnd;
        private System.Windows.Forms.DataGridViewTextBoxColumn Axis;
        private System.Windows.Forms.DataGridViewTextBoxColumn CommandPosition;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button buttonLoadCfg;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
        private System.Windows.Forms.ComboBox CmbAxes;
        private System.Windows.Forms.Label label3;
    }
}

