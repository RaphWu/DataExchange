﻿using Advantech.Motion;//Common Motion API
using System;
namespace ECAM
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cmb_SlaveAxis = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.rdo_FeedbackPos = new System.Windows.Forms.RadioButton();
            this.rdo_CommandPos = new System.Windows.Forms.RadioButton();
            this.txb_SlaveScaling = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.btn_CAMIn = new System.Windows.Forms.Button();
            this.txb_MasterScaling = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txb_SlaveOffset = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txb_MasterOffset = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.btn_GearStop = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rdo_MasterAbsolute = new System.Windows.Forms.RadioButton();
            this.rdo_MasterRelative = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txb_Distance = new System.Windows.Forms.TextBox();
            this.btn_Stop = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.rdo_ContinueMove = new System.Windows.Forms.RadioButton();
            this.rdo_PtoPMove = new System.Windows.Forms.RadioButton();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.rdo_SCurve = new System.Windows.Forms.RadioButton();
            this.rdo_TCurve = new System.Windows.Forms.RadioButton();
            this.btn_GoPositive = new System.Windows.Forms.Button();
            this.btn_GoNegative = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.cmb_MasterAxis = new System.Windows.Forms.ComboBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txb_SlaveCommand = new System.Windows.Forms.TextBox();
            this.txb_SlaveFeedback = new System.Windows.Forms.TextBox();
            this.Lable = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txb_MasterCommand = new System.Windows.Forms.TextBox();
            this.txb_MasterFeedback = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.btn_ResetCounter = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txb_MasterAxisState = new System.Windows.Forms.TextBox();
            this.txb_SlaveAxisState = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_ResetError = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txb_ModuleRange = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btn_DownloadCAMTable = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btn_ConfigCAMTable = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.rdo_SlaveAbsolute = new System.Windows.Forms.RadioButton();
            this.rdo_SlaveRelative = new System.Windows.Forms.RadioButton();
            this.cmb_ConfigCamTableID = new System.Windows.Forms.ComboBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label26 = new System.Windows.Forms.Label();
            this.cmb_CamType = new System.Windows.Forms.ComboBox();
            this.group = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.btn_LoadCAMTableFile = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.group.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.groupBox12.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmb_SlaveAxis
            // 
            this.cmb_SlaveAxis.FormattingEnabled = true;
            this.cmb_SlaveAxis.Location = new System.Drawing.Point(124, 20);
            this.cmb_SlaveAxis.Name = "cmb_SlaveAxis";
            this.cmb_SlaveAxis.Size = new System.Drawing.Size(157, 20);
            this.cmb_SlaveAxis.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 20;
            this.label2.Text = "Slave Axis:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.txb_SlaveScaling);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.btn_CAMIn);
            this.groupBox1.Controls.Add(this.txb_MasterScaling);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.txb_SlaveOffset);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.txb_MasterOffset);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.btn_GearStop);
            this.groupBox1.Controls.Add(this.cmb_SlaveAxis);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(16, 415);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(373, 164);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Slave Axis Operation";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.rdo_FeedbackPos);
            this.groupBox7.Controls.Add(this.rdo_CommandPos);
            this.groupBox7.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox7.Location = new System.Drawing.Point(12, 105);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(209, 45);
            this.groupBox7.TabIndex = 49;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Reference Source";
            // 
            // rdo_FeedbackPos
            // 
            this.rdo_FeedbackPos.AutoSize = true;
            this.rdo_FeedbackPos.Location = new System.Drawing.Point(110, 20);
            this.rdo_FeedbackPos.Name = "rdo_FeedbackPos";
            this.rdo_FeedbackPos.Size = new System.Drawing.Size(95, 16);
            this.rdo_FeedbackPos.TabIndex = 1;
            this.rdo_FeedbackPos.Text = "Feedback Pos";
            this.rdo_FeedbackPos.UseVisualStyleBackColor = true;
            // 
            // rdo_CommandPos
            // 
            this.rdo_CommandPos.AutoSize = true;
            this.rdo_CommandPos.Checked = true;
            this.rdo_CommandPos.Location = new System.Drawing.Point(12, 20);
            this.rdo_CommandPos.Name = "rdo_CommandPos";
            this.rdo_CommandPos.Size = new System.Drawing.Size(89, 16);
            this.rdo_CommandPos.TabIndex = 0;
            this.rdo_CommandPos.TabStop = true;
            this.rdo_CommandPos.Text = "Command Pos";
            this.rdo_CommandPos.UseVisualStyleBackColor = true;
            // 
            // txb_SlaveScaling
            // 
            this.txb_SlaveScaling.Location = new System.Drawing.Point(259, 75);
            this.txb_SlaveScaling.Name = "txb_SlaveScaling";
            this.txb_SlaveScaling.Size = new System.Drawing.Size(100, 21);
            this.txb_SlaveScaling.TabIndex = 48;
            this.txb_SlaveScaling.Text = "1";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(177, 80);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(83, 12);
            this.label29.TabIndex = 47;
            this.label29.Text = "SlaveScaling:";
            // 
            // btn_CAMIn
            // 
            this.btn_CAMIn.Location = new System.Drawing.Point(244, 104);
            this.btn_CAMIn.Name = "btn_CAMIn";
            this.btn_CAMIn.Size = new System.Drawing.Size(75, 25);
            this.btn_CAMIn.TabIndex = 45;
            this.btn_CAMIn.Text = "CAM In";
            this.btn_CAMIn.UseVisualStyleBackColor = true;
            this.btn_CAMIn.Click += new System.EventHandler(this.btn_CAMIn_Click);
            // 
            // txb_MasterScaling
            // 
            this.txb_MasterScaling.Location = new System.Drawing.Point(93, 75);
            this.txb_MasterScaling.Name = "txb_MasterScaling";
            this.txb_MasterScaling.Size = new System.Drawing.Size(80, 21);
            this.txb_MasterScaling.TabIndex = 46;
            this.txb_MasterScaling.Text = "1";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(5, 77);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(89, 12);
            this.label30.TabIndex = 44;
            this.label30.Text = "MasterScaling:";
            // 
            // txb_SlaveOffset
            // 
            this.txb_SlaveOffset.Location = new System.Drawing.Point(259, 47);
            this.txb_SlaveOffset.Name = "txb_SlaveOffset";
            this.txb_SlaveOffset.Size = new System.Drawing.Size(100, 21);
            this.txb_SlaveOffset.TabIndex = 43;
            this.txb_SlaveOffset.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(183, 52);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(77, 12);
            this.label28.TabIndex = 42;
            this.label28.Text = "SlaveOffset:";
            // 
            // txb_MasterOffset
            // 
            this.txb_MasterOffset.Location = new System.Drawing.Point(93, 47);
            this.txb_MasterOffset.Name = "txb_MasterOffset";
            this.txb_MasterOffset.Size = new System.Drawing.Size(80, 21);
            this.txb_MasterOffset.TabIndex = 41;
            this.txb_MasterOffset.Text = "0";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(10, 51);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(83, 12);
            this.label27.TabIndex = 40;
            this.label27.Text = "MasterOffset:";
            // 
            // btn_GearStop
            // 
            this.btn_GearStop.Location = new System.Drawing.Point(244, 133);
            this.btn_GearStop.Name = "btn_GearStop";
            this.btn_GearStop.Size = new System.Drawing.Size(75, 25);
            this.btn_GearStop.TabIndex = 39;
            this.btn_GearStop.Text = "Stop";
            this.btn_GearStop.UseVisualStyleBackColor = true;
            this.btn_GearStop.Click += new System.EventHandler(this.btn_CAMStop_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.txb_Distance);
            this.groupBox3.Controls.Add(this.btn_Stop);
            this.groupBox3.Controls.Add(this.groupBox9);
            this.groupBox3.Controls.Add(this.groupBox10);
            this.groupBox3.Controls.Add(this.btn_GoPositive);
            this.groupBox3.Controls.Add(this.btn_GoNegative);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.cmb_MasterAxis);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox3.Location = new System.Drawing.Point(404, 7);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(317, 260);
            this.groupBox3.TabIndex = 39;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Master Axis Operation";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.rdo_MasterAbsolute);
            this.groupBox5.Controls.Add(this.rdo_MasterRelative);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox5.Location = new System.Drawing.Point(18, 92);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(282, 45);
            this.groupBox5.TabIndex = 48;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Movement Mode";
            // 
            // rdo_MasterAbsolute
            // 
            this.rdo_MasterAbsolute.AutoSize = true;
            this.rdo_MasterAbsolute.Location = new System.Drawing.Point(24, 20);
            this.rdo_MasterAbsolute.Name = "rdo_MasterAbsolute";
            this.rdo_MasterAbsolute.Size = new System.Drawing.Size(71, 16);
            this.rdo_MasterAbsolute.TabIndex = 1;
            this.rdo_MasterAbsolute.Text = "Absolute";
            this.rdo_MasterAbsolute.UseVisualStyleBackColor = true;
            // 
            // rdo_MasterRelative
            // 
            this.rdo_MasterRelative.AutoSize = true;
            this.rdo_MasterRelative.Checked = true;
            this.rdo_MasterRelative.Location = new System.Drawing.Point(177, 20);
            this.rdo_MasterRelative.Name = "rdo_MasterRelative";
            this.rdo_MasterRelative.Size = new System.Drawing.Size(71, 16);
            this.rdo_MasterRelative.TabIndex = 0;
            this.rdo_MasterRelative.TabStop = true;
            this.rdo_MasterRelative.Text = "Relative";
            this.rdo_MasterRelative.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(218, 201);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(23, 12);
            this.label16.TabIndex = 47;
            this.label16.Text = "PPU";
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(31, 202);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 12);
            this.label21.TabIndex = 45;
            this.label21.Text = "Distance:";
            // 
            // txb_Distance
            // 
            this.txb_Distance.Location = new System.Drawing.Point(93, 197);
            this.txb_Distance.Name = "txb_Distance";
            this.txb_Distance.Size = new System.Drawing.Size(119, 21);
            this.txb_Distance.TabIndex = 46;
            this.txb_Distance.Text = "10000";
            // 
            // btn_Stop
            // 
            this.btn_Stop.Location = new System.Drawing.Point(223, 227);
            this.btn_Stop.Name = "btn_Stop";
            this.btn_Stop.Size = new System.Drawing.Size(75, 26);
            this.btn_Stop.TabIndex = 43;
            this.btn_Stop.Text = "Stop";
            this.btn_Stop.Click += new System.EventHandler(this.btn_Stop_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.rdo_ContinueMove);
            this.groupBox9.Controls.Add(this.rdo_PtoPMove);
            this.groupBox9.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox9.Location = new System.Drawing.Point(18, 142);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(282, 45);
            this.groupBox9.TabIndex = 41;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Motion Mode";
            // 
            // rdo_ContinueMove
            // 
            this.rdo_ContinueMove.Location = new System.Drawing.Point(177, 16);
            this.rdo_ContinueMove.Name = "rdo_ContinueMove";
            this.rdo_ContinueMove.Size = new System.Drawing.Size(71, 24);
            this.rdo_ContinueMove.TabIndex = 4;
            this.rdo_ContinueMove.Text = "Continue";
            // 
            // rdo_PtoPMove
            // 
            this.rdo_PtoPMove.Checked = true;
            this.rdo_PtoPMove.Location = new System.Drawing.Point(24, 16);
            this.rdo_PtoPMove.Name = "rdo_PtoPMove";
            this.rdo_PtoPMove.Size = new System.Drawing.Size(104, 24);
            this.rdo_PtoPMove.TabIndex = 5;
            this.rdo_PtoPMove.TabStop = true;
            this.rdo_PtoPMove.Text = "P to P";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.rdo_SCurve);
            this.groupBox10.Controls.Add(this.rdo_TCurve);
            this.groupBox10.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox10.Location = new System.Drawing.Point(18, 42);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(282, 45);
            this.groupBox10.TabIndex = 38;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Speed Pattern";
            // 
            // rdo_SCurve
            // 
            this.rdo_SCurve.Location = new System.Drawing.Point(178, 21);
            this.rdo_SCurve.Name = "rdo_SCurve";
            this.rdo_SCurve.Size = new System.Drawing.Size(63, 21);
            this.rdo_SCurve.TabIndex = 3;
            this.rdo_SCurve.Text = "S-curve";
           
            // 
            // rdo_TCurve
            // 
            this.rdo_TCurve.Checked = true;
            this.rdo_TCurve.Location = new System.Drawing.Point(24, 20);
            this.rdo_TCurve.Name = "rdo_TCurve";
            this.rdo_TCurve.Size = new System.Drawing.Size(66, 24);
            this.rdo_TCurve.TabIndex = 4;
            this.rdo_TCurve.TabStop = true;
            this.rdo_TCurve.Text = "Trapezia";
          
            this.rdo_TCurve.CheckedChanged += new System.EventHandler(this.rdo_TCurve_CheckedChanged);
            // 
            // btn_GoPositive
            // 
            this.btn_GoPositive.Location = new System.Drawing.Point(122, 227);
            this.btn_GoPositive.Name = "btn_GoPositive";
            this.btn_GoPositive.Size = new System.Drawing.Size(75, 26);
            this.btn_GoPositive.TabIndex = 42;
            this.btn_GoPositive.Text = "-->";
            this.btn_GoPositive.Click += new System.EventHandler(this.btn_GoPositive_Click);
            // 
            // btn_GoNegative
            // 
            this.btn_GoNegative.Location = new System.Drawing.Point(21, 227);
            this.btn_GoNegative.Name = "btn_GoNegative";
            this.btn_GoNegative.Size = new System.Drawing.Size(75, 26);
            this.btn_GoNegative.TabIndex = 44;
            this.btn_GoNegative.Text = "<--";
            this.btn_GoNegative.Click += new System.EventHandler(this.btn_GoNegative_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(35, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 12);
            this.label6.TabIndex = 22;
            this.label6.Text = "Master Axis:";
            // 
            // cmb_MasterAxis
            // 
            this.cmb_MasterAxis.FormattingEnabled = true;
            this.cmb_MasterAxis.Location = new System.Drawing.Point(115, 19);
            this.cmb_MasterAxis.Name = "cmb_MasterAxis";
            this.cmb_MasterAxis.Size = new System.Drawing.Size(163, 20);
            this.cmb_MasterAxis.TabIndex = 23;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label24);
            this.groupBox11.Controls.Add(this.txb_SlaveCommand);
            this.groupBox11.Controls.Add(this.txb_SlaveFeedback);
            this.groupBox11.Controls.Add(this.Lable);
            this.groupBox11.Controls.Add(this.label22);
            this.groupBox11.Controls.Add(this.txb_MasterCommand);
            this.groupBox11.Controls.Add(this.txb_MasterFeedback);
            this.groupBox11.Controls.Add(this.label23);
            this.groupBox11.Controls.Add(this.btn_ResetCounter);
            this.groupBox11.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox11.Location = new System.Drawing.Point(404, 274);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(317, 123);
            this.groupBox11.TabIndex = 41;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Position";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(182, 15);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 12);
            this.label24.TabIndex = 14;
            this.label24.Text = "Slave Axis";
            // 
            // txb_SlaveCommand
            // 
            this.txb_SlaveCommand.Location = new System.Drawing.Point(181, 33);
            this.txb_SlaveCommand.Name = "txb_SlaveCommand";
            this.txb_SlaveCommand.ReadOnly = true;
            this.txb_SlaveCommand.Size = new System.Drawing.Size(100, 21);
            this.txb_SlaveCommand.TabIndex = 12;
            this.txb_SlaveCommand.Text = "0";
            // 
            // txb_SlaveFeedback
            // 
            this.txb_SlaveFeedback.Location = new System.Drawing.Point(181, 61);
            this.txb_SlaveFeedback.Name = "txb_SlaveFeedback";
            this.txb_SlaveFeedback.ReadOnly = true;
            this.txb_SlaveFeedback.Size = new System.Drawing.Size(100, 21);
            this.txb_SlaveFeedback.TabIndex = 13;
            this.txb_SlaveFeedback.Text = "0";
            // 
            // Lable
            // 
            this.Lable.AutoSize = true;
            this.Lable.Location = new System.Drawing.Point(74, 15);
            this.Lable.Name = "Lable";
            this.Lable.Size = new System.Drawing.Size(71, 12);
            this.Lable.TabIndex = 11;
            this.Lable.Text = "Master Axis";
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(17, 36);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 12);
            this.label22.TabIndex = 6;
            this.label22.Text = "Command:";
            // 
            // txb_MasterCommand
            // 
            this.txb_MasterCommand.Location = new System.Drawing.Point(73, 32);
            this.txb_MasterCommand.Name = "txb_MasterCommand";
            this.txb_MasterCommand.ReadOnly = true;
            this.txb_MasterCommand.Size = new System.Drawing.Size(100, 21);
            this.txb_MasterCommand.TabIndex = 7;
            this.txb_MasterCommand.Text = "0";
            // 
            // txb_MasterFeedback
            // 
            this.txb_MasterFeedback.Location = new System.Drawing.Point(73, 60);
            this.txb_MasterFeedback.Name = "txb_MasterFeedback";
            this.txb_MasterFeedback.ReadOnly = true;
            this.txb_MasterFeedback.Size = new System.Drawing.Size(100, 21);
            this.txb_MasterFeedback.TabIndex = 8;
            this.txb_MasterFeedback.Text = "0";
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(9, 65);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 12);
            this.label23.TabIndex = 9;
            this.label23.Text = "Feedback:";
            // 
            // btn_ResetCounter
            // 
            this.btn_ResetCounter.Location = new System.Drawing.Point(128, 88);
            this.btn_ResetCounter.Name = "btn_ResetCounter";
            this.btn_ResetCounter.Size = new System.Drawing.Size(96, 26);
            this.btn_ResetCounter.TabIndex = 40;
            this.btn_ResetCounter.Text = "Reset Counter";
            this.btn_ResetCounter.Click += new System.EventHandler(this.btn_ResetCounter_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.txb_MasterAxisState);
            this.groupBox4.Controls.Add(this.txb_SlaveAxisState);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.btn_ResetError);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox4.Location = new System.Drawing.Point(404, 404);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(317, 109);
            this.groupBox4.TabIndex = 42;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Current Axis Status";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(35, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 12);
            this.label4.TabIndex = 26;
            this.label4.Text = "Slave State:";
            // 
            // txb_MasterAxisState
            // 
            this.txb_MasterAxisState.Location = new System.Drawing.Point(117, 20);
            this.txb_MasterAxisState.Name = "txb_MasterAxisState";
            this.txb_MasterAxisState.ReadOnly = true;
            this.txb_MasterAxisState.Size = new System.Drawing.Size(138, 21);
            this.txb_MasterAxisState.TabIndex = 24;
            this.txb_MasterAxisState.Text = "0";
            // 
            // txb_SlaveAxisState
            // 
            this.txb_SlaveAxisState.Location = new System.Drawing.Point(117, 49);
            this.txb_SlaveAxisState.Name = "txb_SlaveAxisState";
            this.txb_SlaveAxisState.ReadOnly = true;
            this.txb_SlaveAxisState.Size = new System.Drawing.Size(139, 21);
            this.txb_SlaveAxisState.TabIndex = 25;
            this.txb_SlaveAxisState.Text = "0";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(30, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 12);
            this.label5.TabIndex = 27;
            this.label5.Text = "Master State:";
            // 
            // btn_ResetError
            // 
            this.btn_ResetError.Location = new System.Drawing.Point(128, 76);
            this.btn_ResetError.Name = "btn_ResetError";
            this.btn_ResetError.Size = new System.Drawing.Size(96, 26);
            this.btn_ResetError.TabIndex = 44;
            this.btn_ResetError.Text = "Reset Error";
            this.btn_ResetError.UseVisualStyleBackColor = true;
            this.btn_ResetError.Click += new System.EventHandler(this.btn_ResetError_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label3);
            this.groupBox8.Controls.Add(this.txb_ModuleRange);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Controls.Add(this.btn_DownloadCAMTable);
            this.groupBox8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox8.Location = new System.Drawing.Point(16, 116);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(373, 77);
            this.groupBox8.TabIndex = 46;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Download CAM Table";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(252, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 12);
            this.label3.TabIndex = 42;
            this.label3.Text = "Pulse";
            // 
            // txb_ModuleRange
            // 
            this.txb_ModuleRange.Location = new System.Drawing.Point(130, 18);
            this.txb_ModuleRange.Name = "txb_ModuleRange";
            this.txb_ModuleRange.ReadOnly = true;
            this.txb_ModuleRange.Size = new System.Drawing.Size(116, 21);
            this.txb_ModuleRange.TabIndex = 41;
            this.txb_ModuleRange.Text = "10000";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(50, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 12);
            this.label12.TabIndex = 40;
            this.label12.Text = "ModuleRange:";
            // 
            // btn_DownloadCAMTable
            // 
            this.btn_DownloadCAMTable.Location = new System.Drawing.Point(131, 45);
            this.btn_DownloadCAMTable.Name = "btn_DownloadCAMTable";
            this.btn_DownloadCAMTable.Size = new System.Drawing.Size(130, 25);
            this.btn_DownloadCAMTable.TabIndex = 39;
            this.btn_DownloadCAMTable.Text = "Download CAM Table";
            this.btn_DownloadCAMTable.UseVisualStyleBackColor = true;
            this.btn_DownloadCAMTable.Click += new System.EventHandler(this.btn_DownloadCAMTable_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btn_ConfigCAMTable);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.groupBox14);
            this.groupBox6.Controls.Add(this.cmb_ConfigCamTableID);
            this.groupBox6.Controls.Add(this.groupBox13);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.cmb_CamType);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox6.Location = new System.Drawing.Point(16, 198);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(373, 154);
            this.groupBox6.TabIndex = 45;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Config CAM Table";
            // 
            // btn_ConfigCAMTable
            // 
            this.btn_ConfigCAMTable.Location = new System.Drawing.Point(131, 120);
            this.btn_ConfigCAMTable.Name = "btn_ConfigCAMTable";
            this.btn_ConfigCAMTable.Size = new System.Drawing.Size(130, 25);
            this.btn_ConfigCAMTable.TabIndex = 38;
            this.btn_ConfigCAMTable.Text = "Config CAM Table";
            this.btn_ConfigCAMTable.UseVisualStyleBackColor = true;
            this.btn_ConfigCAMTable.Click += new System.EventHandler(this.btn_ConfigCAMTable_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(58, 22);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 12);
            this.label25.TabIndex = 32;
            this.label25.Text = "CamTable ID:";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.rdo_SlaveAbsolute);
            this.groupBox14.Controls.Add(this.rdo_SlaveRelative);
            this.groupBox14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox14.Location = new System.Drawing.Point(193, 68);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(169, 45);
            this.groupBox14.TabIndex = 37;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Slave Movement Mode";
            // 
            // rdo_SlaveAbsolute
            // 
            this.rdo_SlaveAbsolute.AutoSize = true;
            this.rdo_SlaveAbsolute.Location = new System.Drawing.Point(11, 20);
            this.rdo_SlaveAbsolute.Name = "rdo_SlaveAbsolute";
            this.rdo_SlaveAbsolute.Size = new System.Drawing.Size(71, 16);
            this.rdo_SlaveAbsolute.TabIndex = 1;
            this.rdo_SlaveAbsolute.Text = "Absolute";
            this.rdo_SlaveAbsolute.UseVisualStyleBackColor = true;
            // 
            // rdo_SlaveRelative
            // 
            this.rdo_SlaveRelative.AutoSize = true;
            this.rdo_SlaveRelative.Checked = true;
            this.rdo_SlaveRelative.Location = new System.Drawing.Point(93, 20);
            this.rdo_SlaveRelative.Name = "rdo_SlaveRelative";
            this.rdo_SlaveRelative.Size = new System.Drawing.Size(71, 16);
            this.rdo_SlaveRelative.TabIndex = 0;
            this.rdo_SlaveRelative.TabStop = true;
            this.rdo_SlaveRelative.Text = "Relative";
            this.rdo_SlaveRelative.UseVisualStyleBackColor = true;
            // 
            // cmb_ConfigCamTableID
            // 
            this.cmb_ConfigCamTableID.FormattingEnabled = true;
            this.cmb_ConfigCamTableID.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cmb_ConfigCamTableID.Location = new System.Drawing.Point(140, 16);
            this.cmb_ConfigCamTableID.Name = "cmb_ConfigCamTableID";
            this.cmb_ConfigCamTableID.Size = new System.Drawing.Size(124, 20);
            this.cmb_ConfigCamTableID.TabIndex = 33;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.radioButton1);
            this.groupBox13.Controls.Add(this.radioButton2);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(11, 68);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(171, 45);
            this.groupBox13.TabIndex = 36;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Master Movement Mode";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(11, 20);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(71, 16);
            this.radioButton1.TabIndex = 1;
            this.radioButton1.Text = "Absolute";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Checked = true;
            this.radioButton2.Location = new System.Drawing.Point(93, 21);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(71, 16);
            this.radioButton2.TabIndex = 0;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Relative";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(52, 47);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(83, 12);
            this.label26.TabIndex = 34;
            this.label26.Text = "Camming Type:";
            // 
            // cmb_CamType
            // 
            this.cmb_CamType.FormattingEnabled = true;
            this.cmb_CamType.Items.AddRange(new object[] {
            "Non periodic",
            "Periodic"});
            this.cmb_CamType.Location = new System.Drawing.Point(140, 41);
            this.cmb_CamType.Name = "cmb_CamType";
            this.cmb_CamType.Size = new System.Drawing.Size(124, 20);
            this.cmb_CamType.TabIndex = 35;
            // 
            // group
            // 
            this.group.Controls.Add(this.label1);
            this.group.Controls.Add(this.CmbAvailableDevice);
            this.group.Controls.Add(this.BtnOpenBoard);
            this.group.Controls.Add(this.BtnCloseBoard);
            this.group.Controls.Add(this.BtnLoadCfg);
            this.group.Controls.Add(this.BtnServo);
            this.group.Location = new System.Drawing.Point(16, 7);
            this.group.Name = "group";
            this.group.Size = new System.Drawing.Size(373, 104);
            this.group.TabIndex = 47;
            this.group.TabStop = false;
            this.group.Text = "Device Operate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "Available device:";
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(156, 16);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(149, 20);
            this.CmbAvailableDevice.TabIndex = 2;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(69, 42);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(98, 25);
            this.BtnOpenBoard.TabIndex = 3;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(222, 42);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(95, 25);
            this.BtnCloseBoard.TabIndex = 5;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(68, 72);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(99, 25);
            this.BtnLoadCfg.TabIndex = 4;
            this.BtnLoadCfg.Text = "Load Config";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            this.BtnLoadCfg.Click += new System.EventHandler(this.BtnLoadCfg_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(222, 73);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(95, 25);
            this.BtnServo.TabIndex = 6;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox2.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox2.Controls.Add(this.pictureBoxORG);
            this.groupBox2.Controls.Add(this.pictureBoxALM);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(404, 520);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(317, 57);
            this.groupBox2.TabIndex = 58;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Master Axis Signal Status";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(248, 31);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 12);
            this.label14.TabIndex = 28;
            this.label14.Text = "-HEL:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(166, 31);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 12);
            this.label15.TabIndex = 27;
            this.label15.Text = "+HEL:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(90, 31);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 26;
            this.label19.Text = "ORG:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(14, 31);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 12);
            this.label20.TabIndex = 25;
            this.label20.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(284, 27);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(204, 27);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(124, 27);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(44, 27);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.btn_LoadCAMTableFile);
            this.groupBox12.Location = new System.Drawing.Point(16, 357);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(373, 53);
            this.groupBox12.TabIndex = 59;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Download CAM Table";
            // 
            // btn_LoadCAMTableFile
            // 
            this.btn_LoadCAMTableFile.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn_LoadCAMTableFile.Location = new System.Drawing.Point(131, 18);
            this.btn_LoadCAMTableFile.Name = "btn_LoadCAMTableFile";
            this.btn_LoadCAMTableFile.Size = new System.Drawing.Size(130, 25);
            this.btn_LoadCAMTableFile.TabIndex = 45;
            this.btn_LoadCAMTableFile.Text = "Load CAMTable File";
            this.btn_LoadCAMTableFile.UseVisualStyleBackColor = true;
            this.btn_LoadCAMTableFile.Click += new System.EventHandler(this.btn_LoadCAMTableFile_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(738, 595);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.group);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "E-CAM";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.group.ResumeLayout(false);
            this.group.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cmb_SlaveAxis;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[64];
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn_GearStop;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rdo_MasterAbsolute;
        private System.Windows.Forms.RadioButton rdo_MasterRelative;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txb_Distance;
        private System.Windows.Forms.Button btn_Stop;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RadioButton rdo_ContinueMove;
        private System.Windows.Forms.RadioButton rdo_PtoPMove;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton rdo_SCurve;
        private System.Windows.Forms.RadioButton rdo_TCurve;
        private System.Windows.Forms.Button btn_GoPositive;
        private System.Windows.Forms.Button btn_GoNegative;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmb_MasterAxis;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txb_SlaveCommand;
        private System.Windows.Forms.TextBox txb_SlaveFeedback;
        private System.Windows.Forms.Label Lable;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txb_MasterCommand;
        private System.Windows.Forms.TextBox txb_MasterFeedback;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btn_ResetCounter;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txb_MasterAxisState;
        private System.Windows.Forms.TextBox txb_SlaveAxisState;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_ResetError;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton rdo_FeedbackPos;
        private System.Windows.Forms.RadioButton rdo_CommandPos;
        private System.Windows.Forms.TextBox txb_SlaveScaling;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button btn_CAMIn;
        private System.Windows.Forms.TextBox txb_MasterScaling;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txb_SlaveOffset;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txb_MasterOffset;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txb_ModuleRange;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn_DownloadCAMTable;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btn_ConfigCAMTable;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.RadioButton rdo_SlaveAbsolute;
        private System.Windows.Forms.RadioButton rdo_SlaveRelative;
        private System.Windows.Forms.ComboBox cmb_ConfigCamTableID;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cmb_CamType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox group;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnLoadCfg;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button btn_LoadCAMTableFile;

    }
}

