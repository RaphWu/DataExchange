using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ECAM
{
    public partial class FormCAMTable : Form
    {
        public FormCAMTable()
        {
           
                InitializeComponent();
           
        }
        private void btn_ok_Click(object sender, EventArgs e)
        {

            MasterArray = new double[8];
            SlaveArray = new double[8];
            PointRangeArray = new double[8];
            SlopeArray = new double[8];
            for (int i = 0; i < dgv_CAM.Rows.Count; i++)
            {
                MasterArray[i] = Convert.ToDouble(dgv_CAM.Rows[i].Cells[1].Value);
                SlaveArray[i] = Convert.ToDouble(dgv_CAM.Rows[i].Cells[2].Value);
                PointRangeArray[i] = Convert.ToDouble(dgv_CAM.Rows[i].Cells[3].Value);
                SlopeArray[i] = Convert.ToDouble(dgv_CAM.Rows[i].Cells[4].Value);
            }
        }
        private void InitdgvCAM()
        {
            dgv_CAM.Rows.Add();
            dgv_CAM.Rows[0].Cells[0].Value = 1;
            dgv_CAM.Rows[0].Cells[1].Value = 0;
            dgv_CAM.Rows[0].Cells[2].Value = 0;
            dgv_CAM.Rows[0].Cells[3].Value = 500;
            dgv_CAM.Rows[0].Cells[4].Value = 0;
            dgv_CAM.Rows.Add();
            dgv_CAM.Rows[1].Cells[0].Value = 2;
            dgv_CAM.Rows[1].Cells[1].Value = 1200;
            dgv_CAM.Rows[1].Cells[2].Value = 5000;
            dgv_CAM.Rows[1].Cells[3].Value = 500;
            dgv_CAM.Rows[1].Cells[4].Value = 0;
            dgv_CAM.Rows.Add();
            dgv_CAM.Rows[2].Cells[0].Value = 3;
            dgv_CAM.Rows[2].Cells[1].Value = 3000;
            dgv_CAM.Rows[2].Cells[2].Value = 2000;
            dgv_CAM.Rows[2].Cells[3].Value = 500;
            dgv_CAM.Rows[2].Cells[4].Value = 0;
            dgv_CAM.Rows.Add();
            dgv_CAM.Rows[3].Cells[0].Value = 4;
            dgv_CAM.Rows[3].Cells[1].Value = 4200;
            dgv_CAM.Rows[3].Cells[2].Value = 6000;
            dgv_CAM.Rows[3].Cells[3].Value = 500;
            dgv_CAM.Rows[3].Cells[4].Value = 0;
            dgv_CAM.Rows.Add();
            dgv_CAM.Rows[4].Cells[0].Value = 5;
            dgv_CAM.Rows[4].Cells[1].Value = 6000;
            dgv_CAM.Rows[4].Cells[2].Value = 1000;
            dgv_CAM.Rows[4].Cells[3].Value = 500;
            dgv_CAM.Rows[4].Cells[4].Value = 0;
            dgv_CAM.Rows.Add();
            dgv_CAM.Rows[5].Cells[0].Value = 6;
            dgv_CAM.Rows[5].Cells[1].Value = 7200;
            dgv_CAM.Rows[5].Cells[2].Value = 6000;
            dgv_CAM.Rows[5].Cells[3].Value = 500;
            dgv_CAM.Rows[5].Cells[4].Value = 0;
            dgv_CAM.Rows.Add();
            dgv_CAM.Rows[6].Cells[0].Value = 7;
            dgv_CAM.Rows[6].Cells[1].Value = 8600;
            dgv_CAM.Rows[6].Cells[2].Value = -1000;
            dgv_CAM.Rows[6].Cells[3].Value = 500;
            dgv_CAM.Rows[6].Cells[4].Value = 0;
            dgv_CAM.Rows.Add();
            dgv_CAM.Rows[7].Cells[0].Value = 8;
            dgv_CAM.Rows[7].Cells[1].Value = 10000;
            dgv_CAM.Rows[7].Cells[2].Value = 0;
            dgv_CAM.Rows[7].Cells[3].Value = 500;
            dgv_CAM.Rows[7].Cells[4].Value = 0;
            dgv_CAM.Height = dgv_CAM.ColumnHeadersHeight + dgv_CAM.Rows.Count * dgv_CAM.Rows[0].Height + 3;
            if (dgv_CAM.Height > 300)
            {
                dgv_CAM.Height = 300;
            }
        
        }
        bool isDownLoad = false;
        private void FormCAMTable_Load(object sender, EventArgs e)
        {
            if (isDownLoad == false)
            {
                InitdgvCAM();
                isDownLoad = true;
            }
            //else
            //{
            //    FormSaveData();
            //}
        }
        //private void FormSaveData()
        //{
        //    for (int i = 0; i < dgv_CAM.Rows.Count; i++)
        //    {
        //        dgv_CAM.Rows[i].Cells[1].Value = Convert.ToDouble(MasterArray[i]);
        //        dgv_CAM.Rows[i].Cells[2].Value = Convert.ToDouble(SlaveArray[i]);
        //        dgv_CAM.Rows[i].Cells[3].Value = Convert.ToDouble(PointRangeArray[i]);
        //        dgv_CAM.Rows[i].Cells[4].Value = Convert.ToDouble(SlopeArray[i]);

        //    }
        //}
    }
}