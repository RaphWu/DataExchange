﻿namespace ARC
{
    partial class Form2DARC
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxAgl = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxCen3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxCen2 = new System.Windows.Forms.TextBox();
            this.textBoxCen1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxEnd3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxEnd2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxEnd1 = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.rdb_Agl = new System.Windows.Forms.RadioButton();
            this.radioButtonCen = new System.Windows.Forms.RadioButton();
            this.radioButtonRef = new System.Windows.Forms.RadioButton();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_OK = new System.Windows.Forms.Button();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.rdo_XZPlane = new System.Windows.Forms.RadioButton();
            this.rdo_YZPlane = new System.Windows.Forms.RadioButton();
            this.rdo_XYPlane = new System.Windows.Forms.RadioButton();
            this.groupBox10.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label15);
            this.groupBox10.Controls.Add(this.textBoxAgl);
            this.groupBox10.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox10.Location = new System.Drawing.Point(284, 191);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(220, 53);
            this.groupBox10.TabIndex = 18;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Arc Agl";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(52, 26);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 12);
            this.label15.TabIndex = 11;
            this.label15.Text = "Agl:";
            // 
            // textBoxAgl
            // 
            this.textBoxAgl.Location = new System.Drawing.Point(84, 21);
            this.textBoxAgl.Name = "textBoxAgl";
            this.textBoxAgl.Size = new System.Drawing.Size(100, 21);
            this.textBoxAgl.TabIndex = 11;
            this.textBoxAgl.Text = "90";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBoxCen3);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.textBoxCen2);
            this.groupBox2.Controls.Add(this.textBoxCen1);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox2.Location = new System.Drawing.Point(19, 11);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(487, 56);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Center";
            // 
            // textBoxCen3
            // 
            this.textBoxCen3.Location = new System.Drawing.Point(374, 23);
            this.textBoxCen3.Name = "textBoxCen3";
            this.textBoxCen3.Size = new System.Drawing.Size(100, 21);
            this.textBoxCen3.TabIndex = 12;
            this.textBoxCen3.Text = "8000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(330, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 11;
            this.label1.Text = "C2/R2:";
            // 
            // textBoxCen2
            // 
            this.textBoxCen2.Location = new System.Drawing.Point(215, 23);
            this.textBoxCen2.Name = "textBoxCen2";
            this.textBoxCen2.Size = new System.Drawing.Size(100, 21);
            this.textBoxCen2.TabIndex = 10;
            this.textBoxCen2.Text = "0";
            // 
            // textBoxCen1
            // 
            this.textBoxCen1.Location = new System.Drawing.Point(52, 23);
            this.textBoxCen1.Name = "textBoxCen1";
            this.textBoxCen1.Size = new System.Drawing.Size(100, 21);
            this.textBoxCen1.TabIndex = 6;
            this.textBoxCen1.Text = "8000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(172, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "C2/R2:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "C1/R1:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.textBoxEnd3);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.textBoxEnd2);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.textBoxEnd1);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox3.Location = new System.Drawing.Point(18, 74);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(488, 50);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "End";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(348, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "E2:";
            // 
            // textBoxEnd3
            // 
            this.textBoxEnd3.Location = new System.Drawing.Point(377, 22);
            this.textBoxEnd3.Name = "textBoxEnd3";
            this.textBoxEnd3.Size = new System.Drawing.Size(100, 21);
            this.textBoxEnd3.TabIndex = 13;
            this.textBoxEnd3.Text = "16000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(187, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "E2:";
            // 
            // textBoxEnd2
            // 
            this.textBoxEnd2.Location = new System.Drawing.Point(216, 22);
            this.textBoxEnd2.Name = "textBoxEnd2";
            this.textBoxEnd2.Size = new System.Drawing.Size(100, 21);
            this.textBoxEnd2.TabIndex = 12;
            this.textBoxEnd2.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "E1:";
            // 
            // textBoxEnd1
            // 
            this.textBoxEnd1.Location = new System.Drawing.Point(53, 20);
            this.textBoxEnd1.Name = "textBoxEnd1";
            this.textBoxEnd1.Size = new System.Drawing.Size(100, 21);
            this.textBoxEnd1.TabIndex = 11;
            this.textBoxEnd1.Text = "16000";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.rdb_Agl);
            this.groupBox9.Controls.Add(this.radioButtonCen);
            this.groupBox9.Controls.Add(this.radioButtonRef);
            this.groupBox9.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox9.Location = new System.Drawing.Point(19, 191);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(244, 53);
            this.groupBox9.TabIndex = 17;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Arc Mode";
            // 
            // rdb_Agl
            // 
            this.rdb_Agl.AutoSize = true;
            this.rdb_Agl.Location = new System.Drawing.Point(184, 26);
            this.rdb_Agl.Name = "rdb_Agl";
            this.rdb_Agl.Size = new System.Drawing.Size(41, 16);
            this.rdb_Agl.TabIndex = 13;
            this.rdb_Agl.Text = "Agl";
            this.rdb_Agl.UseVisualStyleBackColor = true;
            // 
            // radioButtonCen
            // 
            this.radioButtonCen.AutoSize = true;
            this.radioButtonCen.Checked = true;
            this.radioButtonCen.Location = new System.Drawing.Point(28, 25);
            this.radioButtonCen.Name = "radioButtonCen";
            this.radioButtonCen.Size = new System.Drawing.Size(41, 16);
            this.radioButtonCen.TabIndex = 11;
            this.radioButtonCen.TabStop = true;
            this.radioButtonCen.Text = "Cen";
            this.radioButtonCen.UseVisualStyleBackColor = true;
            // 
            // radioButtonRef
            // 
            this.radioButtonRef.AutoSize = true;
            this.radioButtonRef.Location = new System.Drawing.Point(101, 27);
            this.radioButtonRef.Name = "radioButtonRef";
            this.radioButtonRef.Size = new System.Drawing.Size(41, 16);
            this.radioButtonRef.TabIndex = 12;
            this.radioButtonRef.Text = "Ref";
            this.radioButtonRef.UseVisualStyleBackColor = true;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cancel.Location = new System.Drawing.Point(314, 262);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 25);
            this.btn_Cancel.TabIndex = 20;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            // 
            // btn_OK
            // 
            this.btn_OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btn_OK.Location = new System.Drawing.Point(120, 262);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 25);
            this.btn_OK.TabIndex = 19;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.rdo_XZPlane);
            this.groupBox19.Controls.Add(this.rdo_YZPlane);
            this.groupBox19.Controls.Add(this.rdo_XYPlane);
            this.groupBox19.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox19.Location = new System.Drawing.Point(19, 131);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(487, 52);
            this.groupBox19.TabIndex = 33;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Reference Plane";
            this.groupBox19.Enter += new System.EventHandler(this.groupBox19_Enter);
            // 
            // rdo_XZPlane
            // 
            this.rdo_XZPlane.AutoSize = true;
            this.rdo_XZPlane.Location = new System.Drawing.Point(376, 23);
            this.rdo_XZPlane.Name = "rdo_XZPlane";
            this.rdo_XZPlane.Size = new System.Drawing.Size(77, 16);
            this.rdo_XZPlane.TabIndex = 2;
            this.rdo_XZPlane.Text = "X_Z Plane";
            this.rdo_XZPlane.UseVisualStyleBackColor = true;
            // 
            // rdo_YZPlane
            // 
            this.rdo_YZPlane.AutoSize = true;
            this.rdo_YZPlane.Location = new System.Drawing.Point(200, 23);
            this.rdo_YZPlane.Name = "rdo_YZPlane";
            this.rdo_YZPlane.Size = new System.Drawing.Size(77, 16);
            this.rdo_YZPlane.TabIndex = 1;
            this.rdo_YZPlane.Text = "Y_Z Plane";
            this.rdo_YZPlane.UseVisualStyleBackColor = true;
            // 
            // rdo_XYPlane
            // 
            this.rdo_XYPlane.AutoSize = true;
            this.rdo_XYPlane.Checked = true;
            this.rdo_XYPlane.Location = new System.Drawing.Point(27, 25);
            this.rdo_XYPlane.Name = "rdo_XYPlane";
            this.rdo_XYPlane.Size = new System.Drawing.Size(77, 16);
            this.rdo_XYPlane.TabIndex = 0;
            this.rdo_XYPlane.TabStop = true;
            this.rdo_XYPlane.Text = "X_Y Plane";
            this.rdo_XYPlane.UseVisualStyleBackColor = true;
            // 
            // Form2DARC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 311);
            this.Controls.Add(this.groupBox19);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox9);
            this.Name = "Form2DARC";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2DARC";
            this.Load += new System.EventHandler(this.Form2DARC_Load);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label15;
        public System.Windows.Forms.TextBox textBoxAgl;
        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.TextBox textBoxCen2;
        public System.Windows.Forms.TextBox textBoxCen1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox textBoxEnd2;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox textBoxEnd1;
        private System.Windows.Forms.GroupBox groupBox9;
        public System.Windows.Forms.RadioButton rdb_Agl;
        public System.Windows.Forms.RadioButton radioButtonCen;
        public System.Windows.Forms.RadioButton radioButtonRef;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_OK;
        public System.Windows.Forms.TextBox textBoxCen3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox textBoxEnd3;
        private System.Windows.Forms.GroupBox groupBox19;
        public System.Windows.Forms.RadioButton rdo_XZPlane;
        public System.Windows.Forms.RadioButton rdo_YZPlane;
        public System.Windows.Forms.RadioButton rdo_XYPlane;
    }
}