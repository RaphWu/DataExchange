﻿using Advantech.Motion;//Common Motion API
using System;
namespace Change_V
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxVel = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BtnResetCnt = new System.Windows.Forms.Button();
            this.textBoxAct = new System.Windows.Forms.TextBox();
            this.textBoxCmd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxCurState = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxPos = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnChange = new System.Windows.Forms.Button();
            this.BtnPTP = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxChangeV = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxVelH = new System.Windows.Forms.TextBox();
            this.textBoxVelL = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btn_SetParam = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.rdb_Rel = new System.Windows.Forms.RadioButton();
            this.rdb_Abs = new System.Windows.Forms.RadioButton();
            this.textBoxDec = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxAcc = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.buttonLoadCfg = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.rdb_T = new System.Windows.Forms.RadioButton();
            this.rdb_S = new System.Windows.Forms.RadioButton();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.groupBox3.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(65, 63);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(100, 26);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "Reset Error";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            this.BtnResetErr.Click += new System.EventHandler(this.BtnResetErr_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox13);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.groupBox2);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.Location = new System.Drawing.Point(371, 10);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(257, 460);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Info";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label13);
            this.groupBox13.Controls.Add(this.label14);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Controls.Add(this.label20);
            this.groupBox13.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox13.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox13.Controls.Add(this.pictureBoxORG);
            this.groupBox13.Controls.Add(this.pictureBoxALM);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(21, 223);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(215, 116);
            this.groupBox13.TabIndex = 54;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Master Axis Signal Status";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(125, 76);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 12);
            this.label13.TabIndex = 28;
            this.label13.Text = "-HEL:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(28, 76);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 12);
            this.label14.TabIndex = 27;
            this.label14.Text = "+HEL:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(130, 36);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 26;
            this.label19.Text = "ORG:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(35, 36);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 12);
            this.label20.TabIndex = 25;
            this.label20.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(161, 72);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(65, 72);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(161, 31);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(65, 31);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.textBoxVel);
            this.groupBox4.Location = new System.Drawing.Point(21, 148);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(215, 65);
            this.groupBox4.TabIndex = 37;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Axis Param";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(28, 32);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 31;
            this.label12.Text = "Vel:";
            // 
            // textBoxVel
            // 
            this.textBoxVel.Location = new System.Drawing.Point(63, 27);
            this.textBoxVel.Name = "textBoxVel";
            this.textBoxVel.ReadOnly = true;
            this.textBoxVel.Size = new System.Drawing.Size(130, 21);
            this.textBoxVel.TabIndex = 30;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BtnResetCnt);
            this.groupBox2.Controls.Add(this.textBoxAct);
            this.groupBox2.Controls.Add(this.textBoxCmd);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(21, 17);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(215, 121);
            this.groupBox2.TabIndex = 36;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Position";
            // 
            // BtnResetCnt
            // 
            this.BtnResetCnt.Location = new System.Drawing.Point(65, 86);
            this.BtnResetCnt.Name = "BtnResetCnt";
            this.BtnResetCnt.Size = new System.Drawing.Size(100, 25);
            this.BtnResetCnt.TabIndex = 15;
            this.BtnResetCnt.Text = "Reset Counter";
            this.BtnResetCnt.UseVisualStyleBackColor = true;
            this.BtnResetCnt.Click += new System.EventHandler(this.BtnResetCnt_Click);
            // 
            // textBoxAct
            // 
            this.textBoxAct.Location = new System.Drawing.Point(63, 55);
            this.textBoxAct.Name = "textBoxAct";
            this.textBoxAct.ReadOnly = true;
            this.textBoxAct.Size = new System.Drawing.Size(130, 21);
            this.textBoxAct.TabIndex = 33;
            // 
            // textBoxCmd
            // 
            this.textBoxCmd.Location = new System.Drawing.Point(63, 25);
            this.textBoxCmd.Name = "textBoxCmd";
            this.textBoxCmd.ReadOnly = true;
            this.textBoxCmd.Size = new System.Drawing.Size(130, 21);
            this.textBoxCmd.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 58);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 32;
            this.label5.Text = "Act:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(31, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 29;
            this.label8.Text = "Cmd:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.BtnResetErr);
            this.groupBox5.Controls.Add(this.textBoxCurState);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox5.Location = new System.Drawing.Point(21, 349);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(215, 95);
            this.groupBox5.TabIndex = 35;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Current State";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 12);
            this.label11.TabIndex = 33;
            this.label11.Text = "Status:";
            // 
            // textBoxCurState
            // 
            this.textBoxCurState.Location = new System.Drawing.Point(63, 28);
            this.textBoxCurState.Name = "textBoxCurState";
            this.textBoxCurState.ReadOnly = true;
            this.textBoxCurState.Size = new System.Drawing.Size(130, 21);
            this.textBoxCurState.TabIndex = 30;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "Axis:";
            // 
            // textBoxPos
            // 
            this.textBoxPos.Location = new System.Drawing.Point(104, 49);
            this.textBoxPos.Name = "textBoxPos";
            this.textBoxPos.Size = new System.Drawing.Size(141, 21);
            this.textBoxPos.TabIndex = 17;
            this.textBoxPos.Text = "10000";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(74, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 16;
            this.label3.Text = "Pos:";
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(104, 20);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(148, 20);
            this.CmbAxes.TabIndex = 15;
            this.CmbAxes.SelectedIndexChanged += new System.EventHandler(this.CmbAxes_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BtnStop);
            this.groupBox1.Controls.Add(this.BtnChange);
            this.groupBox1.Controls.Add(this.BtnPTP);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.textBoxChangeV);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.textBoxPos);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.CmbAxes);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox1.Location = new System.Drawing.Point(15, 317);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(340, 155);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Change Vel";
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(230, 116);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(80, 26);
            this.BtnStop.TabIndex = 28;
            this.BtnStop.Text = "Stop";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // BtnChange
            // 
            this.BtnChange.Location = new System.Drawing.Point(129, 116);
            this.BtnChange.Name = "BtnChange";
            this.BtnChange.Size = new System.Drawing.Size(80, 26);
            this.BtnChange.TabIndex = 27;
            this.BtnChange.Text = "ChangeV";
            this.BtnChange.UseVisualStyleBackColor = true;
            this.BtnChange.Click += new System.EventHandler(this.BtnChange_Click);
            // 
            // BtnPTP
            // 
            this.BtnPTP.Location = new System.Drawing.Point(28, 116);
            this.BtnPTP.Name = "BtnPTP";
            this.BtnPTP.Size = new System.Drawing.Size(80, 26);
            this.BtnPTP.TabIndex = 14;
            this.BtnPTP.Text = "PTP";
            this.BtnPTP.UseVisualStyleBackColor = true;
            this.BtnPTP.Click += new System.EventHandler(this.BtnPTP_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(251, 85);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 12);
            this.label10.TabIndex = 25;
            this.label10.Text = "PPU";
            // 
            // textBoxChangeV
            // 
            this.textBoxChangeV.Location = new System.Drawing.Point(104, 81);
            this.textBoxChangeV.Name = "textBoxChangeV";
            this.textBoxChangeV.Size = new System.Drawing.Size(142, 21);
            this.textBoxChangeV.TabIndex = 26;
            this.textBoxChangeV.Text = "6000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(32, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 12);
            this.label9.TabIndex = 25;
            this.label9.Text = "Change Vel:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(252, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 12);
            this.label7.TabIndex = 23;
            this.label7.Text = "PPU";
            // 
            // textBoxVelH
            // 
            this.textBoxVelH.Location = new System.Drawing.Point(212, 22);
            this.textBoxVelH.Name = "textBoxVelH";
            this.textBoxVelH.Size = new System.Drawing.Size(95, 21);
            this.textBoxVelH.TabIndex = 22;
            this.textBoxVelH.Text = "4000";
            // 
            // textBoxVelL
            // 
            this.textBoxVelL.Location = new System.Drawing.Point(49, 21);
            this.textBoxVelL.Name = "textBoxVelL";
            this.textBoxVelL.Size = new System.Drawing.Size(95, 21);
            this.textBoxVelL.TabIndex = 20;
            this.textBoxVelL.Text = "1000";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btn_SetParam
            // 
            this.btn_SetParam.Location = new System.Drawing.Point(129, 139);
            this.btn_SetParam.Name = "btn_SetParam";
            this.btn_SetParam.Size = new System.Drawing.Size(100, 26);
            this.btn_SetParam.TabIndex = 39;
            this.btn_SetParam.Text = "Set/Get Param";
            this.btn_SetParam.UseVisualStyleBackColor = true;
            this.btn_SetParam.Click += new System.EventHandler(this.btn_SetParam_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.rdb_Rel);
            this.groupBox9.Controls.Add(this.rdb_Abs);
            this.groupBox9.Location = new System.Drawing.Point(171, 80);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(160, 50);
            this.groupBox9.TabIndex = 38;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "MoveMent Mode";
            // 
            // rdb_Rel
            // 
            this.rdb_Rel.AutoSize = true;
            this.rdb_Rel.Checked = true;
            this.rdb_Rel.Location = new System.Drawing.Point(10, 26);
            this.rdb_Rel.Name = "rdb_Rel";
            this.rdb_Rel.Size = new System.Drawing.Size(71, 16);
            this.rdb_Rel.TabIndex = 35;
            this.rdb_Rel.TabStop = true;
            this.rdb_Rel.Text = "Relative";
            this.rdb_Rel.UseVisualStyleBackColor = true;
            // 
            // rdb_Abs
            // 
            this.rdb_Abs.AutoSize = true;
            this.rdb_Abs.Location = new System.Drawing.Point(87, 25);
            this.rdb_Abs.Name = "rdb_Abs";
            this.rdb_Abs.Size = new System.Drawing.Size(71, 16);
            this.rdb_Abs.TabIndex = 36;
            this.rdb_Abs.Text = "Absolute";
            this.rdb_Abs.UseVisualStyleBackColor = true;
            // 
            // textBoxDec
            // 
            this.textBoxDec.Location = new System.Drawing.Point(211, 52);
            this.textBoxDec.Name = "textBoxDec";
            this.textBoxDec.Size = new System.Drawing.Size(95, 21);
            this.textBoxDec.TabIndex = 33;
            this.textBoxDec.Text = "10000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(177, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 32;
            this.label1.Text = "Dec:";
            // 
            // textBoxAcc
            // 
            this.textBoxAcc.Location = new System.Drawing.Point(49, 51);
            this.textBoxAcc.Name = "textBoxAcc";
            this.textBoxAcc.Size = new System.Drawing.Size(95, 21);
            this.textBoxAcc.TabIndex = 31;
            this.textBoxAcc.Text = "10000";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.buttonLoadCfg);
            this.groupBox7.Controls.Add(this.BtnServo);
            this.groupBox7.Controls.Add(this.BtnCloseBoard);
            this.groupBox7.Controls.Add(this.BtnOpenBoard);
            this.groupBox7.Controls.Add(this.CmbAvailableDevice);
            this.groupBox7.Controls.Add(this.label15);
            this.groupBox7.Location = new System.Drawing.Point(15, 11);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(340, 118);
            this.groupBox7.TabIndex = 22;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Device Operate";
            // 
            // buttonLoadCfg
            // 
            this.buttonLoadCfg.Location = new System.Drawing.Point(70, 81);
            this.buttonLoadCfg.Name = "buttonLoadCfg";
            this.buttonLoadCfg.Size = new System.Drawing.Size(85, 26);
            this.buttonLoadCfg.TabIndex = 31;
            this.buttonLoadCfg.Text = "Load Config";
            this.buttonLoadCfg.UseVisualStyleBackColor = true;
            this.buttonLoadCfg.Click += new System.EventHandler(this.buttonLoadCfg_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(203, 81);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(85, 26);
            this.BtnServo.TabIndex = 17;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(203, 49);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(85, 26);
            this.BtnCloseBoard.TabIndex = 16;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(70, 49);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(85, 26);
            this.BtnOpenBoard.TabIndex = 15;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(135, 20);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(154, 20);
            this.CmbAvailableDevice.TabIndex = 14;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged_1);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(28, 24);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(107, 12);
            this.label15.TabIndex = 13;
            this.label15.Text = "Available device:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(18, 54);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 30;
            this.label16.Text = "Acc:";
            // 
            // rdb_T
            // 
            this.rdb_T.AutoSize = true;
            this.rdb_T.Checked = true;
            this.rdb_T.Location = new System.Drawing.Point(5, 25);
            this.rdb_T.Name = "rdb_T";
            this.rdb_T.Size = new System.Drawing.Size(71, 16);
            this.rdb_T.TabIndex = 35;
            this.rdb_T.TabStop = true;
            this.rdb_T.Text = "T-Curver";
            this.rdb_T.UseVisualStyleBackColor = true;
            // 
            // rdb_S
            // 
            this.rdb_S.AutoSize = true;
            this.rdb_S.Location = new System.Drawing.Point(81, 25);
            this.rdb_S.Name = "rdb_S";
            this.rdb_S.Size = new System.Drawing.Size(71, 16);
            this.rdb_S.TabIndex = 36;
            this.rdb_S.Text = "S-Curver";
            this.rdb_S.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(173, 26);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 12);
            this.label17.TabIndex = 28;
            this.label17.Text = "VelH:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 25);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 12);
            this.label18.TabIndex = 26;
            this.label18.Text = "VelL:";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.btn_SetParam);
            this.groupBox8.Controls.Add(this.groupBox9);
            this.groupBox8.Controls.Add(this.textBoxVelH);
            this.groupBox8.Controls.Add(this.groupBox10);
            this.groupBox8.Controls.Add(this.textBoxDec);
            this.groupBox8.Controls.Add(this.textBoxVelL);
            this.groupBox8.Controls.Add(this.label1);
            this.groupBox8.Controls.Add(this.textBoxAcc);
            this.groupBox8.Controls.Add(this.label16);
            this.groupBox8.Controls.Add(this.label17);
            this.groupBox8.Controls.Add(this.label18);
            this.groupBox8.Location = new System.Drawing.Point(15, 136);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(340, 172);
            this.groupBox8.TabIndex = 23;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Vel Set";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.rdb_T);
            this.groupBox10.Controls.Add(this.rdb_S);
            this.groupBox10.Location = new System.Drawing.Point(8, 80);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(155, 50);
            this.groupBox10.TabIndex = 37;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Jerk";
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 490);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Change_V";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox3.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnResetErr;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBoxCurState;
        private System.Windows.Forms.TextBox textBoxVel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxPos;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox CmbAxes;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Button BtnChange;
        private System.Windows.Forms.Button BtnPTP;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxChangeV;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxVelH;
        private System.Windows.Forms.TextBox textBoxVelL;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label12;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[64];
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        private System.Windows.Forms.TextBox textBoxCmd;
        private System.Windows.Forms.Button btn_SetParam;
        private System.Windows.Forms.GroupBox groupBox9;
        public System.Windows.Forms.RadioButton rdb_Rel;
        public System.Windows.Forms.RadioButton rdb_Abs;
        private System.Windows.Forms.TextBox textBoxDec;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxAcc;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button buttonLoadCfg;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        public System.Windows.Forms.RadioButton rdb_T;
        public System.Windows.Forms.RadioButton rdb_S;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button BtnResetCnt;
        private System.Windows.Forms.TextBox textBoxAct;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
    }
}

