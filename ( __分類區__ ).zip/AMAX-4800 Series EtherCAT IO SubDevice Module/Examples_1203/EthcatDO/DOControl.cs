﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;

namespace EthcatDO
{
    public partial class DOControl : UserControl
    {
        public DOControl()
        {
            InitializeComponent();
            DOLedArray[0] = pbox_DO0;
            DOLedArray[1] = pbox_DO1;
            DOLedArray[2] = pbox_DO2;
            DOLedArray[3] = pbox_DO3;
            DOLedArray[4] = pbox_DO4;
            DOLedArray[5] = pbox_DO5;
            DOLedArray[6] = pbox_DO6;
            DOLedArray[7] = pbox_DO7;

            for (int i = 0; i < 8; i++)
            {
                ((PictureBox)DOLedArray[i]).Image = imageDOList.Images[0];
                ((PictureBox)DOLedArray[i]).Tag = (uint)0;
            }
        }
        object[] DOLedArray = new object[8]; //LedArray for 8DO Status

        private void DOControl_Load(object sender, EventArgs e)
        {
        }

        private ushort m_PortNo = 0;
        public ushort PortNo
        {
            get
            {
                return m_PortNo;
            }
            set
            {
                m_PortNo = value;
                lbl_DOPortNo.Text = m_PortNo.ToString();
            }
        }

        private IntPtr m_DeviceHandle = IntPtr.Zero;
        public IntPtr DeviceHandle
        {
            get
            {
                return m_DeviceHandle;
            }
            set
            {
                m_DeviceHandle = value;
            }
        }

        private string m_SourceToolTip = "";
        public string SourceToolTip
        {
            get
            {
                return m_SourceToolTip;
            }
            set
            {
                m_SourceToolTip = value;
                foreach (Control ctrl in Controls)
                {
                    toolTip_DO.SetToolTip(ctrl, m_SourceToolTip);
                    foreach (Control c in ctrl.Controls)
                        toolTip_DO.SetToolTip(c, m_SourceToolTip);
                }
                toolTip_DO.SetToolTip(this, m_SourceToolTip);
            }
        }

        private int m_InvalidBitCount = 0;
        public int InvalidBitCount
        {
            get
            {
                return m_InvalidBitCount;
            }

            set
            {
                m_InvalidBitCount = value;
                int valid = DOLedArray.Length - m_InvalidBitCount;
                for (int i = 0; i < valid; i++)
                {
                    ((PictureBox)DOLedArray[i]).Image = imageDOList.Images[0];
                    ((PictureBox)DOLedArray[i]).Enabled = true;
                }
                for (int i = valid; i < DOLedArray.Length; i++)
                {
                    ((PictureBox)DOLedArray[i]).Image = imageDOList.Images[2];
                    ((PictureBox)DOLedArray[i]).Enabled = false;
                }
            }
        }

        private void BtnDO_Click(PictureBox pbox_DO, ushort DOChannel)
        {
            UInt32 Result;
            byte DoValue;
            uint DOHex;
            if (pbox_DO.Enabled == false)
                return;
            if ((uint)pbox_DO.Tag == 1)
            {
                DoValue = 0;
            }
            else
            {
                DoValue = 1;
            }

            Result = Motion.mAcm_DaqDoSetBit(DeviceHandle, DOChannel, DoValue);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                StringBuilder ErrorMsg = new StringBuilder("", 100);
                Boolean res = Motion.mAcm_GetErrorMessage(Result, ErrorMsg, 100);
                string ErrorMessage = "";
                if (res)
                    ErrorMessage = ErrorMsg.ToString();
                int m_Port = DOChannel / 8;
                int m_Bit = DOChannel % 8;
                MessageBox.Show("Set Port" + m_Port.ToString() + " Bit" + m_Bit.ToString() + " DO Failed with Error Code=[0x" + Convert.ToString(Result, 16) + "]:" + ErrorMessage, "Advantech Common Motion Utility", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                if ((uint)pbox_DO.Tag == 1)
                {
                    pbox_DO.Image = imageDOList.Images[0];        //0:Green
                    pbox_DO.Tag = (uint)0;                        //Set Mark
                    pbox_DO.BorderStyle = BorderStyle.None;       //BorderStyle
                    DOHex = Convert.ToUInt32(Convert.ToUInt32(lbl_DOHex.Text, 16) - Math.Pow(2, DOChannel % 8));
                    lbl_DOHex.Text = DOHex.ToString("x");
                }
                else
                {
                    pbox_DO.Image = imageDOList.Images[1];       //1:Red
                    pbox_DO.Tag = (uint)1;                       //Set Mark
                    //pbox_DO.BorderStyle =BorderStyle.Fixed3D;    //BorderStyle
                    DOHex = Convert.ToUInt32(Convert.ToUInt32(lbl_DOHex.Text, 16) + Math.Pow(2, DOChannel % 8));
                    lbl_DOHex.Text = DOHex.ToString("x");
                }
            }
        }

        private void pbox_DI0_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pbox_DO0, (ushort)(PortNo * 8 + 0));
        }

        private void pbox_DI1_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pbox_DO1, (ushort)(PortNo * 8 + 1));
        }

        private void pbox_DI2_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pbox_DO2, (ushort)(PortNo * 8 + 2));
        }

        private void pbox_DI3_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pbox_DO3, (ushort)(PortNo * 8 + 3));
        }

        private void pbox_DI4_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pbox_DO4, (ushort)(PortNo * 8 + 4));
        }

        private void pbox_DI5_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pbox_DO5, (ushort)(PortNo * 8 + 5));
        }

        private void pbox_DI6_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pbox_DO6, (ushort)(PortNo * 8 + 6));
        }

        private void pbox_DI7_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pbox_DO7, (ushort)(PortNo * 8 + 7));
        }

        public void RefreshValue()
        {
            if (DeviceHandle != IntPtr.Zero)
            {
                byte DOStatus = 0;
                uint Result = Motion.mAcm_DaqDoGetByte(DeviceHandle, PortNo, ref DOStatus);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    for (int i = 0; i < 8 - m_InvalidBitCount; i++)
                    {
                        if (((DOStatus >> i) & 0x01) == 1)
                        {
                            ((PictureBox)DOLedArray[i]).Image = imageDOList.Images[1];
                            ((PictureBox)DOLedArray[i]).Tag = (uint)1;    //Set Mark
                            //((PictureBox)DOLedArray[i]).BorderStyle = BorderStyle.Fixed3D;    //BorderStyle
                        }
                        else
                        {
                            ((PictureBox)DOLedArray[i]).Image = imageDOList.Images[0];
                            ((PictureBox)DOLedArray[i]).Tag = (uint)0;   //Set Mark
                            ((PictureBox)DOLedArray[i]).BorderStyle = BorderStyle.None;    //BorderStyle
                        }
                    }
                    lbl_DOHex.Text = DOStatus.ToString("x"); //Hex Value
                }
            }
        }
    }
}
