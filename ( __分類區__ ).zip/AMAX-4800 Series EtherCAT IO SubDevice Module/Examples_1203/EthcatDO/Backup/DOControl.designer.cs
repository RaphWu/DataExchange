﻿namespace EthcatDO
{
    partial class DOControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DOControl));
            this.gpLow = new System.Windows.Forms.GroupBox();
            this.pbox_DO0 = new System.Windows.Forms.PictureBox();
            this.pbox_DO1 = new System.Windows.Forms.PictureBox();
            this.pbox_DO2 = new System.Windows.Forms.PictureBox();
            this.pbox_DO3 = new System.Windows.Forms.PictureBox();
            this.gpHi = new System.Windows.Forms.GroupBox();
            this.pbox_DO4 = new System.Windows.Forms.PictureBox();
            this.pbox_DO5 = new System.Windows.Forms.PictureBox();
            this.pbox_DO6 = new System.Windows.Forms.PictureBox();
            this.pbox_DO7 = new System.Windows.Forms.PictureBox();
            this.lbl_DOHex = new System.Windows.Forms.Label();
            this.panel_DIHex = new System.Windows.Forms.Panel();
            this.panel_DIPortNO = new System.Windows.Forms.Panel();
            this.lbl_DOPortNo = new System.Windows.Forms.Label();
            this.imageDOList = new System.Windows.Forms.ImageList(this.components);
            this.imageDOList1 = new System.Windows.Forms.ImageList(this.components);
            this.toolTip_DO = new System.Windows.Forms.ToolTip(this.components);
            this.gpLow.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO3)).BeginInit();
            this.gpHi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO7)).BeginInit();
            this.panel_DIHex.SuspendLayout();
            this.panel_DIPortNO.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpLow
            // 
            this.gpLow.Controls.Add(this.pbox_DO0);
            this.gpLow.Controls.Add(this.pbox_DO1);
            this.gpLow.Controls.Add(this.pbox_DO2);
            this.gpLow.Controls.Add(this.pbox_DO3);
            this.gpLow.Location = new System.Drawing.Point(227, 1);
            this.gpLow.Name = "gpLow";
            this.gpLow.Size = new System.Drawing.Size(155, 42);
            this.gpLow.TabIndex = 20;
            this.gpLow.TabStop = false;
            // 
            // pbox_DO0
            // 
            this.pbox_DO0.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DO0.Location = new System.Drawing.Point(121, 12);
            this.pbox_DO0.Name = "pbox_DO0";
            this.pbox_DO0.Size = new System.Drawing.Size(25, 25);
            this.pbox_DO0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DO0.TabIndex = 13;
            this.pbox_DO0.TabStop = false;
            this.pbox_DO0.Tag = "0";
            this.pbox_DO0.Click += new System.EventHandler(this.pbox_DI0_Click);
            // 
            // pbox_DO1
            // 
            this.pbox_DO1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DO1.Location = new System.Drawing.Point(84, 12);
            this.pbox_DO1.Name = "pbox_DO1";
            this.pbox_DO1.Size = new System.Drawing.Size(25, 25);
            this.pbox_DO1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DO1.TabIndex = 14;
            this.pbox_DO1.TabStop = false;
            this.pbox_DO1.Tag = "0";
            this.pbox_DO1.Click += new System.EventHandler(this.pbox_DI1_Click);
            // 
            // pbox_DO2
            // 
            this.pbox_DO2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DO2.Location = new System.Drawing.Point(47, 12);
            this.pbox_DO2.Name = "pbox_DO2";
            this.pbox_DO2.Size = new System.Drawing.Size(25, 25);
            this.pbox_DO2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DO2.TabIndex = 12;
            this.pbox_DO2.TabStop = false;
            this.pbox_DO2.Tag = "0";
            this.pbox_DO2.Click += new System.EventHandler(this.pbox_DI2_Click);
            // 
            // pbox_DO3
            // 
            this.pbox_DO3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DO3.Location = new System.Drawing.Point(10, 12);
            this.pbox_DO3.Name = "pbox_DO3";
            this.pbox_DO3.Size = new System.Drawing.Size(25, 25);
            this.pbox_DO3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DO3.TabIndex = 11;
            this.pbox_DO3.TabStop = false;
            this.pbox_DO3.Tag = "0";
            this.pbox_DO3.Click += new System.EventHandler(this.pbox_DI3_Click);
            // 
            // gpHi
            // 
            this.gpHi.Controls.Add(this.pbox_DO4);
            this.gpHi.Controls.Add(this.pbox_DO5);
            this.gpHi.Controls.Add(this.pbox_DO6);
            this.gpHi.Controls.Add(this.pbox_DO7);
            this.gpHi.Location = new System.Drawing.Point(59, 1);
            this.gpHi.Name = "gpHi";
            this.gpHi.Size = new System.Drawing.Size(155, 42);
            this.gpHi.TabIndex = 19;
            this.gpHi.TabStop = false;
            // 
            // pbox_DO4
            // 
            this.pbox_DO4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DO4.Location = new System.Drawing.Point(121, 12);
            this.pbox_DO4.Name = "pbox_DO4";
            this.pbox_DO4.Size = new System.Drawing.Size(25, 25);
            this.pbox_DO4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DO4.TabIndex = 13;
            this.pbox_DO4.TabStop = false;
            this.pbox_DO4.Tag = "0";
            this.pbox_DO4.Click += new System.EventHandler(this.pbox_DI4_Click);
            // 
            // pbox_DO5
            // 
            this.pbox_DO5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DO5.Location = new System.Drawing.Point(84, 12);
            this.pbox_DO5.Name = "pbox_DO5";
            this.pbox_DO5.Size = new System.Drawing.Size(25, 25);
            this.pbox_DO5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DO5.TabIndex = 14;
            this.pbox_DO5.TabStop = false;
            this.pbox_DO5.Tag = "0";
            this.pbox_DO5.Click += new System.EventHandler(this.pbox_DI5_Click);
            // 
            // pbox_DO6
            // 
            this.pbox_DO6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DO6.Location = new System.Drawing.Point(47, 12);
            this.pbox_DO6.Name = "pbox_DO6";
            this.pbox_DO6.Size = new System.Drawing.Size(25, 25);
            this.pbox_DO6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DO6.TabIndex = 12;
            this.pbox_DO6.TabStop = false;
            this.pbox_DO6.Tag = "0";
            this.pbox_DO6.Click += new System.EventHandler(this.pbox_DI6_Click);
            // 
            // pbox_DO7
            // 
            this.pbox_DO7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbox_DO7.Location = new System.Drawing.Point(10, 12);
            this.pbox_DO7.Name = "pbox_DO7";
            this.pbox_DO7.Size = new System.Drawing.Size(25, 25);
            this.pbox_DO7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_DO7.TabIndex = 11;
            this.pbox_DO7.TabStop = false;
            this.pbox_DO7.Tag = "0";
            this.pbox_DO7.Click += new System.EventHandler(this.pbox_DI7_Click);
            // 
            // lbl_DOHex
            // 
            this.lbl_DOHex.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_DOHex.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_DOHex.Location = new System.Drawing.Point(0, 0);
            this.lbl_DOHex.Name = "lbl_DOHex";
            this.lbl_DOHex.Size = new System.Drawing.Size(28, 28);
            this.lbl_DOHex.TabIndex = 0;
            this.lbl_DOHex.Text = "0";
            this.lbl_DOHex.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_DIHex
            // 
            this.panel_DIHex.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_DIHex.Controls.Add(this.lbl_DOHex);
            this.panel_DIHex.Location = new System.Drawing.Point(402, 8);
            this.panel_DIHex.Name = "panel_DIHex";
            this.panel_DIHex.Size = new System.Drawing.Size(32, 32);
            this.panel_DIHex.TabIndex = 18;
            // 
            // panel_DIPortNO
            // 
            this.panel_DIPortNO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_DIPortNO.Controls.Add(this.lbl_DOPortNo);
            this.panel_DIPortNO.Location = new System.Drawing.Point(10, 8);
            this.panel_DIPortNO.Name = "panel_DIPortNO";
            this.panel_DIPortNO.Size = new System.Drawing.Size(32, 32);
            this.panel_DIPortNO.TabIndex = 17;
            // 
            // lbl_DOPortNo
            // 
            this.lbl_DOPortNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_DOPortNo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_DOPortNo.Location = new System.Drawing.Point(0, 0);
            this.lbl_DOPortNo.Name = "lbl_DOPortNo";
            this.lbl_DOPortNo.Size = new System.Drawing.Size(28, 28);
            this.lbl_DOPortNo.TabIndex = 0;
            this.lbl_DOPortNo.Text = "0";
            this.lbl_DOPortNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // imageDOList
            // 
            this.imageDOList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageDOList.ImageStream")));
            this.imageDOList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageDOList.Images.SetKeyName(0, "DO_Off_32.png");
            this.imageDOList.Images.SetKeyName(1, "Do_On_32.png");
            this.imageDOList.Images.SetKeyName(2, "disable.bmp");
            // 
            // imageDOList1
            // 
            this.imageDOList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageDOList1.ImageStream")));
            this.imageDOList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageDOList1.Images.SetKeyName(0, "DarkRed1.png");
            this.imageDOList1.Images.SetKeyName(1, "DarkRed.jpg");
            // 
            // toolTip_DO
            // 
            this.toolTip_DO.UseFading = false;
            // 
            // DOControl
            // 
            this.Controls.Add(this.gpLow);
            this.Controls.Add(this.gpHi);
            this.Controls.Add(this.panel_DIHex);
            this.Controls.Add(this.panel_DIPortNO);
            this.Name = "DOControl";
            this.Size = new System.Drawing.Size(440, 42);
            this.Load += new System.EventHandler(this.DOControl_Load);
            this.gpLow.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO3)).EndInit();
            this.gpHi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DO7)).EndInit();
            this.panel_DIHex.ResumeLayout(false);
            this.panel_DIPortNO.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbox_DO0;
        private System.Windows.Forms.PictureBox pbox_DO1;
        private System.Windows.Forms.PictureBox pbox_DO2;
        private System.Windows.Forms.PictureBox pbox_DO3;
        private System.Windows.Forms.PictureBox pbox_DO4;
        private System.Windows.Forms.PictureBox pbox_DO5;
        private System.Windows.Forms.PictureBox pbox_DO6;
        private System.Windows.Forms.PictureBox pbox_DO7;
        private System.Windows.Forms.Panel panel_DIHex;
        private System.Windows.Forms.Panel panel_DIPortNO;
        private System.Windows.Forms.ImageList imageDOList;
        private System.Windows.Forms.ImageList imageDOList1;
        private System.Windows.Forms.ToolTip toolTip_DO;
        private System.Windows.Forms.Label lbl_DOPortNo;
        private System.Windows.Forms.Label lbl_DOHex;
        public System.Windows.Forms.GroupBox gpLow;
        public System.Windows.Forms.GroupBox gpHi;
    }
}
