﻿using Advantech.Motion;
using System;
namespace SimulateOpe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonPos = new System.Windows.Forms.RadioButton();
            this.radioButtonNeg = new System.Windows.Forms.RadioButton();
            this.buttonReset = new System.Windows.Forms.Button();
            this.buttonSuspend = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.buttonStart = new System.Windows.Forms.Button();
            this.comboBoxAxislist = new System.Windows.Forms.ComboBox();
            this.listViewAvailableAxis = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.label1 = new System.Windows.Forms.Label();
            this.cmb_SimulateStartSource = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.group = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxPos = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn_SetParam = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.rdb_Rel = new System.Windows.Forms.RadioButton();
            this.rdb_Abs = new System.Windows.Forms.RadioButton();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.rdb_T = new System.Windows.Forms.RadioButton();
            this.rdb_S = new System.Windows.Forms.RadioButton();
            this.textBoxDec = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.textBoxAcc = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.textBoxVelH = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxVelL = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnMove = new System.Windows.Forms.Button();
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBoxSelectedAxis = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.textBoxCurState = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.group.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonPos);
            this.groupBox1.Controls.Add(this.radioButtonNeg);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox1.Location = new System.Drawing.Point(23, 76);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(292, 46);
            this.groupBox1.TabIndex = 47;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Move Direction";
            // 
            // radioButtonPos
            // 
            this.radioButtonPos.AutoSize = true;
            this.radioButtonPos.Checked = true;
            this.radioButtonPos.Location = new System.Drawing.Point(6, 20);
            this.radioButtonPos.Name = "radioButtonPos";
            this.radioButtonPos.Size = new System.Drawing.Size(85, 16);
            this.radioButtonPos.TabIndex = 7;
            this.radioButtonPos.TabStop = true;
            this.radioButtonPos.Text = "Pos Direction";
            this.radioButtonPos.UseVisualStyleBackColor = true;
            // 
            // radioButtonNeg
            // 
            this.radioButtonNeg.AutoSize = true;
            this.radioButtonNeg.Location = new System.Drawing.Point(179, 20);
            this.radioButtonNeg.Name = "radioButtonNeg";
            this.radioButtonNeg.Size = new System.Drawing.Size(88, 16);
            this.radioButtonNeg.TabIndex = 8;
            this.radioButtonNeg.TabStop = true;
            this.radioButtonNeg.Text = "Neg Direction";
            this.radioButtonNeg.UseVisualStyleBackColor = true;
            // 
            // buttonReset
            // 
            this.buttonReset.Location = new System.Drawing.Point(523, 276);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(98, 28);
            this.buttonReset.TabIndex = 46;
            this.buttonReset.Text = "Reset Counter";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // buttonSuspend
            // 
            this.buttonSuspend.Location = new System.Drawing.Point(18, 266);
            this.buttonSuspend.Name = "buttonSuspend";
            this.buttonSuspend.Size = new System.Drawing.Size(123, 28);
            this.buttonSuspend.TabIndex = 45;
            this.buttonSuspend.Text = "Simulate Suspend Start";
            this.buttonSuspend.UseVisualStyleBackColor = true;
            this.buttonSuspend.Click += new System.EventHandler(this.buttonSuspend_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Location = new System.Drawing.Point(257, 266);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(98, 28);
            this.buttonStop.TabIndex = 44;
            this.buttonStop.Text = "Simulate Stop ";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openFileDialog1";
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(147, 266);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(104, 28);
            this.buttonStart.TabIndex = 43;
            this.buttonStart.Text = "Simulate Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // comboBoxAxislist
            // 
            this.comboBoxAxislist.FormattingEnabled = true;
            this.comboBoxAxislist.Location = new System.Drawing.Point(149, 17);
            this.comboBoxAxislist.Name = "comboBoxAxislist";
            this.comboBoxAxislist.Size = new System.Drawing.Size(168, 20);
            this.comboBoxAxislist.TabIndex = 41;
            // 
            // listViewAvailableAxis
            // 
            this.listViewAvailableAxis.CheckBoxes = true;
            this.listViewAvailableAxis.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listViewAvailableAxis.Location = new System.Drawing.Point(398, 18);
            this.listViewAvailableAxis.Name = "listViewAvailableAxis";
            this.listViewAvailableAxis.Size = new System.Drawing.Size(345, 242);
            this.listViewAvailableAxis.TabIndex = 42;
            this.listViewAvailableAxis.UseCompatibleStateImageBehavior = false;
            this.listViewAvailableAxis.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Available Axis";
            this.columnHeader1.Width = 110;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Command Position";
            this.columnHeader2.Width = 119;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Actual Position";
            this.columnHeader3.Width = 111;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 12);
            this.label1.TabIndex = 40;
            this.label1.Text = "Master Axis:";
            // 
            // cmb_SimulateStartSource
            // 
            this.cmb_SimulateStartSource.FormattingEnabled = true;
            this.cmb_SimulateStartSource.Location = new System.Drawing.Point(149, 48);
            this.cmb_SimulateStartSource.Name = "cmb_SimulateStartSource";
            this.cmb_SimulateStartSource.Size = new System.Drawing.Size(168, 20);
            this.cmb_SimulateStartSource.TabIndex = 50;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 12);
            this.label2.TabIndex = 49;
            this.label2.Text = "Simulate Start Source:";
            // 
            // group
            // 
            this.group.Controls.Add(this.label3);
            this.group.Controls.Add(this.CmbAvailableDevice);
            this.group.Controls.Add(this.BtnOpenBoard);
            this.group.Controls.Add(this.BtnCloseBoard);
            this.group.Controls.Add(this.BtnLoadCfg);
            this.group.Controls.Add(this.BtnServo);
            this.group.Location = new System.Drawing.Point(18, 11);
            this.group.Name = "group";
            this.group.Size = new System.Drawing.Size(337, 110);
            this.group.TabIndex = 51;
            this.group.TabStop = false;
            this.group.Text = "Device Operate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "Available device:";
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(135, 20);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(153, 20);
            this.CmbAvailableDevice.TabIndex = 2;
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(55, 46);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(95, 25);
            this.BtnOpenBoard.TabIndex = 3;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(200, 46);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(95, 25);
            this.BtnCloseBoard.TabIndex = 5;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(54, 77);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(95, 25);
            this.BtnLoadCfg.TabIndex = 4;
            this.BtnLoadCfg.Text = "Load Config";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            this.BtnLoadCfg.Click += new System.EventHandler(this.BtnLoadCfg_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(200, 76);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(95, 25);
            this.BtnServo.TabIndex = 6;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.comboBoxAxislist);
            this.groupBox2.Controls.Add(this.groupBox1);
            this.groupBox2.Controls.Add(this.cmb_SimulateStartSource);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(18, 128);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(337, 132);
            this.groupBox2.TabIndex = 52;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Simulate Set";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label11);
            this.groupBox13.Controls.Add(this.label17);
            this.groupBox13.Controls.Add(this.label12);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox13.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox13.Controls.Add(this.pictureBoxORG);
            this.groupBox13.Controls.Add(this.pictureBoxALM);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(398, 323);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(345, 95);
            this.groupBox13.TabIndex = 114;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Selected Axis Signal Status";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(260, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 12);
            this.label11.TabIndex = 28;
            this.label11.Text = "-HEL:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(173, 41);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 12);
            this.label17.TabIndex = 27;
            this.label17.Text = "+HEL:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(92, 41);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 12);
            this.label12.TabIndex = 26;
            this.label12.Text = "ORG:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(17, 42);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(33, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(298, 37);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(212, 37);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(125, 37);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(50, 37);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.textBoxPos);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.BtnStop);
            this.groupBox3.Controls.Add(this.BtnMove);
            this.groupBox3.Controls.Add(this.CmbAxes);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.Location = new System.Drawing.Point(18, 300);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(362, 256);
            this.groupBox3.TabIndex = 115;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Point to Point Movement";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(27, 227);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 12);
            this.label10.TabIndex = 31;
            this.label10.Text = "EndPoint:";
            // 
            // textBoxPos
            // 
            this.textBoxPos.Location = new System.Drawing.Point(89, 224);
            this.textBoxPos.Name = "textBoxPos";
            this.textBoxPos.Size = new System.Drawing.Size(104, 22);
            this.textBoxPos.TabIndex = 18;
            this.textBoxPos.Text = "50000";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btn_SetParam);
            this.groupBox4.Controls.Add(this.groupBox9);
            this.groupBox4.Controls.Add(this.groupBox8);
            this.groupBox4.Controls.Add(this.textBoxDec);
            this.groupBox4.Controls.Add(this.Label6);
            this.groupBox4.Controls.Add(this.textBoxAcc);
            this.groupBox4.Controls.Add(this.Label8);
            this.groupBox4.Controls.Add(this.textBoxVelH);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.textBoxVelL);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox4.Location = new System.Drawing.Point(11, 40);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(341, 172);
            this.groupBox4.TabIndex = 50;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Vel Set";
            // 
            // btn_SetParam
            // 
            this.btn_SetParam.Location = new System.Drawing.Point(126, 138);
            this.btn_SetParam.Name = "btn_SetParam";
            this.btn_SetParam.Size = new System.Drawing.Size(96, 24);
            this.btn_SetParam.TabIndex = 42;
            this.btn_SetParam.Text = "Set/Get Param";
            this.btn_SetParam.UseVisualStyleBackColor = true;
            this.btn_SetParam.Click += new System.EventHandler(this.btn_SetParam_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.rdb_Rel);
            this.groupBox9.Controls.Add(this.rdb_Abs);
            this.groupBox9.Location = new System.Drawing.Point(176, 77);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(155, 55);
            this.groupBox9.TabIndex = 41;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "MoveMent Mode";
            // 
            // rdb_Rel
            // 
            this.rdb_Rel.AutoSize = true;
            this.rdb_Rel.Checked = true;
            this.rdb_Rel.Location = new System.Drawing.Point(8, 25);
            this.rdb_Rel.Name = "rdb_Rel";
            this.rdb_Rel.Size = new System.Drawing.Size(61, 16);
            this.rdb_Rel.TabIndex = 35;
            this.rdb_Rel.TabStop = true;
            this.rdb_Rel.Text = "Relative";
            this.rdb_Rel.UseVisualStyleBackColor = true;
            // 
            // rdb_Abs
            // 
            this.rdb_Abs.AutoSize = true;
            this.rdb_Abs.Location = new System.Drawing.Point(83, 24);
            this.rdb_Abs.Name = "rdb_Abs";
            this.rdb_Abs.Size = new System.Drawing.Size(64, 16);
            this.rdb_Abs.TabIndex = 36;
            this.rdb_Abs.Text = "Absolute";
            this.rdb_Abs.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.rdb_T);
            this.groupBox8.Controls.Add(this.rdb_S);
            this.groupBox8.Location = new System.Drawing.Point(10, 77);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(155, 55);
            this.groupBox8.TabIndex = 40;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Jerk";
            // 
            // rdb_T
            // 
            this.rdb_T.AutoSize = true;
            this.rdb_T.Checked = true;
            this.rdb_T.Location = new System.Drawing.Point(5, 25);
            this.rdb_T.Name = "rdb_T";
            this.rdb_T.Size = new System.Drawing.Size(67, 16);
            this.rdb_T.TabIndex = 35;
            this.rdb_T.TabStop = true;
            this.rdb_T.Text = "T-Curver";
            this.rdb_T.UseVisualStyleBackColor = true;
            // 
            // rdb_S
            // 
            this.rdb_S.AutoSize = true;
            this.rdb_S.Location = new System.Drawing.Point(82, 25);
            this.rdb_S.Name = "rdb_S";
            this.rdb_S.Size = new System.Drawing.Size(66, 16);
            this.rdb_S.TabIndex = 36;
            this.rdb_S.Text = "S-Curver";
            this.rdb_S.UseVisualStyleBackColor = true;
            // 
            // textBoxDec
            // 
            this.textBoxDec.Location = new System.Drawing.Point(213, 48);
            this.textBoxDec.Name = "textBoxDec";
            this.textBoxDec.Size = new System.Drawing.Size(112, 22);
            this.textBoxDec.TabIndex = 26;
            this.textBoxDec.Text = "10000";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(181, 53);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(31, 12);
            this.Label6.TabIndex = 25;
            this.Label6.Text = "DEC:";
            // 
            // textBoxAcc
            // 
            this.textBoxAcc.Location = new System.Drawing.Point(50, 48);
            this.textBoxAcc.Name = "textBoxAcc";
            this.textBoxAcc.Size = new System.Drawing.Size(112, 22);
            this.textBoxAcc.TabIndex = 24;
            this.textBoxAcc.Text = "10000";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(19, 53);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(32, 12);
            this.Label8.TabIndex = 23;
            this.Label8.Text = "ACC:";
            // 
            // textBoxVelH
            // 
            this.textBoxVelH.Location = new System.Drawing.Point(212, 21);
            this.textBoxVelH.Name = "textBoxVelH";
            this.textBoxVelH.Size = new System.Drawing.Size(112, 22);
            this.textBoxVelH.TabIndex = 22;
            this.textBoxVelH.Text = "8000";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(175, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 12);
            this.label7.TabIndex = 21;
            this.label7.Text = "VelH:";
            // 
            // textBoxVelL
            // 
            this.textBoxVelL.Location = new System.Drawing.Point(50, 21);
            this.textBoxVelL.Name = "textBoxVelL";
            this.textBoxVelL.Size = new System.Drawing.Size(112, 22);
            this.textBoxVelL.TabIndex = 20;
            this.textBoxVelL.TabStop = false;
            this.textBoxVelL.Text = "2000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 12);
            this.label9.TabIndex = 19;
            this.label9.Text = "VelL:";
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(278, 224);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(65, 23);
            this.BtnStop.TabIndex = 25;
            this.BtnStop.Text = "Stop";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // BtnMove
            // 
            this.BtnMove.Location = new System.Drawing.Point(205, 224);
            this.BtnMove.Name = "BtnMove";
            this.BtnMove.Size = new System.Drawing.Size(65, 23);
            this.BtnMove.TabIndex = 20;
            this.BtnMove.Text = "Move";
            this.BtnMove.UseVisualStyleBackColor = true;
            this.BtnMove.Click += new System.EventHandler(this.BtnMove_Click);
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(143, 19);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(132, 20);
            this.CmbAxes.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(103, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 20;
            this.label4.Text = "Axis:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.comboBoxSelectedAxis);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.BtnResetErr);
            this.groupBox5.Controls.Add(this.textBoxCurState);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox5.Location = new System.Drawing.Point(398, 424);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(345, 122);
            this.groupBox5.TabIndex = 116;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Selected Axis State";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(81, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 35;
            this.label13.Text = "Axis:";
            // 
            // comboBoxSelectedAxis
            // 
            this.comboBoxSelectedAxis.FormattingEnabled = true;
            this.comboBoxSelectedAxis.Location = new System.Drawing.Point(125, 21);
            this.comboBoxSelectedAxis.Name = "comboBoxSelectedAxis";
            this.comboBoxSelectedAxis.Size = new System.Drawing.Size(130, 20);
            this.comboBoxSelectedAxis.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(80, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 33;
            this.label5.Text = "Status:";
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(132, 80);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(100, 26);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "Reset Error";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            this.BtnResetErr.Click += new System.EventHandler(this.BtnResetErr_Click);
            // 
            // textBoxCurState
            // 
            this.textBoxCurState.Location = new System.Drawing.Point(125, 52);
            this.textBoxCurState.Name = "textBoxCurState";
            this.textBoxCurState.ReadOnly = true;
            this.textBoxCurState.Size = new System.Drawing.Size(130, 22);
            this.textBoxCurState.TabIndex = 30;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 564);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.group);
            this.Controls.Add(this.buttonReset);
            this.Controls.Add(this.buttonSuspend);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.listViewAvailableAxis);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SimulateOpe";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.group.ResumeLayout(false);
            this.group.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButtonPos;
        private System.Windows.Forms.RadioButton radioButtonNeg;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Button buttonSuspend;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.ComboBox comboBoxAxislist;
        private System.Windows.Forms.ListView listViewAvailableAxis;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Label label1;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[64];
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        private System.Windows.Forms.ComboBox cmb_SimulateStartSource;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox group;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnLoadCfg;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxPos;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btn_SetParam;
        private System.Windows.Forms.GroupBox groupBox9;
        public System.Windows.Forms.RadioButton rdb_Rel;
        public System.Windows.Forms.RadioButton rdb_Abs;
        private System.Windows.Forms.GroupBox groupBox8;
        public System.Windows.Forms.RadioButton rdb_T;
        public System.Windows.Forms.RadioButton rdb_S;
        private System.Windows.Forms.TextBox textBoxDec;
        private System.Windows.Forms.Label Label6;
        private System.Windows.Forms.TextBox textBoxAcc;
        private System.Windows.Forms.Label Label8;
        private System.Windows.Forms.TextBox textBoxVelH;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxVelL;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Button BtnMove;
        private System.Windows.Forms.ComboBox CmbAxes;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBoxSelectedAxis;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button BtnResetErr;
        private System.Windows.Forms.TextBox textBoxCurState;
    }
}

