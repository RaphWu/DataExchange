﻿using Advantech.Motion;//Common Motion API
using System;
namespace Latch
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnMove = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButtonRel = new System.Windows.Forms.RadioButton();
            this.radioButtonAbs = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxPos = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.btn_ResetCount = new System.Windows.Forms.Button();
            this.textBoxAct = new System.Windows.Forms.TextBox();
            this.textBoxCmd = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txb_LatchData = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txb_LatchFlag = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.textBoxCurState = new System.Windows.Forms.TextBox();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.rdo_HighActive = new System.Windows.Forms.RadioButton();
            this.rdo_LowActive = new System.Windows.Forms.RadioButton();
            this.btn_ResetLatch = new System.Windows.Forms.Button();
            this.btn_TriggerLatch = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.rdo_FdbPos = new System.Windows.Forms.RadioButton();
            this.rdo_CmdPos = new System.Windows.Forms.RadioButton();
            this.Latchtimer = new System.Windows.Forms.Timer(this.components);
            this.group = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.group.SuspendLayout();
            this.SuspendLayout();
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(141, 23);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(144, 20);
            this.CmbAxes.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(103, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 20;
            this.label2.Text = "Axis:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BtnStop);
            this.groupBox1.Controls.Add(this.BtnMove);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.CmbAxes);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(18, 126);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(347, 150);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Point to Point Movement";
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(207, 111);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(95, 26);
            this.BtnStop.TabIndex = 25;
            this.BtnStop.Text = "Stop";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // BtnMove
            // 
            this.BtnMove.Location = new System.Drawing.Point(50, 111);
            this.BtnMove.Name = "BtnMove";
            this.BtnMove.Size = new System.Drawing.Size(95, 26);
            this.BtnMove.TabIndex = 20;
            this.BtnMove.Text = "Move";
            this.BtnMove.UseVisualStyleBackColor = true;
            this.BtnMove.Click += new System.EventHandler(this.BtnMove_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButtonRel);
            this.groupBox3.Controls.Add(this.radioButtonAbs);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.Location = new System.Drawing.Point(152, 52);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(181, 48);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Move Mode";
            // 
            // radioButtonRel
            // 
            this.radioButtonRel.AutoSize = true;
            this.radioButtonRel.Checked = true;
            this.radioButtonRel.Location = new System.Drawing.Point(100, 22);
            this.radioButtonRel.Name = "radioButtonRel";
            this.radioButtonRel.Size = new System.Drawing.Size(71, 16);
            this.radioButtonRel.TabIndex = 1;
            this.radioButtonRel.TabStop = true;
            this.radioButtonRel.Text = "Relative";
            this.radioButtonRel.UseVisualStyleBackColor = true;
            // 
            // radioButtonAbs
            // 
            this.radioButtonAbs.AutoSize = true;
            this.radioButtonAbs.Location = new System.Drawing.Point(11, 22);
            this.radioButtonAbs.Name = "radioButtonAbs";
            this.radioButtonAbs.Size = new System.Drawing.Size(71, 16);
            this.radioButtonAbs.TabIndex = 0;
            this.radioButtonAbs.TabStop = true;
            this.radioButtonAbs.Text = "Absolute";
            this.radioButtonAbs.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBoxPos);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(12, 50);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(126, 50);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "End Point";
            // 
            // textBoxPos
            // 
            this.textBoxPos.Location = new System.Drawing.Point(24, 16);
            this.textBoxPos.Name = "textBoxPos";
            this.textBoxPos.Size = new System.Drawing.Size(85, 21);
            this.textBoxPos.TabIndex = 18;
            this.textBoxPos.Text = "50000";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.groupBox13);
            this.groupBox4.Controls.Add(this.groupBox11);
            this.groupBox4.Controls.Add(this.groupBox9);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox4.Location = new System.Drawing.Point(384, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(267, 436);
            this.groupBox4.TabIndex = 29;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Info";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label16);
            this.groupBox13.Controls.Add(this.label17);
            this.groupBox13.Controls.Add(this.label18);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox13.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox13.Controls.Add(this.pictureBoxORG);
            this.groupBox13.Controls.Add(this.pictureBoxALM);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(19, 232);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(229, 87);
            this.groupBox13.TabIndex = 54;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Axis Signal Status";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(145, 60);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 12);
            this.label16.TabIndex = 28;
            this.label16.Text = "-HEL:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(19, 58);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 12);
            this.label17.TabIndex = 27;
            this.label17.Text = "+HEL:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(152, 28);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 26;
            this.label18.Text = "ORG:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(24, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(184, 54);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(57, 53);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(184, 23);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(57, 24);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.btn_ResetCount);
            this.groupBox11.Controls.Add(this.textBoxAct);
            this.groupBox11.Controls.Add(this.textBoxCmd);
            this.groupBox11.Controls.Add(this.label6);
            this.groupBox11.Controls.Add(this.label11);
            this.groupBox11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox11.Location = new System.Drawing.Point(19, 19);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(229, 107);
            this.groupBox11.TabIndex = 38;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Position";
            // 
            // btn_ResetCount
            // 
            this.btn_ResetCount.Location = new System.Drawing.Point(76, 75);
            this.btn_ResetCount.Name = "btn_ResetCount";
            this.btn_ResetCount.Size = new System.Drawing.Size(100, 26);
            this.btn_ResetCount.TabIndex = 15;
            this.btn_ResetCount.Text = "Reset Counter";
            this.btn_ResetCount.UseVisualStyleBackColor = true;
            this.btn_ResetCount.Click += new System.EventHandler(this.btn_ResetCount_Click);
            // 
            // textBoxAct
            // 
            this.textBoxAct.Location = new System.Drawing.Point(87, 47);
            this.textBoxAct.Name = "textBoxAct";
            this.textBoxAct.ReadOnly = true;
            this.textBoxAct.Size = new System.Drawing.Size(121, 21);
            this.textBoxAct.TabIndex = 33;
            // 
            // textBoxCmd
            // 
            this.textBoxCmd.Location = new System.Drawing.Point(87, 19);
            this.textBoxCmd.Name = "textBoxCmd";
            this.textBoxCmd.ReadOnly = true;
            this.textBoxCmd.Size = new System.Drawing.Size(121, 21);
            this.textBoxCmd.TabIndex = 30;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(55, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 32;
            this.label6.Text = "Act:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(55, 24);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 29;
            this.label11.Text = "Cmd:";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label4);
            this.groupBox9.Controls.Add(this.txb_LatchData);
            this.groupBox9.Controls.Add(this.label5);
            this.groupBox9.Controls.Add(this.txb_LatchFlag);
            this.groupBox9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox9.Location = new System.Drawing.Point(19, 135);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(229, 88);
            this.groupBox9.TabIndex = 37;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Latch";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "Latch Data:";
            // 
            // txb_LatchData
            // 
            this.txb_LatchData.Location = new System.Drawing.Point(87, 23);
            this.txb_LatchData.Name = "txb_LatchData";
            this.txb_LatchData.ReadOnly = true;
            this.txb_LatchData.Size = new System.Drawing.Size(121, 21);
            this.txb_LatchData.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 12);
            this.label5.TabIndex = 3;
            this.label5.Text = "Latch Flag:";
            // 
            // txb_LatchFlag
            // 
            this.txb_LatchFlag.Location = new System.Drawing.Point(87, 54);
            this.txb_LatchFlag.Name = "txb_LatchFlag";
            this.txb_LatchFlag.ReadOnly = true;
            this.txb_LatchFlag.Size = new System.Drawing.Size(121, 21);
            this.txb_LatchFlag.TabIndex = 4;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.BtnResetErr);
            this.groupBox5.Controls.Add(this.textBoxCurState);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox5.Location = new System.Drawing.Point(19, 328);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(229, 95);
            this.groupBox5.TabIndex = 36;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Current State";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(37, 32);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 12);
            this.label15.TabIndex = 33;
            this.label15.Text = "Status:";
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(81, 55);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(97, 27);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "Reset Error";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            this.BtnResetErr.Click += new System.EventHandler(this.BtnResetErr_Click);
            // 
            // textBoxCurState
            // 
            this.textBoxCurState.Location = new System.Drawing.Point(87, 27);
            this.textBoxCurState.Name = "textBoxCurState";
            this.textBoxCurState.ReadOnly = true;
            this.textBoxCurState.Size = new System.Drawing.Size(121, 21);
            this.textBoxCurState.TabIndex = 30;
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openFileDialog1";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.groupBox10);
            this.groupBox7.Controls.Add(this.btn_ResetLatch);
            this.groupBox7.Controls.Add(this.btn_TriggerLatch);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox7.Location = new System.Drawing.Point(18, 283);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(347, 165);
            this.groupBox7.TabIndex = 46;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Latch";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.rdo_HighActive);
            this.groupBox10.Controls.Add(this.rdo_LowActive);
            this.groupBox10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox10.Location = new System.Drawing.Point(32, 18);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(286, 46);
            this.groupBox10.TabIndex = 7;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Latch Logic";
            // 
            // rdo_HighActive
            // 
            this.rdo_HighActive.AutoSize = true;
            this.rdo_HighActive.Checked = true;
            this.rdo_HighActive.Location = new System.Drawing.Point(167, 22);
            this.rdo_HighActive.Name = "rdo_HighActive";
            this.rdo_HighActive.Size = new System.Drawing.Size(89, 16);
            this.rdo_HighActive.TabIndex = 1;
            this.rdo_HighActive.TabStop = true;
            this.rdo_HighActive.Text = "High Active";
            this.rdo_HighActive.UseVisualStyleBackColor = true;
            // 
            // rdo_LowActive
            // 
            this.rdo_LowActive.AutoSize = true;
            this.rdo_LowActive.Location = new System.Drawing.Point(19, 22);
            this.rdo_LowActive.Name = "rdo_LowActive";
            this.rdo_LowActive.Size = new System.Drawing.Size(83, 16);
            this.rdo_LowActive.TabIndex = 0;
            this.rdo_LowActive.Text = "Low Active";
            this.rdo_LowActive.UseVisualStyleBackColor = true;
            // 
            // btn_ResetLatch
            // 
            this.btn_ResetLatch.Location = new System.Drawing.Point(207, 130);
            this.btn_ResetLatch.Name = "btn_ResetLatch";
            this.btn_ResetLatch.Size = new System.Drawing.Size(95, 26);
            this.btn_ResetLatch.TabIndex = 6;
            this.btn_ResetLatch.Text = "Reset Latch";
            this.btn_ResetLatch.UseVisualStyleBackColor = true;
            this.btn_ResetLatch.Click += new System.EventHandler(this.btn_ResetLatch_Click);
            // 
            // btn_TriggerLatch
            // 
            this.btn_TriggerLatch.Location = new System.Drawing.Point(50, 130);
            this.btn_TriggerLatch.Name = "btn_TriggerLatch";
            this.btn_TriggerLatch.Size = new System.Drawing.Size(95, 26);
            this.btn_TriggerLatch.TabIndex = 5;
            this.btn_TriggerLatch.Text = "Trigger Latch";
            this.btn_TriggerLatch.UseVisualStyleBackColor = true;
            this.btn_TriggerLatch.Click += new System.EventHandler(this.btn_TriggerLatch_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.rdo_FdbPos);
            this.groupBox8.Controls.Add(this.rdo_CmdPos);
            this.groupBox8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox8.Location = new System.Drawing.Point(32, 73);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(286, 46);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Position Type";
            // 
            // rdo_FdbPos
            // 
            this.rdo_FdbPos.AutoSize = true;
            this.rdo_FdbPos.Location = new System.Drawing.Point(167, 21);
            this.rdo_FdbPos.Name = "rdo_FdbPos";
            this.rdo_FdbPos.Size = new System.Drawing.Size(95, 16);
            this.rdo_FdbPos.TabIndex = 1;
            this.rdo_FdbPos.Text = "Feedback Pos";
            this.rdo_FdbPos.UseVisualStyleBackColor = true;
            // 
            // rdo_CmdPos
            // 
            this.rdo_CmdPos.AutoSize = true;
            this.rdo_CmdPos.Checked = true;
            this.rdo_CmdPos.Location = new System.Drawing.Point(19, 20);
            this.rdo_CmdPos.Name = "rdo_CmdPos";
            this.rdo_CmdPos.Size = new System.Drawing.Size(89, 16);
            this.rdo_CmdPos.TabIndex = 0;
            this.rdo_CmdPos.TabStop = true;
            this.rdo_CmdPos.Text = "Command Pos";
            this.rdo_CmdPos.UseVisualStyleBackColor = true;
            // 
            // group
            // 
            this.group.Controls.Add(this.label1);
            this.group.Controls.Add(this.CmbAvailableDevice);
            this.group.Controls.Add(this.BtnOpenBoard);
            this.group.Controls.Add(this.BtnCloseBoard);
            this.group.Controls.Add(this.BtnLoadCfg);
            this.group.Controls.Add(this.BtnServo);
            this.group.Location = new System.Drawing.Point(18, 11);
            this.group.Name = "group";
            this.group.Size = new System.Drawing.Size(347, 108);
            this.group.TabIndex = 47;
            this.group.TabStop = false;
            this.group.Text = "Device Operate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "Available device:";
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(135, 17);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(176, 20);
            this.CmbAvailableDevice.TabIndex = 2;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(50, 44);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(95, 25);
            this.BtnOpenBoard.TabIndex = 3;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(207, 44);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(95, 25);
            this.BtnCloseBoard.TabIndex = 5;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(50, 74);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(95, 25);
            this.BtnLoadCfg.TabIndex = 4;
            this.BtnLoadCfg.Text = "Load Config";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            this.BtnLoadCfg.Click += new System.EventHandler(this.BtnLoadCfg_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(207, 74);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(95, 25);
            this.BtnServo.TabIndex = 6;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 468);
            this.Controls.Add(this.group);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Latch";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.group.ResumeLayout(false);
            this.group.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox CmbAxes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBoxPos;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Button BtnMove;
        private System.Windows.Forms.RadioButton radioButtonRel;
        private System.Windows.Forms.RadioButton radioButtonAbs;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button BtnResetErr;
        private System.Windows.Forms.TextBox textBoxCurState;
        private System.Windows.Forms.TextBox textBoxCmd;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[64];
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox txb_LatchFlag;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txb_LatchData;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btn_ResetLatch;
        private System.Windows.Forms.Button btn_TriggerLatch;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RadioButton rdo_FdbPos;
        private System.Windows.Forms.RadioButton rdo_CmdPos;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Timer Latchtimer;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton rdo_HighActive;
        private System.Windows.Forms.RadioButton rdo_LowActive;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button btn_ResetCount;
        private System.Windows.Forms.TextBox textBoxAct;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox group;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnLoadCfg;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
    }
}

