﻿using Advantech.Motion;//Common Motion API
using System;
namespace LatchBuffer
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnServo = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_Set = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.rdb_High = new System.Windows.Forms.RadioButton();
            this.rdb_Low = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rdb_RorFEge = new System.Windows.Forms.RadioButton();
            this.rdb_FallingEdge = new System.Windows.Forms.RadioButton();
            this.rdb_RisingEdge = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdb_Fdb = new System.Windows.Forms.RadioButton();
            this.rdb_Cmd = new System.Windows.Forms.RadioButton();
            this.txb_LatchBufMinDist = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txb_LatchBuf_Event_Nums = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBox_LatchBufEnable = new System.Windows.Forms.CheckBox();
            this.cmb_LatchBufAxisID = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btn_LatchBuffedCon = new System.Windows.Forms.Button();
            this.btn_LatchBuffedPTP = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btn_Stop = new System.Windows.Forms.Button();
            this.btn_Continue = new System.Windows.Forms.Button();
            this.btn_ptp = new System.Windows.Forms.Button();
            this.txb_Pos = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.rdb_Rel = new System.Windows.Forms.RadioButton();
            this.rdb_Abs = new System.Windows.Forms.RadioButton();
            this.cmb_SelectedAxis = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btn_ResetLatchBuf = new System.Windows.Forms.Button();
            this.btn_GetLatchBuf = new System.Windows.Forms.Button();
            this.txb_LatchBufCnt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_ResetCount = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxAxisLatchBufCnt = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txb_LatedAxisState = new System.Windows.Forms.TextBox();
            this.txb_LatedAxisCmd = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txb_State = new System.Windows.Forms.TextBox();
            this.txb_CmdPos = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txb_SpaceCnt = new System.Windows.Forms.TextBox();
            this.txb_RemainCnt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(179, 76);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(90, 25);
            this.BtnServo.TabIndex = 12;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(179, 46);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(90, 25);
            this.BtnCloseBoard.TabIndex = 11;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(66, 76);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(90, 25);
            this.BtnLoadCfg.TabIndex = 10;
            this.BtnLoadCfg.Text = "Load Config";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            this.BtnLoadCfg.Click += new System.EventHandler(this.BtnLoadCfg_Click);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(66, 46);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(90, 25);
            this.BtnOpenBoard.TabIndex = 9;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(139, 18);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(146, 20);
            this.CmbAvailableDevice.TabIndex = 8;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "Available device:";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openConfigFileDialog";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_Set);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.txb_LatchBufMinDist);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txb_LatchBuf_Event_Nums);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.checkBox_LatchBufEnable);
            this.groupBox1.Controls.Add(this.cmb_LatchBufAxisID);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(19, 123);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(335, 254);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Latch Buffer";
            // 
            // btn_Set
            // 
            this.btn_Set.Location = new System.Drawing.Point(230, 211);
            this.btn_Set.Name = "btn_Set";
            this.btn_Set.Size = new System.Drawing.Size(91, 30);
            this.btn_Set.TabIndex = 14;
            this.btn_Set.Text = "Set ";
            this.btn_Set.UseVisualStyleBackColor = true;
            this.btn_Set.Click += new System.EventHandler(this.btn_Set_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.rdb_High);
            this.groupBox4.Controls.Add(this.rdb_Low);
            this.groupBox4.Location = new System.Drawing.Point(12, 204);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(207, 42);
            this.groupBox4.TabIndex = 16;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Latch Active";
            // 
            // rdb_High
            // 
            this.rdb_High.AutoSize = true;
            this.rdb_High.Location = new System.Drawing.Point(112, 20);
            this.rdb_High.Name = "rdb_High";
            this.rdb_High.Size = new System.Drawing.Size(89, 16);
            this.rdb_High.TabIndex = 1;
            this.rdb_High.Text = "High Active";
            this.rdb_High.UseVisualStyleBackColor = true;
            // 
            // rdb_Low
            // 
            this.rdb_Low.AutoSize = true;
            this.rdb_Low.Checked = true;
            this.rdb_Low.Location = new System.Drawing.Point(15, 20);
            this.rdb_Low.Name = "rdb_Low";
            this.rdb_Low.Size = new System.Drawing.Size(83, 16);
            this.rdb_Low.TabIndex = 0;
            this.rdb_Low.TabStop = true;
            this.rdb_Low.Text = "Low Active";
            this.rdb_Low.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rdb_RorFEge);
            this.groupBox3.Controls.Add(this.rdb_FallingEdge);
            this.groupBox3.Controls.Add(this.rdb_RisingEdge);
            this.groupBox3.Location = new System.Drawing.Point(12, 159);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(310, 42);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "LatchBuf Edge";
            // 
            // rdb_RorFEge
            // 
            this.rdb_RorFEge.AutoSize = true;
            this.rdb_RorFEge.Location = new System.Drawing.Point(226, 18);
            this.rdb_RorFEge.Name = "rdb_RorFEge";
            this.rdb_RorFEge.Size = new System.Drawing.Size(71, 16);
            this.rdb_RorFEge.TabIndex = 2;
            this.rdb_RorFEge.Text = "RorFEdge";
            this.rdb_RorFEge.UseVisualStyleBackColor = true;
            // 
            // rdb_FallingEdge
            // 
            this.rdb_FallingEdge.AutoSize = true;
            this.rdb_FallingEdge.Location = new System.Drawing.Point(112, 18);
            this.rdb_FallingEdge.Name = "rdb_FallingEdge";
            this.rdb_FallingEdge.Size = new System.Drawing.Size(89, 16);
            this.rdb_FallingEdge.TabIndex = 1;
            this.rdb_FallingEdge.Text = "FallingEdge";
            this.rdb_FallingEdge.UseVisualStyleBackColor = true;
            // 
            // rdb_RisingEdge
            // 
            this.rdb_RisingEdge.AutoSize = true;
            this.rdb_RisingEdge.Checked = true;
            this.rdb_RisingEdge.Location = new System.Drawing.Point(15, 20);
            this.rdb_RisingEdge.Name = "rdb_RisingEdge";
            this.rdb_RisingEdge.Size = new System.Drawing.Size(83, 16);
            this.rdb_RisingEdge.TabIndex = 0;
            this.rdb_RisingEdge.TabStop = true;
            this.rdb_RisingEdge.Text = "RisingEdge";
            this.rdb_RisingEdge.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdb_Fdb);
            this.groupBox2.Controls.Add(this.rdb_Cmd);
            this.groupBox2.Location = new System.Drawing.Point(14, 114);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(205, 42);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Position Type";
            // 
            // rdb_Fdb
            // 
            this.rdb_Fdb.AutoSize = true;
            this.rdb_Fdb.Location = new System.Drawing.Point(112, 19);
            this.rdb_Fdb.Name = "rdb_Fdb";
            this.rdb_Fdb.Size = new System.Drawing.Size(71, 16);
            this.rdb_Fdb.TabIndex = 1;
            this.rdb_Fdb.Text = "FeedBack";
            this.rdb_Fdb.UseVisualStyleBackColor = true;
            // 
            // rdb_Cmd
            // 
            this.rdb_Cmd.AutoSize = true;
            this.rdb_Cmd.Checked = true;
            this.rdb_Cmd.Location = new System.Drawing.Point(15, 19);
            this.rdb_Cmd.Name = "rdb_Cmd";
            this.rdb_Cmd.Size = new System.Drawing.Size(65, 16);
            this.rdb_Cmd.TabIndex = 0;
            this.rdb_Cmd.TabStop = true;
            this.rdb_Cmd.Text = "Command";
            this.rdb_Cmd.UseVisualStyleBackColor = true;
            // 
            // txb_LatchBufMinDist
            // 
            this.txb_LatchBufMinDist.Location = new System.Drawing.Point(135, 71);
            this.txb_LatchBufMinDist.Name = "txb_LatchBufMinDist";
            this.txb_LatchBufMinDist.Size = new System.Drawing.Size(123, 21);
            this.txb_LatchBufMinDist.TabIndex = 6;
            this.txb_LatchBufMinDist.Text = "1000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 12);
            this.label4.TabIndex = 5;
            this.label4.Text = "LatchBuf Min Dist:";
            // 
            // txb_LatchBuf_Event_Nums
            // 
            this.txb_LatchBuf_Event_Nums.Location = new System.Drawing.Point(135, 44);
            this.txb_LatchBuf_Event_Nums.Name = "txb_LatchBuf_Event_Nums";
            this.txb_LatchBuf_Event_Nums.Size = new System.Drawing.Size(123, 21);
            this.txb_LatchBuf_Event_Nums.TabIndex = 4;
            this.txb_LatchBuf_Event_Nums.Text = "128";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "LatchBuf Event Nums:";
            // 
            // checkBox_LatchBufEnable
            // 
            this.checkBox_LatchBufEnable.AutoSize = true;
            this.checkBox_LatchBufEnable.Location = new System.Drawing.Point(136, 97);
            this.checkBox_LatchBufEnable.Name = "checkBox_LatchBufEnable";
            this.checkBox_LatchBufEnable.Size = new System.Drawing.Size(138, 16);
            this.checkBox_LatchBufEnable.TabIndex = 2;
            this.checkBox_LatchBufEnable.Text = "Latch Buffer Enable";
            this.checkBox_LatchBufEnable.UseVisualStyleBackColor = true;
            // 
            // cmb_LatchBufAxisID
            // 
            this.cmb_LatchBufAxisID.FormattingEnabled = true;
            this.cmb_LatchBufAxisID.Location = new System.Drawing.Point(135, 18);
            this.cmb_LatchBufAxisID.Name = "cmb_LatchBufAxisID";
            this.cmb_LatchBufAxisID.Size = new System.Drawing.Size(148, 20);
            this.cmb_LatchBufAxisID.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "LatchBuf Axis ID:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btn_LatchBuffedCon);
            this.groupBox5.Controls.Add(this.btn_LatchBuffedPTP);
            this.groupBox5.Location = new System.Drawing.Point(19, 380);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(335, 50);
            this.groupBox5.TabIndex = 14;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "LatchBuffed Axis Movement";
            // 
            // btn_LatchBuffedCon
            // 
            this.btn_LatchBuffedCon.Location = new System.Drawing.Point(220, 19);
            this.btn_LatchBuffedCon.Name = "btn_LatchBuffedCon";
            this.btn_LatchBuffedCon.Size = new System.Drawing.Size(75, 23);
            this.btn_LatchBuffedCon.TabIndex = 16;
            this.btn_LatchBuffedCon.Text = "Continue";
            this.btn_LatchBuffedCon.UseVisualStyleBackColor = true;
            this.btn_LatchBuffedCon.Click += new System.EventHandler(this.btn_LatchBuffedCon_Click);
            // 
            // btn_LatchBuffedPTP
            // 
            this.btn_LatchBuffedPTP.Location = new System.Drawing.Point(56, 19);
            this.btn_LatchBuffedPTP.Name = "btn_LatchBuffedPTP";
            this.btn_LatchBuffedPTP.Size = new System.Drawing.Size(75, 23);
            this.btn_LatchBuffedPTP.TabIndex = 15;
            this.btn_LatchBuffedPTP.Text = "PTP";
            this.btn_LatchBuffedPTP.UseVisualStyleBackColor = true;
            this.btn_LatchBuffedPTP.Click += new System.EventHandler(this.btn_LatchBuffedPTP_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btn_Stop);
            this.groupBox6.Controls.Add(this.btn_Continue);
            this.groupBox6.Controls.Add(this.btn_ptp);
            this.groupBox6.Controls.Add(this.txb_Pos);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.groupBox10);
            this.groupBox6.Controls.Add(this.cmb_SelectedAxis);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Location = new System.Drawing.Point(19, 433);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(335, 128);
            this.groupBox6.TabIndex = 15;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "LatchBuff Axis Movement";
            // 
            // btn_Stop
            // 
            this.btn_Stop.Location = new System.Drawing.Point(239, 95);
            this.btn_Stop.Name = "btn_Stop";
            this.btn_Stop.Size = new System.Drawing.Size(75, 26);
            this.btn_Stop.TabIndex = 33;
            this.btn_Stop.Text = "Stop";
            this.btn_Stop.UseVisualStyleBackColor = true;
            this.btn_Stop.Click += new System.EventHandler(this.btn_Stop_Click);
            // 
            // btn_Continue
            // 
            this.btn_Continue.Location = new System.Drawing.Point(134, 95);
            this.btn_Continue.Name = "btn_Continue";
            this.btn_Continue.Size = new System.Drawing.Size(75, 26);
            this.btn_Continue.TabIndex = 32;
            this.btn_Continue.Text = "Continue";
            this.btn_Continue.UseVisualStyleBackColor = true;
            this.btn_Continue.Click += new System.EventHandler(this.btn_Continue_Click);
            // 
            // btn_ptp
            // 
            this.btn_ptp.Location = new System.Drawing.Point(29, 95);
            this.btn_ptp.Name = "btn_ptp";
            this.btn_ptp.Size = new System.Drawing.Size(75, 26);
            this.btn_ptp.TabIndex = 31;
            this.btn_ptp.Text = "PTP";
            this.btn_ptp.UseVisualStyleBackColor = true;
            this.btn_ptp.Click += new System.EventHandler(this.btn_ptp_Click);
            // 
            // txb_Pos
            // 
            this.txb_Pos.Location = new System.Drawing.Point(214, 65);
            this.txb_Pos.Name = "txb_Pos";
            this.txb_Pos.Size = new System.Drawing.Size(103, 21);
            this.txb_Pos.TabIndex = 30;
            this.txb_Pos.Text = "50000";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(214, 49);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 29;
            this.label10.Text = "End Point:";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.rdb_Rel);
            this.groupBox10.Controls.Add(this.rdb_Abs);
            this.groupBox10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox10.Location = new System.Drawing.Point(15, 43);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(188, 46);
            this.groupBox10.TabIndex = 28;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Move Mode";
            // 
            // rdb_Rel
            // 
            this.rdb_Rel.AutoSize = true;
            this.rdb_Rel.Checked = true;
            this.rdb_Rel.Location = new System.Drawing.Point(103, 21);
            this.rdb_Rel.Name = "rdb_Rel";
            this.rdb_Rel.Size = new System.Drawing.Size(71, 16);
            this.rdb_Rel.TabIndex = 1;
            this.rdb_Rel.TabStop = true;
            this.rdb_Rel.Text = "Relative";
            this.rdb_Rel.UseVisualStyleBackColor = true;
            // 
            // rdb_Abs
            // 
            this.rdb_Abs.AutoSize = true;
            this.rdb_Abs.Location = new System.Drawing.Point(16, 22);
            this.rdb_Abs.Name = "rdb_Abs";
            this.rdb_Abs.Size = new System.Drawing.Size(71, 16);
            this.rdb_Abs.TabIndex = 0;
            this.rdb_Abs.TabStop = true;
            this.rdb_Abs.Text = "Absolute";
            this.rdb_Abs.UseVisualStyleBackColor = true;
            // 
            // cmb_SelectedAxis
            // 
            this.cmb_SelectedAxis.Location = new System.Drawing.Point(130, 19);
            this.cmb_SelectedAxis.Name = "cmb_SelectedAxis";
            this.cmb_SelectedAxis.Size = new System.Drawing.Size(146, 20);
            this.cmb_SelectedAxis.TabIndex = 16;
            this.cmb_SelectedAxis.SelectedIndexChanged += new System.EventHandler(this.cmb_SelectedAxis_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(39, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 12);
            this.label5.TabIndex = 16;
            this.label5.Text = "Selected Axis:";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.btn_ResetLatchBuf);
            this.groupBox9.Controls.Add(this.btn_GetLatchBuf);
            this.groupBox9.Controls.Add(this.txb_LatchBufCnt);
            this.groupBox9.Controls.Add(this.label13);
            this.groupBox9.Controls.Add(this.dataGridView1);
            this.groupBox9.Location = new System.Drawing.Point(373, 257);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(312, 239);
            this.groupBox9.TabIndex = 18;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "LatchBuf Data:";
            // 
            // btn_ResetLatchBuf
            // 
            this.btn_ResetLatchBuf.Location = new System.Drawing.Point(182, 206);
            this.btn_ResetLatchBuf.Name = "btn_ResetLatchBuf";
            this.btn_ResetLatchBuf.Size = new System.Drawing.Size(104, 26);
            this.btn_ResetLatchBuf.TabIndex = 4;
            this.btn_ResetLatchBuf.Text = "Reset LatchBuf";
            this.btn_ResetLatchBuf.UseVisualStyleBackColor = true;
            this.btn_ResetLatchBuf.Click += new System.EventHandler(this.btn_ResetLatchBuf_Click);
            // 
            // btn_GetLatchBuf
            // 
            this.btn_GetLatchBuf.Location = new System.Drawing.Point(37, 206);
            this.btn_GetLatchBuf.Name = "btn_GetLatchBuf";
            this.btn_GetLatchBuf.Size = new System.Drawing.Size(104, 26);
            this.btn_GetLatchBuf.TabIndex = 3;
            this.btn_GetLatchBuf.Text = "Get LatchBuf";
            this.btn_GetLatchBuf.UseVisualStyleBackColor = true;
            this.btn_GetLatchBuf.Click += new System.EventHandler(this.btn_GetLatchBuf_Click);
            // 
            // txb_LatchBufCnt
            // 
            this.txb_LatchBufCnt.Location = new System.Drawing.Point(127, 177);
            this.txb_LatchBufCnt.Name = "txb_LatchBufCnt";
            this.txb_LatchBufCnt.Size = new System.Drawing.Size(100, 21);
            this.txb_LatchBufCnt.TabIndex = 2;
            this.txb_LatchBufCnt.Text = "32";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(33, 182);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 12);
            this.label13.TabIndex = 1;
            this.label13.Text = "Latch Buf Cnt:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dataGridView1.Location = new System.Drawing.Point(45, 18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 10;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(231, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "DataIndex";
            this.Column1.Name = "Column1";
            this.Column1.Width = 90;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "DataValues";
            this.Column2.Name = "Column2";
            this.Column2.Width = 120;
            // 
            // btn_ResetCount
            // 
            this.btn_ResetCount.Location = new System.Drawing.Point(46, 151);
            this.btn_ResetCount.Name = "btn_ResetCount";
            this.btn_ResetCount.Size = new System.Drawing.Size(91, 26);
            this.btn_ResetCount.TabIndex = 17;
            this.btn_ResetCount.Text = "Reset Count";
            this.btn_ResetCount.UseVisualStyleBackColor = true;
            this.btn_ResetCount.Click += new System.EventHandler(this.btn_ResetCount_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button1);
            this.groupBox7.Controls.Add(this.textBoxAxisLatchBufCnt);
            this.groupBox7.Controls.Add(this.btn_ResetCount);
            this.groupBox7.Controls.Add(this.label21);
            this.groupBox7.Controls.Add(this.txb_LatedAxisState);
            this.groupBox7.Controls.Add(this.txb_LatedAxisCmd);
            this.groupBox7.Controls.Add(this.label9);
            this.groupBox7.Controls.Add(this.label8);
            this.groupBox7.Controls.Add(this.txb_State);
            this.groupBox7.Controls.Add(this.txb_CmdPos);
            this.groupBox7.Controls.Add(this.label7);
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Location = new System.Drawing.Point(373, 10);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(312, 183);
            this.groupBox7.TabIndex = 116;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Axis Info";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(182, 151);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 26);
            this.button1.TabIndex = 66;
            this.button1.Text = "Reset Error";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxAxisLatchBufCnt
            // 
            this.textBoxAxisLatchBufCnt.Location = new System.Drawing.Point(154, 122);
            this.textBoxAxisLatchBufCnt.Name = "textBoxAxisLatchBufCnt";
            this.textBoxAxisLatchBufCnt.ReadOnly = true;
            this.textBoxAxisLatchBufCnt.Size = new System.Drawing.Size(133, 21);
            this.textBoxAxisLatchBufCnt.TabIndex = 65;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(67, 127);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(83, 12);
            this.label21.TabIndex = 64;
            this.label21.Text = "LatchBuf Cnt:";
            // 
            // txb_LatedAxisState
            // 
            this.txb_LatedAxisState.Location = new System.Drawing.Point(154, 96);
            this.txb_LatedAxisState.Name = "txb_LatedAxisState";
            this.txb_LatedAxisState.ReadOnly = true;
            this.txb_LatedAxisState.Size = new System.Drawing.Size(133, 21);
            this.txb_LatedAxisState.TabIndex = 20;
            // 
            // txb_LatedAxisCmd
            // 
            this.txb_LatedAxisCmd.Location = new System.Drawing.Point(154, 70);
            this.txb_LatedAxisCmd.Name = "txb_LatedAxisCmd";
            this.txb_LatedAxisCmd.ReadOnly = true;
            this.txb_LatedAxisCmd.Size = new System.Drawing.Size(133, 21);
            this.txb_LatedAxisCmd.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 101);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(131, 12);
            this.label9.TabIndex = 18;
            this.label9.Text = "LatchBuffed Ax State:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(137, 12);
            this.label8.TabIndex = 17;
            this.label8.Text = "LatchBuffed Ax CmdPos:";
            // 
            // txb_State
            // 
            this.txb_State.Location = new System.Drawing.Point(154, 44);
            this.txb_State.Name = "txb_State";
            this.txb_State.ReadOnly = true;
            this.txb_State.Size = new System.Drawing.Size(133, 21);
            this.txb_State.TabIndex = 3;
            // 
            // txb_CmdPos
            // 
            this.txb_CmdPos.Location = new System.Drawing.Point(154, 18);
            this.txb_CmdPos.Name = "txb_CmdPos";
            this.txb_CmdPos.ReadOnly = true;
            this.txb_CmdPos.Size = new System.Drawing.Size(133, 21);
            this.txb_CmdPos.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(37, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "LatchBuf Ax State:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "LatchBuf Ax CmdPos:";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label14);
            this.groupBox13.Controls.Add(this.label17);
            this.groupBox13.Controls.Add(this.label15);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox13.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox13.Controls.Add(this.pictureBoxORG);
            this.groupBox13.Controls.Add(this.pictureBoxALM);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(373, 504);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(312, 55);
            this.groupBox13.TabIndex = 117;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Selected Axis Signal Status";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(242, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 12);
            this.label14.TabIndex = 28;
            this.label14.Text = "-HEL:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(164, 29);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 12);
            this.label17.TabIndex = 27;
            this.label17.Text = "+HEL:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(91, 29);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 12);
            this.label15.TabIndex = 26;
            this.label15.Text = "ORG:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(17, 28);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(277, 24);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(200, 24);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(123, 24);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(46, 24);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txb_SpaceCnt);
            this.groupBox8.Controls.Add(this.txb_RemainCnt);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Location = new System.Drawing.Point(373, 201);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(312, 48);
            this.groupBox8.TabIndex = 118;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "LatchBuff Info:";
            // 
            // txb_SpaceCnt
            // 
            this.txb_SpaceCnt.Location = new System.Drawing.Point(229, 19);
            this.txb_SpaceCnt.Name = "txb_SpaceCnt";
            this.txb_SpaceCnt.Size = new System.Drawing.Size(69, 21);
            this.txb_SpaceCnt.TabIndex = 24;
            // 
            // txb_RemainCnt
            // 
            this.txb_RemainCnt.Location = new System.Drawing.Point(82, 19);
            this.txb_RemainCnt.Name = "txb_RemainCnt";
            this.txb_RemainCnt.Size = new System.Drawing.Size(69, 21);
            this.txb_RemainCnt.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(161, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 22;
            this.label11.Text = "Space Cnt:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 24);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 12);
            this.label12.TabIndex = 21;
            this.label12.Text = "Remain Cnt:";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label1);
            this.groupBox11.Controls.Add(this.CmbAvailableDevice);
            this.groupBox11.Controls.Add(this.BtnOpenBoard);
            this.groupBox11.Controls.Add(this.BtnCloseBoard);
            this.groupBox11.Controls.Add(this.BtnServo);
            this.groupBox11.Controls.Add(this.BtnLoadCfg);
            this.groupBox11.Location = new System.Drawing.Point(19, 10);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(335, 110);
            this.groupBox11.TabIndex = 119;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Device Operate";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 578);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LatchBuffer";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnLoadCfg;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;

        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle;
        IntPtr[] m_Axishand = new IntPtr[64];
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        Int32 m_CurAxis =0;
        uint[] m_AxLatchBufCnt = new uint[64];
        uint[] AxEnableEvtArray = new uint[64];
        uint[] GpEnableEvt = new uint[64];
        double[]  m_DataBuffer = new double[128];
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txb_LatchBuf_Event_Nums;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBox_LatchBufEnable;
        private System.Windows.Forms.ComboBox cmb_LatchBufAxisID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txb_LatchBufMinDist;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdb_Fdb;
        private System.Windows.Forms.RadioButton rdb_Cmd;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rdb_High;
        private System.Windows.Forms.RadioButton rdb_Low;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rdb_RorFEge;
        private System.Windows.Forms.RadioButton rdb_FallingEdge;
        private System.Windows.Forms.RadioButton rdb_RisingEdge;
        private System.Windows.Forms.Button btn_Set;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btn_LatchBuffedCon;
        private System.Windows.Forms.Button btn_LatchBuffedPTP;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txb_Pos;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton rdb_Rel;
        private System.Windows.Forms.RadioButton rdb_Abs;
        private System.Windows.Forms.ComboBox cmb_SelectedAxis;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_Stop;
        private System.Windows.Forms.Button btn_Continue;
        private System.Windows.Forms.Button btn_ptp;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button btn_ResetLatchBuf;
        private System.Windows.Forms.Button btn_GetLatchBuf;
        private System.Windows.Forms.TextBox txb_LatchBufCnt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.Button btn_ResetCount;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBoxAxisLatchBufCnt;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txb_LatedAxisState;
        private System.Windows.Forms.TextBox txb_LatedAxisCmd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txb_State;
        private System.Windows.Forms.TextBox txb_CmdPos;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txb_SpaceCnt;
        private System.Windows.Forms.TextBox txb_RemainCnt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button button1;
    
    }
}

