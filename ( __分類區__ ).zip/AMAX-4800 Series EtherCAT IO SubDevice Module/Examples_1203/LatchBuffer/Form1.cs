using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Advantech.Motion;//Common Motion API
using System.Diagnostics;
using System.Threading;
namespace LatchBuffer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            VersionIsOk = GetDevCfgDllDrvVer(); //Get Driver Version Number, this step is not necessary
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }
        Thread CheckEventThread;
        Boolean VersionIsOk = false;
        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            uint Result;
            int i = 0; 
			uint retry = 0, SlaveOnRing0 = 0, SlaveOnRing1 = 0;
			bool rescan = false;
            uint AxesPerDev = new uint();
            string strTemp;
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            do
            {
                Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Device Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    retry++;
                    rescan = true;
                    if (retry > 10)
                        return;
                    System.Threading.Thread.Sleep(1000);
                }
                else
                {
					//User must check the slave count on each ring match the actual connection.
					//We recommend using following code that was marked to check connection status.
					//The example expect there is one slave on Motion ring and user does not connect any slave on IO ring.
					rescan = false;
					/*Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R0, ref SlaveOnRing0);
					Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R1, ref SlaveOnRing1);
					if (SlaveOnRing0 != 1 || SlaveOnRing1 != 0)
					{
						strTemp = "Retrieved the slave states do not match the actual connection.";
						ShowMessages(strTemp, Result);
						Motion.mAcm_DevReOpen(m_DeviceHandle);
						Motion.mAcm_DevClose(ref m_DeviceHandle);
						System.Threading.Thread.Sleep(1000);
						retry = 0;
						rescan = true;
					}*/
                }
            } while (rescan == true);
            //FT_DevAxesCount:Get axis number of this device.
            //if you device is fixed(for example: PCI-1245),You can not get FT_DevAxesCount property value
            //This step is not necessary
            //You can also use the old API: Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev, ref BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get Axis Number Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            m_ulAxisCount = AxesPerDev;
            dataGridView1.Rows.Clear();
            cmb_SelectedAxis.Items.Clear();
            cmb_LatchBufAxisID.Items.Clear();
            for (i = 0; i < m_ulAxisCount; i++)
            {
                //Open every Axis and get the each Axis Handle
                //And Initial property for each Axis 		
                //Open Axis 
                Result = Motion.mAcm_AxOpen(m_DeviceHandle, (UInt16)i, ref m_Axishand[i]);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Axis Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                cmb_SelectedAxis.Items.Add(String.Format("{0:d}-Axis", i));
                cmb_LatchBufAxisID.Items.Add(String.Format("{0:d}-Axis",i));
                //Reset Command Counter
                double cmdPosition = new double();
                cmdPosition = 0;
                Motion.mAcm_AxSetCmdPosition(m_Axishand[i], cmdPosition);
            }
            cmb_SelectedAxis.SelectedIndex = 0;
            cmb_LatchBufAxisID.SelectedIndex = 0;
            m_bInit = true;
            //User should create a new thread to check event status,for example:CheckEvtThread() function.
            CheckEventThread = new Thread(new ThreadStart(CheckEvtThread));
            CheckEventThread.Start();
            timer1.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            if (VersionIsOk == false)
            {
               return;
            }
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot��Perhaps the opposite 
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, (uint)Result);
                return;
            }
            //If you want to get the device number of fixed equipment��you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }       
        }

        private void BtnLoadCfg_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            this.OpenConfigFile.FileName = ".cfg";
            if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                return;
            //Set all configurations for the device according to the loaded file
            Result = Motion.mAcm_DevLoadConfig(m_DeviceHandle, OpenConfigFile.FileName);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Load Config Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }		 
        }

        private void BtnServo_Click(object sender, EventArgs e)
        {
            UInt32 AxisNum;
            UInt32 Result;
            string strTemp;
            //Check the servoOno flag to decide if turn on or turn off the ServoOn output.
            if (m_bInit != true)
            {
                return;
            }
            if (m_bServoOn == false)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver ON,1: On
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 1);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo On Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = true;
                    BtnServo.Text = "Servo Off";
                }
            }
            else
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver OFF,0: Off
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 0);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo Off Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = false;
                    BtnServo.Text = "Servo On";
                }
            }
        }

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();
        }

        private void btn_Set_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            uint m_LatchEnable =1;
            uint m_LatchLogic;
            uint m_LatchBufEnable;
            uint m_Rise_fall_edge;
            uint m_MinDist;
            uint m_LatchBufEventNum;
            uint m_LatchBufSource;
            uint m_LatchBuffID;
            ulong dDevType;
            dDevType = (DeviceNum & 0xff000000) >> 24;
            //CFG_AxLatchEnable,Enable latch function.
            //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchEnable, ref m_LatchEnable, BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchEnable, m_LatchEnable);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_AxLatchEnable Property Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            if (rdb_Low.Checked)
            {
                m_LatchLogic = 0;
            }
            else
            {
                m_LatchLogic = 1;
            }
            //CFG_AxLatchLogic,Set the active logic for Latch signal
            //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchLogic, ref m_LatchLogic,BufferLength);
            // unsigned long BufferLength;
            // BufferLength =4; buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchLogic, m_LatchLogic);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_AxLatchLogic Property Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            if (checkBox_LatchBufEnable.Checked)
            {
                m_LatchBufEnable = 1;
            }
            else
            {
                m_LatchBufEnable = 0;
            }
            //CFG_AxLatchBufEnable,Enable latchBuffer function.
            //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchBufEnable, ref m_LatchBufEnable, (uint)Marshal.SizeOf(typeof(uint)));
            Result = Motion.mAcm_SetU32Property(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchBufEnable,  m_LatchBufEnable);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_AxLatchBufEnable Property Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            if ( dDevType == (ulong)DevTypeID.PCI1245 || dDevType == (ulong)DevTypeID.PCI1265)
            {
                m_Rise_fall_edge = 0;
            }
            else
            {
                if (rdb_RisingEdge.Checked)
                {
                    m_Rise_fall_edge = 0;
                }
                else if (rdb_FallingEdge.Checked)
                {
                    m_Rise_fall_edge = 1;
                }
                else
                {
                    m_Rise_fall_edge = 2;
                }
                //CFG_AxLatchBufEdge,Set the edge for LatchBuffer
                //You can also use the old API: Motion.mAcm_SetProperty(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchBufEdge, ref m_Rise_fall_edge, (uint)Marshal.SizeOf(typeof(uint)))
                Result = Motion.mAcm_SetU32Property(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchBufEdge,m_Rise_fall_edge);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set CFG_AxLatchBufEdge Property  Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
           
            m_MinDist =Convert.ToUInt32(txb_LatchBufMinDist.Text);
            //CFG_AxLatchBufMinDist,Set the min distance for LatchBuffer
            //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchBufMinDist, ref m_MinDist, (uint)Marshal.SizeOf(typeof(uint)));
            Result = Motion.mAcm_SetU32Property(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchBufMinDist, m_MinDist);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_AxLatchBufMinDist Property  Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            m_LatchBufEventNum = Convert.ToUInt32(txb_LatchBuf_Event_Nums.Text);
            //CFG_AxLatchBufEventNum,Set the latchbuffer event number
            //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchBufEventNum, ref m_LatchBufEventNum, (uint)Marshal.SizeOf(typeof(uint)))
            Result = Motion.mAcm_SetU32Property(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchBufEventNum,m_LatchBufEventNum);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "SetCFG_AxLatchBufEventNum Property  Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            if (rdb_Cmd.Checked)
            {
                m_LatchBufSource = 0;
            }
            else
            {
                m_LatchBufSource = 1;
            }
            //CFG_AxLatchBufSource,Set the latchbuffer Source
            //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchBufSource, ref m_LatchBufSource, (uint)Marshal.SizeOf(typeof(uint)));       
            Result = Motion.mAcm_SetU32Property(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchBufSource, m_LatchBufSource );
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_AxLatchBufSource Property  Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }

            m_LatchBuffID = (uint)cmb_LatchBufAxisID.SelectedIndex;
            if (dDevType == (ulong)DevTypeID.PCI1265 || dDevType == (ulong)DevTypeID.PCI1245)
            {
               
            }
            else
            {
                //CFG_AxLatchBufAxisID,Set the latchbuffer axis'ID
	         	//You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchBufAxisID, ref m_LatchBuffID, (uint)Marshal.SizeOf(typeof(uint)));
                Result = Motion.mAcm_SetU32Property(m_Axishand[m_CurAxis], (uint)PropertyID.CFG_AxLatchBufAxisID,  m_LatchBuffID);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set CFG_AxLatchBufAxisID Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
            AxEnableEvtArray[m_CurAxis] |= (uint)EventType.EVT_AX_LATCHBUF_DONE;  
            //Enable motion event
            Result = Motion.mAcm_EnableMotionEvent(m_DeviceHandle, AxEnableEvtArray, GpEnableEvt, m_ulAxisCount, 3);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "EnableMotionEvent Filed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }

        private void cmb_SelectedAxis_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_CurAxis = cmb_SelectedAxis.SelectedIndex;
        }

        private void btn_LatchBuffedPTP_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            double m_OldPos;
            int m_LatchAxisID;
            m_LatchAxisID = cmb_LatchBufAxisID.SelectedIndex;
            m_OldPos = Convert.ToDouble(txb_Pos.Text);
            if (rdb_Rel.Checked)
            {
                //Start single axis's relative position motion.
                Result = Motion.mAcm_AxMoveRel(m_Axishand[m_LatchAxisID], m_OldPos);
            
            }
            else
            {
                //Start single axis's absolute position motion.
                Result = Motion.mAcm_AxMoveAbs(m_Axishand[m_LatchAxisID], m_OldPos);
           
          }
          if (Result != (uint)ErrorCode.SUCCESS)
          {
              strTemp = "PTP Move Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
              ShowMessages(strTemp, Result);
          }
        }

        private void btn_ptp_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            double m_OldPos;       
            m_OldPos = Convert.ToDouble(txb_Pos.Text);
            if (rdb_Rel.Checked)
            {
                //Start single axis's relative position motion.
                Result = Motion.mAcm_AxMoveRel(m_Axishand[m_CurAxis], m_OldPos);
                
            }
            else
            {
                //Start single axis's absolute position motion.
                Result = Motion.mAcm_AxMoveAbs(m_Axishand[m_CurAxis], m_OldPos);             
            }
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "PTP Move Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
        }

        private void btn_LatchBuffedCon_Click(object sender, EventArgs e)
        {
          
            UInt32 Result;
            string strTemp;
            int m_LatchAxisID;
            m_LatchAxisID = cmb_LatchBufAxisID.SelectedIndex;
            //To command axis to make a never ending movement with a specified velocity.1: Negative direction.
             Result = Motion.mAcm_AxMoveVel(m_Axishand[m_LatchAxisID], 0);
             if (Result != (uint)ErrorCode.SUCCESS)
             {
                 strTemp = "Continue Move Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                 ShowMessages(strTemp, Result);
                 return;
             }      
        }

        private void btn_Continue_Click(object sender, EventArgs e)
        {
         
            UInt32 Result;
            string strTemp;
            //To command axis to make a never ending movement with a specified velocity.1: Negative direction.
            Result = Motion.mAcm_AxMoveVel(m_Axishand[m_CurAxis], 0);
             if (Result != (uint)ErrorCode.SUCCESS)
             {
                 strTemp = "Continue Move Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                 ShowMessages(strTemp, Result);
                 return;
              }
        }

        private void btn_Stop_Click(object sender, EventArgs e)
        {
           
            int m_LatchAxisID;
            UInt32 Result;
            string strTemp;
            m_LatchAxisID = cmb_LatchBufAxisID.SelectedIndex;
            //To command axis to decelerate to stop.
            Result = Motion.mAcm_AxStopEmg(m_Axishand[m_CurAxis]);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Axis To decelerate Stop Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            //To command axis to decelerate to stop.
            Result= Motion.mAcm_AxStopEmg(m_Axishand[m_LatchAxisID]);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Axis To decelerate Stop Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            return;	
        }

        private void btn_ResetCount_Click(object sender, EventArgs e)
        {
            double cmdPosition = 0;
            if (m_bInit == true)
            {
                for (uint AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Set command position for the specified axis
                    Motion.mAcm_AxSetCmdPosition(m_Axishand[AxisNum], cmdPosition);
                }
            }
            textBoxAxisLatchBufCnt.Text = "0";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            UInt32 Result;
            UInt32 RemainCnt = 0;
            UInt32 SpaceCnt = 0;
            double CurPos=0;
            double LatchCurPos=0;
            ushort State=0;
            //CEdit* MIN;
            UInt32 IOStatus = new UInt32();
            UInt32 m_LatchBuffID;
            m_LatchBuffID = (UInt32)cmb_LatchBufAxisID.SelectedIndex;
            //	Result = Acm_GetProperty(m_Axishand[m_CurAxis],CFG_AxLatchLogic,&m_minDis,&BUFFER);
            //   strTemp.Format("%d",m_minDis);
            if (m_bInit)
            {
                //Get current command position of the specified axis
                Result = Motion.mAcm_AxGetCmdPosition(m_Axishand[m_LatchBuffID], ref LatchCurPos);
                txb_LatedAxisCmd.Text = Convert.ToString(LatchCurPos);
                //get latchBuffer Status
                Result = Motion.mAcm_AxGetLatchBufferStatus(m_Axishand[m_CurAxis], ref RemainCnt, ref SpaceCnt);
                txb_SpaceCnt.Text = Convert.ToString(SpaceCnt);
                txb_RemainCnt.Text = Convert.ToString(RemainCnt);
                Motion.mAcm_AxGetCmdPosition(m_Axishand[m_CurAxis], ref CurPos);
                txb_CmdPos.Text = Convert.ToString(CurPos);
                //Get the motion I/O status of the axis.
                Result = Motion.mAcm_AxGetMotionIO(m_Axishand[m_CurAxis], ref IOStatus);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    GetMotionIOStatus(IOStatus);
                }
                //Get the Axis's current state
                Result = Motion.mAcm_AxGetState(m_Axishand[m_CurAxis], ref State);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    txb_State.Text = ((AxisState)State).ToString();
                }  
                //Get the Axis's current state
                Result = Motion.mAcm_AxGetState(m_Axishand[m_LatchBuffID], ref State);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    txb_LatedAxisState.Text = ((AxisState)State).ToString();
                }
                textBoxAxisLatchBufCnt.Text = Convert.ToString(m_AxLatchBufCnt[cmb_SelectedAxis.SelectedIndex]);
            }
        }

        private void btn_GetLatchBuf_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            UInt32 DataCnt;
            String strTemp;
            DataCnt = Convert.ToUInt32(txb_LatchBufCnt.Text);
            //Read axis's latchbuffer data
            Result = Motion.mAcm_AxReadLatchBuffer(m_Axishand[m_CurAxis], m_DataBuffer, ref DataCnt);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get LatchBuff Data Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            dataGridView1.Rows.Clear();
            for (int i = 0; i < DataCnt; i++)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[i].Cells[0].Value = i;
                dataGridView1.Rows[i].Cells[1].Value = (m_DataBuffer[i]).ToString();
            }	
        }

        private void btn_ResetLatchBuf_Click(object sender, EventArgs e)
        {
           UInt32 Result;
           String strTemp;
           //Reset LatchBuffer Data
           Result = Motion.mAcm_AxResetLatchBuffer(m_Axishand[m_CurAxis]);
           if (Result !=(uint)ErrorCode.SUCCESS)
           {
               strTemp = "Reset LatchBuffer Data Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
               ShowMessages(strTemp, Result);
               return;
           }
           dataGridView1.Rows.Clear();
            //memset(m_DataBuffer, 0, sizeof(m_DataBuffer));
       }
         //User-defined API to show error message
        private void ShowMessages(string DetailMessage, uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            //Get the error message according to error code returned from API
            Boolean res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
            string ErrorMessage = "";
            if (res)
                ErrorMessage = ErrorMsg.ToString();
            MessageBox.Show(DetailMessage + "\r\nError Message:" + ErrorMessage, "LatchBuffer", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
         //User-defined API to close board
        private void CloseBoardOrForm()
        {
            ushort[] usAxisState = new ushort[64];
            uint AxisNum;
            if (m_bInit == true)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Get the axis's current state
                    Motion.mAcm_AxGetState(m_Axishand[AxisNum], ref usAxisState[AxisNum]);
                    if (usAxisState[AxisNum] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        // Reset the axis' state. If the axis is in ErrorStop state, the state will be changed to Ready after calling this function
                        Motion.mAcm_AxResetError(m_Axishand[AxisNum]);
                    }
                    //To command axis to decelerate to stop.
                    Motion.mAcm_AxStopDec(m_Axishand[AxisNum]);
                }
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    Motion.mAcm_AxClose(ref m_Axishand[AxisNum]);

                }
                CheckEventThread.Abort();      //Abort thread
                m_bInit = false;
                cmb_LatchBufAxisID.Items.Clear();
                cmb_LatchBufAxisID.Text = "";
                cmb_SelectedAxis.Items.Clear();
                cmb_SelectedAxis.Text = "";
                txb_CmdPos.Text = "";
                txb_State.Text = "";
                txb_LatedAxisState.Text = "";
                txb_RemainCnt.Text = "";
                txb_SpaceCnt.Text = "";
                txb_LatedAxisCmd.Text = "";
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                dataGridView1.Rows.Clear();
                textBoxAxisLatchBufCnt.Text = "";
                timer1.Enabled = false;
            }
        }
        //get the device number of fixed equipment
        private UInt32 GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID)
        {
            return (UInt32)(DevType << 24 | BoardID << 12 | MasterRingNo << 8 | SlaveBoardID);
        }
        private void CheckEvtThread()
        {
            uint Result;
            UInt32[] AxEvtStatusArray = new UInt32[64];
            UInt32[] GpEvtStatusArray = new UInt32[64];
            UInt32 i;
            while (m_bInit)
            {
                //Check axis and groups enabled motion event status
                //If you want to get event status of axis or groups, you should enable
                //these events by calling Motion.mAcm_EnableMotionEvent
                Result = Motion.mAcm_CheckMotionEvent(m_DeviceHandle, AxEvtStatusArray, GpEvtStatusArray, m_ulAxisCount, 3, 10);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    for (i = 0; i < m_ulAxisCount; i++)
                    {
                        
                        if ((AxEvtStatusArray[i] & (uint)EventType.EVT_AX_LATCHBUF_DONE) > 0)
                        {
                            m_AxLatchBufCnt[i]++;
                        }
                    }
                }
            }
        }
        private void GetMotionIOStatus(uint IOStatus)
        {
            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ALM) > 0)//ALM
            {
                pictureBoxALM.BackColor = Color.Red;
            }
            else
            {
                pictureBoxALM.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ORG) > 0)//ORG
            {
                pictureBoxORG.BackColor = Color.Red;
            }
            else
            {
                pictureBoxORG.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTP) > 0)//+EL
            {
                pictureBoxPosHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxPosHEL.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTN) > 0)//-EL
            {
                pictureBoxNegHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxNegHEL.BackColor = Color.Gray;
            }
        }
        private Boolean GetDevCfgDllDrvVer()
        {
            string fileName = "";
            FileVersionInfo myFileVersionInfo;
            string FileVersion = "";
            fileName = Environment.SystemDirectory + "\\ADVMOT.dll";//SystemDirectoryָSystem32 
            myFileVersionInfo = FileVersionInfo.GetVersionInfo(fileName);
            FileVersion = myFileVersionInfo.FileVersion;
            string DetailMessage;
            string[] strSplit = FileVersion.Split(',');
            if (Convert.ToUInt16(strSplit[0]) < 2)
            {
                DetailMessage = "The Driver Version  Is Too Low" + "\r\nYou can update the driver through the driver installation package ";
                DetailMessage = DetailMessage + "\r\nThe Current Driver Version Number is " + FileVersion;
                DetailMessage = DetailMessage + "\r\nYou need to update the driver to 2.0.0.0 version and above";
                MessageBox.Show(DetailMessage, "LatchBuffer", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;              
            }
            return true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UInt32 m_LatchBuffID;
            string strTemp;
            uint Result;
            m_LatchBuffID = (UInt32)cmb_LatchBufAxisID.SelectedIndex;
            //Start single axis's absolute position motion.
            Result = Motion.mAcm_AxResetError(m_Axishand[m_LatchBuffID]);
           if (Result != (uint)ErrorCode.SUCCESS)
           {
              strTemp = "Reset Error Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
              ShowMessages(strTemp, Result);
          }
          Result = Motion.mAcm_AxResetError(m_Axishand[m_CurAxis]);
          if (Result != (uint)ErrorCode.SUCCESS)
          {
              strTemp = "Reset Error Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
              ShowMessages(strTemp, Result);
          }
        }
    }
}