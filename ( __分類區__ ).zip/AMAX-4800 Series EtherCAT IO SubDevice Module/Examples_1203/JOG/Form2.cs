﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API

namespace PTP
{
    public partial class Form2 : Form
    {
        public int JogP;
        public int JogN;
        public IntPtr Axishand = IntPtr.Zero;
     

        public Form2()
        {
            InitializeComponent();
        }
        private void ShowMessages(string DetailMessage, uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            //Get the error message according to error code returned from API
            Boolean res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
            string ErrorMessage = "";
            if (res)
                ErrorMessage = ErrorMsg.ToString();
            MessageBox.Show(DetailMessage + "\r\nError Message:" + ErrorMessage, "Jog", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void buttonRight_MouseDown(object sender, MouseEventArgs e)
        {
            UInt32 result;
            string strTemp;
            //Start software jog positive motion.
            result = Motion.mAcm_AxJog(Axishand,0);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Software jog motion Failed With Error Code: [0x" + Convert.ToString(result, 16) + "]";
                ShowMessages(strTemp, result);
                return;
            }
        }

        private void buttonRight_MouseUp(object sender, MouseEventArgs e)
        {
            UInt32 result;
            string strTemp;
            //Stop axis motion.
            result = Motion.mAcm_AxStopDec(Axishand);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Stop motion Failed With Error Code: [0x" + Convert.ToString(result, 16) + "]";
                ShowMessages(strTemp, result);
                return;
            }
        }

        private void buttonLeft_MouseDown(object sender, MouseEventArgs e)
        {
            UInt32 result;
            string strTemp;
            //Start software jog negative motion.
            result = Motion.mAcm_AxJog(Axishand,1);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Software jog motion Failed With Error Code: [0x" + Convert.ToString(result, 16) + "]";
                ShowMessages(strTemp, result);
                return;
            }

        }

        private void buttonLeft_MouseUp(object sender, MouseEventArgs e)
        {
            UInt32 result;
            string strTemp;
            //Stop axis motion.
            result = Motion.mAcm_AxStopDec(Axishand);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Stop motion Failed With Error Code: [0x" + Convert.ToString(result, 16) + "]";
                ShowMessages(strTemp, result);
                return;
            }
        }
       
      

       
    }
}