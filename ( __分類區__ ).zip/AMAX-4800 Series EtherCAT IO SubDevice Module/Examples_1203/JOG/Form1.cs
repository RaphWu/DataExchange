﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Runtime.InteropServices; //For Marshal
using System.Diagnostics;
namespace PTP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            VersionIsOk = GetDevCfgDllDrvVer(); //Get Driver Version Number, this step is not necessary
        }
        Boolean VersionIsOk = false;
        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            if (VersionIsOk == false)
            {
                return;
            }
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot，Perhaps the opposite
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, (uint)Result);
                return;
            }
            //If you want to get the device number of fixed equipment，you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            double CurCmd = new double();
            double CurPos = new double();
            UInt16 AxState = new UInt16();
            UInt32 Result;
            UInt32 IOStatus = new UInt32();
            if (m_bInit)
            {
                //Get current command position of the specified axis
                Motion.mAcm_AxGetCmdPosition(m_Axishand[CmbAxes.SelectedIndex], ref CurCmd);
                //Get current actual position of the specified axis
                Motion.mAcm_AxGetActualPosition(m_Axishand[CmbAxes.SelectedIndex], ref CurPos);
                textBoxAct.Text = Convert.ToString(CurPos);
                textBoxCmd.Text = Convert.ToString(CurCmd);
                //Get the motion I/O status of the axis.
                Result = Motion.mAcm_AxGetMotionIO(m_Axishand[CmbAxes.SelectedIndex], ref IOStatus);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    GetMotionIOStatus(IOStatus);
                }
                //Get the Axis's current state
                Motion.mAcm_AxGetState(m_Axishand[CmbAxes.SelectedIndex], ref AxState);
                textBoxCurState.Text = ((AxisState)AxState).ToString(); 
            }
        }

        private void BtnResetCnt_Click(object sender, EventArgs e)
        {
            double cmdPosition = new double();
            uint Result;
            string strTemp;
            cmdPosition = 0;
            if (m_bInit == true)
            {
                //Set command position for the specified axis.
                Result = Motion.mAcm_AxSetCmdPosition(m_Axishand[CmbAxes.SelectedIndex], cmdPosition);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set axis's command position failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
        }

        private void BtnResetErr_Click(object sender, EventArgs e)
        {

            UInt32 Result;
            string strTemp;
            //Reset the axis' state. If the axis is in ErrorStop state, the state will
            //be changed to Ready after calling this function.
            Result = Motion.mAcm_AxResetError(m_Axishand[CmbAxes.SelectedIndex]);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Reset axis's error failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }
        private void buttonLoadCfg_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            this.OpenConfigFile.FileName = ".cfg";
            if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                return;
            //Set all configurations for the device according to the loaded file
            Result = Motion.mAcm_DevLoadConfig(m_DeviceHandle, OpenConfigFile.FileName);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Load Config Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }		 
        }

        private void BtnServo_Click(object sender, EventArgs e)
        {
            UInt32 AxisNum;
            UInt32 Result;
            string strTemp;
            //Check the servoOno flag to decide if turn on or turn off the ServoOn output.
            if (m_bInit != true)
            {
                return;
            }
            if (m_bServoOn == false)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver ON,1: On
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 1);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo On Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = true;
                    BtnServo.Text = "Servo Off";
                }
            }
            else
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver OFF,0: Off
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 0);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo Off Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = false;
                    BtnServo.Text = "Servo On";
                }
            }
        }

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();
        }
        private void CloseBoardOrForm()
        {
            UInt16[] usAxisState = new UInt16[64];
            uint AxisNum;
            //Stop Every Axes
            if (m_bInit == true)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Get the axis's current state
                    Motion.mAcm_AxGetState(m_Axishand[AxisNum], ref usAxisState[AxisNum]);
                    if (usAxisState[AxisNum] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        // Reset the axis' state. If the axis is in ErrorStop state, the state will be changed to Ready after calling this function
                        Motion.mAcm_AxResetError(m_Axishand[AxisNum]);
                    }
                    //To command axis to decelerate to stop.
                    Motion.mAcm_AxStopDec(m_Axishand[AxisNum]);
                }
                //Close Axes
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    Motion.mAcm_AxClose(ref m_Axishand[AxisNum]);
                }
                m_ulAxisCount = 0;
                //Close Device
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                m_DeviceHandle = IntPtr.Zero;
                timer1.Enabled = false;
                m_bInit = false;
                CmbAxes.Items.Clear();
                CmbAxes.Text = "";
                textBoxCmd.Clear();
                textBoxCurState.Clear();
                textBoxCmd.Clear();
                textBoxAct.Clear();
            }
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            uint Result;
            int i = 0;
			uint retry = 0, SlaveOnRing0 = 0, SlaveOnRing1 = 0;
            bool rescan = false;
            uint AxesPerDev = new uint();
            string strTemp;
            comboBoxJogPAssign.Items.Clear();
            comboBoxJogNAssign.Items.Clear();
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            do
            {
                Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Device Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    retry++;
                    rescan = true;
                    if (retry > 10)
                        return;
                    System.Threading.Thread.Sleep(1000);
                }
                else
                {
					//User must check the slave count on each ring match the actual connection.
					//We recommend using following code that was marked to check connection status.
					//The example expect there is one slave on Motion ring and user does not connect any slave on IO ring.
					rescan = false;
					/*Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R0, ref SlaveOnRing0);
					Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R1, ref SlaveOnRing1);
					if (SlaveOnRing0 != 1 || SlaveOnRing1 != 0)
					{
						strTemp = "Retrieved the slave states do not match the actual connection.";
						ShowMessages(strTemp, Result);
						Motion.mAcm_DevReOpen(m_DeviceHandle);
						Motion.mAcm_DevClose(ref m_DeviceHandle);
						System.Threading.Thread.Sleep(1000);
						retry = 0;
						rescan = true;
					}*/
                }
            } while (rescan == true);
            //FT_DevAxesCount:Get axis number of this device.
            //if you device is fixed(for example: PCI-1245),You can not get FT_DevAxesCount property value
            //This step is not necessary
            //You can also use the old API: Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev, ref BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get Axis Number Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            m_ulAxisCount = AxesPerDev;
            CmbAxes.Items.Clear();
            for (i = 0; i < m_ulAxisCount; i++)
            {
                //Open every Axis and get the each Axis Handle
                //And Initial property for each Axis 		
                // Open Axis. The second parameter is the position of this axis.
                // The first axis is 0, the second one is 1 and so on.
                Result = Motion.mAcm_AxOpen(m_DeviceHandle, (UInt16)i, ref m_Axishand[i]);
                // Another way to open axis is "Motion.mAcm_AxOpenbyID" . 
                // The second parameter of mAcm_AxOpenbyID is the EtherCAT Slave ID
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Axis Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                CmbAxes.Items.Add(String.Format("{0:d}-Axis", i));
                //Reset Command Counter
                double cmdPosition = new double();
                cmdPosition = 0;
                //Set command position for the specified axis
                Motion.mAcm_AxSetCmdPosition(m_Axishand[i], cmdPosition);

            }
            //Get DI maximum number of channel
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DaqDiMaxChan, ref  DIChanNum);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get Property FT_DaqDiMaxChan Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            for (i=0;i<DIChanNum;i++)
            {
                comboBoxJogPAssign.Items.Add(i.ToString());
                comboBoxJogNAssign.Items.Add(i.ToString());
            }
            if (DIChanNum > 0)
            {
                comboBoxJogPAssign.SelectedIndex = 0;
                comboBoxJogNAssign.SelectedIndex = 0;
            }
            CmbAxes.SelectedIndex = 0;
            m_bInit = true;
            timer1.Enabled = true;
        }
        //User-defined API to show error message
        private void ShowMessages(string DetailMessage, uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            //Get the error message according to error code returned from API
            Boolean res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
            string ErrorMessage = "";
            if (res)
                ErrorMessage = ErrorMsg.ToString();
            MessageBox.Show(DetailMessage + "\r\nError Message:" + ErrorMessage, "Jog", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void GetMotionIOStatus(uint IOStatus)
        {
            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ALM) > 0)//ALM
            {
                pictureBoxALM.BackColor = Color.Red;
            }
            else
            {
                pictureBoxALM.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ORG) > 0)//ORG
            {
                pictureBoxORG.BackColor = Color.Red;
            }
            else
            {
                pictureBoxORG.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTP) > 0)//+EL
            {
                pictureBoxPosHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxPosHEL.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTN) > 0)//-EL
            {
                pictureBoxNegHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxNegHEL.BackColor = Color.Gray;
            }
        }
        
        //Get Axis Velocity Param
        private void GetAxisVelParam()
        {
            double axJogVelLow = new double();
            double axJogVelHight = new double();
            double axJogAcc = new double();
            double axJogDec = new double();
            UInt32 axJogVLTime = new UInt32();
            UInt32 Result;
            string strTemp = "";
            //Get low velocity (start velocity) of this axis (Unit: PPU/S).
            //You can also use the old API:  Acm_GetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxVelLow, ref axvellow,ref BufferLength);
            // uint BufferLength;
            // BufferLength = 8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxJogVelLow, ref axJogVelLow);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get low velocity failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            textBoxJVelL.Text = Convert.ToString(axJogVelLow);
            //get high velocity (driving velocity) of this axis (Unit: PPU/s).
            //You can also use the old API:  Acm_GetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxVelHigh, ref axvelhigh,ref BufferLength);
            // uint BufferLength;
            // BufferLength = 8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxJogVelHigh, ref axJogVelHight);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get High velocity failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            textBoxJVelH.Text = Convert.ToString(axJogVelHight);
            //get acceleration of this axis (Unit: PPU/s2).
            //You can also use the old API:  Acm_GetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxAcc, ref axacc,ref BufferLength);
            // uint BufferLength;
            // BufferLength = 8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxJogAcc, ref axJogAcc);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get acceleration  failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            textBoxJAcc.Text = Convert.ToString(axJogAcc);
            //get deceleration of this axis (Unit: PPU/s2).
            //You can also use the old API: Motion.mAcm_GetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxDec, ref axdec, ref BufferLength);
            // uint BufferLength;
            // BufferLength = 8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxJogDec, ref axJogDec);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get deceleration  failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            textBoxJDec.Text = Convert.ToString(axJogDec);
            Result = Motion.mAcm_GetU32Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxJogVLTime, ref axJogVLTime);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get jog VH time  failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            textBoxJVLTime.Text = Convert.ToString(axJogVLTime);
        }

        private void CmbAxes_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetAxisVelParam();
        }
        //get the device number of fixed equipment
        private UInt32 GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID)
        {
            return (UInt32)(DevType << 24 | BoardID << 12 | MasterRingNo << 8 | SlaveBoardID);
        }
        private Boolean GetDevCfgDllDrvVer()
        {
            string fileName = "";
            FileVersionInfo myFileVersionInfo;
            string FileVersion = "";
            fileName = Environment.SystemDirectory + "\\ADVMOT.dll";//SystemDirectory指System32 
            myFileVersionInfo = FileVersionInfo.GetVersionInfo(fileName);
            FileVersion = myFileVersionInfo.FileVersion;
            string DetailMessage;
            string[] strSplit = FileVersion.Split(',');
            if (Convert.ToUInt16(strSplit[0]) < 2)
            {
                DetailMessage = "The Driver Version  Is Too Low" + "\r\nYou can update the driver through the driver installation package ";
                DetailMessage = DetailMessage + "\r\nThe Current Driver Version Number is " + FileVersion;
                DetailMessage = DetailMessage + "\r\nYou need to update the driver to 2.0.0.0 version and above";
                MessageBox.Show(DetailMessage, "PTP", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            double axJogVelLow;
            double axJogVelHigh;
            double axJogAcc;
            double axJogDec;
            UInt32 axJogVLTime;
            string strTemp;
            axJogVelLow = Convert.ToDouble(textBoxJVelL.Text);
            //Set low velocity (start velocity) of this axis (Unit: PPU/S).
            //This property value must be smaller than or equal to PAR_AxVelHigh
            //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxVelLow, ref AxVelLow, BufferLength);
            // UInt32  BufferLength;
            //BufferLength =8; buffer size for the property
            Result = Motion.mAcm_SetF64Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxJogVelLow, axJogVelLow);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set low velocity failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            axJogVelHigh = Convert.ToDouble(textBoxJVelH.Text);
            // Set high velocity (driving velocity) of this axis (Unit: PPU/s).
            //This property value must be smaller than CFG_AxMaxVel and greater than PAR_AxVelLow
            //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxVelHigh,ref AxVelHigh,BufferLength)
            // UInt32  BufferLength;
            //BufferLength =8; buffer size for the property
            Result = Motion.mAcm_SetF64Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxJogVelHigh, axJogVelHigh);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set high velocity failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            axJogAcc = Convert.ToDouble(textBoxJAcc.Text);
            // Set acceleration of this axis (Unit: PPU/s2).
            //This property value must be smaller than or equal to CFG_AxMaxAcc
            //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxAcc,ref AxAcc,BufferLength)
            // UInt32  BufferLength;
            //BufferLength =8; buffer size for the property
            Result = Motion.mAcm_SetF64Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxJogAcc, axJogAcc);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set acceleration failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            axJogDec = Convert.ToDouble(textBoxJDec.Text);
            //Set deceleration of this axis (Unit: PPU/s2).
            //This property value must be smaller than or equal to CFG_AxMaxDec
            //You can also use the old API:Motion.mAcm_SetProperty(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.PAR_AxDcc,ref AxDec,BufferLength)
            // UInt32  BufferLength;
            //BufferLength =8; buffer size for the property
            Result = Motion.mAcm_SetF64Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxJogDec, axJogDec);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set deceleration failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            axJogVLTime = Convert.ToUInt32(textBoxJVLTime.Text);
            Result = Motion.mAcm_SetU32Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxJogVLTime,axJogVLTime);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set jog velocity low time failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
          
            GetAxisVelParam(); //Get Axis Velocity Param
        }

        private void btnStartJog_Click(object sender, EventArgs e)
        {
            UInt32 result;
            string strTemp;
            //Enable or disable external drive mode.Setting 1 is jog mode.
            result = Motion.mAcm_AxSetExtDrive(m_Axishand[0], 1);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Start jog mode failed with error code: [0x" + Convert.ToString(result, 16) + "]";
                ShowMessages(strTemp, result);
                return;
            }
            btnStartJog.Enabled = false;
            buttonExternalDrive.Enabled = true;
            btnStoptJog.Enabled = true;
        }

        private void btnStoptJog_Click(object sender, EventArgs e)
        {
            UInt32 result;
            string strTemp;
            //Disable jog mode.
            result = Motion.mAcm_AxSetExtDrive(m_Axishand[0], 0);
            if (result != (uint)ErrorCode.SUCCESS)
            {

                strTemp = "Stop jog mode failed with error code: [0x" + Convert.ToString(result, 16) + "]";
                ShowMessages(strTemp, result);
                return;
            }
            btnStartJog.Enabled = true;
            buttonExternalDrive.Enabled = false;
            btnStoptJog.Enabled = false;
        }

        private void buttonExternalDrive_Click(object sender, EventArgs e)
        {
            Form2 external = new Form2();
            external.Axishand = m_Axishand[CmbAxes.SelectedIndex];
            external.JogP = comboBoxJogPAssign.SelectedIndex;
            external.JogN = comboBoxJogNAssign.SelectedIndex;
            external.ShowDialog();
        }

        private void btnPinAssign_Click(object sender, EventArgs e)
        {
            UInt32 result;
            string strTemp;
            //Set specific DI channel to drive jog positive motion.
            result = Motion.mAcm_SetU32Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxJogPAssign, (uint)comboBoxJogPAssign.SelectedIndex);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set JogPAssign failed with error code: [0x" + Convert.ToString(result, 16) + "]";
                ShowMessages(strTemp, result);
                return;
            }
            //Set specific DI channel to drive jog negative motion.
            result = Motion.mAcm_SetU32Property(m_Axishand[CmbAxes.SelectedIndex], (uint)PropertyID.CFG_AxJogNAssign, (uint)comboBoxJogNAssign.SelectedIndex);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set JogNAssign failed with error code: [0x" + Convert.ToString(result, 16) + "]";
                ShowMessages(strTemp, result);
                return;
            }
        }
    }
}