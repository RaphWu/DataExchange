﻿namespace AIO
{
    partial class FormEtherCATAISetup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEtherCATAISetup));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cb_Enable = new System.Windows.Forms.CheckBox();
            this.btn_Apply = new System.Windows.Forms.Button();
            this.cmb_IntgTime = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmb_InputRange = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmb_ChanIndex = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cb_Enable);
            this.groupBox1.Controls.Add(this.btn_Apply);
            this.groupBox1.Controls.Add(this.cmb_IntgTime);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cmb_InputRange);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cmb_ChanIndex);
            this.groupBox1.Controls.Add(this.label1);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // cb_Enable
            // 
            resources.ApplyResources(this.cb_Enable, "cb_Enable");
            this.cb_Enable.Checked = true;
            this.cb_Enable.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_Enable.Name = "cb_Enable";
            this.cb_Enable.UseVisualStyleBackColor = true;
            // 
            // btn_Apply
            // 
            resources.ApplyResources(this.btn_Apply, "btn_Apply");
            this.btn_Apply.Name = "btn_Apply";
            this.btn_Apply.UseVisualStyleBackColor = true;
            this.btn_Apply.Click += new System.EventHandler(this.btn_Apply_Click);
            // 
            // cmb_IntgTime
            // 
            this.cmb_IntgTime.FormattingEnabled = true;
            this.cmb_IntgTime.Items.AddRange(new object[] {
            resources.GetString("cmb_IntgTime.Items"),
            resources.GetString("cmb_IntgTime.Items1")});
            resources.ApplyResources(this.cmb_IntgTime, "cmb_IntgTime");
            this.cmb_IntgTime.Name = "cmb_IntgTime";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // cmb_InputRange
            // 
            this.cmb_InputRange.FormattingEnabled = true;
            resources.ApplyResources(this.cmb_InputRange, "cmb_InputRange");
            this.cmb_InputRange.Name = "cmb_InputRange";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // cmb_ChanIndex
            // 
            this.cmb_ChanIndex.FormattingEnabled = true;
            resources.ApplyResources(this.cmb_ChanIndex, "cmb_ChanIndex");
            this.cmb_ChanIndex.Name = "cmb_ChanIndex";
            this.cmb_ChanIndex.SelectedIndexChanged += new System.EventHandler(this.cmb_ChanIndex_SelectedIndexChanged);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // FormEtherCATAISetup
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormEtherCATAISetup";
            this.Load += new System.EventHandler(this.FormAnalogInputSetup_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox cb_Enable;
        private System.Windows.Forms.Button btn_Apply;
        private System.Windows.Forms.ComboBox cmb_IntgTime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmb_InputRange;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmb_ChanIndex;
        private System.Windows.Forms.Label label1;
    }
}