﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;

namespace AIO
{
    public partial class FormEtherCATAISetup : Form
    {
        public FormEtherCATAISetup()
        {
            InitializeComponent();
        }

        private uint AINumber = 0;
        private FormAI frmAI = null;
        private IntPtr m_devhand = IntPtr.Zero;
        public FormEtherCATAISetup(FormAI m_frmAI,uint m_AINumber)
        {
            InitializeComponent();
            AINumber = m_AINumber;
            m_devhand = GlobalVar.m_DeviceHandle;
            frmAI = m_frmAI;

        }
        private void FormAnalogInputSetup_Load(object sender, EventArgs e)
        {
            for (uint i = 0; i < AINumber; i++)
            {
                cmb_ChanIndex.Items.Add(i.ToString());
            }

            uint m_AiRangeMap =0; 
            uint Ret;
            Ret = Motion.mAcm_GetU32Property(m_devhand, (uint)PropertyID.FT_DaqAiRangeMap, ref m_AiRangeMap);
            if (Ret ==(uint)ErrorCode.SUCCESS)
            {
                if (((uint)AiRangeMap.AI_NEG_10V_TO_10V & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("+/-10V");
                }
                if (((uint)AiRangeMap.AI_NEG_5V_TO_5V & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("+/-5V");
                }
                if (((uint)AiRangeMap.AI_NEG_2500MV_TO_2500MV & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("+/-2.5V");
                }
                if (((uint)AiRangeMap.AI_NEG_1250MV_TO_1250MV & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("+/-1.25V");
                }
                if (((uint)AiRangeMap.AI_NEG_625MV_TO_625MV & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("+/-625mV");
                }
                if (((uint)AiRangeMap.AI_NEG_1V_TO_1V & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("+/-1V");                
                }
                if (((uint)AiRangeMap.AI_NEG_500MV_TO_500MV & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("+/-500mV");
                }
                if (((uint)AiRangeMap.AI_NEG_150MV_TO_150MV & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("+/-150mV");
                }
                if (((uint)AiRangeMap.AI_NEG_0_TO_10V & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("0~10V");
                }
                if (((uint)AiRangeMap.AI_NEG_0_TO_500MV & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("0~500mV");
                }
                if (((uint)AiRangeMap.AI_0MA_TO_20MA & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("0~20mA");
                }
                if (((uint)AiRangeMap.AI_4MA_TO_20MA & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("4~20mA");
                }
                if (((uint)AiRangeMap.AI_NEG_20MA_TO_20MA & m_AiRangeMap) > 0)
                {
                    cmb_InputRange.Items.Add("+/-20mA");
                }
            }

            if (AINumber > 0)
                cmb_ChanIndex.SelectedIndex = 0;
        }

        private void btn_Apply_Click(object sender, EventArgs e)
        {
            uint Ret = 0;
            double m_AiEnable = 0;
            double m_AiRange = 0;
            double m_AiIntTime = 0;
            string ErrorMessage = "";
            if (cb_Enable.Checked)
                m_AiEnable = 1;
            else      
                m_AiEnable = 0;
            switch (cmb_InputRange.Text)
            {
                case "+/-10V":
                    m_AiRange = (uint)AiRange.AI_NEG_10V_TO_10V;
                    break;
                case "+/-5V":
                    m_AiRange = (uint)AiRange.AI_NEG_5V_TO_5V;
                    break;
                case "+/-2.5V":
                    m_AiRange = (uint)AiRange.AI_NEG_2500MV_TO_2500MV;
                    break;
                case "+/-1.25V":
                    m_AiRange = (uint)AiRange.AI_NEG_1250MV_TO_1250MV;
                    break;
                case "+/-1V":
                    m_AiRange = (uint)AiRange.AI_NEG_1V_TO_1V;
                    break;
                case "+/-625mV":
                    m_AiRange = (uint)AiRange.AI_NEG_625MV_TO_625MV;
                    break;
                case "+/-500mV":
                    m_AiRange = (uint)AiRange.AI_NEG_500MV_TO_500MV;
                    break;
                case "+/-150mV":
                    m_AiRange = (uint)AiRange.AI_NEG_150MV_TO_150MV;
                    break;
                case "0~10V":
                    m_AiRange = (uint)AiRange.AI_NEG_0_TO_10V;
                    break;
                case "0~500mV":
                    m_AiRange = (uint)AiRange.AI_NEG_0_TO_500MV;
                    break;
                case "0~20mA":
                    m_AiRange = (uint)AiRange.AI_0MA_TO_20MA;
                    break;
                case "4~20mA":
                    m_AiRange = (uint)AiRange.AI_4MA_TO_20MA;
                    break;
                case "+/-20mA":
                    m_AiRange = (uint)AiRange.AI_NEG_20MA_TO_20MA;
                    break;
                default:
                    m_AiRange = (uint)AiRange.AI_NEG_10V_TO_10V;
                    break;
            }
            m_AiIntTime = (double)cmb_IntgTime.SelectedIndex;
                          
                Ret = Motion.mAcm_SetChannelProperty(m_devhand, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqAiEnable, m_AiEnable);
                /*if (Ret != (uint)ErrorCode.SUCCESS)
                {
                    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                    MessageBox.Show("Channel " + cmb_ChanIndex.SelectedIndex.ToString() + " Set AiEnable Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    return;
                }*/
                Ret = Motion.mAcm_SetChannelProperty(m_devhand, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqAiRange, m_AiRange);
                if (Ret != (uint)ErrorCode.SUCCESS)
                {
                    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                    MessageBox.Show("Channel " + cmb_ChanIndex.SelectedIndex.ToString() + " Set AiRange Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    return;
                }
                Ret = Motion.mAcm_SetChannelProperty(m_devhand, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqAiIntegrationTime, m_AiIntTime);
                /*if (Ret != (uint)ErrorCode.SUCCESS)
                {
                    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                    MessageBox.Show("Channel " + cmb_ChanIndex.SelectedIndex.ToString() + " Set AiIntegrationTime Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    return;
                }*/
            
            frmAI.RefreshAISetup(false);
        }

        
       

        private void cmb_ChanIndex_SelectedIndexChanged(object sender, EventArgs e)
        {
            uint Ret = 0;
            double m_AiEnable = 0;
            double m_AiRange = 0;
            double m_AiIntTime = 0;
            string ErrorMessage = "";
            //Get CFG_CH_DaqAiEnable
            Ret = Motion.mAcm_GetChannelProperty(m_devhand, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqAiEnable, ref m_AiEnable);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel 0 Get AiEnable Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
            Ret = Motion.mAcm_GetChannelProperty(m_devhand, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqAiRange, ref m_AiRange);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel 0 Get AiRange Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
            Ret = Motion.mAcm_GetChannelProperty(m_devhand, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqAiIntegrationTime, ref m_AiIntTime);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel 0 Get AiIntegrationTime Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAI", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }

            if (m_AiEnable == 1)
            {
                cb_Enable.Checked = true;
            }
            else
            {
                cb_Enable.Checked = false;
            }

            switch ((uint)m_AiRange)
            {
                case (uint)AiRange.AI_NEG_10V_TO_10V:
                    cmb_InputRange.Text = "+/-10V";
                    break;
                case (uint)AiRange.AI_NEG_5V_TO_5V:
                    cmb_InputRange.Text = "+/-5V";
                    break;
                case (uint)AiRange.AI_NEG_2500MV_TO_2500MV:
                    cmb_InputRange.Text = "+/-2.5V";
                    break;
                case (uint)AiRange.AI_NEG_1250MV_TO_1250MV:
                    cmb_InputRange.Text = "+/-1.25V";
                    break;
                case (uint)AiRange.AI_NEG_1V_TO_1V:
                    cmb_InputRange.Text = "+/-1V";
                    break;
                case (uint)AiRange.AI_NEG_625MV_TO_625MV:
                    cmb_InputRange.Text = "+/-625mV";
                    break;
                case (uint)AiRange.AI_NEG_500MV_TO_500MV:
                    cmb_InputRange.Text = "+/-500mV";
                    break;
                case (uint)AiRange.AI_NEG_150MV_TO_150MV:
                    cmb_InputRange.Text = "+/-150mV";
                    break;
                case (uint)AiRange.AI_NEG_0_TO_10V:
                    cmb_InputRange.Text = "0~10V";
                    break;
                case (uint)AiRange.AI_NEG_0_TO_500MV:
                    cmb_InputRange.Text = "0~500mV";
                    break;
                case (uint)AiRange.AI_0MA_TO_20MA:
                    cmb_InputRange.Text = "0~20mA";
                    break;
                case (uint)AiRange.AI_4MA_TO_20MA:
                    cmb_InputRange.Text = "4~20mA";
                    break;
                case (uint)AiRange.AI_NEG_20MA_TO_20MA:
                    cmb_InputRange.Text = "+/-20mA";
                    break;
                default:
                    cmb_InputRange.Text = "";
                    break;
            }

            cmb_IntgTime.SelectedIndex = (int)m_AiIntTime;
        }

       
    }
}
