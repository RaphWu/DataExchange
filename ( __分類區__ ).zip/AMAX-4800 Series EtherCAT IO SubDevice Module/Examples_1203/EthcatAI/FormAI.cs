﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Diagnostics;
namespace AIO
{
    public partial class FormAI : Form
    {
        public FormAI()
        {
            InitializeComponent();
           // VersionIsOk = GetDevCfgDllDrvVer();
        }
        Boolean VersionIsOk = false;
        private uint AINumber = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            string ErrorMessage;
            //Get Driver Version Number, this step is not necessary
            
            //if (VersionIsOk == false)
            //{
            //   // return;
            //}
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot，Perhaps the opposite
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ErrorMessage = GlobalVar.GetErrorMessage((uint)Result);
                MessageBox.Show(strTemp + "\r\nError Message:" + ErrorMessage, "AIO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }
            //If you want to get the device number of fixed equipment，you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            RefreshAIValue(); 
        }

        private void btn_OpenBrd_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            uint retry = 0, SlaveOnRing0 = 0, SlaveOnRing1 = 0;
            bool rescan = false;
            string strTemp;
            string ErrorMessage;
            uint buffer = 0;
            lv_AIValue.Items.Clear();
            AINumber = 0;
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            do
            {
                Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Device Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ErrorMessage = GlobalVar.GetErrorMessage(Result);
                    MessageBox.Show(strTemp + "\r\nError Message:" + ErrorMessage, "EthcatAI", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    retry++;
                    rescan = true;
                    if (retry > 10)
                        return;
                    System.Threading.Thread.Sleep(1000);
                }
                else
                {
					//User must check the slave count on each ring match the actual connection.
					//We recommend using following code that was marked to check connection status.
					//The example expect there is one slave on Motion ring and user does not connect any slave on IO ring.
					rescan = false;
					/*Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R0, ref SlaveOnRing0);
					Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R1, ref SlaveOnRing1);
					if (SlaveOnRing0 != 1 || SlaveOnRing1 != 0)
					{
						MessageBox.Show("Retrieved the slave states do not match the actual connection.", "EthcatAI", MessageBoxButtons.OK, MessageBoxIcon.Error);
						Motion.mAcm_DevReOpen(m_DeviceHandle);
						Motion.mAcm_DevClose(ref m_DeviceHandle);
						System.Threading.Thread.Sleep(1000);
						retry = 0;
						rescan = true;
					}*/
                }
            } while (rescan == true);           
            GlobalVar.m_DeviceHandle = m_DeviceHandle;
            ulong dDevType;
            dDevType = (DeviceNum & 0xff000000) >> 24;
            if (dDevType == (ulong)DevTypeID.EtherCAT)
            {
                this.OpenConfigFile.FileName = "";
                if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                    return;

                Result = Motion.mAcm_LoadENI(m_DeviceHandle, OpenConfigFile.FileName);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Load ENI Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ErrorMessage = GlobalVar.GetErrorMessage(Result);
                    MessageBox.Show(ErrorMessage + "\r\nError Message:" + ErrorMessage, "EthcatAI", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }                
            }
            RefreshAISetup(true);
            m_bInit = true;
            timer1.Enabled = true;           
        }
        public void RefreshAISetup(bool IsInitial)
        {
            string[] subItems = new string[4];
            uint Ret = 0;
            double m_AiEnable = 0;
            double m_AiRange = 0;
            double m_AiIntTime = 0;
            float m_AiValue = 0;
            string strAiRange = "";
            string strAiIntTime = "";
            string ErrorMessage = "";
            uint m_FtAiMaxChan = 0;
            lv_AIValue.BeginUpdate();
            Ret = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DaqAiMaxDiffChan, ref m_FtAiMaxChan);
            AINumber = m_FtAiMaxChan;
            if (IsInitial)
            {
                for (int i = 0; i < AINumber; i++)
                {
                    subItems[0] = "CH-" + i.ToString();
                    ListViewItem lvi = new ListViewItem(subItems);
                    lv_AIValue.Items.Add(lvi);
                }
            }
            for (int i = 0; i < AINumber; i++)
            {

                Ret = Motion.mAcm_GetChannelProperty(m_DeviceHandle, (uint)i, (uint)PropertyID.CFG_CH_DaqAiEnable, ref m_AiEnable);
                /*if (Ret != (uint)ErrorCode.SUCCESS)
                {
                    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                    MessageBox.Show("Channel " + i.ToString() + " Get AiEnable Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "Advantech Common Motion Utility", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                   //return;
                }*/
                Ret = Motion.mAcm_GetChannelProperty(m_DeviceHandle, (uint)i, (uint)PropertyID.CFG_CH_DaqAiRange, ref m_AiRange);
                if (Ret != (uint)ErrorCode.SUCCESS)
                {
                    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                    MessageBox.Show("Channel " + i.ToString() + " Get AiRange Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "Advantech Common Motion Utility", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                   // return;
                }
                Ret = Motion.mAcm_GetChannelProperty(m_DeviceHandle, (uint)i, (uint)PropertyID.CFG_CH_DaqAiIntegrationTime, ref m_AiIntTime);
                /*if (Ret != (uint)ErrorCode.SUCCESS)
                {
                    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                    MessageBox.Show("Channel " + i.ToString() + " Get AiIntegrationTime Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "Advantech Common Motion Utility", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                   // return;
                }*/
                if (m_AiRange > 15)//Current
                {
                    Ret = Motion.mAcm_DaqAiGetCurrData(m_DeviceHandle, (ushort)i, ref m_AiValue);
                }
                else           //Voltage
                {
                    Ret = Motion.mAcm_DaqAiGetVoltData(m_DeviceHandle, (ushort)i, ref m_AiValue);
                }
                if (Ret != (uint)ErrorCode.SUCCESS)
                {
                    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                    MessageBox.Show("Channel " + i.ToString() + " Get AI Data failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "Advantech Common Motion Utility", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                  //  return;
                }

                switch ((uint)m_AiRange)
                {
                    case (uint)AiRange.AI_NEG_10V_TO_10V:
                        strAiRange = "+/-10V";
                        break;
                    case (uint)AiRange.AI_NEG_5V_TO_5V:
                        strAiRange = "+/-5V";
                        break;
                    case (uint)AiRange.AI_NEG_2500MV_TO_2500MV:
                        strAiRange = "+/-2.5V";
                        break;
                    case (uint)AiRange.AI_NEG_1250MV_TO_1250MV:
                        strAiRange = "+/-1.25V";
                        break;
                    case (uint)AiRange.AI_NEG_1V_TO_1V:
                        strAiRange = "+/-1V";
                        break;
                    case (uint)AiRange.AI_NEG_625MV_TO_625MV:
                        strAiRange = "+/-625mV";
                        break;
                    case (uint)AiRange.AI_NEG_500MV_TO_500MV:
                        strAiRange = "+/-500mV";
                        break;
                    case (uint)AiRange.AI_NEG_150MV_TO_150MV:
                        strAiRange = "+/-150mV";
                        break;
                    case (uint)AiRange.AI_NEG_0_TO_10V:
                        strAiRange = "0~10V";
                        break;
                    case (uint)AiRange.AI_NEG_0_TO_500MV:
                        strAiRange = "0~500mV";
                        break;
                    case (uint)AiRange.AI_0MA_TO_20MA:
                        strAiRange = "0~20mA";
                        break;
                    case (uint)AiRange.AI_4MA_TO_20MA:
                        strAiRange = "4~20mA";
                        break;
                    case (uint)AiRange.AI_NEG_20MA_TO_20MA:
                        strAiRange = "+/-20mA";
                        break;
                    default:
                        strAiRange = "+/-10V";
                        break;
                }

                switch ((uint)m_AiIntTime)
                {
                    case 0:
                        strAiIntTime = "60HZ";
                        break;
                    case 1:
                        strAiIntTime = "50HZ";
                        break;
                    default:
                        strAiIntTime = "60HZ";
                        break;
                }
                subItems[1] = m_AiValue.ToString("0.000");
                subItems[2] = strAiRange;
                subItems[3] = strAiIntTime;
                lv_AIValue.Items[i].SubItems[1].Text = subItems[1];
                lv_AIValue.Items[i].SubItems[2].Text = subItems[2];
                lv_AIValue.Items[i].SubItems[3].Text = subItems[3];

                if (m_AiEnable == 1)
                {
                    lv_AIValue.Items[i].Checked = true;
                }
                else
                {
                    lv_AIValue.Items[i].Checked = false;
                }
            }
            lv_AIValue.EndUpdate();
        }

        public void RefreshAIValue()
        {
            float m_AiValue = 0;
            double m_AiRange = 0;
            uint Ret = 0;

            lv_AIValue.BeginUpdate();
            for (int i = 0; i < AINumber; i++)
            {
                string strPreValue = lv_AIValue.Items[i].SubItems[1].Text;
                Ret = Motion.mAcm_GetChannelProperty(GlobalVar.m_DeviceHandle, (uint)i, (uint)PropertyID.CFG_CH_DaqAiRange, ref m_AiRange);
                if (Ret == (uint)ErrorCode.SUCCESS)
                {
                    if (m_AiRange > 15)//Current
                    {
                        Ret = Motion.mAcm_DaqAiGetCurrData(GlobalVar.m_DeviceHandle, (ushort)i, ref m_AiValue);
                    }
                    else           //Voltage
                    {
                        Ret = Motion.mAcm_DaqAiGetVoltData(GlobalVar.m_DeviceHandle, (ushort)i, ref m_AiValue);
                    }
                    if (Ret == (uint)ErrorCode.SUCCESS)
                    {
                        if (strPreValue != m_AiValue.ToString("0.000"))
                            lv_AIValue.Items[i].SubItems[1].Text = m_AiValue.ToString("0.000");
                    }
                }
            }
            lv_AIValue.EndUpdate();
        }

        private void btn_CloseBrd_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();//Close Board
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseBoardOrForm();//Close Board And Form
        }

    
        //User-defined API to close board
        private void CloseBoardOrForm()
        {
            if (m_bInit)
            {
                //Close a device
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                lv_AIValue.Items.Clear();
                timer1.Enabled = false;
                m_bInit = false;
                
            }
        }
        //get the device number of fixed equipment
        private UInt32 GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID)
        {
            return (UInt32)(DevType << 24 | BoardID << 12 | MasterRingNo << 8 | SlaveBoardID);
        }
        private Boolean GetDevCfgDllDrvVer()
        {
            string fileName = "";
            FileVersionInfo myFileVersionInfo;
            string FileVersion = "";
            fileName = Environment.SystemDirectory + "\\ADVMOT.dll";//SystemDirectory指System32 
            myFileVersionInfo = FileVersionInfo.GetVersionInfo(fileName);
            FileVersion = myFileVersionInfo.FileVersion;
            string DetailMessage;
            string[] strSplit = FileVersion.Split(',');
            if (Convert.ToUInt16(strSplit[0]) < 2)
            {
                DetailMessage = "The Driver Version  Is Too Low" + "\r\nYou can update the driver through the driver installation package ";
                DetailMessage = DetailMessage + "\r\nThe Current Driver Version Number is " + FileVersion;
                DetailMessage = DetailMessage + "\r\nYou need to update the driver to 2.0.0.0 version and above";
                MessageBox.Show(DetailMessage, "EthcatAI", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void lv_AIValue_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            uint Ret = 0;
            double m_PreAiEnable = 0;
            double m_AiEnable = 0;
            string ErrorMessage = "";

            if (e.Index != -1)
            {
                if (lv_AIValue.Items[e.Index].Checked)
                {
                    m_AiEnable = 0;
                }
                else
                {
                    m_AiEnable = 1;
                }
                Ret = Motion.mAcm_GetChannelProperty(GlobalVar.m_DeviceHandle, (uint)e.Index, (uint)PropertyID.CFG_CH_DaqAiEnable, ref m_PreAiEnable);
                /*if (Ret != (uint)ErrorCode.SUCCESS)
                {
                    ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                    MessageBox.Show("Channel " + e.Index.ToString() + " Get AiEnable Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "Advantech Common Motion Utility", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    return;
                }*/
                if (m_AiEnable != m_PreAiEnable)
                {
                    Ret = Motion.mAcm_SetChannelProperty(GlobalVar.m_DeviceHandle, (uint)e.Index, (uint)PropertyID.CFG_CH_DaqAiEnable, m_AiEnable);
                    if (Ret != (uint)ErrorCode.SUCCESS)
                    /*{
                        e.NewValue = e.CurrentValue;
                        ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                        MessageBox.Show("Channel " + e.Index.ToString() + " Set AiEnable Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "Advantech Common Motion Utility", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                        return;
                    }*/
                }
            } 
        }

        private void btn_AISetup_Click(object sender, EventArgs e)
        {
            FormEtherCATAISetup frmAISetup = new FormEtherCATAISetup(this, AINumber);
            DialogResult ret = frmAISetup.ShowDialog();
        }

     
    }
}
