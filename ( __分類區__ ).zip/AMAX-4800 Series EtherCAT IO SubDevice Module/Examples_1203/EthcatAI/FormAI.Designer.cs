﻿using Advantech.Motion;
using System;
namespace AIO
{
    partial class FormAI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btn_OpenBoard = new System.Windows.Forms.Button();
            this.btn_CloseBoard = new System.Windows.Forms.Button();
            this.col_Channel = new System.Windows.Forms.ColumnHeader();
            this.col_Value = new System.Windows.Forms.ColumnHeader();
            this.col_InputRange = new System.Windows.Forms.ColumnHeader();
            this.col_IntgTime = new System.Windows.Forms.ColumnHeader();
            this.btn_AISetup = new System.Windows.Forms.Button();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.lv_AIValue = new AIO.ListViewNF();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(175, 20);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(190, 20);
            this.CmbAvailableDevice.TabIndex = 20;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(62, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 19;
            this.label1.Text = "Available device:";
            // 
            // timer1
            // 
            this.timer1.Interval = 200;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btn_OpenBoard
            // 
            this.btn_OpenBoard.Location = new System.Drawing.Point(64, 51);
            this.btn_OpenBoard.Name = "btn_OpenBoard";
            this.btn_OpenBoard.Size = new System.Drawing.Size(97, 26);
            this.btn_OpenBoard.TabIndex = 22;
            this.btn_OpenBoard.Text = "Open Board";
            this.btn_OpenBoard.UseVisualStyleBackColor = true;
            this.btn_OpenBoard.Click += new System.EventHandler(this.btn_OpenBrd_Click);
            // 
            // btn_CloseBoard
            // 
            this.btn_CloseBoard.Location = new System.Drawing.Point(253, 51);
            this.btn_CloseBoard.Name = "btn_CloseBoard";
            this.btn_CloseBoard.Size = new System.Drawing.Size(97, 26);
            this.btn_CloseBoard.TabIndex = 22;
            this.btn_CloseBoard.Text = "Close Board";
            this.btn_CloseBoard.UseVisualStyleBackColor = true;
            this.btn_CloseBoard.Click += new System.EventHandler(this.btn_CloseBrd_Click);
            // 
            // col_Channel
            // 
            this.col_Channel.Text = "Channel_Enable";
            this.col_Channel.Width = 100;
            // 
            // col_Value
            // 
            this.col_Value.Text = "Value";
            this.col_Value.Width = 80;
            // 
            // col_InputRange
            // 
            this.col_InputRange.Text = "Input Range";
            this.col_InputRange.Width = 100;
            // 
            // col_IntgTime
            // 
            this.col_IntgTime.Text = "Integration Time";
            this.col_IntgTime.Width = 120;
            // 
            // btn_AISetup
            // 
            this.btn_AISetup.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn_AISetup.Location = new System.Drawing.Point(64, 83);
            this.btn_AISetup.Name = "btn_AISetup";
            this.btn_AISetup.Size = new System.Drawing.Size(97, 26);
            this.btn_AISetup.TabIndex = 24;
            this.btn_AISetup.Text = "AI Setup>>";
            this.btn_AISetup.UseVisualStyleBackColor = true;
            this.btn_AISetup.Click += new System.EventHandler(this.btn_AISetup_Click);
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openConfigFileDialog";
            // 
            // lv_AIValue
            // 
            this.lv_AIValue.CheckBoxes = true;
            this.lv_AIValue.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lv_AIValue.FullRowSelect = true;
            this.lv_AIValue.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lv_AIValue.Location = new System.Drawing.Point(37, 127);
            this.lv_AIValue.Name = "lv_AIValue";
            this.lv_AIValue.Size = new System.Drawing.Size(429, 347);
            this.lv_AIValue.TabIndex = 23;
            this.lv_AIValue.UseCompatibleStateImageBehavior = false;
            this.lv_AIValue.View = System.Windows.Forms.View.Details;
            this.lv_AIValue.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.lv_AIValue_ItemCheck);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Channel_Enable";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Value";
            this.columnHeader2.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Input Range";
            this.columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Integration Time";
            this.columnHeader4.Width = 120;
            // 
            // FormAI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 504);
            this.Controls.Add(this.btn_AISetup);
            this.Controls.Add(this.lv_AIValue);
            this.Controls.Add(this.btn_CloseBoard);
            this.Controls.Add(this.btn_OpenBoard);
            this.Controls.Add(this.CmbAvailableDevice);
            this.Controls.Add(this.label1);
            this.Name = "FormAI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EtchcatAI";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[64];
        uint m_ulAxisCount = 0;
        bool m_bInit = false;

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn_OpenBoard;
        private System.Windows.Forms.Button btn_CloseBoard;
        private System.Windows.Forms.ColumnHeader col_Channel;
        private System.Windows.Forms.ColumnHeader col_Value;
        private System.Windows.Forms.ColumnHeader col_InputRange;
        private System.Windows.Forms.ColumnHeader col_IntgTime;
        private ListViewNF lv_AIValue;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Button btn_AISetup;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
    }
}

