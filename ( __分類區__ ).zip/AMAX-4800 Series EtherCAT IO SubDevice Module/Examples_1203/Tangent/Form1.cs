﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Runtime.InteropServices; //For Marshal
using System.Diagnostics;
namespace Tangent
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            VersionIsOk = GetDevCfgDllDrvVer(); //Get Driver Version Number, this step is not necessary
        }
        uint motionAxisCount = 0;
        double[] LineEndArray;
        double[] CenterArray;
        double[] EndArray;

        Boolean VersionIsOk = false;
        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            if (VersionIsOk == false)
            {
                return;
            }
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot，Perhaps the opposite
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, (uint)Result);
                return;
            }
            //If you want to get the device number of fixed equipment，you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            UInt16 AxState = new UInt16();
            ushort GpState = 0;
            double CommandPos = 0;
            double FeedbackPos = 0;
            uint Result;
            UInt32 IOStatus = new UInt32();
            if (m_bInit)
            {
                for (int i = 0; i < m_ulAxisCount; i++)
                {
                    //Get current command position of the specified axis
                    Motion.mAcm_AxGetCmdPosition(m_Axishand[i],ref CommandPos);
                    //Get current actual position of the specified axis
                    Motion.mAcm_AxGetActualPosition(m_Axishand[i],ref FeedbackPos);
                    dgv_Position.Rows[0].Cells[i + 1].Value = Convert.ToString(CommandPos);
                    dgv_Position.Rows[1].Cells[i + 1].Value = Convert.ToString(FeedbackPos);
                }
                //Get the Axis's current state
                Motion.mAcm_AxGetState(m_Axishand[cmb_Axis.SelectedIndex], ref AxState);
                txb_MasterAxisState.Text = ((AxisState)AxState).ToString();
                //Get the motion I/O status of the axis.
                Result = Motion.mAcm_AxGetMotionIO(m_Axishand[cmb_Axis.SelectedIndex], ref IOStatus);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    GetMotionIOStatus(IOStatus);
                }
                //Get the group's current state.
                Motion.mAcm_GpGetState(m_GpHand,ref GpState);
                txb_GroupState.Text = ((GroupState)GpState).ToString();
            }
        }
        private void btn_TangentStop_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            if (m_bInit)
            {
                //To command axis to decelerate to stop.
                Result = Motion.mAcm_AxStopDec(m_Axishand[cmb_Axis.SelectedIndex]);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Axis To decelerate Stop Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
        }

        private void GetMotionIOStatus(uint IOStatus)
        {
            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ALM) > 0)//ALM
            {
                pictureBoxALM.BackColor = Color.Red;
            }
            else
            {
                pictureBoxALM.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ORG) > 0)//ORG
            {
                pictureBoxORG.BackColor = Color.Red;
            }
            else
            {
                pictureBoxORG.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTP) > 0)//+EL
            {
                pictureBoxPosHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxPosHEL.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTN) > 0)//-EL
            {
                pictureBoxNegHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxNegHEL.BackColor = Color.Gray;
            }
        }
        private void btn_ResetCounter_Click(object sender, EventArgs e)
        {
            double cmdPosition = new double();
            uint Result;
            string strTemp;
            cmdPosition = 0;
            if (m_bInit == true)
            {
                for (int i = 0; i < m_ulAxisCount;i++ )
                {
                    //Set command position for the specified axis.
                    //If you want to reset counter,you should stop tangent of group first.
                    Result = Motion.mAcm_AxSetCmdPosition(m_Axishand[i], cmdPosition);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Set axis's command position failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }              
            }
        }

        private void btn_ResetError_Click(object sender, EventArgs e)
        {
            uint Result;
            UInt16 State = new UInt16();
            string strTemp;
            if (m_bInit == true)
            {
                for (uint AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    ////Reset the axis' state. If the axis is in ErrorStop state, the state will
                    //be changed to Ready after calling this function.
                    Result = Motion.mAcm_AxResetError(m_Axishand[AxisNum]);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Reset axis's error failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
                //Get the group's current state
                Motion.mAcm_GpGetState(m_GpHand, ref State);
                if (State == (UInt16)GroupState.STA_Gp_ErrorStop)
                {
                    //Reset group states
                    Result = Motion.mAcm_GpResetError(m_GpHand);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Reset group's error failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
            }
        }

        private void cbx_Axes_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strTemp;
            uint Result;
            if (cbx_Axes.GetItemCheckState(cbx_Axes.SelectedIndex) == CheckState.Checked)
            {
                //Add an axis to the specified group
                Result = Motion.mAcm_GpAddAxis(ref m_GpHand, m_Axishand[cbx_Axes.SelectedIndex]);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Add Axis To Group Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    cbx_Axes.SetItemCheckState(cbx_Axes.SelectedIndex, CheckState.Unchecked);
                    return;
                }
                motionAxisCount++;
            }
            else
            {
                //Remove an axis from the specified group.
                Result = Motion.mAcm_GpRemAxis(m_GpHand, m_Axishand[cbx_Axes.SelectedIndex]);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Remove Axis Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    cbx_Axes.SetItemCheckState(cbx_Axes.SelectedIndex, CheckState.Checked);
                    return;
                }
                motionAxisCount--;
            }
        }

        private void MoveLine()
        {
            string strTemp;
            LineEndArray = new double[motionAxisCount];
            int ArrayIdex = 0;
            uint Result = 0;
            for (int i = 0; i < m_ulAxisCount; i++)
            {
                if (cbx_Axes.GetItemCheckState(i) == CheckState.Checked)
                {
                    LineEndArray[ArrayIdex] = Convert.ToDouble(dgv_Ends.Rows[i].Cells[1].Value);
                    ArrayIdex++;
                }
            }
            try
            {
                if (radioButtonRel.Checked)
                {
                    //Command group to execute relative line interpolation
                    Result = Motion.mAcm_GpMoveLinearRel(m_GpHand, LineEndArray, ref motionAxisCount);
                }
                else
                {
                     //Command group to execute absolute line interpolation
                    Result = Motion.mAcm_GpMoveLinearAbs(m_GpHand, LineEndArray, ref motionAxisCount);
                }
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Line Motion Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp,Result);
                }
            }
            catch (System.Exception)
            {
                MessageBox.Show("Invalid Line Command", "Tangent", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
            }
        }

        private void MoveArc()
        {
            uint Result = 0;
            string strTemp;
            uint refPlane = 0;
            CenterArray = new double[motionAxisCount];
            EndArray = new double[motionAxisCount];
            int ArrayIdex = 0;
            for (int i = 0; i < m_ulAxisCount; i++)
            {
                if (cbx_Axes.GetItemCheckState(i) == CheckState.Checked)
                {
                    CenterArray[ArrayIdex] = Convert.ToDouble(dgv_Ends.Rows[i].Cells[2].Value);
                    EndArray[ArrayIdex] = Convert.ToDouble(dgv_Ends.Rows[i].Cells[3].Value);
                    ArrayIdex++;
                }
            }
            try
            {
                if (rdo_XYPlane.Checked)
                    refPlane = 0;
                else if (rdo_YZPlane.Checked)
                    refPlane = 1;
                else if (rdo_XZPlane.Checked)
                    refPlane = 2;
                //Set reference plane for helix motion and arc interpolation.
                //You  can also use the old API Motion.mAcm_SetProperty(m_GpHand, (uint)PropertyID.PAR_GpRefPlane,ref refPlane,BufferLength)
               //  UInt32 BufferLength;
                //BufferLength = 4; //buffer size for the property
                Result = Motion.mAcm_SetU32Property(m_GpHand, (uint)PropertyID.PAR_GpRefPlane, refPlane);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set Reference Plane Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                if (radioButtonRel.Checked)
                {
                    if (rdo_CW.Checked)
                    {
                        //Command group to execute relative ARC interpolation
                        Result = Motion.mAcm_GpMoveCircularRel(m_GpHand, CenterArray, EndArray, ref motionAxisCount, 0);
                    }
                    else
                    {
                        Result = Motion.mAcm_GpMoveCircularRel(m_GpHand, CenterArray, EndArray, ref motionAxisCount, 1);
                    }
                }
                else
                {
                    if (rdo_CW.Checked)
                    {
                        //Command group to execute absolute ARC interpolation
                        Result = Motion.mAcm_GpMoveCircularAbs(m_GpHand, CenterArray, EndArray, ref motionAxisCount, 0);
                    }
                    else
                    {
                        Result = Motion.mAcm_GpMoveCircularAbs(m_GpHand, CenterArray, EndArray, ref motionAxisCount, 1);
                    }
                }

                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Arc Motion Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                }
            }
            catch (System.Exception)
            {
                MessageBox.Show("Invalid Arc Command", "Tangent", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
            }
        }

        private void MoveSpiral()
        {
            uint Result = 0;
            string strTemp;
            uint refPlane = 0;
            CenterArray = new double[motionAxisCount];
            EndArray = new double[motionAxisCount];
            int ArrayIdex = 0;
            for (int i = 0; i < m_ulAxisCount; i++)
            {
                if (cbx_Axes.GetItemCheckState(i) == CheckState.Checked)
                {
                    CenterArray[ArrayIdex] = Convert.ToDouble(dgv_Ends.Rows[i].Cells[2].Value);
                    EndArray[ArrayIdex] = Convert.ToDouble(dgv_Ends.Rows[i].Cells[3].Value);
                    ArrayIdex++;
                }
            }
            try
            {
                if (rdo_XYPlane.Checked)
                    refPlane = 0;
                else if (rdo_YZPlane.Checked)
                    refPlane = 1;
                else if (rdo_XZPlane.Checked)
                    refPlane = 2;
                //Set reference plane for helix motion and arc interpolation.
                //You  can also use the old API Motion.mAcm_SetProperty(m_GpHand, (uint)PropertyID.PAR_GpRefPlane,ref refPlane,BufferLength)
                //  UInt32 BufferLength;
                //BufferLength = 4; //buffer size for the property
                Result = Motion.mAcm_SetU32Property(m_GpHand, (uint)PropertyID.PAR_GpRefPlane, refPlane);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set Reference Plane Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                if (radioButtonRel.Checked)
                {
                    if (rdo_CW.Checked)
                    {
                        //Command group to move relative spiral
                        Result = Motion.mAcm_GpMoveHelixRel(m_GpHand, CenterArray, EndArray, ref motionAxisCount, 0);
                    }
                    else
                    {
                        Result = Motion.mAcm_GpMoveHelixRel(m_GpHand, CenterArray, EndArray, ref motionAxisCount, 1);
                    }
                }
                else
                {
                    if (rdo_CW.Checked)
                    {
                        //Command group to move absolute spiral.
                        Result = Motion.mAcm_GpMoveHelixAbs(m_GpHand, CenterArray, EndArray, ref motionAxisCount, 0);
                    }
                    else
                    {
                        Result = Motion.mAcm_GpMoveHelixAbs(m_GpHand, CenterArray, EndArray, ref motionAxisCount, 1);
                    }
                }

                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Helix Motion Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                }
            }
            catch (System.Exception)
            {
                MessageBox.Show("Invalid Tangent Command", "Tangent", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
            }
        }

        private void btn_Move_Click(object sender, EventArgs e)
        {
            if(m_bInit)
            {
                if (rdo_Line.Checked)
                {
                    MoveLine();
                }
                else if (rdo_Arc.Checked)
                {
                    MoveArc();
                }
                else if (rdo_Spiral.Checked)
                {
                    MoveSpiral();
                }
            }
        }

        private void btn_GroupStop_Click(object sender, EventArgs e)
        {
            string strTemp;
            uint Result;
            //Command axis in this group to stop immediately without deceleration
            Result = Motion.mAcm_GpStopEmg(m_GpHand);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "The group to stop immediately failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
            return;
        }
        private void buttonLoadCfg_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            this.OpenConfigFile.FileName = ".cfg";
            if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                return;
            //Set all configurations for the device according to the loaded file
            Result = Motion.mAcm_DevLoadConfig(m_DeviceHandle, OpenConfigFile.FileName);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Load Config Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }		 
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            uint Result;
            int i = 0;
			uint retry = 0, SlaveOnRing0 = 0, SlaveOnRing1 = 0;
            bool rescan = false;
            uint AxesPerDev = new uint();
            string strTemp;
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            do
            {
                Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Device Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    retry++;
                    rescan = true;
                    if (retry > 10)
                        return;
                    System.Threading.Thread.Sleep(1000);
                }
                else
                {
					//User must check the slave count on each ring match the actual connection.
					//We recommend using following code that was marked to check connection status.
					//The example expect there is one slave on Motion ring and user does not connect any slave on IO ring.
					rescan = false;
					/*Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R0, ref SlaveOnRing0);
					Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R1, ref SlaveOnRing1);
					if (SlaveOnRing0 != 1 || SlaveOnRing1 != 0)
					{
						strTemp = "Retrieved the slave states do not match the actual connection.";
						ShowMessages(strTemp, Result);
						Motion.mAcm_DevReOpen(m_DeviceHandle);
						Motion.mAcm_DevClose(ref m_DeviceHandle);
						System.Threading.Thread.Sleep(1000);
						retry = 0;
						rescan = true;
					}*/
                }
            } while (rescan == true);
            //FT_DevAxesCount:Get axis number of this device.
            //if you device is fixed(for example: PCI-1245),You can not get FT_DevAxesCount property value
            //This step is not necessary
            //You can also use the old API: Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev, ref BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get Axis Number Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            m_ulAxisCount = AxesPerDev;
            motionAxisCount = 0;
            cmb_Axis.Items.Clear();
            cbx_Axes.Items.Clear();
            dgv_Ends.Rows.Clear();               //For Next Open
            if (dgv_Position.ColumnCount > 1)
            {
                dgv_Position.Columns.Clear();
                dgv_Position.Columns.Add("Position", "Position");
                dgv_Position.Columns[0].SortMode = DataGridViewColumnSortMode.NotSortable;
                dgv_Position.Columns[0].Width = 60;
            }
            dgv_Position.Width = dgv_Position.RowHeadersWidth + dgv_Position.Columns[0].Width;
            dgv_Ends.Height = dgv_Ends.ColumnHeadersHeight;
            //if you device is fixed,for example: PCI-1245 m_ulAxisCount =4
            for (i = 0; i < m_ulAxisCount; i++)
            {
                //Open every Axis and get the each Axis Handle
                //And Initial property for each Axis 		
                // Open Axis. The second parameter is the position of this axis.
                // The first axis is 0, the second one is 1 and so on.
                Result = Motion.mAcm_AxOpen(m_DeviceHandle, (UInt16)i, ref m_Axishand[i]);
                // Another way to open axis is "Motion.mAcm_AxOpenbyID" . 
                // The second parameter of mAcm_AxOpenbyID is the EtherCAT Slave ID
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Axis Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                cmb_Axis.Items.Add(String.Format("{0:d}-Axis", i));
                cbx_Axes.Items.Add(String.Format("{0:d}-Axis", i));
                dgv_Ends.Rows.Add();
                dgv_Ends.Height = dgv_Ends.Height + dgv_Ends.Rows[i].Height;
                dgv_Ends.Rows[i].Cells[0].Value = String.Format("{0:d}", i) + "-Axis";
                dgv_Ends.Rows[i].Cells[0].ReadOnly = true;
                dgv_Ends.Rows[i].Cells[1].Value = "8000";
                if (i % 2 == 0)
                {
                    dgv_Ends.Rows[i].Cells[2].Value = "8000";
                    dgv_Ends.Rows[i].Cells[3].Value = "16000";
                }
                else
                {
                    dgv_Ends.Rows[i].Cells[2].Value = "0";
                    dgv_Ends.Rows[i].Cells[3].Value = "0";
                }
                dgv_Position.Columns.Add("Axis" + Convert.ToString(i), String.Format("{0:d}", i) + "-Axis");//Add(string columnName,string headerText)
                dgv_Position.Columns[i + 1].SortMode = DataGridViewColumnSortMode.NotSortable;
                dgv_Position.Columns[i + 1].Width = 80;
                dgv_Position.Columns[i + 1].DefaultCellStyle.BackColor = Color.LightGray;
                dgv_Position.Width = dgv_Position.Width + dgv_Position.Columns[i + 1].Width;
                double cmdPosition = new double();
                //Set command position for the specified axis
                cmdPosition = 0;
                Motion.mAcm_AxSetCmdPosition(m_Axishand[i], cmdPosition);
            }
            dgv_Ends.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;//ColumnHeader Align MiddleCenter;
            if (dgv_Ends.Height < 120)
                dgv_Ends.Height = dgv_Ends.Height + 3;
            else
                dgv_Ends.Height = 120;
            if (dgv_Position.Width < 604)
                dgv_Position.Width = dgv_Position.Width + 3;
            else
                dgv_Position.Width = 604;
            dgv_Position.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;//ColumnHeader Align MiddleCenter;
            dgv_Position.Rows.Add();
            dgv_Position.ReadOnly = true;
            dgv_Position.Rows[0].Cells[0].Value = "Command";
            dgv_Position.Rows.Add();
            dgv_Position.Rows[1].Cells[0].Value = "Feedback";
            dgv_Position.Columns[0].DefaultCellStyle.BackColor = dgv_Position.ColumnHeadersDefaultCellStyle.BackColor;
            cmb_Axis.SelectedIndex = 2;
            rdo_Arc.Checked = true;
            m_bInit = true;
            timer1.Enabled = true;
        }

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();
        }

        private void BtnServo_Click(object sender, EventArgs e)
        {
            UInt32 AxisNum;
            UInt32 Result;
            string strTemp;
            //Check the servoOno flag to decide if turn on or turn off the ServoOn output.
            if (m_bInit != true)
            {
                return;
            }
            if (m_bServoOn == false)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver ON,1: On
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 1);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo On Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = true;
                    BtnServo.Text = "Servo Off";
                }
            }
            else
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver OFF,0: Off
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 0);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo Off Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = false;
                    BtnServo.Text = "Servo On";
                }
            }
        }
        //User-defined API to show error message
        private void ShowMessages(string DetailMessage, uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            //Get the error message according to error code returned from API
            Boolean res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
            string ErrorMessage = "";
            if (res)
                ErrorMessage = ErrorMsg.ToString();
            MessageBox.Show(DetailMessage + "\r\nError Message:" + ErrorMessage, "Tangent", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        //User-defined API to close board
        private void CloseBoardOrForm()
        {
            UInt16[] usAxisState = new UInt16[64];
            int AxisNum;
            //Stop Every Axes
            if (m_bInit == true)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Get the axis's current state
                    Motion.mAcm_AxGetState(m_Axishand[AxisNum], ref usAxisState[AxisNum]);
                    if (usAxisState[AxisNum] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        // Reset the axis' state. If the axis is in ErrorStop state, the state will be changed to Ready after calling this function
                        Motion.mAcm_AxResetError(m_Axishand[AxisNum]);
                    }
                    //To command axis to decelerate to stop.
                    Motion.mAcm_AxStopDec(m_Axishand[AxisNum]);
                }
                //Close Group
                Motion.mAcm_GpClose(ref m_GpHand);
                m_GpHand = IntPtr.Zero;
                //Close Axes
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    if (cbx_Axes.GetItemCheckState(AxisNum) == CheckState.Checked)
                    {
                        cbx_Axes.SetItemCheckState(AxisNum, CheckState.Unchecked);
                    }
                    //Close Axes
                    Motion.mAcm_AxClose(ref m_Axishand[AxisNum]);
                }
                m_ulAxisCount = 0;
                //Close Device
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                m_DeviceHandle = IntPtr.Zero;
                timer1.Enabled = false;
                m_bInit = false;
                cmb_Axis.Items.Clear();
                cmb_Axis.Text = "";
                cbx_Axes.Items.Clear();
                motionAxisCount = 0;
                dgv_Ends.Rows.Clear();
                dgv_Position.Rows.Clear();
            }
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseBoardOrForm();
        }
        //get the device number of fixed equipment
        private UInt32 GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID)
        {
            return (UInt32)(DevType << 24 | BoardID << 12 | MasterRingNo << 8 | SlaveBoardID);
        }

        private void btn_TangentIn_Click(object sender, EventArgs e)
        {
            byte WorkingPlane = 0;
            short Dir = 0;
            string strTemp;
            short[] StartVectorArray = new short[3];
            uint result = 0;
            if (m_bInit != true)
            {
                return;
            }
            if (rdo_XYPlane.Checked)
            {
                WorkingPlane = 0;
              
            }
            else if (rdo_YZPlane.Checked)
            {
                WorkingPlane = 1;
                
            }
            else if (rdo_XZPlane.Checked)
            {
                WorkingPlane = 2;
               
            }
            if (rdo_Opposite.Checked)
            {
                Dir = 1;
            }
            if ((txb_XPos.Text == "0") && (txb_YPos.Text == "0") && (txb_ZPos.Text == "0"))
            {
                MessageBox.Show("Please Input The Start Vector First!", "Tangent", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
            StartVectorArray[0] = Convert.ToInt16(txb_XPos.Text);
            StartVectorArray[1] = Convert.ToInt16(txb_YPos.Text);
            StartVectorArray[2] = Convert.ToInt16(txb_ZPos.Text);
            if (txb_ModuleRange.Text == "0")
            {
                MessageBox.Show("Please Set ModuleRange First", "Tangent", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
            if (m_bInit)
            {
                uint ModuleRange = Convert.ToUInt32(txb_ModuleRange.Text);
                //Set pulse number when axis moves 360 degree
                //You can also use the old API:  Motion.mAcm_SetProperty(m_Axishand[cmb_Axis.SelectedIndex], (uint)PropertyID.CFG_AxModuleRange, ref ModuleRange, (uint)Marshal.SizeOf(typeof(uint)));
                result = Motion.mAcm_SetU32Property(m_Axishand[cmb_Axis.SelectedIndex], (uint)PropertyID.CFG_AxModuleRange, ModuleRange);
                if (result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set CFG_AxModuleRange Property Failed With Error Code: [0x" + Convert.ToString(result, 16) + "]";
                    ShowMessages(strTemp, result);
                    return;
                }
                //Command axis to move at same direction with tangent of group path
                result = Motion.mAcm_AxTangentInGp(m_Axishand[cmb_Axis.SelectedIndex], m_GpHand, StartVectorArray, WorkingPlane, Dir);
                if (result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Tangent Motion Failed With Error Code: [0x" + Convert.ToString(result, 16) + "]";
                    ShowMessages(strTemp, result);
                    return;
                }
            }
        }
        private Boolean GetDevCfgDllDrvVer()
        {
            string fileName = "";
            FileVersionInfo myFileVersionInfo;
            string FileVersion = "";
            fileName = Environment.SystemDirectory + "\\ADVMOT.dll";//SystemDirectory means System32 
            myFileVersionInfo = FileVersionInfo.GetVersionInfo(fileName);
            FileVersion = myFileVersionInfo.FileVersion;
            string DetailMessage;
            string[] strSplit = FileVersion.Split(',');
            if (Convert.ToUInt16(strSplit[0]) < 2)
            {
                DetailMessage = "The Driver Version  Is Too Low" + "\r\nYou can update the driver through the driver installation package ";
                DetailMessage = DetailMessage + "\r\nThe Current Driver Version Number is " + FileVersion;
                DetailMessage = DetailMessage + "\r\nYou need to update the driver to 2.0.0.0 version and above";
                MessageBox.Show(DetailMessage, "Tangent", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
    }
}