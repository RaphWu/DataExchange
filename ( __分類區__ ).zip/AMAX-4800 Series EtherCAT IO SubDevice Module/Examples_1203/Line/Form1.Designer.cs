﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Diagnostics;
namespace Line
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnMove = new System.Windows.Forms.Button();
            this.BtnStop = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_SetParam = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioButtonRel = new System.Windows.Forms.RadioButton();
            this.radioButtonAbs = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.BtnClearEnd = new System.Windows.Forms.Button();
            this.BtnSetEnd = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxEnd = new System.Windows.Forms.TextBox();
            this.BtnAddAxes = new System.Windows.Forms.Button();
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.listBoxEndPoint = new System.Windows.Forms.ListBox();
            this.listBoxAxesInGp = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.buttonLoadCfg = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.Button1 = new System.Windows.Forms.Button();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.textBoxAxState = new System.Windows.Forms.TextBox();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxGpState = new System.Windows.Forms.TextBox();
            this.CmbOperateAxis = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.BtnResetCounter = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxAxCmd = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.GroupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnMove
            // 
            this.BtnMove.Location = new System.Drawing.Point(65, 263);
            this.BtnMove.Name = "BtnMove";
            this.BtnMove.Size = new System.Drawing.Size(93, 28);
            this.BtnMove.TabIndex = 28;
            this.BtnMove.Text = "Move";
            this.BtnMove.UseVisualStyleBackColor = true;
            this.BtnMove.Click += new System.EventHandler(this.BtnMove_Click);
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(204, 263);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(87, 28);
            this.BtnStop.TabIndex = 28;
            this.BtnStop.Text = "Stop";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_SetParam);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.BtnStop);
            this.groupBox1.Controls.Add(this.BtnMove);
            this.groupBox1.Controls.Add(this.BtnAddAxes);
            this.groupBox1.Controls.Add(this.CmbAxes);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox1.Location = new System.Drawing.Point(17, 150);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(331, 310);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Line Interpolation Operation";
            // 
            // btn_SetParam
            // 
            this.btn_SetParam.Location = new System.Drawing.Point(208, 65);
            this.btn_SetParam.Name = "btn_SetParam";
            this.btn_SetParam.Size = new System.Drawing.Size(95, 25);
            this.btn_SetParam.TabIndex = 27;
            this.btn_SetParam.Text = "Set/Get Param";
            this.btn_SetParam.UseVisualStyleBackColor = true;
            this.btn_SetParam.Click += new System.EventHandler(this.btn_SetParam_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(71, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 12);
            this.label7.TabIndex = 26;
            this.label7.Text = "Group Velocity Param:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioButtonRel);
            this.groupBox4.Controls.Add(this.radioButtonAbs);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox4.Location = new System.Drawing.Point(25, 202);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(281, 49);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Movement Mode";
            // 
            // radioButtonRel
            // 
            this.radioButtonRel.AutoSize = true;
            this.radioButtonRel.Checked = true;
            this.radioButtonRel.Location = new System.Drawing.Point(193, 23);
            this.radioButtonRel.Name = "radioButtonRel";
            this.radioButtonRel.Size = new System.Drawing.Size(71, 16);
            this.radioButtonRel.TabIndex = 7;
            this.radioButtonRel.TabStop = true;
            this.radioButtonRel.Text = "Relative";
            this.radioButtonRel.UseVisualStyleBackColor = true;
            // 
            // radioButtonAbs
            // 
            this.radioButtonAbs.AutoSize = true;
            this.radioButtonAbs.Location = new System.Drawing.Point(30, 23);
            this.radioButtonAbs.Name = "radioButtonAbs";
            this.radioButtonAbs.Size = new System.Drawing.Size(71, 16);
            this.radioButtonAbs.TabIndex = 6;
            this.radioButtonAbs.Text = "Absolute";
            this.radioButtonAbs.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.BtnClearEnd);
            this.groupBox3.Controls.Add(this.BtnSetEnd);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.textBoxEnd);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox3.Location = new System.Drawing.Point(25, 99);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(281, 89);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "End";
            // 
            // BtnClearEnd
            // 
            this.BtnClearEnd.Location = new System.Drawing.Point(167, 51);
            this.BtnClearEnd.Name = "BtnClearEnd";
            this.BtnClearEnd.Size = new System.Drawing.Size(89, 28);
            this.BtnClearEnd.TabIndex = 12;
            this.BtnClearEnd.Text = "Clear";
            this.BtnClearEnd.UseVisualStyleBackColor = true;
            this.BtnClearEnd.Click += new System.EventHandler(this.BtnClearEnd_Click);
            // 
            // BtnSetEnd
            // 
            this.BtnSetEnd.Location = new System.Drawing.Point(34, 51);
            this.BtnSetEnd.Name = "BtnSetEnd";
            this.BtnSetEnd.Size = new System.Drawing.Size(89, 28);
            this.BtnSetEnd.TabIndex = 9;
            this.BtnSetEnd.Text = "Add End";
            this.BtnSetEnd.UseVisualStyleBackColor = true;
            this.BtnSetEnd.Click += new System.EventHandler(this.BtnSetEnd_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(64, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "EndPoint:";
            // 
            // textBoxEnd
            // 
            this.textBoxEnd.Location = new System.Drawing.Point(124, 21);
            this.textBoxEnd.Name = "textBoxEnd";
            this.textBoxEnd.Size = new System.Drawing.Size(132, 21);
            this.textBoxEnd.TabIndex = 11;
            this.textBoxEnd.Text = "10000";
            // 
            // BtnAddAxes
            // 
            this.BtnAddAxes.Location = new System.Drawing.Point(208, 29);
            this.BtnAddAxes.Name = "BtnAddAxes";
            this.BtnAddAxes.Size = new System.Drawing.Size(95, 25);
            this.BtnAddAxes.TabIndex = 1;
            this.BtnAddAxes.Text = "Add Axis";
            this.BtnAddAxes.UseVisualStyleBackColor = true;
            this.BtnAddAxes.Click += new System.EventHandler(this.BtnAddAxes_Click);
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(65, 33);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(136, 20);
            this.CmbAxes.TabIndex = 0;
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openConfigFileDialog";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // listBoxEndPoint
            // 
            this.listBoxEndPoint.BackColor = System.Drawing.SystemColors.Control;
            this.listBoxEndPoint.FormattingEnabled = true;
            this.listBoxEndPoint.ItemHeight = 12;
            this.listBoxEndPoint.Location = new System.Drawing.Point(146, 38);
            this.listBoxEndPoint.Name = "listBoxEndPoint";
            this.listBoxEndPoint.Size = new System.Drawing.Size(119, 100);
            this.listBoxEndPoint.TabIndex = 29;
            // 
            // listBoxAxesInGp
            // 
            this.listBoxAxesInGp.BackColor = System.Drawing.SystemColors.Control;
            this.listBoxAxesInGp.FormattingEnabled = true;
            this.listBoxAxesInGp.ItemHeight = 12;
            this.listBoxAxesInGp.Location = new System.Drawing.Point(12, 35);
            this.listBoxAxesInGp.Name = "listBoxAxesInGp";
            this.listBoxAxesInGp.Size = new System.Drawing.Size(114, 100);
            this.listBoxAxesInGp.TabIndex = 30;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.listBoxEndPoint);
            this.groupBox2.Controls.Add(this.listBoxAxesInGp);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(368, 10);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(277, 146);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Axes info and End Point Array";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(147, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 31;
            this.label5.Text = "End Point:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 12);
            this.label4.TabIndex = 19;
            this.label4.Text = "Axes In Gp:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.buttonLoadCfg);
            this.groupBox6.Controls.Add(this.BtnServo);
            this.groupBox6.Controls.Add(this.BtnCloseBoard);
            this.groupBox6.Controls.Add(this.BtnOpenBoard);
            this.groupBox6.Controls.Add(this.CmbAvailableDevice);
            this.groupBox6.Controls.Add(this.label1);
            this.groupBox6.Location = new System.Drawing.Point(16, 8);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(331, 133);
            this.groupBox6.TabIndex = 29;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Device Operate";
            // 
            // buttonLoadCfg
            // 
            this.buttonLoadCfg.Location = new System.Drawing.Point(52, 87);
            this.buttonLoadCfg.Name = "buttonLoadCfg";
            this.buttonLoadCfg.Size = new System.Drawing.Size(89, 26);
            this.buttonLoadCfg.TabIndex = 31;
            this.buttonLoadCfg.Text = "Load Config";
            this.buttonLoadCfg.UseVisualStyleBackColor = true;
            this.buttonLoadCfg.Click += new System.EventHandler(this.buttonLoadCfg_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(208, 87);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(95, 26);
            this.BtnServo.TabIndex = 17;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(209, 51);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(95, 26);
            this.BtnCloseBoard.TabIndex = 16;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(52, 51);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(89, 26);
            this.BtnOpenBoard.TabIndex = 15;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(133, 20);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(174, 20);
            this.CmbAvailableDevice.TabIndex = 14;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "Available device:";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.Button1);
            this.groupBox13.Controls.Add(this.GroupBox5);
            this.groupBox13.Controls.Add(this.textBoxAxState);
            this.groupBox13.Controls.Add(this.BtnResetErr);
            this.groupBox13.Controls.Add(this.label11);
            this.groupBox13.Controls.Add(this.textBoxGpState);
            this.groupBox13.Controls.Add(this.CmbOperateAxis);
            this.groupBox13.Controls.Add(this.label13);
            this.groupBox13.Controls.Add(this.Label2);
            this.groupBox13.Controls.Add(this.BtnResetCounter);
            this.groupBox13.Controls.Add(this.label3);
            this.groupBox13.Controls.Add(this.textBoxAxCmd);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(367, 167);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(277, 291);
            this.groupBox13.TabIndex = 123;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Axis/Group Info";
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(115, 256);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(105, 25);
            this.Button1.TabIndex = 34;
            this.Button1.Text = "Reset Error";
            this.Button1.UseVisualStyleBackColor = true;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // GroupBox5
            // 
            this.GroupBox5.Controls.Add(this.label19);
            this.GroupBox5.Controls.Add(this.pictureBoxALM);
            this.GroupBox5.Controls.Add(this.label12);
            this.GroupBox5.Controls.Add(this.pictureBoxORG);
            this.GroupBox5.Controls.Add(this.label17);
            this.GroupBox5.Controls.Add(this.pictureBoxPosHEL);
            this.GroupBox5.Controls.Add(this.Label8);
            this.GroupBox5.Controls.Add(this.pictureBoxNegHEL);
            this.GroupBox5.Location = new System.Drawing.Point(21, 105);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Size = new System.Drawing.Size(239, 80);
            this.GroupBox5.TabIndex = 33;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "Axis Motion IO";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(38, 28);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "ALM:";
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(69, 25);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(140, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 26;
            this.label12.Text = "ORG:";
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(172, 25);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(31, 59);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 12);
            this.label17.TabIndex = 27;
            this.label17.Text = "+HEL:";
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(69, 56);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(134, 58);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(35, 12);
            this.Label8.TabIndex = 28;
            this.Label8.Text = "-HEL:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(172, 55);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // textBoxAxState
            // 
            this.textBoxAxState.Location = new System.Drawing.Point(113, 197);
            this.textBoxAxState.Name = "textBoxAxState";
            this.textBoxAxState.ReadOnly = true;
            this.textBoxAxState.Size = new System.Drawing.Size(122, 21);
            this.textBoxAxState.TabIndex = 10;
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(-93, 496);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(98, 25);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "Reset Error";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(36, 199);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 12);
            this.label11.TabIndex = 9;
            this.label11.Text = "Axis State:";
            // 
            // textBoxGpState
            // 
            this.textBoxGpState.Location = new System.Drawing.Point(113, 224);
            this.textBoxGpState.Name = "textBoxGpState";
            this.textBoxGpState.ReadOnly = true;
            this.textBoxGpState.Size = new System.Drawing.Size(122, 21);
            this.textBoxGpState.TabIndex = 17;
            // 
            // CmbOperateAxis
            // 
            this.CmbOperateAxis.FormattingEnabled = true;
            this.CmbOperateAxis.Location = new System.Drawing.Point(115, 22);
            this.CmbOperateAxis.Name = "CmbOperateAxis";
            this.CmbOperateAxis.Size = new System.Drawing.Size(141, 20);
            this.CmbOperateAxis.TabIndex = 32;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(30, 225);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 12);
            this.label13.TabIndex = 16;
            this.label13.Text = "Group State:";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(15, 26);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(95, 12);
            this.Label2.TabIndex = 31;
            this.Label2.Text = "Operation Axis:";
            // 
            // BtnResetCounter
            // 
            this.BtnResetCounter.Location = new System.Drawing.Point(115, 77);
            this.BtnResetCounter.Name = "BtnResetCounter";
            this.BtnResetCounter.Size = new System.Drawing.Size(105, 26);
            this.BtnResetCounter.TabIndex = 15;
            this.BtnResetCounter.Text = "Reset Counter";
            this.BtnResetCounter.UseVisualStyleBackColor = true;
            this.BtnResetCounter.Click += new System.EventHandler(this.BtnResetCounter_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(80, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 18;
            this.label3.Text = "Cmd:";
            // 
            // textBoxAxCmd
            // 
            this.textBoxAxCmd.Location = new System.Drawing.Point(115, 50);
            this.textBoxAxCmd.Name = "textBoxAxCmd";
            this.textBoxAxCmd.ReadOnly = true;
            this.textBoxAxCmd.Size = new System.Drawing.Size(141, 21);
            this.textBoxAxCmd.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 478);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Line";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.GroupBox5.ResumeLayout(false);
            this.GroupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnMove;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radioButtonRel;
        private System.Windows.Forms.RadioButton radioButtonAbs;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxEnd;
        private System.Windows.Forms.Button BtnAddAxes;
        private System.Windows.Forms.ComboBox CmbAxes;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button BtnSetEnd;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        List <string> list1 = new List<string>();
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[64];
        IntPtr m_GpHand = IntPtr.Zero;
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        uint AxCountInGp = 0;
        double[] EndArray = new double[64];
        uint EndPointNum = 0;
        uint[] AxisArray = new uint[64];
        bool m_IsGpOpen = false;
        private System.Windows.Forms.ListBox listBoxEndPoint;
        private System.Windows.Forms.ListBox listBoxAxesInGp;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BtnClearEnd;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button buttonLoadCfg;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_SetParam;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.GroupBox GroupBox5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBoxALM;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.Label Label8;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.TextBox textBoxAxState;
        private System.Windows.Forms.Button BtnResetErr;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxGpState;
        private System.Windows.Forms.ComboBox CmbOperateAxis;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label Label2;
        private System.Windows.Forms.Button BtnResetCounter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxAxCmd;
    }
}

