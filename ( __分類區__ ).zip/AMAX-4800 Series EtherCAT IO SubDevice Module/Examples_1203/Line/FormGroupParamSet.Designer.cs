﻿namespace Line
{
    partial class FormGroupParamSet
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_VelLow = new System.Windows.Forms.TextBox();
            this.txt_VelHigh = new System.Windows.Forms.TextBox();
            this.txt_Acc = new System.Windows.Forms.TextBox();
            this.txt_Dec = new System.Windows.Forms.TextBox();
            this.rdb_T = new System.Windows.Forms.RadioButton();
            this.rdb_S = new System.Windows.Forms.RadioButton();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "GpVelLow:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "GpVelHigh:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(100, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "GpAcc:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(100, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "GpDec:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(94, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "GpJerk:";
            // 
            // txt_VelLow
            // 
            this.txt_VelLow.Location = new System.Drawing.Point(147, 20);
            this.txt_VelLow.Name = "txt_VelLow";
            this.txt_VelLow.Size = new System.Drawing.Size(161, 21);
            this.txt_VelLow.TabIndex = 5;
            this.txt_VelLow.Text = "2000";
            // 
            // txt_VelHigh
            // 
            this.txt_VelHigh.Location = new System.Drawing.Point(147, 59);
            this.txt_VelHigh.Name = "txt_VelHigh";
            this.txt_VelHigh.Size = new System.Drawing.Size(161, 21);
            this.txt_VelHigh.TabIndex = 6;
            this.txt_VelHigh.Text = "8000";
            // 
            // txt_Acc
            // 
            this.txt_Acc.Location = new System.Drawing.Point(147, 100);
            this.txt_Acc.Name = "txt_Acc";
            this.txt_Acc.Size = new System.Drawing.Size(161, 21);
            this.txt_Acc.TabIndex = 7;
            this.txt_Acc.Text = "10000";
            // 
            // txt_Dec
            // 
            this.txt_Dec.Location = new System.Drawing.Point(147, 144);
            this.txt_Dec.Name = "txt_Dec";
            this.txt_Dec.Size = new System.Drawing.Size(161, 21);
            this.txt_Dec.TabIndex = 8;
            this.txt_Dec.Text = "10000";
            // 
            // rdb_T
            // 
            this.rdb_T.AutoSize = true;
            this.rdb_T.Checked = true;
            this.rdb_T.Location = new System.Drawing.Point(147, 192);
            this.rdb_T.Name = "rdb_T";
            this.rdb_T.Size = new System.Drawing.Size(71, 16);
            this.rdb_T.TabIndex = 9;
            this.rdb_T.TabStop = true;
            this.rdb_T.Text = "T-Curver";
            this.rdb_T.UseVisualStyleBackColor = true;
            // 
            // rdb_S
            // 
            this.rdb_S.AutoSize = true;
            this.rdb_S.Location = new System.Drawing.Point(248, 192);
            this.rdb_S.Name = "rdb_S";
            this.rdb_S.Size = new System.Drawing.Size(71, 16);
            this.rdb_S.TabIndex = 10;
            this.rdb_S.Text = "S-Curver";
            this.rdb_S.UseVisualStyleBackColor = true;
            // 
            // btn_OK
            // 
            this.btn_OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btn_OK.Location = new System.Drawing.Point(66, 231);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_OK.TabIndex = 11;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cancel.Location = new System.Drawing.Point(248, 231);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 12;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            // 
            // FormGroupParamSet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(416, 287);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.rdb_S);
            this.Controls.Add(this.rdb_T);
            this.Controls.Add(this.txt_Dec);
            this.Controls.Add(this.txt_Acc);
            this.Controls.Add(this.txt_VelHigh);
            this.Controls.Add(this.txt_VelLow);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormGroupParamSet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GroupParamSet";
            this.Load += new System.EventHandler(this.FormGroupParamSet_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox txt_VelLow;
        public System.Windows.Forms.TextBox txt_VelHigh;
        public System.Windows.Forms.TextBox txt_Acc;
        public System.Windows.Forms.TextBox txt_Dec;
        public System.Windows.Forms.RadioButton rdb_T;
        public System.Windows.Forms.RadioButton rdb_S;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_Cancel;
    }
}