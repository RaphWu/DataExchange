﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Runtime.InteropServices; //For Marshal
using System.Threading;

using System.Diagnostics;
namespace Event
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            VersionIsOk = GetDevCfgDllDrvVer(); //Get Driver Version Number, this step is not necessary
        }
        Thread CheckEventThread;
        Thread CheckDevEventThread;
        Boolean VersionIsOk = false;
        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            if (VersionIsOk == false)
            {
                return;
            }
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot，Perhaps the opposite 
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, (uint)Result);
                return;
            }
            //If you want to get the device number of fixed equipment，you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
        }
       
    
        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }     

        private void buttonSet_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            UInt32 m_LatchBufEnable = 0;
            UInt32 PropertyVal=new UInt32();
            string strTemp;
            if(m_bInit)
            {
                if (checkBoxMotionRing.Checked)
                {
                    DevEnableEvt |= (uint)EventType.EVT_DEV_DISCONNET;
                }
                else
                {
                    DevEnableEvt &= ~(uint)EventType.EVT_DEV_DISCONNET;
                }
                if (checkBoxIORing.Checked)
                {
                    DevEnableEvt |= (uint)EventType.EVT_DEV_IO_DISCONNET;
                }
                else
                {
                    DevEnableEvt &= ~(uint)EventType.EVT_DEV_IO_DISCONNET;
                }
                if (CheckBoxAxisMotionDone.Checked)
                {
                    AxEnableEvtArray[CmbAxes.SelectedIndex] |= (uint)EventType.EVT_AX_MOTION_DONE;
                }
                else
                { AxEnableEvtArray[CmbAxes.SelectedIndex] &= ~(uint)EventType.EVT_AX_MOTION_DONE; }

                
                if (checkBoxVHStart.Checked)
                {
                    AxEnableEvtArray[CmbAxes.SelectedIndex] |=(uint) EventType.EVT_AX_VH_START;
                }
                else
                {
                    AxEnableEvtArray[CmbAxes.SelectedIndex] &= ~(uint)EventType.EVT_AX_VH_START;
                }

                if (checkBoxVHEnd.Checked)
                {
                    AxEnableEvtArray[CmbAxes.SelectedIndex] |= (uint)EventType.EVT_AX_VH_END;
                }
                else
                {
                    AxEnableEvtArray[CmbAxes.SelectedIndex] &= ~(uint)EventType.EVT_AX_VH_END;
                }
               
                
                if (checkBoxGpMotionDone.Checked)
                {
                    GpEnableEvt[0] |= (uint)EventType.EVT_GP1_MOTION_DONE << Convert.ToByte(textBoxGpID.Text);
                }
                else
                {
                    GpEnableEvt[0] &= ~(uint)EventType.EVT_GP1_MOTION_DONE << Convert.ToByte(textBoxGpID.Text);
                }

                if (checkBoxGpVHStart.Checked)
                {
                    GpEnableEvt[1] |= (uint)EventType.EVT_GP1_VH_START << Convert.ToByte(textBoxGpID.Text);
                }
                else
                {
                    GpEnableEvt[1] &= ~(uint)EventType.EVT_GP1_VH_START << Convert.ToByte(textBoxGpID.Text);
                }

                if(checkBoxGpVHEnd.Checked)
                {
                    GpEnableEvt[2] |= (uint)EventType.EVT_GP1_VH_END << Convert.ToByte(textBoxGpID.Text);
                }
                else
                {
                    GpEnableEvt[2] &= ~(uint)EventType.EVT_GP1_VH_END << Convert.ToByte(textBoxGpID.Text);
                }
                //Enable motion event
                Result = Motion.mAcm_EnableMotionEvent(m_DeviceHandle, AxEnableEvtArray, GpEnableEvt, m_ulAxisCount, 3);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "EnableMotionEvent Filed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                //Enable device enable event
                Result = Motion.mAcm_DevEnableEvent(m_DeviceHandle, DevEnableEvt);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "DevEnableEvent Filed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
        }

        private void BtnAddAxis_Click(object sender, EventArgs e)
        {
            uint Result;
            uint AxesInfoInGp = new uint();
            string strTemp,strTemp2;
            if (m_bInit != true)
            {
                return;
            }
            //Add an axis to the specified group
            Result = Motion.mAcm_GpAddAxis(ref m_GpHand, m_Axishand[comboBoxAddAxis.SelectedIndex]);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Add Axis To Group Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            else//add axis success
            {
                AxCountInGp++;
                //Get the GroupID through GroupHandle
                //You  can also use the old API Motion.mAcm_GetProperty(m_GpHand, (uint)PropertyID.PAR_GpGroupID, ref AxesInfoInGp,ref BufferLength)
                // UInt32  BufferLength;
                //BufferLength =4; buffer size for the property
                Result = Motion.mAcm_GetU32Property(m_GpHand, (uint)PropertyID.PAR_GpGroupID, ref AxesInfoInGp);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    textBoxGpID.Text = Convert.ToString(AxesInfoInGp, 10);
                }
                //Get information about which axis is (are) in this group
                //You  can also use the old API Motion.mAcm_GetProperty(m_GpHand, (uint)PropertyID.CFG_GpAxesInGroup, ref AxesInfoInGp,ref BufferLength)
                // UInt32  BufferLength;
                //BufferLength =4; buffer size for the property
                Result = Motion.mAcm_GetU32Property(m_GpHand, (uint)PropertyID.CFG_GpAxesInGroup, ref AxesInfoInGp);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    strTemp2 = "";
                    uint bit = 1;
                    for (int i = 0; i < m_ulAxisCount; ++i)
                    {  
                        if ((AxesInfoInGp & bit) == bit)
                            strTemp2 += i.ToString() + ".";
                        bit = bit << 1;
                    }
                    textBoxAxesInGp.Text = strTemp2;
                }
            }
        }

        private void buttonPTP_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            if (radioButtonRel.Checked)
            {
                //Start single axis's relative position motion
                Result = Motion.mAcm_AxMoveRel(m_Axishand[CmbAxes.SelectedIndex], 10000);
            }
            else
            {
                //Start single axis's absolute position motion.
                Result = Motion.mAcm_AxMoveAbs(m_Axishand[CmbAxes.SelectedIndex], 10000);
            }
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "PTP Move Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
        }

        private void buttonLine_Click(object sender, EventArgs e)
        {
            uint Result;
            double[] Distance ={ 10000, 10000 };
            uint Element = new uint();
            string strTemp;
            Element=2;
            if (radioButtonRel.Checked)
            {
                //Command group to execute relative line interpolation
                Result = Motion.mAcm_GpMoveLinearRel(m_GpHand, Distance, ref Element);
            }
            else
            {
                //Command group to execute absolute line interpolation
                Result = Motion.mAcm_GpMoveLinearAbs(m_GpHand, Distance, ref Element);
            }
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Line Move Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
        }
        private void CheckDevEvtThread()
        {
            uint result;
            while (m_bInit)
            {
                UInt32 DevEvtStatus = 0;
                //Check device enable event status
                //If you want to get event status of device, you should enable
                //these events by calling Motion.mAcm_DevEnableEvent
                result = Motion.mAcm_DevCheckEvent(m_DeviceHandle, ref DevEvtStatus, int.MaxValue);
                if (result == (uint)ErrorCode.SUCCESS)
                {
                    if ((DevEvtStatus & (uint)EventType. EVT_DEV_DISCONNET) > 0)
                    {
                        DevMotRingDisCnt++;
                    }
                    if ((DevEvtStatus & (uint)EventType.EVT_DEV_IO_DISCONNET) > 0)
                    {
                        DevIORingDisCnt++;
                    }
                }
            }	
        }
        private void CheckEvtThread()
        {
            uint Result;
            UInt32 i;
            while (m_bInit)
            {
                UInt32[] AxEvtStatusArray = new UInt32[64];
                UInt32[] GpEvtStatusArray = new UInt32[64];
                //Check axis and groups enabled motion event status
                //If you want to get event status of axis or groups, you should enable
                //these events by calling Motion.mAcm_EnableMotionEvent
                Result = Motion.mAcm_CheckMotionEvent(m_DeviceHandle, AxEvtStatusArray, GpEvtStatusArray, m_ulAxisCount, 3, 1000000);
                
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    for (i = 0; i < m_ulAxisCount; i++)
                    {

                        if ((AxEvtStatusArray[i] & (uint)EventType.EVT_AX_MOTION_DONE) > 0)
                        {
                            m_AxDoneEvtCnt[i]++;
                        }
                        if ((AxEvtStatusArray[i] & (uint)EventType.EVT_AX_VH_START) > 0)
                        {
                            m_AxVHStartCnt[i]++;
                        }
                        if ((AxEvtStatusArray[i] & (uint)EventType.EVT_AX_VH_END) >0)
                        {
                            m_AxVHEndCnt[i]++;
                        }
                       
                    }
                    if (m_GpHand != IntPtr.Zero)
                    {
                        if(textBoxGpID.Text!="")
                        {
                            if ((GpEvtStatusArray[0] & ((uint)EventType.EVT_GP1_MOTION_DONE << Convert.ToByte(textBoxGpID.Text))) > 0)
                            {
                                m_GpDoneEvtCnt++;
                            }
                            if ((GpEvtStatusArray[1] & ((uint)EventType.EVT_GP1_VH_START << Convert.ToByte(textBoxGpID.Text))) > 0)
                            {
                                m_GpVHStartCnt++;
                            }
                            if ((GpEvtStatusArray[2] & ((uint)EventType.EVT_GP1_VH_END << Convert.ToByte(textBoxGpID.Text))) > 0)
                            {
                                m_GpVHEndCnt++;
                            }
                        }
                    }                   
                }
            }	
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            double CurCmd = new double();
            UInt16 AxState=0;
            UInt16 GpState=0;
            uint IOStatus = new uint();
            uint Result;
            string strTemp = "";
            if (m_bInit)
            {
                //Get the motion I/O status of the axis.
                Result = Motion.mAcm_AxGetMotionIO(m_Axishand[CmbAxes.SelectedIndex], ref IOStatus);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    GetMotionIOStatus(IOStatus);
                }
                //Get current command position of the specified axis
                Motion.mAcm_AxGetCmdPosition(m_Axishand[CmbAxes.SelectedIndex], ref CurCmd);
                textBoxCmdPos.Text = Convert.ToString(CurCmd);
                textBoxAxDoneCnt.Text = Convert.ToString(m_AxDoneEvtCnt[CmbAxes.SelectedIndex]);
                textBoxMotionDisCnt.Text = Convert.ToString(DevMotRingDisCnt);
                textBoxIODisCnt.Text = Convert.ToString(DevIORingDisCnt);
                textBoxVHStartCnt.Text = Convert.ToString(m_AxVHStartCnt[CmbAxes.SelectedIndex]);
                textBoxVHEndCnt.Text = Convert.ToString(m_AxVHEndCnt[CmbAxes.SelectedIndex]);
                //Get the axis's current state.
                Motion.mAcm_AxGetState(m_Axishand[CmbAxes.SelectedIndex], ref AxState);
                textBoxAxState.Text = ((AxisState)AxState).ToString();
                if (m_GpHand != IntPtr.Zero)
                {
                    //Get the group's current state
                    Motion.mAcm_GpGetState(m_GpHand, ref GpState);
                    textBoxGpState.Text = ((GroupState)GpState).ToString();
                    textBoxGpDoneCnt.Text = Convert.ToString(m_GpDoneEvtCnt);
                    textBoxGpVHStartCnt.Text = Convert.ToString(m_GpVHStartCnt);
                    textBoxGpVHEndCnt.Text = Convert.ToString(m_GpVHEndCnt);
                }
                else
                {
                    textBoxGpID.Text = "";
                    textBoxAxesInGp.Text = "";
                    textBoxGpDoneCnt.Text = "";
                    textBoxGpState.Text = "";
                }
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            CloseBoardOrForm();
        }
        private void GetMotionIOStatus(uint IOStatus)
        {
            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ALM) > 0)//ALM
            {
                pictureBoxALM.BackColor = Color.Red;
            }
            else
            {
                pictureBoxALM.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ORG) > 0)//ORG
            {
                pictureBoxORG.BackColor = Color.Red;
            }
            else
            {
                pictureBoxORG.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTP) > 0)//+EL
            {
                pictureBoxPosHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxPosHEL.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTN) > 0)//-EL
            {
                pictureBoxNegHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxNegHEL.BackColor = Color.Gray;
            }
        }
        private void BtnAxReset_Click(object sender, EventArgs e)
        {
            double cmdPosition = new double();
            cmdPosition = 0;
            for (UInt32 i = 0; i < m_ulAxisCount; i++)
            {
                m_AxDoneEvtCnt[i] = 0;
                m_AxCmpEvtCnt[i] = 0;
                m_AxVHStartCnt[i] = 0;
                m_AxVHEndCnt[i] = 0;
                m_AxLatchBufCnt[i] = 0;
            }                   
            if (m_bInit == true)
            {
                //Set command position for the specified axis
                Motion.mAcm_AxSetCmdPosition(m_Axishand[CmbAxes.SelectedIndex], cmdPosition);
            
            }
        }

        private void BtnGpReset_Click(object sender, EventArgs e)
        {
            m_GpDoneEvtCnt=0;
            m_GpVHStartCnt=0;
            m_GpVHEndCnt = 0;
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            uint Result;
            int i = 0;
			uint retry = 0, SlaveOnRing0 = 0, SlaveOnRing1 = 0;
            bool rescan = false;
            uint[] slaveDevs = new uint[16];
            uint AxesPerDev = new uint();
            string strTemp;
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            do
            {
                Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Device Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    retry++;
                    rescan = true;
                    if (retry > 10)
                        return;
                    System.Threading.Thread.Sleep(1000);
                }
                else
                {
					//User must check the slave count on each ring match the actual connection.
					//We recommend using following code that was marked to check connection status.
					//The example expect there is one slave on Motion ring and user does not connect any slave on IO ring.
					rescan = false;
					/*Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R0, ref SlaveOnRing0);
					Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R1, ref SlaveOnRing1);
					if (SlaveOnRing0 != 1 || SlaveOnRing1 != 0)
					{
						strTemp = "Retrieved the slave states do not match the actual connection.";
						ShowMessages(strTemp, Result);
						Motion.mAcm_DevReOpen(m_DeviceHandle);
						Motion.mAcm_DevClose(ref m_DeviceHandle);
						System.Threading.Thread.Sleep(1000);
						retry = 0;
						rescan = true;
					}*/
                }
            } while (rescan == true);
            //FT_DevAxesCount:Get axis number of this device.
            //if you device is fixed(for example: PCI-1245),You can not get FT_DevAxesCount property value
            //This step is not necessary
            //You can also use the old API: Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev, ref BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get Axis Number Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            m_ulAxisCount = AxesPerDev;
            CmbAxes.Items.Clear();
            comboBoxAddAxis.Items.Clear();
            //if you device is fixed,for example: PCI-1245 m_ulAxisCount =4
            for (i = 0; i < m_ulAxisCount; i++)
            {
                //Open every Axis and get the each Axis Handle
                //And Initial property for each Axis 		
                // Open Axis. The second parameter is the position of this axis.
                // The first axis is 0, the second one is 1 and so on.
                Result = Motion.mAcm_AxOpen(m_DeviceHandle, (UInt16)i, ref m_Axishand[i]);
                // Another way to open axis is "Motion.mAcm_AxOpenbyID" . 
                // The second parameter of mAcm_AxOpenbyID is the EtherCAT Slave ID
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Axis Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                CmbAxes.Items.Add(String.Format("{0:d}-Axis", i));
                comboBoxAddAxis.Items.Add(String.Format("{0:d}-Axis", i));
                double cmdPosition = new double();
                cmdPosition = 0;
                //Set command position for the specified axis
                Motion.mAcm_AxSetCmdPosition(m_Axishand[i], cmdPosition);
            }
            CmbAxes.SelectedIndex = 0;
            comboBoxAddAxis.SelectedIndex = 0;
            m_bInit = true;
            //User should create a new thread to check event status,for example:CheckEvtThread() function.
            CheckEventThread = new Thread(new ThreadStart(CheckEvtThread));
            CheckDevEventThread = new Thread(new ThreadStart(CheckDevEvtThread));
            CheckEventThread.Start();
            CheckDevEventThread.Start();
            timer1.Enabled = true;
        }

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();
        }
        //User-defined API to show error message
        private void ShowMessages(string DetailMessage, uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            //Get the error message according to error code returned from API
            Boolean res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
            string ErrorMessage = "";
            if (res)
                ErrorMessage = ErrorMsg.ToString();
            MessageBox.Show(DetailMessage + "\r\nError Message:" + ErrorMessage, "Event", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        //User-defined API to close board
        private void CloseBoardOrForm()
        {
            UInt16[] usAxisState = new UInt16[64];
            uint AxisNum;
            //Stop Every Axes
            if (m_bInit == true)
            {
                CheckEventThread.Abort();      //Abort thread
                CheckDevEventThread.Abort();
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Get the axis's current state.
                    Motion.mAcm_AxGetState(m_Axishand[AxisNum], ref usAxisState[AxisNum]);
                    if (usAxisState[AxisNum] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        // Reset the axis' state. If the axis is in ErrorStop state, the state will
                        //be changed to Ready after calling this function.
                        Motion.mAcm_AxResetError(m_Axishand[AxisNum]);
                    }
                    // To command axis to decelerate to stop.
                    Motion.mAcm_AxStopDec(m_Axishand[AxisNum]);
                }
                //Remove all axis in the group and close the group handle
                Motion.mAcm_GpClose(ref m_GpHand);
                m_GpHand = IntPtr.Zero;
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Close Axes
                    Motion.mAcm_AxClose(ref m_Axishand[AxisNum]);
                }
                m_ulAxisCount = 0;
                AxCountInGp = 0;
                //Close Device
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                m_DeviceHandle = IntPtr.Zero;
                timer1.Enabled = false;
                m_bInit = false;
                CmbAxes.Items.Clear();
                CmbAxes.Text = "";
                comboBoxAddAxis.Items.Clear();
                comboBoxAddAxis.Text = "";
                textBoxAxDoneCnt.Clear();
              
                textBoxVHStartCnt.Clear();
                textBoxVHEndCnt.Clear();
                textBoxCmdPos.Clear();
                textBoxAxState.Clear();
                textBoxGpID.Clear();
                textBoxAxesInGp.Clear();
                textBoxGpDoneCnt.Clear();
                textBoxGpVHStartCnt.Clear();
                textBoxGpVHEndCnt.Clear();
                textBoxGpState.Clear();
                CheckBoxAxisMotionDone.Checked = false;
                checkBoxVHStart.Checked = false;
                checkBoxVHEnd.Checked = false;
                checkBoxGpMotionDone.Checked = false;
                checkBoxGpVHEnd.Checked = false;
                checkBoxGpVHStart.Checked = false;
               
            }
        }

        private void BtnServo_Click(object sender, EventArgs e)
        {
            UInt32 AxisNum;
            UInt32 Result;
            string strTemp;
            //Check the servoOno flag to decide if turn on or turn off the ServoOn output.
            if (m_bInit != true)
            {
                return;
            }
            if (m_bServoOn == false)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver ON,1: On
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 1);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo On Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = true;
                    BtnServo.Text = "Servo Off";
                }
            }
            else
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver OFF,0: Off
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 0);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo Off Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = false;
                    BtnServo.Text = "Servo On";
                }
            }

        }
        //get the device number of fixed equipment
        private UInt32 GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID)
        {
            return (UInt32)(DevType << 24 | BoardID << 12 | MasterRingNo << 8 | SlaveBoardID);
        }
        private void BtnLoadCfg_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            this.openFileDialog.FileName = ".cfg";
            if (openFileDialog.ShowDialog() != DialogResult.OK)
                return;
            //Set all configurations for the device according to the loaded file
            Result = Motion.mAcm_DevLoadConfig(m_DeviceHandle, openFileDialog.FileName);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Load Config Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }		 
        }
        private Boolean GetDevCfgDllDrvVer()
        {
            string fileName = "";
            FileVersionInfo myFileVersionInfo;
            string FileVersion = "";
            fileName = Environment.SystemDirectory + "\\ADVMOT.dll";//SystemDirectory指System32 
            myFileVersionInfo = FileVersionInfo.GetVersionInfo(fileName);
            FileVersion = myFileVersionInfo.FileVersion;
            string DetailMessage;
            string[] strSplit = FileVersion.Split(',');
            if (Convert.ToUInt16(strSplit[0]) < 2)
            {
                
                DetailMessage = "The Driver Version  Is Too Low" + "\r\nYou can update the driver through the driver installation package ";
                DetailMessage = DetailMessage + "\r\nThe Current Driver Version Number is " + FileVersion;
                DetailMessage = DetailMessage + "\r\nYou need to update the driver to 2.0.0.0 version and above";
                MessageBox.Show(DetailMessage, "Event", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
                    
            }
            return true;
        }

        private void CmbAvailableDevice_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

     

        private void btn_AxStop_Click(object sender, EventArgs e)
        {
           
            UInt32 Result;
            string strTemp;
            
            //To command axis to decelerate to stop.
            Result = Motion.mAcm_AxStopEmg(m_Axishand[CmbAxes.SelectedIndex]);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Axis To decelerate Stop Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }

        private void btn_ResetError_Click(object sender, EventArgs e)
        {
            uint Result;
            UInt16 State = new UInt16();
            string strTemp;
            if (m_bInit == true)
            {
                
                //Get the group's current state
                Motion.mAcm_AxGetState(m_Axishand[CmbAxes.SelectedIndex], ref State);
                if (State == (UInt16)AxisState.STA_AX_ERROR_STOP)
                {
                    //Reset axis states
                    Result = Motion.mAcm_AxResetError(m_Axishand[CmbAxes.SelectedIndex]);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Reset axis's error failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
            }
        }

        private void btn_GpResetError_Click(object sender, EventArgs e)
        {
            uint Result;
            UInt16 State = new UInt16();
            string strTemp;
            if (m_bInit == true)
            {
                //Get the group's current state
                Motion.mAcm_GpGetState(m_GpHand, ref State);
                if (State == (UInt16)GroupState.STA_Gp_ErrorStop)
                {
                    //Reset group states
                    Result = Motion.mAcm_GpResetError(m_GpHand);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Reset group's error failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
            }
        }

        private void btn_GpStop_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;

            //To group to decelerate to stop.
            Result = Motion.mAcm_GpStopEmg(m_GpHand);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Gp To decelerate Stop Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }

        private void BtnDevReset_Click(object sender, EventArgs e)
        {
            DevMotRingDisCnt = 0;
            DevIORingDisCnt = 0;
        }
    }
}