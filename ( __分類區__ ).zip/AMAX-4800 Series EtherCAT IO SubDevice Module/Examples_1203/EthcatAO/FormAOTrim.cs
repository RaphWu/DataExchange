﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API

namespace EthcatAO
{
    public partial class FormAOTrim : Form
    {
        public FormAOTrim()
        {
            InitializeComponent();
        }

        private uint ChannelNo=0;
        private uint TrimType = 0;
        private short TotalCaliValue = 0;
        private bool bSetTypeSucceed = true;

        public FormAOTrim(uint m_ChannelNo,uint m_TrimType)
        {
            InitializeComponent();

            ChannelNo = m_ChannelNo;
            TrimType=m_TrimType;
            string strTrimType="";
            strTrimType=" Trim for 4mA";
            this.Text = "Channel " + m_ChannelNo.ToString() + strTrimType;        
            uint Ret = 0;
            string ErrorMessage = "";
            Ret = Motion.mAcm_DaqAoSetCaliType(GlobalVar.m_DeviceHandle, (ushort)ChannelNo, (ushort)TrimType);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                bSetTypeSucceed = false;
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + ChannelNo.ToString() + " Set calibration type failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
        }

        private void bt_minus10_Click(object sender, EventArgs e)
        {
            short CaliValue = 0;
            if (((Button)sender).Name.Equals("bt_minus10"))
            {
                CaliValue = -10;
                TotalCaliValue -= 10;
            }
            else if (((Button)sender).Name.Equals("bt_minus1"))
            {
                CaliValue = -1;
                TotalCaliValue -= 1;
            }
            else if (((Button)sender).Name.Equals("bt_plus1"))
            {
                CaliValue = 1;
                TotalCaliValue += 1;
            }
            else if (((Button)sender).Name.Equals("bt_plus10"))
            {
                CaliValue = 10;
                TotalCaliValue += 10;
            }

            if (TotalCaliValue < -85)
                bt_minus10.Enabled = false;
            else if (TotalCaliValue < -95)
            {
                bt_minus1.Enabled = false;
                TotalCaliValue = -95;
            }
            else if (TotalCaliValue > 85)
                bt_plus10.Enabled = false;
            else if (TotalCaliValue > 95)
            {
                bt_plus1.Enabled = false;
                TotalCaliValue = 95;
            }
            else
            {
                bt_minus10.Enabled = true;
                bt_minus1.Enabled = true;
                bt_plus1.Enabled = true;
                bt_plus10.Enabled = true;
            }

            uint Ret = 0;
            string ErrorMessage = "";
            Ret = Motion.mAcm_DaqAoSetCaliValue(GlobalVar.m_DeviceHandle, (ushort)ChannelNo, (ushort)CaliValue);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + ChannelNo.ToString() + " Set calibration value failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
        }

        private void bt_Apply_Click(object sender, EventArgs e)
        {
            uint Ret = 0;
            string ErrorMessage = "";
            Ret = Motion.mAcm_DaqAoCaliDone(GlobalVar.m_DeviceHandle, (ushort)ChannelNo);           
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + ChannelNo.ToString() + " 's calibration failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
			this.Close();
        }

        private void FormAOTrim_Shown(object sender, EventArgs e)
        {
            if(!bSetTypeSucceed)
            {
                this.Close();
            }
        }

        private void FormAOTrim_Load(object sender, EventArgs e)
        {

        }
    }
}