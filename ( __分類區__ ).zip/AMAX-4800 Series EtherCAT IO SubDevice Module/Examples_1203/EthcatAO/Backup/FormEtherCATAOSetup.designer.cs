﻿namespace EthcatAO
{
    partial class FormEtherCATAOSetup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEtherCATAOSetup));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_Apply = new System.Windows.Forms.Button();
            this.cmb_OutputRange = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmb_ChanIndex = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gp_SetOutValue = new System.Windows.Forms.GroupBox();
            this.lbl_Unit = new System.Windows.Forms.Label();
            this.btn_ApplyOutput = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txb_CurValue = new System.Windows.Forms.TextBox();
            this.txb_Value = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_EndValue = new System.Windows.Forms.Label();
            this.lbl_StartValue = new System.Windows.Forms.Label();
            this.tb_Output = new System.Windows.Forms.TrackBar();
            this.label5 = new System.Windows.Forms.Label();
            this.cmb_OutputEnable = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.gp_SetOutValue.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tb_Output)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmb_OutputEnable);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btn_Apply);
            this.groupBox1.Controls.Add(this.cmb_OutputRange);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cmb_ChanIndex);
            this.groupBox1.Controls.Add(this.label1);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // btn_Apply
            // 
            resources.ApplyResources(this.btn_Apply, "btn_Apply");
            this.btn_Apply.Name = "btn_Apply";
            this.btn_Apply.UseVisualStyleBackColor = true;
            this.btn_Apply.Click += new System.EventHandler(this.btn_Apply_Click);
            // 
            // cmb_OutputRange
            // 
            this.cmb_OutputRange.FormattingEnabled = true;
            resources.ApplyResources(this.cmb_OutputRange, "cmb_OutputRange");
            this.cmb_OutputRange.Name = "cmb_OutputRange";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // cmb_ChanIndex
            // 
            this.cmb_ChanIndex.FormattingEnabled = true;
            resources.ApplyResources(this.cmb_ChanIndex, "cmb_ChanIndex");
            this.cmb_ChanIndex.Name = "cmb_ChanIndex";
            this.cmb_ChanIndex.SelectedIndexChanged += new System.EventHandler(this.cmb_OutputRange_SelectedIndexChanged);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // gp_SetOutValue
            // 
            this.gp_SetOutValue.Controls.Add(this.lbl_Unit);
            this.gp_SetOutValue.Controls.Add(this.btn_ApplyOutput);
            this.gp_SetOutValue.Controls.Add(this.label4);
            this.gp_SetOutValue.Controls.Add(this.txb_CurValue);
            this.gp_SetOutValue.Controls.Add(this.txb_Value);
            this.gp_SetOutValue.Controls.Add(this.label3);
            this.gp_SetOutValue.Controls.Add(this.lbl_EndValue);
            this.gp_SetOutValue.Controls.Add(this.lbl_StartValue);
            this.gp_SetOutValue.Controls.Add(this.tb_Output);
            resources.ApplyResources(this.gp_SetOutValue, "gp_SetOutValue");
            this.gp_SetOutValue.Name = "gp_SetOutValue";
            this.gp_SetOutValue.TabStop = false;
            // 
            // lbl_Unit
            // 
            resources.ApplyResources(this.lbl_Unit, "lbl_Unit");
            this.lbl_Unit.Name = "lbl_Unit";
            // 
            // btn_ApplyOutput
            // 
            resources.ApplyResources(this.btn_ApplyOutput, "btn_ApplyOutput");
            this.btn_ApplyOutput.Name = "btn_ApplyOutput";
            this.btn_ApplyOutput.UseVisualStyleBackColor = true;
            this.btn_ApplyOutput.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // txb_CurValue
            // 
            resources.ApplyResources(this.txb_CurValue, "txb_CurValue");
            this.txb_CurValue.Name = "txb_CurValue";
            this.txb_CurValue.ReadOnly = true;
            // 
            // txb_Value
            // 
            resources.ApplyResources(this.txb_Value, "txb_Value");
            this.txb_Value.Name = "txb_Value";
            this.txb_Value.ReadOnly = true;
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // lbl_EndValue
            // 
            resources.ApplyResources(this.lbl_EndValue, "lbl_EndValue");
            this.lbl_EndValue.Name = "lbl_EndValue";
            // 
            // lbl_StartValue
            // 
            resources.ApplyResources(this.lbl_StartValue, "lbl_StartValue");
            this.lbl_StartValue.Name = "lbl_StartValue";
            // 
            // tb_Output
            // 
            resources.ApplyResources(this.tb_Output, "tb_Output");
            this.tb_Output.Name = "tb_Output";
            this.tb_Output.Scroll += new System.EventHandler(this.tb_Output_Scroll);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // cmb_OutputEnable
            // 
            this.cmb_OutputEnable.FormattingEnabled = true;
            this.cmb_OutputEnable.Items.AddRange(new object[] {
            resources.GetString("cmb_OutputEnable.Items"),
            resources.GetString("cmb_OutputEnable.Items1"),
            resources.GetString("cmb_OutputEnable.Items2")});
            resources.ApplyResources(this.cmb_OutputEnable, "cmb_OutputEnable");
            this.cmb_OutputEnable.Name = "cmb_OutputEnable";
            // 
            // FormEtherCATAOSetup
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gp_SetOutValue);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormEtherCATAOSetup";
            this.Load += new System.EventHandler(this.FormAnalogOutputSetup_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gp_SetOutValue.ResumeLayout(false);
            this.gp_SetOutValue.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tb_Output)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_Apply;
        private System.Windows.Forms.ComboBox cmb_OutputRange;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmb_ChanIndex;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gp_SetOutValue;
        private System.Windows.Forms.Label lbl_StartValue;
        private System.Windows.Forms.TrackBar tb_Output;
        private System.Windows.Forms.TextBox txb_Value;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_EndValue;
        private System.Windows.Forms.TextBox txb_CurValue;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_ApplyOutput;
        private System.Windows.Forms.Label lbl_Unit;
        private System.Windows.Forms.ComboBox cmb_OutputEnable;
        private System.Windows.Forms.Label label5;
    }
}