﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;

namespace EthcatAO
{
    public partial class FormEtherCATAOSetup : Form
    {
        public FormEtherCATAOSetup()
        {
            InitializeComponent();
        }

        private uint AONumber = 128;
        private FormAO formAO = null;
        public FormEtherCATAOSetup(FormAO m_formAO, uint m_AONumber)
        {
            InitializeComponent();
            AONumber = m_AONumber;
            formAO = m_formAO;
        }

        private void FormAnalogOutputSetup_Load(object sender, EventArgs e)
        {
			uint m_AoOutRange = 0;
			
            cmb_ChanIndex.Items.Clear();
            cmb_OutputEnable.Items.Clear();
            cmb_OutputRange.Items.Clear();

            for (uint i = 0; i < AONumber; i++)
            {
                cmb_ChanIndex.Items.Add(i.ToString());
            }
            uint Result = Motion.mAcm_GetU32Property(GlobalVar.m_DeviceHandle ,(uint)PropertyID.FT_DaqAoRangeMap, ref m_AoOutRange);
          
            if (((uint)AoRangeMap.AO_NEG_10V_TO_10V & m_AoOutRange) > 0)
            {
                cmb_OutputRange.Items.Add("+/-10V");
            }
            if (((uint)AoRangeMap.AO_NEG_5V_TO_5V & m_AoOutRange) > 0)
            {
                cmb_OutputRange.Items.Add("+/-5V");
            }
            if (((uint)AoRangeMap.AO_NEG_2500MV_TO_2500MV & m_AoOutRange) > 0)
            {
                cmb_OutputRange.Items.Add("+/-2.5V");
            }
            if (((uint)AoRangeMap.AO_NEG_1250MV_TO_1250MV & m_AoOutRange) > 0)
            {
                cmb_OutputRange.Items.Add("+/-1.25V");
            }
            if (((uint)AoRangeMap.AO_NEG_625MV_TO_625MV & m_AoOutRange) > 0)
            {
                cmb_OutputRange.Items.Add("+/-625mV");
            }
            if (((uint)AoRangeMap.AO_NEG_0V_TO_10V & m_AoOutRange) > 0)
            {
                cmb_OutputRange.Items.Add("0~10V");
            }
            if (((uint)AoRangeMap.AO_0MA_TO_20MA & m_AoOutRange) > 0)
            {
                cmb_OutputRange.Items.Add("0~20mA");
            }
            if (((uint)AoRangeMap.AO_4MA_TO_20MA & m_AoOutRange) > 0)
            {
                cmb_OutputRange.Items.Add("4~20mA");
            }

            if (AONumber > 0)
                cmb_ChanIndex.SelectedIndex = 0;

            //gp_SetOutValue.Enabled = false;
            cmb_OutputRange_SelectedIndexChanged(null, null);

            double m_AoEnable = 0;
            Result = Motion.mAcm_GetChannelProperty(GlobalVar.m_DeviceHandle, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqAoEnable, ref m_AoEnable);
            if (Result == (uint)ErrorCode.SUCCESS)
            {
                cmb_OutputEnable.Items.Add("DISABLE");
                cmb_OutputEnable.Items.Add("ENABLE");
                cmb_OutputEnable.SelectedIndex = (int)m_AoEnable;
            }
            else
            {
                cmb_OutputEnable.Items.Add("NOT_SUPPORT");
                cmb_OutputEnable.SelectedIndex = 0;
            }
        }

        private void btn_Apply_Click(object sender, EventArgs e)
        {
            uint Ret = 0;
            double m_AoRange = 0;
            string ErrorMessage = "";

            double StartValue = 0;
            double EndValue = 0;
            bool isMV = false;

            switch (cmb_OutputEnable.Text)
            {
                case "DISABLE":
                case "ENABLE":
                    Ret = Motion.mAcm_SetChannelProperty(GlobalVar.m_DeviceHandle, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqAoEnable, (double)cmb_OutputEnable.SelectedIndex);
                    if (Ret != (uint)ErrorCode.SUCCESS)
                    {
                        ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                        MessageBox.Show("Channel " + cmb_ChanIndex.SelectedIndex.ToString() + " Set AoEnable Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                        return;
                    }
                    break;
            }
            switch (cmb_OutputRange.Text)
            {
                case "+/-10V":
                    m_AoRange = (uint)AoRange.AO_NEG_10V_TO_10V;
                    StartValue = -10;
                    EndValue = 10;
                    break;
                case "+/-5V":
                    m_AoRange = (uint)AoRange.AO_NEG_5V_TO_5V;
                    StartValue = -5;
                    EndValue = 5;
                    break;
                case "+/-2.5V":
                    m_AoRange = (uint)AoRange.AO_NEG_2500MV_TO_2500MV;
                    StartValue = -2.5;
                    EndValue = 2.5;
                    break;
                case "+/-1.25V":
                    m_AoRange = (uint)AoRange.AO_NEG_1250MV_TO_1250MV;
                    StartValue = -1.25;
                    EndValue = 1.25;
                    break;
                case "+/-625mV":
                    m_AoRange = (uint)AoRange.AO_NEG_625MV_TO_625MV;
                    StartValue = -625;
                    EndValue = 625;
                    isMV = true;
                    break;
                case "0~10V":
                    m_AoRange = (uint)AoRange.AO_NEG_0V_TO_10V;
                    StartValue = 0;
                    EndValue = 10;
                    break;
                case "0~20mA":
                    m_AoRange = (uint)AoRange.AO_0MA_TO_20MA;
                    StartValue = 0;
                    EndValue = 20;
                    break;
                case "4~20mA":
                    m_AoRange = (uint)AoRange.AO_4MA_TO_20MA;
                    StartValue = 4;
                    EndValue = 20;
                    break;
                default:
                    m_AoRange = (uint)AoRange.AO_NEG_10V_TO_10V;
                    StartValue = -10;
                    EndValue = 10;
                    break;
            }
            //Set CFG_CH_DaqAoRange
            Ret = Motion.mAcm_SetChannelProperty(GlobalVar.m_DeviceHandle, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqAoRange, m_AoRange);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + cmb_ChanIndex.SelectedIndex.ToString() + " Set AoRange Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
            
            
            formAO.RefreshAOSetup(false);

            tb_Output.SetRange((int)StartValue*1000, (int)EndValue*1000);
            float m_AoValue = 0;
            if (m_AoRange > 15)
            {
                lbl_StartValue.Text = StartValue.ToString() + " mA";
                lbl_EndValue.Text = EndValue.ToString() + " mA";
                lbl_Unit.Text = "mA";
                //Get the current output value of a specified analog output channel
                Ret = Motion.mAcm_DaqAoGetCurrData(GlobalVar.m_DeviceHandle, (ushort)cmb_ChanIndex.SelectedIndex, ref m_AoValue);
            }
            else
            {
                if (isMV)
                {
                    lbl_StartValue.Text = StartValue.ToString() + " mV";
                    lbl_EndValue.Text = EndValue.ToString() + " mV";
                    lbl_Unit.Text = "mV";
                }
                else
                {
                    lbl_StartValue.Text = StartValue.ToString() + " V";
                    lbl_EndValue.Text = EndValue.ToString() + " V";
                    lbl_Unit.Text = "V";
                }
                //Get the current output value of a specified analog output channel
                Ret = Motion.mAcm_DaqAoGetVoltData(GlobalVar.m_DeviceHandle, (ushort)cmb_ChanIndex.SelectedIndex, ref m_AoValue);
                
            }
            tb_Output.Value = (int)(m_AoValue * 1000);
            float tmpOutValue = ((float)tb_Output.Value) / 1000;
            txb_Value.Text = tmpOutValue.ToString();
            if (Ret == (uint)ErrorCode.SUCCESS)
            {
                txb_CurValue.Text = m_AoValue.ToString("0.000");
            }
            else
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + 0.ToString() + " Get Data failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
            gp_SetOutValue.Enabled = true;
        }

       

        private void cmb_OutputRange_SelectedIndexChanged(object sender, EventArgs e)
        {
            uint Ret = 0;
            double m_AoRange = 0;
            string ErrorMessage = "";

            Ret = Motion.mAcm_GetChannelProperty(GlobalVar.m_DeviceHandle, (uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqAoRange, ref m_AoRange);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + 0.ToString() + " Get AoRange Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }

            double StartValue = 0;
            double EndValue = 0;
            bool isMV = false;
            switch ((uint)m_AoRange)
            {
                case (uint)AoRange.AO_NEG_10V_TO_10V:
                    cmb_OutputRange.Text = "+/-10V";
                    StartValue = -10;
                    EndValue = 10;
                    break;
                case (uint)AoRange.AO_NEG_5V_TO_5V:
                    cmb_OutputRange.Text = "+/-5V";
                    StartValue = -5;
                    EndValue = 5;
                    break;
                case (uint)AoRange.AO_NEG_2500MV_TO_2500MV:
                    cmb_OutputRange.Text = "+/-2.5V";
                    StartValue = -2.5;
                    EndValue = 2.5;
                    break;
                case (uint)AoRange.AO_NEG_1250MV_TO_1250MV:
                    cmb_OutputRange.Text = "+/-1.25V";
                    StartValue = -1.25;
                    EndValue = 1.25;
                    break;
                case (uint)AoRange.AO_NEG_625MV_TO_625MV:
                    cmb_OutputRange.Text = "+/-625mV";
                    StartValue = -625;
                    EndValue = 625;
                    isMV = true;
                    break;
                case (uint)AoRange.AO_NEG_0V_TO_10V:
                    cmb_OutputRange.Text = "0~10V";
                    StartValue = 0;
                    EndValue = 10;
                    break;
                case (uint)AoRange.AO_0MA_TO_20MA:
                    cmb_OutputRange.Text = "0~20mA";
                    StartValue = 0;
                    EndValue = 20;
                    break;
                case (uint)AoRange.AO_4MA_TO_20MA:
                    cmb_OutputRange.Text = "4~20mA";
                    StartValue = 4;
                    EndValue = 20;
                    break;
                default:
                    cmb_OutputRange.Text = "";
                    StartValue = -10;
                    EndValue = 10;
                    break;
            }
            tb_Output.SetRange((int)StartValue*1000, (int)EndValue*1000);

            float m_AoValue = 0;
            if (m_AoRange > 15)
            {
                lbl_StartValue.Text = StartValue.ToString() + " mA";
                lbl_EndValue.Text = EndValue.ToString() + " mA";
                lbl_Unit.Text = "mA";
                Ret = Motion.mAcm_DaqAoGetCurrData(GlobalVar.m_DeviceHandle, (ushort)cmb_ChanIndex.SelectedIndex, ref m_AoValue);
          
            }
            else
            {
                if (isMV)
                {
                    lbl_StartValue.Text = StartValue.ToString() + " mV";
                    lbl_EndValue.Text = EndValue.ToString() + " mV";
                    lbl_Unit.Text = "mV";
                }
                else
                {
                    lbl_StartValue.Text = StartValue.ToString() + " V";
                    lbl_EndValue.Text = EndValue.ToString() + " V";
                    lbl_Unit.Text = "V";
                }
                Ret = Motion.mAcm_DaqAoGetVoltData(GlobalVar.m_DeviceHandle, (ushort)cmb_ChanIndex.SelectedIndex, ref m_AoValue);
              
            }
            float tmpOutValue = ((float)tb_Output.Value) / 1000;
            txb_Value.Text = tmpOutValue.ToString();
            if (Ret == (uint)ErrorCode.SUCCESS)
            {
                txb_CurValue.Text = m_AoValue.ToString("0.000");
            }
            else
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + cmb_ChanIndex.SelectedIndex.ToString() + " Get Data failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
            //gp_SetOutValue.Enabled = false;
        }

        private void tb_Output_Scroll(object sender, EventArgs e)
        {
            float tmpOutValue = ((float)tb_Output.Value) / 1000;
            txb_Value.Text = tmpOutValue.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            uint Ret = 0;
            float m_AoValue = 0;
            double m_AoRange = 0;
            string ErrorMessage = "";
            
            m_AoValue = (float)Convert.ToDouble(txb_Value.Text);

            
            //Get the current output value of a specified analog output channel
            Ret = Motion.mAcm_GetChannelProperty(GlobalVar.m_DeviceHandle,(uint)cmb_ChanIndex.SelectedIndex, (uint)PropertyID.CFG_CH_DaqAoRange, ref m_AoRange);
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + 0.ToString() + " Get AoRange Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
            if (m_AoRange > 15)
            {
                //Set the current output value of a specified analog output channel within the analog current output range.
                Ret = Motion.mAcm_DaqAoSetCurrData(GlobalVar.m_DeviceHandle, (ushort)cmb_ChanIndex.SelectedIndex, m_AoValue);
            
            }
            else
            {
                //Set the current output value of a specified analog output channel within the analog current output range.
                Ret = Motion.mAcm_DaqAoSetVoltData(GlobalVar.m_DeviceHandle, (ushort)cmb_ChanIndex.SelectedIndex, m_AoValue);
               
            }
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + cmb_ChanIndex.SelectedIndex.ToString() + " Set Data failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
            

            if (m_AoRange > 15)
            {
                Ret = Motion.mAcm_DaqAoGetCurrData(GlobalVar.m_DeviceHandle, (ushort)cmb_ChanIndex.SelectedIndex, ref m_AoValue);
            }
            else
            {
                Ret = Motion.mAcm_DaqAoGetVoltData(GlobalVar.m_DeviceHandle, (ushort)cmb_ChanIndex.SelectedIndex, ref m_AoValue);
               
            }
            if (Ret != (uint)ErrorCode.SUCCESS)
            {
                ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                MessageBox.Show("Channel " + cmb_ChanIndex.SelectedIndex.ToString() + " Get Data failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                return;
            }
            txb_CurValue.Text = m_AoValue.ToString("0.000");
        }

       
    }
}