﻿using Advantech.Motion;
using System;
namespace EthcatAO
{
    partial class FormAO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btn_OpenBoard = new System.Windows.Forms.Button();
            this.btn_CloseBoard = new System.Windows.Forms.Button();
            this.btn_AOSetup = new System.Windows.Forms.Button();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.lv_AOValue = new EthcatAO.ListViewNF();
            this.col_Channel = new System.Windows.Forms.ColumnHeader();
            this.col_Value = new System.Windows.Forms.ColumnHeader();
            this.col_Raw = new System.Windows.Forms.ColumnHeader();
            this.col_OutputRange = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(181, 17);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(169, 20);
            this.CmbAvailableDevice.TabIndex = 20;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(74, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 19;
            this.label1.Text = "Available device:";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btn_OpenBoard
            // 
            this.btn_OpenBoard.Location = new System.Drawing.Point(84, 47);
            this.btn_OpenBoard.Name = "btn_OpenBoard";
            this.btn_OpenBoard.Size = new System.Drawing.Size(97, 26);
            this.btn_OpenBoard.TabIndex = 22;
            this.btn_OpenBoard.Text = "Open Board";
            this.btn_OpenBoard.UseVisualStyleBackColor = true;
            this.btn_OpenBoard.Click += new System.EventHandler(this.btn_OpenBrd_Click);
            // 
            // btn_CloseBoard
            // 
            this.btn_CloseBoard.Location = new System.Drawing.Point(253, 43);
            this.btn_CloseBoard.Name = "btn_CloseBoard";
            this.btn_CloseBoard.Size = new System.Drawing.Size(97, 26);
            this.btn_CloseBoard.TabIndex = 22;
            this.btn_CloseBoard.Text = "Close Board";
            this.btn_CloseBoard.UseVisualStyleBackColor = true;
            this.btn_CloseBoard.Click += new System.EventHandler(this.btn_CloseBrd_Click);
            // 
            // btn_AOSetup
            // 
            this.btn_AOSetup.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn_AOSetup.Location = new System.Drawing.Point(84, 79);
            this.btn_AOSetup.Name = "btn_AOSetup";
            this.btn_AOSetup.Size = new System.Drawing.Size(97, 26);
            this.btn_AOSetup.TabIndex = 25;
            this.btn_AOSetup.Text = "AO Setup>>";
            this.btn_AOSetup.UseVisualStyleBackColor = true;
            this.btn_AOSetup.Click += new System.EventHandler(this.btn_AOSetup_Click);
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openConfigFileDialog";
            // 
            // lv_AOValue
            // 
            this.lv_AOValue.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_Channel,
            this.col_Value,
            this.col_Raw,
            this.col_OutputRange});
            this.lv_AOValue.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lv_AOValue.Location = new System.Drawing.Point(28, 124);
            this.lv_AOValue.Name = "lv_AOValue";
            this.lv_AOValue.Size = new System.Drawing.Size(411, 364);
            this.lv_AOValue.TabIndex = 24;
            this.lv_AOValue.UseCompatibleStateImageBehavior = false;
            this.lv_AOValue.View = System.Windows.Forms.View.Details;
            // 
            // col_Channel
            // 
            this.col_Channel.Text = "Channel";
            this.col_Channel.Width = 100;
            // 
            // col_Value
            // 
            this.col_Value.Text = "Value";
            this.col_Value.Width = 80;
            // 
            // col_Raw
            // 
            this.col_Raw.Text = "Raw";
            this.col_Raw.Width = 100;
            // 
            // col_OutputRange
            // 
            this.col_OutputRange.Text = "Output Range";
            this.col_OutputRange.Width = 120;
            // 
            // FormAO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 515);
            this.Controls.Add(this.btn_AOSetup);
            this.Controls.Add(this.lv_AOValue);
            this.Controls.Add(this.btn_CloseBoard);
            this.Controls.Add(this.btn_OpenBoard);
            this.Controls.Add(this.CmbAvailableDevice);
            this.Controls.Add(this.label1);
            this.Name = "FormAO";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EthcatAO";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        
      
        uint m_ulAxisCount = 0;
        bool m_bInit = false;

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn_OpenBoard;
        private System.Windows.Forms.Button btn_CloseBoard;
        private ListViewNF lv_AOValue;
        private System.Windows.Forms.ColumnHeader col_Channel;
        private System.Windows.Forms.ColumnHeader col_Value;
        private System.Windows.Forms.ColumnHeader col_Raw;
        private System.Windows.Forms.ColumnHeader col_OutputRange;
        private System.Windows.Forms.Button btn_AOSetup;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
    }
}

