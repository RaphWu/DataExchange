﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Diagnostics;
namespace EthcatAO
{
    public partial class FormAO : Form
    {
        public FormAO()
        {
            InitializeComponent();
           // VersionIsOk = GetDevCfgDllDrvVer();
        }
        Boolean VersionIsOk = false;
        private uint AONumber = 0;

        private IntPtr m_devhand = IntPtr.Zero;
        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            string ErrorMessage;
            //Get Driver Version Number, this step is not necessary
            
          //  if (VersionIsOk == false)
          //  {
               // return;
         //   }
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot，Perhaps the opposite
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ErrorMessage = GlobalVar.GetErrorMessage((uint)Result);
                MessageBox.Show(strTemp + "\r\nError Message:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }
            //If you want to get the device number of fixed equipment，you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            RefreshAOValue();
        }

        private void btn_OpenBrd_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            uint retry = 0, SlaveOnRing0 = 0, SlaveOnRing1 = 0;
            bool rescan = false;
            string strTemp;
            string ErrorMessage;
            lv_AOValue.Items.Clear();
            AONumber = 0;
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            do
            {
                Result = Motion.mAcm_DevOpen(DeviceNum, ref m_devhand);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Device Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ErrorMessage = GlobalVar.GetErrorMessage(Result);
                    MessageBox.Show(strTemp + "\r\nError Message:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    retry++;
                    rescan = true;
                    if (retry > 10)
                        return;
                    System.Threading.Thread.Sleep(1000);
                }
                else
                {
					//User must check the slave count on each ring match the actual connection.
					//We recommend using following code that was marked to check connection status.
					//The example expect there is one slave on Motion ring and user does not connect any slave on IO ring.
					rescan = false;
					/*Result = Motion.mAcm_GetU32Property(m_devhand, (uint)PropertyID.FT_MasCyclicCnt_R0, ref SlaveOnRing0);
					Result = Motion.mAcm_GetU32Property(m_devhand, (uint)PropertyID.FT_MasCyclicCnt_R1, ref SlaveOnRing1);
					if (SlaveOnRing0 != 1 || SlaveOnRing1 != 0)
					{
						MessageBox.Show("Retrieved the slave states do not match the actual connection.", "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error);
						Motion.mAcm_DevReOpen(m_devhand);
						Motion.mAcm_DevClose(ref m_devhand);
						System.Threading.Thread.Sleep(1000);
						retry = 0;
						rescan = true;
					}*/
                }
            } while (rescan == true); 
            ulong dDevType;
            dDevType = (DeviceNum & 0xff000000) >> 24;
            GlobalVar.m_DeviceHandle = m_devhand;
            if (dDevType == (ulong)DevTypeID.EtherCAT)
            {
                this.OpenConfigFile.FileName = "";
                if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                    return;

                Result = Motion.mAcm_LoadENI(m_devhand, OpenConfigFile.FileName);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Load ENI Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ErrorMessage = GlobalVar.GetErrorMessage(Result);
                    MessageBox.Show(ErrorMessage + "\r\nError Message:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }                  
            }
            RefreshAOSetup(true);
            m_bInit = true;
            timer1.Enabled = true;          
        }
        public void RefreshAOSetup(bool IsInitial)
        {
            string[] subItems = new string[4];
            uint Ret = 0;
            double m_AoRange = 0;
            float m_AoValue = 0;
            ushort m_AoRawValue = 0;
            string strAoRange = "";
            string ErrorMessage = "";
            lv_AOValue.BeginUpdate();
            Ret = Motion.mAcm_GetU32Property(m_devhand, (uint)PropertyID.FT_DaqAoMaxChan, ref AONumber);
            if (Ret == (uint)(ErrorCode.SUCCESS))
            {
                for (int i = 0; i < AONumber; i++)
                {
                    Ret = Motion.mAcm_GetChannelProperty(m_devhand, (uint)i, (uint)PropertyID.CFG_CH_DaqAoRange, ref m_AoRange);
                    if (Ret != (uint)ErrorCode.SUCCESS)
                    {
                        ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                        MessageBox.Show("Channel " + i.ToString() + " Get AoRange Property failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                        //return;
                    }
                    if (m_AoRange > 15)
                    {
                        Ret = Motion.mAcm_DaqAoGetCurrData(m_devhand, (ushort)i, ref m_AoValue);
                    }
                    else
                    {
                        Ret = Motion.mAcm_DaqAoGetVoltData(m_devhand, (ushort)i, ref m_AoValue);

                    }
                    if (Ret != (uint)ErrorCode.SUCCESS)
                    {
                        ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                        MessageBox.Show("Channel " + i.ToString() + " Get AO Data failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                        //return;
                    }
                    Ret = Motion.mAcm_DaqAoGetRawData(m_devhand, (ushort)i, ref m_AoRawValue);
                    if (Ret != (uint)ErrorCode.SUCCESS)
                    {
                        ErrorMessage = GlobalVar.GetErrorMessage(Ret);
                        MessageBox.Show("Channel " + i.ToString() + " Get AO Raw Data failed with Error Code=[0x" + Convert.ToString(Ret, 16) + "]:" + ErrorMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                        //return;
                    }

                    switch ((uint)m_AoRange)
                    {
                        case (uint)AoRange.AO_NEG_10V_TO_10V:
                            strAoRange = "+/-10V";
                            break;
                        case (uint)AoRange.AO_NEG_5V_TO_5V:
                            strAoRange = "+/-5V";
                            break;
                        case (uint)AoRange.AO_NEG_2500MV_TO_2500MV:
                            strAoRange = "+/-2.5V";
                            break;
                        case (uint)AoRange.AO_NEG_1250MV_TO_1250MV:
                            strAoRange = "+/-1.25V";
                            break;
                        case (uint)AoRange.AO_NEG_625MV_TO_625MV:
                            strAoRange = "+/-0.625";
                            break;
                        case (uint)AoRange.AO_NEG_0V_TO_10V:
                            strAoRange = "0~10V";
                            break;
                        case (uint)AoRange.AO_0MA_TO_20MA:
                            strAoRange = "0~20mA";
                            break;
                        case (uint)AoRange.AO_4MA_TO_20MA:
                            strAoRange = "4~20mA";
                            break;
                        default:
                            strAoRange = "+/-10V";
                            break;
                    }

                    subItems[0] = "CH-" + i.ToString();
                    subItems[1] = m_AoValue.ToString("0.000");
                    subItems[2] = "0x" + m_AoRawValue.ToString("X");
                    subItems[3] = strAoRange;
                    if (IsInitial)
                    {
                        ListViewItem lvi = new ListViewItem(subItems);
                        lv_AOValue.Items.Add(lvi);
                    }
                    else
                    {
                        lv_AOValue.Items[i].SubItems[1].Text = subItems[1];
                        lv_AOValue.Items[i].SubItems[2].Text = subItems[2];
                        lv_AOValue.Items[i].SubItems[3].Text = subItems[3];
                    }
                }
               
            }
            lv_AOValue.EndUpdate();
        }

        public void RefreshAOValue()
        {
            uint Ret = 0;
            double m_AoRange = 0;
            float m_AoValue = 0;
            ushort m_AoRawValue = 0;
         
            lv_AOValue.BeginUpdate();
            for (int i = 0; i < AONumber; i++)
            {
                Ret = Motion.mAcm_GetChannelProperty(m_devhand, (uint)i, (uint)PropertyID.CFG_CH_DaqAoRange, ref m_AoRange);
                if (Ret == (uint)ErrorCode.SUCCESS)
                {
                    if (m_AoRange > 15)
                    {
                        Ret = Motion.mAcm_DaqAoGetCurrData(m_devhand, (ushort)i, ref m_AoValue);

                    }
                    else
                    {
                        Ret = Motion.mAcm_DaqAoGetVoltData(m_devhand, (ushort)i, ref m_AoValue);
                    }
                    if (Ret == (uint)ErrorCode.SUCCESS)
                    {
                        lv_AOValue.Items[i].SubItems[1].Text = m_AoValue.ToString("0.000");
                    }
                }
                Ret = Motion.mAcm_DaqAoGetRawData(m_devhand, (ushort)i, ref m_AoRawValue);

                if (Ret == (uint)ErrorCode.SUCCESS)
                {
                    lv_AOValue.Items[i].SubItems[2].Text = "0x" + m_AoRawValue.ToString("X");
                }

            }
            lv_AOValue.EndUpdate();
        }
        private void btn_CloseBrd_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();//Close Board
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseBoardOrForm();//Close Board And Form
        }

        //User-defined API to close board
        private void CloseBoardOrForm()
        {
            if (m_bInit)
            {
                //Close a device
                Motion.mAcm_DevClose(ref GlobalVar.m_DeviceHandle);
                lv_AOValue.Items.Clear();
                timer1.Enabled = false;
                m_bInit = false;
              
            }
        }
        //get the device number of fixed equipment
        private UInt32 GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID)
        {
            return (UInt32)(DevType << 24 | BoardID << 12 | MasterRingNo << 8 | SlaveBoardID);
        }
        private Boolean GetDevCfgDllDrvVer()
        {
            string fileName = "";
            FileVersionInfo myFileVersionInfo;
            string FileVersion = "";
            fileName = Environment.SystemDirectory + "\\ADVMOT.dll";//SystemDirectory指System32 
            myFileVersionInfo = FileVersionInfo.GetVersionInfo(fileName);
            FileVersion = myFileVersionInfo.FileVersion;
            string DetailMessage;
            string[] strSplit = FileVersion.Split(',');
            if (Convert.ToUInt16(strSplit[0]) < 2)
            {
                DetailMessage = "The Driver Version  Is Too Low" + "\r\nYou can update the driver through the driver installation package ";
                DetailMessage = DetailMessage + "\r\nThe Current Driver Version Number is " + FileVersion;
                DetailMessage = DetailMessage + "\r\nYou need to update the driver to 2.0.0.0 version and above";
                MessageBox.Show(DetailMessage, "EthcatAO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void btn_AOSetup_Click(object sender, EventArgs e)
        {
            FormEtherCATAOSetup frmAOSetup = new FormEtherCATAOSetup(this, AONumber);
            DialogResult ret = frmAOSetup.ShowDialog();
        }
    }
}