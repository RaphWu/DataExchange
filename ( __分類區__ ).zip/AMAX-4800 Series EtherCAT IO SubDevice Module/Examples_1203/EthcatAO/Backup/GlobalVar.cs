﻿using System;
using System.Collections.Generic;
using System.Text;
using Advantech.Motion;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace EthcatAO
{
    class GlobalVar
    {
        public static IntPtr m_DeviceHandle = IntPtr.Zero;
        public static string GetErrorMessage(uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            Boolean res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
            string ErrorMessage = "";
            if (res)
            {
                ErrorMessage = ErrorMsg.ToString();
            }
            return ErrorMessage;
        }
    }
    class ListViewNF : System.Windows.Forms.ListView
    {
        public ListViewNF()
        {
            // 开启双缓冲
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);

            // Enable the OnNotifyMessage event so we get a chance to filter out 
            // Windows messages before they get to the form's WndProc
            this.SetStyle(ControlStyles.EnableNotifyMessage, true);
        }

        protected override void OnNotifyMessage(Message m)
        {
            //Filter out the WM_ERASEBKGND message
            if (m.Msg != 0x14)
            {
                base.OnNotifyMessage(m);
            }

        }
       
    }
}