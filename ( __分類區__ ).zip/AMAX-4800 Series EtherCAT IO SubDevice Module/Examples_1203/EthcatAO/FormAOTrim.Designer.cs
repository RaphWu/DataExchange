﻿namespace EthcatAO
{
    partial class FormAOTrim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAOTrim));
            this.bt_Apply = new System.Windows.Forms.Button();
            this.bt_plus10 = new System.Windows.Forms.Button();
            this.bt_plus1 = new System.Windows.Forms.Button();
            this.bt_minus1 = new System.Windows.Forms.Button();
            this.bt_minus10 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_Apply
            // 
            resources.ApplyResources(this.bt_Apply, "bt_Apply");
            this.bt_Apply.Name = "bt_Apply";
            this.bt_Apply.UseVisualStyleBackColor = true;
            this.bt_Apply.Click += new System.EventHandler(this.bt_Apply_Click);
            // 
            // bt_plus10
            // 
            resources.ApplyResources(this.bt_plus10, "bt_plus10");
            this.bt_plus10.Name = "bt_plus10";
            this.bt_plus10.UseVisualStyleBackColor = true;
            this.bt_plus10.Click += new System.EventHandler(this.bt_minus10_Click);
            // 
            // bt_plus1
            // 
            resources.ApplyResources(this.bt_plus1, "bt_plus1");
            this.bt_plus1.Name = "bt_plus1";
            this.bt_plus1.UseVisualStyleBackColor = true;
            this.bt_plus1.Click += new System.EventHandler(this.bt_minus10_Click);
            // 
            // bt_minus1
            // 
            resources.ApplyResources(this.bt_minus1, "bt_minus1");
            this.bt_minus1.Name = "bt_minus1";
            this.bt_minus1.UseVisualStyleBackColor = true;
            this.bt_minus1.Click += new System.EventHandler(this.bt_minus10_Click);
            // 
            // bt_minus10
            // 
            resources.ApplyResources(this.bt_minus10, "bt_minus10");
            this.bt_minus10.Name = "bt_minus10";
            this.bt_minus10.UseVisualStyleBackColor = true;
            this.bt_minus10.Click += new System.EventHandler(this.bt_minus10_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // FormAOTrim
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bt_Apply);
            this.Controls.Add(this.bt_plus10);
            this.Controls.Add(this.bt_plus1);
            this.Controls.Add(this.bt_minus1);
            this.Controls.Add(this.bt_minus10);
            this.Controls.Add(this.label3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAOTrim";
            this.Load += new System.EventHandler(this.FormAOTrim_Load);
            this.Shown += new System.EventHandler(this.FormAOTrim_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_Apply;
        private System.Windows.Forms.Button bt_plus10;
        private System.Windows.Forms.Button bt_plus1;
        private System.Windows.Forms.Button bt_minus1;
        private System.Windows.Forms.Button bt_minus10;
        private System.Windows.Forms.Label label3;
    }
}