﻿namespace AdvantechTest.Models
{
    public class MenuItemDefine
    {
        public MenuItemDefine(string name, string pageKey)
        {
            Name = name;
            PageKey = pageKey;
        }

        public string Name { get; }
        public string PageKey { get; }
    }
}
