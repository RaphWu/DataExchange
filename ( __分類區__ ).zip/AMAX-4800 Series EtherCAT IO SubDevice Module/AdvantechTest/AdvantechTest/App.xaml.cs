﻿using Advantech.Core.Constants;
using AdvantechTest.ViewModels;
using AdvantechTest.Views;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Unity;
using System.Windows;

namespace AdvantechTest
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : PrismApplication
    {
        protected override Window CreateShell()
        {
            return Container.Resolve<MainWindow>();
        }

        protected override void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<SideMenu, SideMenuViewModel>(PageKeys.SideMenu);
        }

        protected override void ConfigureModuleCatalog(IModuleCatalog moduleCatalog)
        {
            moduleCatalog.AddModule<AdvantechLib.AdvantechLibModule>();
            moduleCatalog.AddModule<Advantech.Core.CoreModule>();
            moduleCatalog.AddModule<Glorytek.WPF.WPFModule>();
        }
    }
}
