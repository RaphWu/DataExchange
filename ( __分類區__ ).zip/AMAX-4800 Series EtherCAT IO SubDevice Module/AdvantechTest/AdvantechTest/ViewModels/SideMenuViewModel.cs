﻿using Advantech.Core.Constants;
using AdvantechLib.Contracts;
using AdvantechTest.Models;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System.Collections.ObjectModel;
using System.Linq;

namespace AdvantechTest.ViewModels
{
    public class SideMenuViewModel : BindableBase
    {
        private IRegionNavigationService _navigationService;
        private readonly IRegionManager _regionManager;
        private readonly IAdvantech _advantech;

        public SideMenuViewModel(IRegionManager regionManager, IAdvantech advantech)
        {
            _regionManager = regionManager;
            _advantech = advantech;

            MenuList = new ObservableCollection<MenuItemDefine>(new[]
            {
                new MenuItemDefine("DeviceManager", PageKeys.DeviceManager),
                new MenuItemDefine("EthcatDO", PageKeys.EthcatDo),
                new MenuItemDefine("EthcatDI", PageKeys.EthcatDi),
                new MenuItemDefine("EthcatAO", PageKeys.EthcatAo),
            });
        }

        /// <summary>
        /// 主視窗載入。
        /// </summary>
        public DelegateCommand LoadedCommand
            => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
        private void ExecuteLoadedCommand()
        {
            _navigationService = _regionManager.Regions[RegionNames.MainRegion].NavigationService;
            SelectedMenu = MenuList.First();
        }
        private DelegateCommand _loadedCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand Unloaded
            => _unloaded ??= new DelegateCommand(ExecuteUnloaded);
        private void ExecuteUnloaded()
        {
            _advantech.CloseDevice();
        }
        private DelegateCommand _unloaded;

        /********************
         * Menu
         ********************/
        public ObservableCollection<MenuItemDefine> MenuList { get; }

        public MenuItemDefine SelectedMenu
        {
            get { return _selectedMenu; }
            set
            {
                SetProperty(ref _selectedMenu, value);
                if (value != null)
                    _navigationService.RequestNavigate(value.PageKey);
            }
        }
        private MenuItemDefine _selectedMenu;

        public int SelectedMenuIndex
        {
            get { return _selectedMenuIndex; }
            set { SetProperty(ref _selectedMenuIndex, value); }
        }
        private int _selectedMenuIndex;
    }
}
