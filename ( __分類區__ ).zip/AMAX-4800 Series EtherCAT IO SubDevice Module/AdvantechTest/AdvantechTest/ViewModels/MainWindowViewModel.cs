﻿using Advantech.Core.Constants;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;

namespace AdvantechTest.ViewModels
{
    public class MainWindowViewModel : BindableBase
    {
        private IRegionNavigationService _navigationService;
        private readonly IRegionManager _regionManager;

        public MainWindowViewModel(IRegionManager regionManager)
        {
            _regionManager = regionManager;
        }

        /// <summary>
        /// 主視窗載入。
        /// </summary>
        public DelegateCommand LoadedCommand
            => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
        private void ExecuteLoadedCommand()
        {
            _regionManager.Regions[RegionNames.SideMenuRegion].NavigationService.RequestNavigate(PageKeys.SideMenu);

        }
        private DelegateCommand _loadedCommand;
    }
}
