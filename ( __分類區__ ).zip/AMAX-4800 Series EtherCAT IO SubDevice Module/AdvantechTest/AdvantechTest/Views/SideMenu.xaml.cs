﻿using System.Windows.Controls;

namespace AdvantechTest.Views
{
    /// <summary>
    /// Interaction logic for SideMenu
    /// </summary>
    public partial class SideMenu : UserControl
    {
        public SideMenu()
        {
            InitializeComponent();
        }
    }
}
