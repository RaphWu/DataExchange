﻿namespace Advantech.Core.Constants
{
    public class PageKeys
    {
        public const string SideMenu = "SideMenu";
        public const string DeviceManager = "DeviceManager";
        public const string EthcatDo = "EthcatDo";
        public const string EthcatDi = "EthcatDi";
        public const string EthcatAo = "EthcatAo";
    }
}
