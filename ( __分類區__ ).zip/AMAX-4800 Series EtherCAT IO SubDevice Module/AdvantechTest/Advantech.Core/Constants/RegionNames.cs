﻿namespace Advantech.Core.Constants
{
    public static class RegionNames
    {
        public const string SideMenuRegion = "SideMenuRegion";
        public const string MainRegion = "MainRegion";
        public const string DeviceManagerRegionDo = "DeviceManagerRegionDo";
        public const string DeviceManagerRegionDi = "DeviceManagerRegionDi";
    }
}
