﻿using Prism.Events;

namespace Advantech.Core.Events
{
    public class DeviceEvents
    {
        public class DeviceOpendEvent : PubSubEvent<bool> { }
        public class DeviceClosedEvent : PubSubEvent<bool> { }
    }
}
