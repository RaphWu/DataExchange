﻿using Advantech.Motion;
using AdvantechLib.Contracts;
using AdvantechLib.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using static Advantech.Core.Events.DeviceEvents;

namespace AdvantechLib.Services
{
    public partial class AdvantechService : IAdvantech
    {
        private readonly AdvantechData _advanDatas = AdvantechData.Instance;
        private static IntPtr _deviceHandle = IntPtr.Zero;

        /********************
         * ctor
         ********************/
        public AdvantechService()
        {
        }

        /********************
         * 
         ********************/
        /// <inheritdoc/>
        public ErrorCode UpdateDeviceList()
        {
            try
            {
                int result = Motion.mAcm_GetAvailableDevs(_advanDatas.CurrentAvailableDevs, Motion.MAX_DEVICES, ref _advanDatas.DeviceCount);
                ErrorCode errCode = Enum.Parse<ErrorCode>(result.ToString());
                if (errCode != ErrorCode.SUCCESS)
                {
                    ShowErrorMessage("獲取設備編號失敗。", (uint)result);
                    return errCode;
                }

                _advanDatas.AvailableDeviceList.Clear();
                if (_advanDatas.DeviceCount > 0)
                {
                    for (int i = 0; i < _advanDatas.DeviceCount; i++)
                        _advanDatas.AvailableDeviceList.Add(_advanDatas.CurrentAvailableDevs[i].DeviceName);
                    _advanDatas.CurrentAvailableDevice = _advanDatas.AvailableDeviceList.FirstOrDefault();
                }
                else
                {
                    _advanDatas.CurrentAvailableDevice = "";
                }

                return errCode;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "驅動程式異常或未安裝！", MessageBoxButton.OK, MessageBoxImage.Error);
                Application.Current.Shutdown(0);
                return ErrorCode.LoadDllFailed;
            }
        }

        /// <inheritdoc/>
        public ErrorCode OpenDeviceByDeviceNumber(uint deviceNumber)
        {
            uint result;
            ErrorCode errCode;

            uint retry = 0;
            bool rescan = false;

            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            do
            {
                result = Motion.mAcm_DevOpen(deviceNumber, ref _deviceHandle);
                errCode = Enum.Parse<ErrorCode>(result.ToString());

                if (errCode == ErrorCode.SUCCESS)
                {
                    // User must check the slave count on each ring match the actual connection.
                    // We recommend using following code that was marked to check connection status.
                    // The example expect there is one slave on Motion ring and user does not connect any slave on IO ring.
                    // 用戶必須檢查每個環上的從屬計數是否與實際連接相匹配。
                    // 我們建議使用以下標記的代碼來檢查連接狀態。
                    // 該示例期望在 Motion ring 上有一個從站，並且用戶不在 IO ring 上連接任何從站。
                    rescan = false;
                    /*Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R0, ref SlaveOnRing0);
                    Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R1, ref SlaveOnRing1);
                    if (SlaveOnRing0 != 1 || SlaveOnRing1 != 0)
                    {
                    MessageBox.Show("Retrieved the slave states do not match the actual connection.", "EthcatDO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Motion.mAcm_DevReOpen(m_DeviceHandle);
                    Motion.mAcm_DevClose(ref m_DeviceHandle);
                    System.Threading.Thread.Sleep(1000);
                    retry = 0;
                    rescan = true;
                    }*/
                }
                else
                {
                    ShowErrorMessage("設備開啟錯誤。", result);

                    rescan = true;
                    if (++retry > 10)
                        return errCode;
                    Task.Delay(1000).Wait();
                }
            } while (rescan == true);

            ulong dDevType = (deviceNumber & 0xFF000000) >> 24;
            //pn_DOValue.Controls.Clear();
            _advanDatas.DeviceHandle = _deviceHandle;

            if (dDevType == (ulong)DevTypeID.EtherCAT)
            {
                MessageBox.Show("測試區dDevType");
                //OpenConfigFile.FileName = "";
                //if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                //    return;

                //This API is for EtherCAT LAN port.
                //Result = Motion.mAcm_LoadENI(_deviceHandle, OpenConfigFile.FileName);
                //if (Result != (uint)ErrorCode.SUCCESS)
                //{
                //    strTemp = "ENI載入錯誤，錯誤碼：[0x" + Convert.ToString(Result, 16) + "]";
                //    ErrorMessage = CommonFunc.GetErrorMessage(Result);
                //    MessageBox.Show($"{strTemp}\n錯誤訊息：{ErrorMessage}", "Advantech錯誤", MessageBoxButton.OK, MessageBoxImage.Error);
                //    return;
                //}
            }

            // user can customize mapping table and export to file.
            // This API can load mapping table which was customized previously.This step is optional.
            // Result = Motion.mAcm_DevLoadMapFile(m_DeviceHandle, "PCI1203_IO_table.xml");
            // 用戶可以自定義映射表並導出到文件。
            // 該API可以加載之前自定義的映射表。此步驟是可選的。

            _advanDatas.IsOpen = true;
            if (InitDevice() != ErrorCode.SUCCESS)
                _advanDatas.IsOpen = false;

            return ErrorCode.SUCCESS;
        }

        /// <inheritdoc/>
        public ErrorCode OpenDevice(string configFileName)
        {
            uint result;
            ErrorCode errCode;

            uint retry = 0;
            bool rescan = false;

            _advanDatas.IsOpen = false;

            uint deviceNumber = default;
            result = Motion.mAcm_GetDevNum((uint)DevTypeID.PCI1203, 0, ref deviceNumber);
            errCode = Enum.Parse<ErrorCode>(result.ToString());
            if (errCode == ErrorCode.SUCCESS)
            {
                _advanDatas.DeviceNumber = deviceNumber;
            }
            else
            {
                ShowErrorMessage("PCI1203開啟錯誤。", result);
                return errCode;
            }

            do
            {
                result = Motion.mAcm_DevOpen(_advanDatas.DeviceNumber, ref _deviceHandle);
                errCode = Enum.Parse<ErrorCode>(result.ToString());
                if (errCode == ErrorCode.SUCCESS)
                {
                    // User must check the slave count on each ring match the actual connection.
                    // We recommend using following code that was marked to check connection status.
                    // The example expect there is one slave on Motion ring and user does not connect any slave on IO ring.
                    // 用戶必須檢查每個環上的從屬計數是否與實際連接相匹配。
                    // 我們建議使用以下標記的代碼來檢查連接狀態。
                    // 該示例期望在 Motion ring 上有一個從站，並且用戶不在 IO ring 上連接任何從站。
                    rescan = false;
                    /*Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R0, ref SlaveOnRing0);
                    Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_MasCyclicCnt_R1, ref SlaveOnRing1);
                    if (SlaveOnRing0 != 1 || SlaveOnRing1 != 0)
                    {
                    MessageBox.Show("Retrieved the slave states do not match the actual connection.", "EthcatDO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Motion.mAcm_DevReOpen(m_DeviceHandle);
                    Motion.mAcm_DevClose(ref m_DeviceHandle);
                    System.Threading.Thread.Sleep(1000);
                    retry = 0;
                    rescan = true;
                    }*/
                }
                else
                {
                    ShowErrorMessage("設備開啟錯誤。", result);

                    rescan = true;
                    if (++retry > 10)
                        return errCode;
                    Task.Delay(1000).Wait();
                }
            } while (rescan == true);

            ulong dDevType = (_advanDatas.DeviceNumber & 0xFF000000) >> 24;
            //pn_DOValue.Controls.Clear();
            _advanDatas.DeviceHandle = _deviceHandle;

            if (dDevType == (ulong)DevTypeID.EtherCAT)
            {
                MessageBox.Show("測試區dDevType");
                //OpenConfigFile.FileName = "";
                //if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                //    return;

                //This API is for EtherCAT LAN port.
                //Result = Motion.mAcm_LoadENI(_deviceHandle, OpenConfigFile.FileName);
                //if (Result != (uint)ErrorCode.SUCCESS)
                //{
                //    strTemp = "ENI載入錯誤，錯誤碼：[0x" + Convert.ToString(Result, 16) + "]";
                //    ErrorMessage = CommonFunc.GetErrorMessage(Result);
                //    MessageBox.Show($"{strTemp}\n錯誤訊息：{ErrorMessage}", "Advantech錯誤", MessageBoxButton.OK, MessageBoxImage.Error);
                //    return;
                //}
            }

            result = Motion.mAcm_DevLoadMapFile(_advanDatas.DeviceHandle, configFileName);
            errCode = Enum.Parse<ErrorCode>(result.ToString());
            if (errCode != ErrorCode.SUCCESS)
            {
                MessageBox.Show(configFileName);
                return errCode;
            }

            _advanDatas.IsOpen = true;
            if (InitDevice() != ErrorCode.SUCCESS)
                _advanDatas.IsOpen = false;

            return ErrorCode.SUCCESS;
        }

        /// <inheritdoc/>
        public ErrorCode CloseDevice()
        {
            ErrorCode errCode = ErrorCode.SUCCESS;
            if (_advanDatas.IsOpen)
            {
                uint result = Motion.mAcm_DevClose(ref _advanDatas.DeviceHandle);
                errCode = Enum.Parse<ErrorCode>(result.ToString());
                if (errCode != ErrorCode.SUCCESS)
                    ShowErrorMessage("設備關閉錯誤。", result);
                _advanDatas.IsOpen = false;
            }
            else
            {
                errCode = ErrorCode.DeviceNotOpened;
            }

            return errCode;
        }

        /// <summary>
        /// 週邊初始化。
        /// </summary>
        /// <returns>返回的錯誤碼。</returns>
        private ErrorCode InitDevice()
        {
            ErrorCode errCodeDO = InitDo();
            if (errCodeDO != ErrorCode.SUCCESS)
                return errCodeDO;

            ErrorCode errCodeAO = InitAo();
            if (errCodeAO != ErrorCode.SUCCESS)
                return errCodeAO;

            return ErrorCode.SUCCESS;
        }

        /// <summary>
        /// 顯示錯誤訊息。
        /// </summary>
        /// <param name="title">開頭標題。</param>
        /// <param name="resultCode">Advantach函數返回碼。</param>
        private static void ShowErrorMessage(string title, uint resultCode)
        {
            string errCode = $"錯誤碼：[0x" + Convert.ToString(resultCode, 16) + "]";
            string errMsg = $"錯誤訊息：{CommonFunc.GetErrorMessage(resultCode)}";
            MessageBox.Show($"{title}\n{errCode}\n{errMsg}", "Advantech錯誤", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
