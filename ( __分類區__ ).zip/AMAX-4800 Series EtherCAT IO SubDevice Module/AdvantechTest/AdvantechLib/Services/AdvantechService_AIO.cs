﻿using Advantech.Motion;
using AdvantechLib.Contracts;
using AdvantechLib.Exceptions;
using AdvantechLib.Models;
using Newtonsoft.Json.Linq;
using System;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace AdvantechLib.Services
{
    public partial class AdvantechService : IAdvantech_AIO
    {
        /********************
         * Enabled
         ********************/
        /// <inheritdoc/>
        public ErrorCode UpdateAoEnable(uint channel)
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;
            else if (_advanDatas.AoChannelList.Count == 0)
                return ErrorCode.DevRegDataLost;

            var ch = _advanDatas.AoChannelList[(int)channel];
            double enable = default;
            uint result = Motion.mAcm_GetChannelProperty(_deviceHandle, channel, (uint)PropertyID.CFG_CH_DaqAoEnable, ref enable);

            if (result == (uint)ErrorCode.SUCCESS)
                ch.Enabled = enable == 1.0;
            return Enum.Parse<ErrorCode>(result.ToString());
        }

        /// <inheritdoc/>
        public ErrorCode UpdateAoEnable()
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;
            else if (_advanDatas.AoChannelList.Count == 0)
                return ErrorCode.DevRegDataLost;

            for (uint channel = 0; channel < _advanDatas.AoChannelNumber; channel++)
            {
                var ch = _advanDatas.AoChannelList[(int)channel];
                double enable = default;
                uint result = Motion.mAcm_GetChannelProperty(_deviceHandle, channel, (uint)PropertyID.CFG_CH_DaqAoEnable, ref enable);

                if (result == (uint)ErrorCode.SUCCESS)
                    ch.Enabled = enable == 1.0;
                else
                    return Enum.Parse<ErrorCode>(result.ToString());
            }
            return ErrorCode.SUCCESS;
        }

        /// <inheritdoc/>
        public ErrorCode SetAoEnable(uint channel)
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;
            else if (_advanDatas.AoChannelList.Count == 0)
                return ErrorCode.DevRegDataLost;

            double enable = _advanDatas.AoChannelList[(int)channel].Enabled ? 1.0 : 0.0;
            uint result = Motion.mAcm_SetChannelProperty(_deviceHandle, channel, (uint)PropertyID.CFG_CH_DaqAoEnable, enable);
            return Enum.Parse<ErrorCode>(result.ToString());
        }

        /// <inheritdoc/>
        public ErrorCode SetAoEnable()
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;
            else if (_advanDatas.AoChannelList.Count == 0)
                return ErrorCode.DevRegDataLost;

            for (uint channel = 0; channel < _advanDatas.AoChannelNumber; channel++)
            {
                double enable = _advanDatas.AoChannelList[(int)channel].Enabled ? 1.0 : 0.0;
                uint result = Motion.mAcm_SetChannelProperty(_deviceHandle, channel, (uint)PropertyID.CFG_CH_DaqAoEnable, enable);
                if (result != (uint)ErrorCode.SUCCESS)
                    return Enum.Parse<ErrorCode>(result.ToString());
            }
            return ErrorCode.SUCCESS;
        }

        /********************
         * Range
         ********************/
        /// <inheritdoc/>
        public ErrorCode UpdateAoRange(uint channel)
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;
            else if (_advanDatas.AoChannelList.Count == 0)
                return ErrorCode.DevRegDataLost;

            var ch = _advanDatas.AoChannelList[(int)channel];
            if (ch.Enabled)
            {
                double range = default;
                uint result = Motion.mAcm_GetChannelProperty(_deviceHandle, channel, (uint)PropertyID.CFG_CH_DaqAoRange, ref range);

                if (result == (uint)ErrorCode.SUCCESS)
                    ch.Range = range;
                return Enum.Parse<ErrorCode>(result.ToString());
            }
            else
            {
                return ErrorCode.Dsp_ChannelIsDisable;
            }
        }

        /// <inheritdoc/>
        public ErrorCode UpdateAoRange()
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;
            else if (_advanDatas.AoChannelList.Count == 0)
                return ErrorCode.DevRegDataLost;

            for (uint channel = 0; channel < _advanDatas.AoChannelNumber; channel++)
            {
                var ch = _advanDatas.AoChannelList[(int)channel];
                if (ch.Enabled)
                {
                    double range = default;
                    uint result = Motion.mAcm_GetChannelProperty(_deviceHandle, channel, (uint)PropertyID.CFG_CH_DaqAoRange, ref range);
                    if (result == (uint)ErrorCode.SUCCESS)
                        ch.Range = range;
                    else
                        return Enum.Parse<ErrorCode>(result.ToString());
                }
            }
            return ErrorCode.SUCCESS;
        }

        /// <inheritdoc/>
        public ErrorCode SetAoRange(uint channel)
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;
            else if (_advanDatas.AoChannelList.Count == 0)
                return ErrorCode.DevRegDataLost;

            var ch = _advanDatas.AoChannelList[(int)channel];
            if (ch.Enabled)
            {
                double range = ch.Range;
                uint result = Motion.mAcm_SetChannelProperty(_deviceHandle, channel, (uint)PropertyID.CFG_CH_DaqAoRange, range);
                return Enum.Parse<ErrorCode>(result.ToString());
            }
            else
            {
                return ErrorCode.Dsp_ChannelIsDisable;
            }
        }

        /// <inheritdoc/>
        public ErrorCode SetAoRange()
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;
            else if (_advanDatas.AoChannelList.Count == 0)
                return ErrorCode.DevRegDataLost;

            for (uint channel = 0; channel < _advanDatas.AoChannelNumber; channel++)
            {
                var ch = _advanDatas.AoChannelList[(int)channel];
                if (ch.Enabled)
                {
                    double range = ch.Range;
                    uint result = Motion.mAcm_SetChannelProperty(_deviceHandle, channel, (uint)PropertyID.CFG_CH_DaqAoRange, range);
                    if (result != (uint)ErrorCode.SUCCESS)
                        return Enum.Parse<ErrorCode>(result.ToString());
                }
            }
            return ErrorCode.SUCCESS;
        }

        /// <inheritdoc/>
        public ErrorCode GetMaxMinValue(AoRange range, out double MaxValue, out double MinValue, out double EditProportion, out string Unit)
        {
            switch (range)
            {
                case AoRange.AO_NEG_10V_TO_10V:
                    MaxValue = 10.0;
                    MinValue = -10.0;
                    EditProportion = 1.0;
                    Unit = "V";
                    break;

                case AoRange.AO_NEG_5V_TO_5V:
                    MaxValue = 5.0;
                    MinValue = -5.0;
                    EditProportion = 1.0;
                    Unit = "V";
                    break;

                case AoRange.AO_NEG_2500MV_TO_2500MV:
                    MaxValue = 2500.0;
                    MinValue = -2500.0;
                    EditProportion = 0.001;
                    Unit = "mV";
                    break;

                case AoRange.AO_NEG_1250MV_TO_1250MV:
                    MaxValue = 1250.0;
                    MinValue = -1250.0;
                    EditProportion = 0.001;
                    Unit = "mV";
                    break;

                case AoRange.AO_NEG_625MV_TO_625MV:
                    MaxValue = 625.0;
                    MinValue = -625.0;
                    EditProportion = 0.001;
                    Unit = "mV";
                    break;

                case AoRange.AO_NEG_0V_TO_10V:
                    MaxValue = 10.0;
                    MinValue = 0.0;
                    EditProportion = 1;
                    Unit = "V";
                    break;

                case AoRange.AO_NEG_0V_TO_5V:
                    MaxValue = 5.0;
                    MinValue = 0.0;
                    EditProportion = 1;
                    Unit = "V";
                    break;

                case AoRange.AO_0MA_TO_20MA:
                    MaxValue = 20.0;
                    MinValue = 0.0;
                    EditProportion = 0.001;
                    Unit = "mA";
                    break;

                case AoRange.AO_4MA_TO_20MA:
                    MaxValue = 20.0;
                    MinValue = 4.0;
                    EditProportion = 0.001;
                    Unit = "mA";
                    break;

                default:
                    MaxValue = 0.0;
                    MinValue = 0.0;
                    EditProportion = 1;
                    Unit = "";
                    return ErrorCode.InvalidAoRange;
            };
            return ErrorCode.SUCCESS;
        }

        /********************
         * Value
         ********************/
        /// <inheritdoc/>
        public ErrorCode UpdateAoValue(uint channel)
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;
            else if (_advanDatas.AoChannelList.Count == 0)
                return ErrorCode.InvalidAoRange;

            var ch = _advanDatas.AoChannelList[(int)channel];
            if (ch.Enabled)
            {
                uint result;
                float value = default;

                result = ch.Range >= 0x10000u
                    ? Motion.mAcm_DaqAoGetCurrData(_deviceHandle, (ushort)channel, ref value)  // 電流檔
                    : Motion.mAcm_DaqAoGetVoltData(_deviceHandle, (ushort)channel, ref value); // 電壓檔
                ErrorCode errCode = Enum.Parse<ErrorCode>(result.ToString());

                ch.Value = errCode == ErrorCode.SUCCESS ? value : 0.0F;
                return errCode;
            }
            else
            {
                ch.Value = 0.0F;
                return ErrorCode.Dsp_ChannelIsDisable;
            }
        }

        /// <inheritdoc/>
        public ErrorCode UpdateAoValue()
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;
            else if (_advanDatas.AoChannelList.Count == 0)
                return ErrorCode.DevRegDataLost;

            uint result;
            float value = default;

            for (uint channel = 0; channel < _advanDatas.AoChannelNumber; channel++)
            {
                var ch = _advanDatas.AoChannelList[(int)channel];
                if (ch.Enabled)
                {
                    result = ch.Range >= 0x10000u
                        ? Motion.mAcm_DaqAoGetCurrData(_deviceHandle, (ushort)channel, ref value)  // 電流檔
                        : Motion.mAcm_DaqAoGetVoltData(_deviceHandle, (ushort)channel, ref value); // 電壓檔

                    if (result == (uint)ErrorCode.SUCCESS)
                    {
                        ch.Value = value;
                    }
                    else
                    {
                        ch.Value = 0.0F;
                        return Enum.Parse<ErrorCode>(result.ToString());
                    }
                }
            }
            return ErrorCode.SUCCESS;
        }

        /// <inheritdoc/>
        public ErrorCode SetAoValue(uint channel, float value)
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;
            else if (_advanDatas.AoChannelList.Count == 0)
                return ErrorCode.InvalidAoRange;

            var ch = _advanDatas.AoChannelList[(int)channel];
            if (ch.Enabled)
            {
                //float value = ch.Value;
                uint result = ch.Range >= 0x10000u
                    ? Motion.mAcm_DaqAoSetCurrData(_deviceHandle, (ushort)channel, value)  // 電流檔
                    : Motion.mAcm_DaqAoSetVoltData(_deviceHandle, (ushort)channel, value); // 電壓檔
                return Enum.Parse<ErrorCode>(result.ToString());
            }
            else
            {
                return ErrorCode.Dsp_ChannelIsDisable;
            }
        }

        /// <inheritdoc/>
        public ErrorCode SetAoValue(float[] values)
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;
            else if (_advanDatas.AoChannelList.Count == 0)
                return ErrorCode.DevRegDataLost;

            for (uint channel = 0; channel < _advanDatas.AoChannelNumber; channel++)
            {
                var ch = _advanDatas.AoChannelList[(int)channel];
                if (ch.Enabled)
                {
                    float value = values[(int)channel];
                    uint result = ch.Range >= 0x10000u
                        ? Motion.mAcm_DaqAoSetCurrData(_deviceHandle, (ushort)channel, value)  // 電流檔
                        : Motion.mAcm_DaqAoSetVoltData(_deviceHandle, (ushort)channel, value); // 電壓檔

                    if (result != (uint)ErrorCode.SUCCESS)
                        return Enum.Parse<ErrorCode>(result.ToString());
                }
            }
            return ErrorCode.SUCCESS;
        }

        /********************
         * Common Functions
         ********************/
        /// <summary>
        /// 獲取板卡支持的AO範圍。
        /// </summary>
        /// <returns>返回的錯誤碼。</returns>
        internal ErrorCode GenerateRangeList()
        {
            if (!_advanDatas.IsOpen)
                return ErrorCode.DeviceNotOpened;

            uint range = default;
            _advanDatas.RangeList = new();

            uint result = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.FT_DaqAoRangeMap, ref range);
            if (result != (uint)ErrorCode.SUCCESS)
                return Enum.Parse<ErrorCode>(result.ToString());

            if ((range & (uint)AoRangeMap.AO_NEG_10V_TO_10V) > 0)
                _advanDatas.RangeList.Add((double)AoRange.AO_NEG_10V_TO_10V, "+/-10V");

            if ((range & (uint)AoRangeMap.AO_NEG_5V_TO_5V) > 0)
                _advanDatas.RangeList.Add((double)AoRange.AO_NEG_5V_TO_5V, "+/-5V");

            if ((range & (uint)AoRangeMap.AO_NEG_2500MV_TO_2500MV) > 0)
                _advanDatas.RangeList.Add((double)AoRange.AO_NEG_2500MV_TO_2500MV, "+/-2.5V");

            if ((range & (uint)AoRangeMap.AO_NEG_1250MV_TO_1250MV) > 0)
                _advanDatas.RangeList.Add((double)AoRange.AO_NEG_1250MV_TO_1250MV, "+/-1.25V");

            if ((range & (uint)AoRangeMap.AO_NEG_625MV_TO_625MV) > 0)
                _advanDatas.RangeList.Add((double)AoRange.AO_NEG_625MV_TO_625MV, "+/-625mV");

            if ((range & (uint)AoRangeMap.AO_NEG_0V_TO_10V) > 0)
                _advanDatas.RangeList.Add((double)AoRange.AO_NEG_0V_TO_10V, "0~10V");

            if ((range & (uint)AoRangeMap.AO_NEG_0V_TO_5V) > 0)
                _advanDatas.RangeList.Add((double)AoRange.AO_NEG_0V_TO_5V, "0~5V");

            if ((range & (uint)AoRangeMap.AO_0MA_TO_20MA) > 0)
                _advanDatas.RangeList.Add((double)AoRange.AO_0MA_TO_20MA, "0~20mA");

            if ((range & (uint)AoRangeMap.AO_4MA_TO_20MA) > 0)
                _advanDatas.RangeList.Add((double)AoRange.AO_4MA_TO_20MA, "4~20mA");

            return ErrorCode.SUCCESS;
        }

        /// <summary>
        /// 初始化AO資訊。
        /// </summary>
        /// <returns>返回的錯誤碼。</returns>
        private ErrorCode InitAo()
        {
            try
            {
                uint result;
                ErrorCode errCode;

                result = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.FT_DaqAoMaxChan, ref _advanDatas.AoChannelNumber);
                if (result != (uint)ErrorCode.SUCCESS)
                {
                    AoException e = new();
                    e.Data["ErrorResult"] = result;
                    throw e;
                }

                for (uint channel = 0; channel < _advanDatas.AoChannelNumber; channel++)
                    _advanDatas.AoChannelList.Add(new AnalogData(channel));

                errCode = GenerateRangeList();
                if (errCode != ErrorCode.SUCCESS)
                {
                    AoException e = new();
                    e.Data["ErrorResult"] = errCode;
                    throw e;
                }

                errCode = UpdateAoEnable();
                if (errCode != ErrorCode.SUCCESS)
                {
                    AoException e = new();
                    e.Data["ErrorResult"] = errCode;
                    throw e;
                }

                errCode = UpdateAoRange();
                if (errCode != ErrorCode.SUCCESS)
                {
                    AoException e = new();
                    e.Data["ErrorResult"] = errCode;
                    throw e;
                }

                errCode = UpdateAoValue();
                if (errCode != ErrorCode.SUCCESS)
                {
                    AoException e = new();
                    e.Data["ErrorResult"] = errCode;
                    throw e;
                }
            }
            catch (AoException ae)
            {
                var result = (uint)ae.Data["ErrorResult"];
                ShowErrorMessage("AO設備初始化錯誤。", result);
                return Enum.Parse<ErrorCode>(result.ToString());
            }
            return ErrorCode.SUCCESS;
        }
    }
}
