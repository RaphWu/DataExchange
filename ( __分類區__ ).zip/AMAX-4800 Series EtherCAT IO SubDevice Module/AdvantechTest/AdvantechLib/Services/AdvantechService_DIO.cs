﻿using Advantech.Motion;
using AdvantechLib.Contracts;
using System;

namespace AdvantechLib.Services
{
    public partial class AdvantechService : IAdvantech_DIO
    {
        /********************
         * Digital Output
         ********************/
        /// <inheritdoc/>
        public ErrorCode GetDoByteValue(ushort portNo, out byte byteData)
        {
            /// <inheritdoc/>
            if (_advanDatas.DeviceHandle != IntPtr.Zero)
            {
                byte DOStatus = 0;

                uint result = Motion.mAcm_DaqDoGetByte(_advanDatas.DeviceHandle, portNo, ref DOStatus);
                ErrorCode errCode = Enum.Parse<ErrorCode>(result.ToString());
                if (errCode == ErrorCode.SUCCESS)
                {
                    byteData = DOStatus;
                    return ErrorCode.SUCCESS;
                }
                else
                {
                    byteData = 0;
                    return errCode;
                }
            }
            else
            {
                byteData = 0;
                return ErrorCode.InvalidParameter;
            }
        }

        /// <inheritdoc/>
        public ErrorCode SetDoByteValue(ushort portNo, byte byteData)
        {
            /// <inheritdoc/>
            if (_advanDatas.DeviceHandle != IntPtr.Zero)
            {
                uint result = Motion.mAcm_DaqDoSetByte(_advanDatas.DeviceHandle, portNo, byteData);
                return Enum.Parse<ErrorCode>(result.ToString());
            }
            else
            {
                return ErrorCode.InvalidParameter;
            }
        }

        /********************
         * Digital Input
         ********************/
        /// <inheritdoc/>
        public ErrorCode GetDiBytesValue(ushort portNo, ushort numPort, out byte[] byteData)
        {
            /// <inheritdoc/>
            if (_advanDatas.DeviceHandle != IntPtr.Zero)
            {
                byte[] DOStatus = new byte[numPort];

                uint result = Motion.mAcm_DaqDiGetBytes(_advanDatas.DeviceHandle, portNo, numPort, DOStatus);
                ErrorCode errCode = Enum.Parse<ErrorCode>(result.ToString());
                if (errCode == ErrorCode.SUCCESS)
                {
                    byteData = DOStatus;
                    return ErrorCode.SUCCESS;
                }
                else
                {
                    byteData = null;
                    return errCode;
                }
            }
            else
            {
                byteData = null;
                return ErrorCode.InvalidParameter;
            }
        }

        /// <inheritdoc/>
        public ErrorCode GetDiByteValue(ushort portNo, out byte byteData)
        {
            /// <inheritdoc/>
            if (_advanDatas.DeviceHandle != IntPtr.Zero)
            {
                byte DOStatus = 0;

                uint result = Motion.mAcm_DaqDiGetByte(_advanDatas.DeviceHandle, portNo, ref DOStatus);
                ErrorCode errCode = Enum.Parse<ErrorCode>(result.ToString());
                if (errCode == ErrorCode.SUCCESS)
                {
                    byteData = DOStatus;
                    return ErrorCode.SUCCESS;
                }
                else
                {
                    byteData = 0;
                    return errCode;
                }
            }
            else
            {
                byteData = 0;
                return ErrorCode.InvalidParameter;
            }
        }

        /********************
         * Init
         ********************/
        /// <summary>
        /// 初始化DO資訊。
        /// </summary>
        /// <returns>返回的錯誤碼。</returns>
        private ErrorCode InitDo()
        {
            uint result;
            ErrorCode errCode;

            result = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.FT_DaqDoMaxChan, ref _advanDatas.DoChannelNumber);
            errCode = Enum.Parse<ErrorCode>(result.ToString());

            if (errCode == ErrorCode.SUCCESS)
                _advanDatas.DoCount = _advanDatas.DoChannelNumber / 8;
            else
                ShowErrorMessage("DO設備初始化錯誤。", result);

            return errCode;
        }
    }
}
