﻿using Advantech.Motion;
using System.Text;

namespace AdvantechLib.Services
{
    internal static class CommonFunc
    {
        /// <summary>
        /// 取得錯誤訊息。
        /// </summary>
        /// <param name="errorCode">錯誤碼。</param>
        /// <returns>錯誤訊息。</returns>
        public static string GetErrorMessage(uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            bool res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);

            return res ? ErrorMsg.ToString() : "";
        }
    }
}
