﻿using Advantech.Core.Constants;
using AdvantechLib.Contracts;
using AdvantechLib.Services;
using AdvantechLib.ViewModels;
using AdvantechLib.Views;
using Prism.Ioc;
using Prism.Modularity;

namespace AdvantechLib
{
    public class AdvantechLibModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {
        }

        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<DeviceManager, DeviceManagerViewModel>(PageKeys.DeviceManager);
            containerRegistry.RegisterForNavigation<EthcatDo, EthcatDoViewModel>(PageKeys.EthcatDo);
            containerRegistry.RegisterForNavigation<EthcatDi, EthcatDiViewModel>(PageKeys.EthcatDi);
            containerRegistry.RegisterForNavigation<EthcatAo, EthcatAoViewModel>(PageKeys.EthcatAo);

            containerRegistry.Register<IAdvantech, AdvantechService>();
        }
    }
}