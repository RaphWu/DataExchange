﻿using Advantech.Motion;
using AdvantechLib.Contracts;
using AdvantechLib.Models;
using Prism.Mvvm;
using Prism.Regions;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Timers;

namespace AdvantechLib.ViewModels
{
    public class EthcatDoViewModel : BindableBase, INavigationAware
    {
        private readonly AdvantechData _advanDatas = AdvantechData.Instance;
        private readonly Timer _scanTimer;
        private readonly Timer _thunderboltTimer;

        /********************
         * INavigationAware
         ********************/
        public void OnNavigatedTo(NavigationContext navigationContext)
        {
            PageLoaded();
        }

        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
            PageClose();
        }

        public bool IsNavigationTarget(NavigationContext navigationContext) => true;

        /********************
         * ctor
         ********************/
        private readonly IAdvantech _advantech;

        public EthcatDoViewModel(IAdvantech advantech)
        {
            _advantech = advantech;

            _scanTimer = new Timer
            {
                Interval = 50,
                AutoReset = true
            };
            _scanTimer.Elapsed += RefreshDoValue;

            _thunderboltTimer = new Timer
            {
                Interval = 100,
                AutoReset = true,
            };
            _thunderboltTimer.Elapsed += ThunderboltEvent;
        }

        private void RefreshDoValue(object sender, ElapsedEventArgs e)
        {
            for (ushort portNo = 0; portNo < _advanDatas.DoCount; portNo++)
            {
                if (_advantech.GetDoByteValue(portNo, out byte portValue) == ErrorCode.SUCCESS
                    && DoList[portNo].ByteData != portValue)
                    DoList[portNo].ByteData = portValue;
            }
        }

        /********************
         * Device
         ********************/
        ///// <summary>
        ///// 開啟設備。
        ///// </summary>
        private void PageLoaded()
        {
            if (_advanDatas.IsOpen)
            {
                for (ushort portNo = 0; portNo < _advanDatas.DoCount; portNo++)
                    DoList.Add(new DigitalDataDemo(portNo));

                _scanTimer.Start();
            }
        }

        ///// <summary>
        ///// 關閉設備。
        ///// </summary>
        private void PageClose()
        {
            _scanTimer.Stop();
            Thunderbolt = false;
            DoList.Clear();
        }

        ///// <summary>
        ///// 開啟設備。
        ///// </summary>
        //public DelegateCommand OpenDeviceCommand
        //    => _openDeviceCommand ??= new DelegateCommand(ExecuteOpenDeviceCommand);
        //private void ExecuteOpenDeviceCommand()
        //{
        //    if (_advantech.OpenDeviceByDeviceNumber(_advanDatas.DeviceNumber) == ErrorCode.SUCCESS)
        //    {
        //        for (ushort portNo = 0; portNo < _advanDatas.DOCount; portNo++)
        //            DOList.Add(new DigitalIODemo(portNo));

        //        _scanTimer.Start();
        //    }
        //}
        //private DelegateCommand _openDeviceCommand;

        ///// <summary>
        ///// 關閉設備。
        ///// </summary>
        //public DelegateCommand CloseDeviceCommand
        //    => _closeDeviceCommand ??= new DelegateCommand(ExecuteCloseDeviceCommand);
        //private void ExecuteCloseDeviceCommand()
        //{
        //    _scanTimer.Stop();
        //    Thunderbolt = false;
        //    DOList.Clear();
        //    _ = _advantech.CloseDevice(_advanDatas.DeviceHandle);
        //}
        //private DelegateCommand _closeDeviceCommand;

        /********************
         * 霹靂燈測試
         ********************/
        private byte _masterDO;
        private bool _masterForw = true;
        private int _masterSpeedDiv;
        private List<byte> _slaveDO;
        private bool _slaveForw = true;

        /// <summary>
        /// 霹靂燈開關。
        /// </summary>
        public bool Thunderbolt
        {
            get { return _thunderbolt; }
            set
            {
                SetProperty(ref _thunderbolt, value);
                if (value)
                {
                    _masterDO = 0x01;
                    _masterSpeedDiv = 0;

                    _slaveDO = new List<byte>();
                    if (_advanDatas.DoCount > 1)
                    {
                        for (int poerNo = 0; poerNo < _advanDatas.DoCount; poerNo++)
                            _slaveDO.Add(0);
                        _slaveDO[0] = 0x01;
                        _slaveDO[1] = 0x01;
                        _slaveDO[2] = 0x00;
                        _slaveDO[3] = 0x00;
                    }

                    _thunderboltTimer.Start();
                }
                else
                {
                    _thunderboltTimer.Stop();
                }
            }
        }
        private bool _thunderbolt;

        private void ThunderboltEvent(object sender, ElapsedEventArgs e)
        {
            if (++_masterSpeedDiv % 3 == 0)
            {
                _advantech.SetDoByteValue(0, _masterDO);
                if (_masterForw)
                {
                    _masterDO = (byte)(_masterDO << 1);
                    if (_masterDO == 0x08)
                        _masterForw = false;
                }
                else
                {
                    _masterDO = (byte)(_masterDO >> 1);
                    if (_masterDO == 0x01)
                        _masterForw = true;
                }
            }

            if (_advanDatas.DoCount > 1)
            {
                for (ushort portNo = 1; portNo < _advanDatas.DoCount; portNo++)
                    _advantech.SetDoByteValue(portNo, _slaveDO[portNo - 1]);

                if (_slaveForw)
                {
                    if (_slaveDO[0] == 0x80)
                    {
                        _slaveDO[0] = 0x00;
                        _slaveDO[1] = 0x00;
                        _slaveDO[2] = 0x01;
                        _slaveDO[3] = 0x01;
                    }
                    else
                    {
                        _slaveDO[0] = (byte)(_slaveDO[0] << 1);
                        _slaveDO[1] = (byte)(_slaveDO[1] << 1);
                        _slaveDO[2] = (byte)(_slaveDO[2] << 1);
                        _slaveDO[3] = (byte)(_slaveDO[3] << 1);
                    }

                    if (_slaveDO[2] == 0x80)
                        _slaveForw = false;
                }
                else
                {
                    if (_slaveDO[2] == 0x01)
                    {
                        _slaveDO[0] = 0x80;
                        _slaveDO[1] = 0x80;
                        _slaveDO[2] = 0x00;
                        _slaveDO[3] = 0x00;
                    }
                    else
                    {
                        _slaveDO[0] = (byte)(_slaveDO[0] >> 1);
                        _slaveDO[1] = (byte)(_slaveDO[1] >> 1);
                        _slaveDO[2] = (byte)(_slaveDO[2] >> 1);
                        _slaveDO[3] = (byte)(_slaveDO[3] >> 1);
                    }

                    if (_slaveDO[0] == 0x01)
                        _slaveForw = true;
                }
            }
        }

        /********************
         * Property
         ********************/
        public ObservableCollection<DigitalDataDemo> DoList
        {
            get { return _doList; }
            set { SetProperty(ref _doList, value); }
        }
        private ObservableCollection<DigitalDataDemo> _doList = new();
    }
}
