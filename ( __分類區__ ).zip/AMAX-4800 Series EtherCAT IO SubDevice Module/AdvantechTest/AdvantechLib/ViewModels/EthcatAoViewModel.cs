﻿using Advantech.Motion;
using AdvantechLib.Contracts;
using AdvantechLib.Models;
using Glorytek.CSharp.Data;
using Glorytek.WPF.Helpers;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Channels;
using System.Timers;

namespace AdvantechLib.ViewModels
{
    public class EthcatAoViewModel : BindableBase, INavigationAware
    {
        private readonly AdvantechData _advanDatas = AdvantechData.Instance;
        private readonly Timer _scanTimer;

        /********************
         * INavigationAware
         ********************/
        public void OnNavigatedTo(NavigationContext navigationContext)
        {
            CanEditAoSetting = false;
            PageLoaded();
        }

        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
            PageClose();
        }

        public bool IsNavigationTarget(NavigationContext navigationContext) => true;

        /********************
         * ctor
         ********************/
        private readonly IAdvantech _advantech;

        public EthcatAoViewModel(IAdvantech advantech)
        {
            _advantech = advantech;

            _scanTimer = new Timer
            {
                Interval = 100,
                AutoReset = true
            };
            _scanTimer.Elapsed += RefreshAoValue;
        }

        private void RefreshAoValue(object sender, ElapsedEventArgs e)
        {
            _advantech.UpdateAoValue();
            for (int channel = 0; channel < AoList.Count; channel++)
                AoList[channel].Value = _advanDatas.AoChannelList[channel].Value;
        }

        /********************
         * Device
         ********************/
        ///// <summary>
        ///// 開啟設備。
        ///// </summary>
        private void PageLoaded()
        {
            if (_advanDatas.IsOpen)
            {
                AoList = new ObservableCollection<AnalogData>(_advanDatas.AoChannelList);

                float[] values = new float[AoList.Count];
                for (int channel = 0; channel < AoList.Count; channel++)
                {
                    var ch = _advanDatas.AoChannelList[channel];
                    ch.Enabled = true;
                    ch.Range = (double)AoRange.AO_NEG_10V_TO_10V;
                    values[channel] = channel + 1;
                }
                _advantech.SetAoEnable();
                _advantech.SetAoRange();
                _advantech.SetAoValue(values);

                //_advanDatas.RangeList = new()
                //{
                //    { 1, "111" },
                //    { 2, "111" },
                //    { 3, "111" },
                //    { 4, "111" }
                //};

                RangeList = _advanDatas.RangeList;

                _scanTimer.Start();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public Dictionary<double, string> RangeList
        {
            get { return _rangeList; }
            set { SetProperty(ref _rangeList, value); }
        }
        private Dictionary<double, string> _rangeList;

        ///// <summary>
        ///// 關閉設備。
        ///// </summary>
        private void PageClose()
        {
            _scanTimer.Stop();
            AoList.Clear();
        }

        /********************
         * Property
         ********************/
        /// <summary>
        /// 
        /// </summary>
        public ObservableCollection<AnalogData> AoList
        {
            get { return _aoList; }
            set { SetProperty(ref _aoList, value); }
        }
        private ObservableCollection<AnalogData> _aoList = new();

        /// <summary>
        /// 
        /// </summary>
        public AnalogData AoItem
        {
            get { return _aoItem; }
            set
            {
                SetProperty(ref _aoItem, value);

                EditChannel = value.Channel;
                EditEnabled = value.Enabled;
                EditRange = value.Range;
                EditValue = value.Value;
            }
        }
        private AnalogData _aoItem;

        /// <summary>
        /// 
        /// </summary>
        public bool CanEditAoSetting
        {
            get { return _canEditAoSetting; }
            set { SetProperty(ref _canEditAoSetting, value); }
        }
        private bool _canEditAoSetting = false;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand ApplyChannelCommand
            => _applyChannelCommand ??= new DelegateCommand(ExecuteApplyChannelCommand);
        private void ExecuteApplyChannelCommand()
        {
            _advanDatas.AoChannelList[(int)EditChannel].Enabled = EditEnabled;
            _advanDatas.AoChannelList[(int)EditChannel].Range = EditRange;
            _advantech.SetAoEnable(EditChannel);
            _advantech.SetAoRange(EditChannel);

            _advantech.SetAoValue(EditChannel, (float)(EditValue * EditProportion).Format(3));
        }
        private DelegateCommand _applyChannelCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand ApplyOutputCommand
            => _applyOutputCommand ??= new DelegateCommand(ExecuteApplyOutputCommand);
        private void ExecuteApplyOutputCommand()
        {
            _advantech.SetAoValue(EditChannel, (float)(EditValue * EditProportion).Format(3));
        }
        private DelegateCommand _applyOutputCommand;

        /********************
         * 
         ********************/
        /// <summary>
        /// 
        /// </summary>
        public uint EditChannel
        {
            get { return _editChannel; }
            set { SetProperty(ref _editChannel, value); }
        }
        private uint _editChannel;

        /// <summary>
        /// 
        /// </summary>
        public bool EditEnabled
        {
            get { return _editEnabled; }
            set { SetProperty(ref _editEnabled, value); }
        }
        private bool _editEnabled;

        /// <summary>
        /// 
        /// </summary>
        public double EditRange
        {
            get { return _editRange; }
            set
            {
                SetProperty(ref _editRange, value);

                _ = _advantech.GetMaxMinValue(Enum.Parse<AoRange>(value.ToString()),
                                              out double editValueMax,
                                              out double editValueMin,
                                              out double proportion,
                                              out string unit);
                EditValueMax = editValueMax;
                EditValueMin = editValueMin;
                EditProportion = proportion;
                Unit = unit;
            }
        }
        private double _editRange;

        /// <summary>
        /// 
        /// </summary>
        public float EditValue
        {
            get { return _editValue; }
            set { SetProperty(ref _editValue, value); }
        }
        private float _editValue;

        /// <summary>
        /// 
        /// </summary>
        public double EditValueMax
        {
            get { return _editValueMax; }
            set { SetProperty(ref _editValueMax, value); }
        }
        private double _editValueMax;

        /// <summary>
        /// 
        /// </summary>
        public double EditValueMin
        {
            get { return _editValueMin; }
            set { SetProperty(ref _editValueMin, value); }
        }
        private double _editValueMin;

        /// <summary>
        /// 
        /// </summary>
        public double EditProportion
        {
            get { return _editProportion; }
            set { SetProperty(ref _editProportion, value); }
        }
        private double _editProportion;

        /// <summary>
        /// 
        /// </summary>
        public string Unit
        {
            get { return _unit; }
            set { SetProperty(ref _unit, value); }
        }
        private string _unit;
    }
}
