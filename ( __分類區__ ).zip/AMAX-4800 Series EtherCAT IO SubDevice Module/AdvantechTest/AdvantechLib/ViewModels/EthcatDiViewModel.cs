﻿using Advantech.Motion;
using AdvantechLib.Contracts;
using AdvantechLib.Models;
using Prism.Mvvm;
using Prism.Regions;
using System.Collections.ObjectModel;
using System.Timers;

namespace AdvantechLib.ViewModels
{
    public class EthcatDiViewModel : BindableBase, INavigationAware
    {
        private readonly AdvantechData _advanDatas = AdvantechData.Instance;
        private readonly Timer _scanTimer;

        /********************
         * INavigationAware
         ********************/
        public void OnNavigatedTo(NavigationContext navigationContext)
        {
            PageLoaded();
        }

        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
            PageClose();
        }

        public bool IsNavigationTarget(NavigationContext navigationContext) => true;

        /********************
         * ctor
         ********************/
        private readonly IAdvantech _advantech;

        public EthcatDiViewModel(IAdvantech advantech)
        {
            _advantech = advantech;

            _scanTimer = new Timer
            {
                Interval = 100,
                AutoReset = true
            };
            _scanTimer.Elapsed += UpdateDIValue;
        }

        private void UpdateDIValue(object sender, ElapsedEventArgs e)
        {
            if (_advantech.GetDiBytesValue(0, (ushort)_advanDatas.DoCount, out byte[] portValue) == ErrorCode.SUCCESS)
            {
                for (int portNo = 0; portNo < _advanDatas.DoCount; portNo++)
                    DiList[portNo].ByteData = portValue[portNo];
            }
        }

        /********************
         * Device
         ********************/
        ///// <summary>
        ///// 開啟設備。
        ///// </summary>
        private void PageLoaded()
        {
            if (_advanDatas.IsOpen)
            {
                for (ushort portNo = 0; portNo < _advanDatas.DoCount; portNo++)
                    DiList.Add(new DigitalDataDemo(portNo));

                _scanTimer.Start();
            }
        }

        ///// <summary>
        ///// 關閉設備。
        ///// </summary>
        private void PageClose()
        {
            _scanTimer.Stop();
            DiList.Clear();
        }

        ///// <summary>
        ///// 開啟設備。
        ///// </summary>
        //public DelegateCommand OpenDeviceCommand
        //    => _openDeviceCommand ??= new DelegateCommand(ExecuteOpenDeviceCommand);
        //private void ExecuteOpenDeviceCommand()
        //{
        //    if (_advantech.OpenDeviceByDeviceNumber(_advanDatas.DeviceNumber) == ErrorCode.SUCCESS)
        //    {
        //        for (ushort portNo = 0; portNo < _advanDatas.DOCount; portNo++)
        //            DiList.Add(new DigitalIODemo(portNo));

        //        _scanTimer.Start();
        //    }
        //}
        //private DelegateCommand _openDeviceCommand;

        ///// <summary>
        ///// 關閉設備。
        ///// </summary>
        //public DelegateCommand CloseDeviceCommand
        //    => _closeDeviceCommand ??= new DelegateCommand(ExecuteCloseDeviceCommand);
        //private void ExecuteCloseDeviceCommand()
        //{
        //    _scanTimer.Stop();
        //    DiList.Clear();
        //    _ = _advantech.CloseDevice(_advanDatas.DeviceHandle);
        //}
        //private DelegateCommand _closeDeviceCommand;

        /********************
         * Property
         ********************/
        public ObservableCollection<DigitalDataDemo> DiList
        {
            get { return _diList; }
            set { SetProperty(ref _diList, value); }
        }
        private ObservableCollection<DigitalDataDemo> _diList = new();
    }
}
