﻿using AdvantechLib.Contracts;
using AdvantechLib.Models;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;

namespace AdvantechLib.ViewModels
{
    public class DeviceManagerViewModel : BindableBase, INavigationAware
    {
        private readonly AdvantechData _advanDatas = AdvantechData.Instance;

        /********************
         * INavigationAware
         ********************/
        public void OnNavigatedTo(NavigationContext navigationContext)
        {
            _advantech.UpdateDeviceList();
        }

        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
        }

        public bool IsNavigationTarget(NavigationContext navigationContext) => true;

        /********************
         * ctor
         ********************/
        private readonly IAdvantech _advantech;

        public DeviceManagerViewModel(IAdvantech advantech)
        {
            _advantech = advantech;
            ConfigFileName = "PCI1203_IO_table.xml";
        }

        /********************
         * Device
         ********************/
        /// <summary>
        /// 
        /// </summary>
        public string ConfigFileName
        {
            get { return _configFileName; }
            set { SetProperty(ref _configFileName, value); }
        }
        private string _configFileName;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand OpenDeviceByConfigFileCommand
            => _openDeviceByConfigFileCommand ??= new DelegateCommand(ExecuteOpenDeviceByConfigFileCommand);
        private void ExecuteOpenDeviceByConfigFileCommand()
        {
            _advantech.OpenDevice(ConfigFileName);
        }
        private DelegateCommand _openDeviceByConfigFileCommand;

        /// <summary>
        /// 開啟設備。
        /// </summary>
        public DelegateCommand OpenSelectedDeviceCommand
           => _openSelectedDeviceCommand ??= new DelegateCommand(ExecuteOpenSelectedDeviceCommand);
        private void ExecuteOpenSelectedDeviceCommand()
        {
            _ = _advantech.OpenDeviceByDeviceNumber(_advanDatas.DeviceNumber);
        }
        private DelegateCommand _openSelectedDeviceCommand;

        /// <summary>
        /// 關閉設備。
        /// </summary>
        public DelegateCommand CloseDeviceCommand
            => _closeDeviceCommand ??= new DelegateCommand(ExecuteCloseDeviceCommand);
        private void ExecuteCloseDeviceCommand()
        {
            _ = _advantech.CloseDevice();
        }
        private DelegateCommand _closeDeviceCommand;
    }
}
