﻿using Advantech.Motion;
using Prism.Mvvm;
using System;

namespace AdvantechLib.Models
{
    public class AnalogData : BindableBase
    {
        public AnalogData(uint channel)
        {
            Channel = channel;
        }

        /// <summary>
        /// 通道啟用。
        /// </summary>
        public bool Enabled
        {
            get { return _enabled; }
            set { SetProperty(ref _enabled, value); }
        }
        private bool _enabled;

        /// <summary>
        /// 通道。
        /// </summary>
        public uint Channel
        {
            get { return _channel; }
            set { SetProperty(ref _channel, value); }
        }
        private uint _channel;

        /// <summary>
        /// 讀取值。
        /// </summary>
        public float Value
        {
            get { return _value; }
            set { SetProperty(ref _value, value); }
        }
        private float _value;

        /// <summary>
        /// AO範圍設定值。
        /// </summary>
        public double Range
        {
            get { return _range; }
            set
            {
                SetProperty(ref _range, value);

                RangeString = Enum.Parse<AoRange>(value.ToString()) switch
                {
                    AoRange.AO_NEG_10V_TO_10V => "+/-10V",
                    AoRange.AO_NEG_5V_TO_5V => "+/-5V",
                    AoRange.AO_NEG_2500MV_TO_2500MV => "+/-2.5V",
                    AoRange.AO_NEG_1250MV_TO_1250MV => "+/-1.25V",
                    AoRange.AO_NEG_625MV_TO_625MV => "+/-0.625",
                    AoRange.AO_NEG_0V_TO_10V => "0~10V",
                    AoRange.AO_NEG_0V_TO_5V => "0~5V",
                    AoRange.AO_0MA_TO_20MA => "0~20mA",
                    AoRange.AO_4MA_TO_20MA => "4~20mA",
                    _ => "",
                };
            }
        }
        private double _range;

        /// <summary>
        /// AO範圍設定值顯示字串。
        /// </summary>
        public string RangeString
        {
            get { return _rangeString; }
            set { SetProperty(ref _rangeString, value); }
        }
        private string _rangeString = "";
    }
}
