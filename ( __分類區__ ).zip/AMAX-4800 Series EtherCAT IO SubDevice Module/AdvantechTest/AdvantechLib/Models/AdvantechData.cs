﻿using Advantech.Motion;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AdvantechLib.Models
{
    public class AdvantechData : BindableBase
    {
        private AdvantechData() { }
        private static readonly Lazy<AdvantechData> _instance = new(() => new AdvantechData());
        public static AdvantechData Instance => _instance.Value;

        /********************
         * 設備
         ********************/
        /// <summary>
        /// 設備是否啟用。
        /// </summary>
        public bool IsOpen
        {
            get { return _isOpen; }
            set { SetProperty(ref _isOpen, value); }
        }
        private bool _isOpen;

        /// <summary>
        /// 啟用的設備編號。
        /// </summary>
        public uint DeviceNumber { get; set; }

        /// <summary>
        /// 已開啟的設備Handle。
        /// </summary>
        public IntPtr DeviceHandle = IntPtr.Zero;

        /********************
         * Digital Output
         ********************/
        /// <summary>
        /// 可用數位輸出通道數。
        /// </summary>
        public uint DoChannelNumber = 128;

        /// <summary>
        /// 可用數位輸出設備數。
        /// </summary>
        public uint DoCount = 0;

        /********************
         * Digital Input
         ********************/
        /// <summary>
        /// 可用數位輸入通道數。
        /// </summary>
        public uint DiChannelNumber = 128;

        /// <summary>
        /// 可用數位輸入設備數。
        /// </summary>
        public uint DiCount = 0;

        /********************
         * Analog Output
         ********************/
        /// <summary>
        /// 板卡支持的AO範圍。
        /// </summary>
        public Dictionary<double, string> RangeList = new();

        /// <summary>
        /// 可用類比輸出通道數。
        /// </summary>
        public uint AoChannelNumber = 128;

        ///// <summary>
        ///// 可用類比輸出設備數。
        ///// </summary>
        //public uint AoCount = 0;

        /// <summary>
        /// AO各通道內容。
        /// </summary>
        public List<AnalogData> AoChannelList
        {
            get { return _aoChannelList; }
            set { SetProperty(ref _aoChannelList, value); }
        }
        private List<AnalogData> _aoChannelList = new();

        /********************
         * Library
         ********************/
        /// <summary>
        /// Library讀入的所有可用設備清單。
        /// </summary>
        public DEV_LIST[] CurrentAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];

        /// <summary>
        /// Library讀入的所有可用設備數。
        /// </summary>
        public uint DeviceCount = 0;

        /********************
         * 設備名稱列表
         ********************/
        /// <summary>
        /// 可用設備名稱列表。
        /// </summary>
        public List<string> AvailableDeviceList
        {
            get { return _availableDeviceList; }
            set { SetProperty(ref _availableDeviceList, value); }
        }
        private List<string> _availableDeviceList = new();

        /// <summary>
        /// 選取的可用設備名稱。
        /// </summary>
        public string CurrentAvailableDevice
        {
            get { return _currentAvailableDevice; }
            set
            {
                SetProperty(ref _currentAvailableDevice, value);
                if (!string.IsNullOrEmpty(value))
                {
                    var dev = CurrentAvailableDevs.FirstOrDefault(x => x.DeviceName == value);
                    DeviceNumber = dev.DeviceNum;
                }
            }
        }
        private string _currentAvailableDevice;
    }
}
