﻿using Prism.Mvvm;

namespace AdvantechLib.Models
{
    public class DigitalDataDemo : BindableBase
    {
        public DigitalDataDemo(ushort port)
        {
            Port = port;
            ByteData = 0;
        }

        public ushort Port
        {
            get { return _port; }
            set { SetProperty(ref _port, value); }
        }
        private ushort _port;

        public bool Bit0
        {
            get { return _bit0; }
            set { SetProperty(ref _bit0, value); }
        }
        private bool _bit0;

        public bool Bit1
        {
            get { return _bit1; }
            set { SetProperty(ref _bit1, value); }
        }
        private bool _bit1;

        public bool Bit2
        {
            get { return _bit2; }
            set { SetProperty(ref _bit2, value); }
        }
        private bool _bit2;

        public bool Bit3
        {
            get { return _bit3; }
            set { SetProperty(ref _bit3, value); }
        }
        private bool _bit3;

        public bool Bit4
        {
            get { return _bit4; }
            set { SetProperty(ref _bit4, value); }
        }
        private bool _bit4;

        public bool Bit5
        {
            get { return _bit5; }
            set { SetProperty(ref _bit5, value); }
        }
        private bool _bit5;

        public bool Bit6
        {
            get { return _bit6; }
            set { SetProperty(ref _bit6, value); }
        }
        private bool _bit6;

        public bool Bit7
        {
            get { return _bit7; }
            set { SetProperty(ref _bit7, value); }
        }
        private bool _bit7;

        public byte ByteData
        {
            get { return _byteData; }
            set
            {
                if (_byteData != value)
                {
                    SetProperty(ref _byteData, value);
                    Bit0 = (value & 0x01) != 0;
                    Bit1 = (value & 0x02) != 0;
                    Bit2 = (value & 0x04) != 0;
                    Bit3 = (value & 0x08) != 0;
                    Bit4 = (value & 0x10) != 0;
                    Bit5 = (value & 0x20) != 0;
                    Bit6 = (value & 0x40) != 0;
                    Bit7 = (value & 0x80) != 0;
                }
            }
        }
        private byte _byteData;
    }
}
