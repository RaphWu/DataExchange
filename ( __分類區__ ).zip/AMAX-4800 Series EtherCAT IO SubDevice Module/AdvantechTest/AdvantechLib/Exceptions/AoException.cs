﻿using System;
using System.Runtime.Serialization;

namespace AdvantechLib.Exceptions
{
    public class AoException : Exception, ISerializable
    {
        public AoException() : base("AO異常") { }
        public AoException(string message) : base(message) { }
        public AoException(string message, Exception inner) : base(message, inner) { }
        protected AoException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
