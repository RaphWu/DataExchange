﻿using Advantech.Core.Constants;
using Prism.Regions;
using System.Windows.Controls;

namespace AdvantechLib.Views
{
    /// <summary>
    /// Interaction logic for ViewA.xaml
    /// </summary>
    public partial class EthcatDo : UserControl
    {
        public EthcatDo(IRegionManager regionManager)
        {
            InitializeComponent();
            regionManager.RegisterViewWithRegion(RegionNames.DeviceManagerRegionDo, nameof(DeviceManager));
        }
    }
}
