﻿using Advantech.Core.Constants;
using Prism.Regions;
using System.Windows.Controls;

namespace AdvantechLib.Views
{
    /// <summary>
    /// Interaction logic for EthcatDI
    /// </summary>
    public partial class EthcatDi : UserControl
    {
        public EthcatDi(IRegionManager regionManager)
        {
            InitializeComponent();
            regionManager.RegisterViewWithRegion(RegionNames.DeviceManagerRegionDi, nameof(DeviceManager));
        }
    }
}
