﻿using System.Windows.Controls;

namespace AdvantechLib.Views
{
    /// <summary>
    /// Interaction logic for EthcatDAC
    /// </summary>
    public partial class EthcatAo : UserControl
    {
        public EthcatAo()
        {
            InitializeComponent();
        }
    }
}
