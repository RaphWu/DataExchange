﻿using System.Windows.Controls;

namespace AdvantechLib.Views
{
    /// <summary>
    /// Interaction logic for DeviceManager
    /// </summary>
    public partial class DeviceManager : UserControl
    {
        public DeviceManager()
        {
            InitializeComponent();
        }
    }
}
