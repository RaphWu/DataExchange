﻿using Advantech.Motion;

namespace AdvantechLib.Contracts
{
    public interface IAdvantech : IAdvantech_DIO, IAdvantech_AIO
    {
        /// <summary>
        /// 更新可用設備名稱列表。
        /// </summary>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode UpdateDeviceList();

        /// <summary>
        /// 使用設備編號開啟設備。
        /// </summary>
        /// <param name="deviceNumber">設備編號。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode OpenDeviceByDeviceNumber(uint deviceNumber);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        ErrorCode OpenDevice(string configFileName);

        /// <summary>
        /// 關閉設備。
        /// </summary>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode CloseDevice();
    }
}
