﻿using Advantech.Motion;

namespace AdvantechLib.Contracts
{
    public interface IAdvantech_AIO
    {
        /********************
         * Enabled
         ********************/
        /// <summary>
        /// 更新指定AO通道的啟用/禁用狀態。
        /// </summary>
        /// <param name="channel">指定的AO通道。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode UpdateAoEnable(uint channel);

        /// <summary>
        /// 更新所有AO通道的啟用/禁用狀態。
        /// </summary> 
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode UpdateAoEnable();

        /// <summary>
        /// 設定指定AO通道的啟用/禁用狀態。
        /// </summary>
        /// <param name="channel">指定的AO通道。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode SetAoEnable(uint channel);

        /// <summary>
        /// 設定所有AO通道的啟用/禁用狀態。
        /// </summary> 
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode SetAoEnable();

        /********************
         * Range
         ********************/
        /// <summary>
        /// 更新指定AO通道的範圍設定值。
        /// </summary>
        /// <param name="channel">指定的AO通道。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode UpdateAoRange(uint channel);

        /// <summary>
        /// 更新所有AO通道的範圍設定值。
        /// </summary>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode UpdateAoRange();

        /// <summary>
        /// 設定指定AO通道的範圍設定值。
        /// </summary>
        /// <param name="channel">指定的AO通道。</param>
        /// <param name="range">AO範圍設定值。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode SetAoRange(uint channel);

        /// <summary>
        /// 設定所有AO通道的範圍設定值。
        /// </summary>
        /// <param name="range">AO範圍設定值。</param>
        /// <returns>返回的錯誤碼。</returns>
        /// <remarks>Disable的Channel會自動跳過。</remarks>
        ErrorCode SetAoRange();

        /// <summary>
        /// 以Range取得AO範圍設定值。
        /// </summary>
        /// <param name="range">設定的Range值。</param>
        /// <param name="MaxValue">取得的最大值。</param>
        /// <param name="MinValue">取得的最小值。</param>
        /// <param name="EditProportion">比例，實際值要乘上此值。</param>
        /// <param name="Unit">單位。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode GetMaxMinValue(AoRange range, out double MaxValue, out double MinValue, out double EditProportion, out string Unit);

        /********************
         * Value
         ********************/
        /// <summary>
        /// 更新指定AO通道的AO值。
        /// </summary>
        /// <param name="channel">指定的AO通道。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode UpdateAoValue(uint channel);

        /// <summary>
        /// 更新所有AO通道的AO值。
        /// </summary>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode UpdateAoValue();

        /// <summary>
        /// 設定指定AO通道的AO值。
        /// </summary>
        /// <param name="channel">指定的AO通道。</param>
        /// <param name="value">設定AO值。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode SetAoValue(uint channel, float value);

        /// <summary>
        /// 設定所有AO通道的AO值。
        /// </summary>
        /// <param name="values">設定AO值。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode SetAoValue(float[] values);
    }
}
