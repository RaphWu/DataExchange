﻿using Advantech.Motion;

namespace AdvantechLib.Contracts
{
    public interface IAdvantech_DIO
    {
        /********************
         * Digital Output
         ********************/
        /// <summary>
        /// 讀取指定DO Port的byte值。
        /// </summary>
        /// <param name="portNo">DO Port編號。</param>
        /// <param name="byteData">讀取的byte值。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode GetDoByteValue(ushort portNo, out byte byteData);

        /// <summary>
        /// 將byte值指定給DO Port。
        /// </summary>
        /// <param name="portNo">DO Port編號。</param>
        /// <param name="byteData">要設定的byte值。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode SetDoByteValue(ushort portNo, byte byteData);

        /********************
         * Digital Input
         ********************/
        /// <summary>
        /// 讀取從DI Port開始連續numPort個Port的byte值。
        /// </summary>
        /// <param name="portNo">DI Port編號。</param>
        /// <param name="numPort">讀取Port數。</param>
        /// <param name="byteData">讀取的byte[]值。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode GetDiBytesValue(ushort portNo, ushort numPort, out byte[] byteData);

        /// <summary>
        /// 讀取指定DI Port的byte值。
        /// </summary>
        /// <param name="portNo">DI Port編號。</param>
        /// <param name="byteData">讀取的byte值。</param>
        /// <returns>返回的錯誤碼。</returns>
        ErrorCode GetDiByteValue(ushort portNo, out byte byteData);
    }
}
