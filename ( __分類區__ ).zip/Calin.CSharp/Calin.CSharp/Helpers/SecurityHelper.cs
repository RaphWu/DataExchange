﻿using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace Calin.CSharp.Helpers
{
    /// <summary>
    /// 提供加密、解密及雜湊相關的安全性輔助方法。
    /// </summary>
    public static class SecurityHelper
    {
        private static readonly byte[] Key = Encoding.UTF8.GetBytes("Your32ByteLengthKeyHere!");
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("16ByteIVVector!");

        /// <summary>
        /// 使用 AES 加密演算法加密純文字。
        /// </summary>
        /// <param name="plainText">要加密的純文字。</param>
        /// <returns>加密後的字串（Base64 編碼）。</returns>
        public static string EncryptAES(string plainText)
        {
            using (var aes = Aes.Create())
            {
                aes.Key = Key; aes.IV = IV;
                using (var ms = new MemoryStream())
                using (var cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
                using (var sw = new StreamWriter(cs))
                {
                    sw.Write(plainText); sw.Flush(); cs.FlushFinalBlock();
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }

        /// <summary>
        /// 使用 AES 解密演算法解密加密字串。
        /// </summary>
        /// <param name="cipherText">要解密的加密字串（Base64 編碼）。</param>
        /// <returns>解密後的純文字。</returns>
        public static string DecryptAES(string cipherText)
        {
            var buffer = Convert.FromBase64String(cipherText);
            using (var aes = Aes.Create())
            {
                aes.Key = Key; aes.IV = IV;
                using (var ms = new MemoryStream(buffer))
                using (var cs = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read))
                using (var sr = new StreamReader(cs))
                {
                    return sr.ReadToEnd();
                }
            }
        }

        /// <summary>
        /// MD5加密。
        /// </summary>
        /// <param name="textToEncrypt">待加密字串。</param>
        /// <returns>加密後字串。若為空字串表示演算失敗。</returns>
        public static string GetMD5Hash(this string textToEncrypt)
        {
            using (var cryptoMD5 = global::System.Security.Cryptography.MD5.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(textToEncrypt);                  //將字串編碼成 UTF8 位元組陣列
                var hash = cryptoMD5.ComputeHash(bytes);                            //取得雜湊值位元組陣列
                var md5 = BitConverter.ToString(hash).Replace("-", string.Empty);   //取得 MD5
                return md5;
            }
        }

        /// <summary>
        /// 驗證MD5值。
        /// </summary>
        /// <param name="str">待比較的值。</param>
        /// <param name="hash">被比較的MD5 Hash字串。</param>
        /// <returns>驗證結果。</returns>
        public static bool VerifyMD5Hash(string str, string hash)
        {
            string hashOfInput = str.GetMD5Hash();
            return hashOfInput.CompareTo(hash) == 0;
        }

        /// <summary>
        /// 使用 PBKDF2 演算法產生密碼的雜湊值。
        /// </summary>
        /// <param name="password">要雜湊的密碼。</param>
        /// <returns>包含鹽值與雜湊值的 Base64 編碼字串。</returns>
        public static string HashPassword(string password)
        {
            using (var rfc = new Rfc2898DeriveBytes(password, 16, 10000))
            {
                var salt = rfc.Salt;
                var hash = rfc.GetBytes(32);
                var result = new byte[48];
                Buffer.BlockCopy(salt, 0, result, 0, 16);
                Buffer.BlockCopy(hash, 0, result, 16, 32);
                return Convert.ToBase64String(result);
            }
        }

        /// <summary>
        /// 驗證密碼是否與雜湊值相符。
        /// </summary>
        /// <param name="password">要驗證的密碼。</param>
        /// <param name="hashed">包含鹽值與雜湊值的 Base64 編碼字串。</param>
        /// <returns>如果密碼與雜湊值相符則為 true，否則為 false。</returns>
        public static bool VerifyPassword(string password, string hashed)
        {
            var bytes = Convert.FromBase64String(hashed);
            var salt = new byte[16]; Buffer.BlockCopy(bytes, 0, salt, 0, 16);
            var hash = new byte[32]; Buffer.BlockCopy(bytes, 16, hash, 0, 32);
            using (var rfc = new Rfc2898DeriveBytes(password, salt, 10000))
            {
                return rfc.GetBytes(32).SequenceEqual(hash);
            }
        }
    }
}
