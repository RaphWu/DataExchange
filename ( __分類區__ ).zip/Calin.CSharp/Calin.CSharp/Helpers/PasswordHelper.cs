﻿using System;
using System.Security.Cryptography;

namespace Calin.CSharp.Helpers
{
    /// <summary>
    /// 提供密碼雜湊與驗證的輔助方法。
    /// </summary>
    public static class PasswordHelper
    {
        private const int SaltSize = 16; // 128 位元
        private const int KeySize = 32;  // 256 位元
        private const int Iterations = 10000;

        /// <summary>
        /// 將提供的密碼進行雜湊處理，並返回包含鹽值的雜湊字串。
        /// </summary>
        /// <param name="password">要雜湊的密碼。</param>
        /// <returns>包含鹽值的 Base64 編碼雜湊字串。</returns>
        public static string HashPassword(string password)
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                byte[] salt = new byte[SaltSize];
                rng.GetBytes(salt);

                using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, Iterations))
                {
                    var key = pbkdf2.GetBytes(KeySize);
                    var hashBytes = new byte[SaltSize + KeySize];
                    Buffer.BlockCopy(salt, 0, hashBytes, 0, SaltSize);
                    Buffer.BlockCopy(key, 0, hashBytes, SaltSize, KeySize);
                    return Convert.ToBase64String(hashBytes);
                }
            }
        }

        /// <summary>
        /// 驗證提供的密碼是否與儲存的雜湊密碼相符。
        /// </summary>
        /// <param name="password">要驗證的密碼。</param>
        /// <param name="hashedPassword">儲存的 Base64 編碼雜湊密碼。</param>
        /// <returns>如果密碼驗證成功則返回 true，否則返回 false。</returns>
        public static bool VerifyPassword(string password, string hashedPassword)
        {
            var hashBytes = Convert.FromBase64String(hashedPassword);
            byte[] salt = new byte[SaltSize];
            Buffer.BlockCopy(hashBytes, 0, salt, 0, SaltSize);

            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, Iterations))
            {
                var key = pbkdf2.GetBytes(KeySize);
                for (int i = 0; i < KeySize; i++)
                {
                    if (hashBytes[i + SaltSize] != key[i])
                        return false;
                }
                return true;
            }
        }
    }
}
