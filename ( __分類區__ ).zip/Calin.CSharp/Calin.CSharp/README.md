﻿# Calin.CSharp

Calin.CSharp 是佳凌科技關於 C# 應用程式開發的組件庫，旨在提供 C# 

# 目標框架

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0

# NuGet 依賴

- AutoFac
- Serilog
	- Serilog.Sinks.File
	- Serilog.Formatting.Compact
