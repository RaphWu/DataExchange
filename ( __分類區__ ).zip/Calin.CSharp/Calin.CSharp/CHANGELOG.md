﻿# Calin.Csharp

## 2026-01-13 v0.0.3

- 所以共用模組的版本號重新編排
- 合併 TaskPulse V1 建立的基礎架構庫
	- 合併 Extensions 及 Helpers 的函數庫
	- 新璔 Calin.CSharp.Framework.Coordination;
	- 新璔 Calin.CSharp.Framework.Logging;

## 2025-10-07 v1.0.3

- 新增自動版本遞增功能
- EnumHelper 新增 `public static string GetDescription<T>(string propertyName)`

## Calin.Csharp v1.0.1

2025-09-30
- x86改回AnyCPU

## Calin.Csharp v1.0.0

2025-09-25
- 初版
