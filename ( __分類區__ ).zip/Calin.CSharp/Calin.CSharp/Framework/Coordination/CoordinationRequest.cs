using System;
using System.Collections.Generic;

namespace Calin.CSharp.Framework.Coordination
{
    /// <summary>
    /// ��սШD����¦��@�C
    /// �ШD�����i�ܴy�z����A�ȴy�z�u�o�ͤF����v�C
    /// </summary>
    public class CoordinationRequest : ICoordinationRequest
    {
        /// <inheritdoc/>
        public string RequestId { get; }

        /// <inheritdoc/>
        public string RequestType { get; }

        /// <summary>
        /// ���o�ШD���B�~�W�U���ơC
        /// </summary>
        public IReadOnlyDictionary<string, object> Context { get; }

        /// <summary>
        /// ��l�ƨ�սШD�C
        /// </summary>
        /// <param name="requestType">�ШD�������ѡC</param>
        /// <param name="context">�i�諸�W�U���ơC</param>
        public CoordinationRequest(string requestType, IDictionary<string, object> context = null)
        {
            if (string.IsNullOrWhiteSpace(requestType))
                throw new ArgumentNullException(nameof(requestType));

            RequestId = Guid.NewGuid().ToString("N");
            RequestType = requestType;
            Context = context != null
                ? new Dictionary<string, object>(context)
                : new Dictionary<string, object>();
        }

        /// <summary>
        /// ��l�ƨ�սШD�A�ϥΫ��w�� RequestId�C
        /// </summary>
        /// <param name="requestId">�ШD�ߤ@�ѧO�X�C</param>
        /// <param name="requestType">�ШD�������ѡC</param>
        /// <param name="context">�i�諸�W�U���ơC</param>
        public CoordinationRequest(string requestId, string requestType, IDictionary<string, object> context = null)
        {
            if (string.IsNullOrWhiteSpace(requestId))
                throw new ArgumentNullException(nameof(requestId));
            if (string.IsNullOrWhiteSpace(requestType))
                throw new ArgumentNullException(nameof(requestType));

            RequestId = requestId;
            RequestType = requestType;
            Context = context != null
                ? new Dictionary<string, object>(context)
                : new Dictionary<string, object>();
        }
    }
}
