﻿using Autofac;
using Calin.CSharp.Framework.Coordination;
using Calin.CSharp.Framework.Logging;

namespace Calin.CSharp
{
    public class CSharpModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterModule<LoggingModule>();
            builder.RegisterModule<CoordinationModule>();
        }
    }
}
