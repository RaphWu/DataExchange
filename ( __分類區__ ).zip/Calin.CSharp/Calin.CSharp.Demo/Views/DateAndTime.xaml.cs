﻿using System.Windows.Controls;

namespace Calin.CSharp.Demo.Views
{
    /// <summary>
    /// DateAndTime.xaml 的互動邏輯
    /// </summary>
    public partial class DateAndTime : UserControl
    {
        public DateAndTime()
        {
            InitializeComponent();
        }
    }
}
