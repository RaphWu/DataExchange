﻿namespace Calin.CSharp.Demo.Constants
{
    public class RegionNames
    {
        public const string MainRegion = "MainRegion";
    }
}
