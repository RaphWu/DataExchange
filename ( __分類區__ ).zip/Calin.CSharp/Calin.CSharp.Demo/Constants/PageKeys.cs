﻿namespace Calin.CSharp.Demo.Constants
{
    public class PageKeys
    {
        public const string DateAndTime = "DateAndTime";
    }
}
