﻿namespace Calin.CSharp.Demo.Services
{
    public enum AppTheme
    {
        Default,
        Light,
        Dark
    }
}
