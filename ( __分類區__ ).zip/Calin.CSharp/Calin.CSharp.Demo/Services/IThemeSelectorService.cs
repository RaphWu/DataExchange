﻿namespace Calin.CSharp.Demo.Services
{
    // 修改自Template Studio for WPF
    /// <summary>
    /// 佈景主題服務介面。
    /// </summary>
    public interface IThemeSelectorService
    {
        void InitializeTheme();

        void SetTheme(AppTheme theme);

        AppTheme GetCurrentTheme();
    }
}
