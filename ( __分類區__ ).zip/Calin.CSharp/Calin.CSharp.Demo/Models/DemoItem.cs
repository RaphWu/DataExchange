﻿namespace Calin.CSharp.Demo.Models
{
    public class DemoItem
    {
        public DemoItem(string name, string pageKey)
        {
            Name = name;
            PageKey = pageKey;
        }

        public string Name { get; }
        public string PageKey { get; }
    }
}
