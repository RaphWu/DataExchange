﻿using RJCP.IO.Ports;

namespace Calin.SerialPort
{
    /// <summary>
    /// SerialPort 設定類別。
    /// </summary>
    public sealed class SerialPortConfig
    {
        /// <summary>
        /// 取得或設定 SerialPort 的名稱。
        /// 預設值為 "COM1"。
        /// </summary>
        public string PortName { get; set; } = "COM1";

        /// <summary>
        /// 取得或設定 SerialPort 的鮑率。
        /// 預設值為 9600。
        /// </summary>
        public int BaudRate { get; set; } = 9600;

        /// <summary>
        /// 取得或設定 SerialPort 的資料位元數。
        /// 預設值為 8。
        /// </summary>
        public int DataBits { get; set; } = 8;

        /// <summary>
        /// 取得或設定 SerialPort 的同位位元。
        /// 預設值為 <see cref="Parity.None"/>。
        /// </summary>
        public Parity Parity { get; set; } = Parity.None;

        /// <summary>
        /// 取得或設定 SerialPort 的停止位元。
        /// 預設值為 <see cref="StopBits.One"/>。
        /// </summary>
        public StopBits StopBits { get; set; } = StopBits.One;

        /// <summary>
        /// 取得或設定 SerialPort 的交握模式。
        /// 預設值為 <see cref="Handshake.None"/>。
        /// </summary>
        public Handshake Handshake { get; set; } = Handshake.None;

        /// <summary>
        /// 取得或設定 SerialPort 的讀取逾時時間（毫秒）。
        /// 預設值為 1000 毫秒。
        /// </summary>
        public int ReadTimeout { get; set; } = 1000;

        /// <summary>
        /// 取得或設定 SerialPort 的寫入逾時時間（毫秒）。
        /// 預設值為 1000 毫秒。
        /// </summary>
        public int WriteTimeout { get; set; } = 1000;

        /// <summary>
        /// 取得或設定是否啟用 RTS (Request to Send) 信號。
        /// 預設值為 false。
        /// </summary>
        public bool RtsEnable { get; set; } = false;

        /// <summary>
        /// 取得或設定是否啟用 DTR (Data Terminal Ready) 信號。
        /// 預設值為 false。
        /// </summary>
        public bool DtrEnable { get; set; } = false;

        /// <summary>
        /// 取得或設定是否啟用自動重連機制。
        /// 預設值為 false。
        /// </summary>
        public bool EnableAutoReconnect { get; set; } = false;

        /// <summary>
        /// 取得或設定自動重連的間隔時間（毫秒）。
        /// 預設值為 5000 毫秒 (5 秒)。
        /// </summary>
        public int ReconnectInterval { get; set; } = 5000;

        /// <summary>
        /// 取得或設定是否啟用心跳檢測機制。
        /// 預設值為 false。
        /// </summary>
        public bool EnableHeartbeat { get; set; } = false;

        /// <summary>
        /// 取得或設定心跳檢測的間隔時間（毫秒）。
        /// 預設值為 30000 毫秒 (30 秒)。
        /// </summary>
        public int HeartbeatInterval { get; set; } = 30000;

        /// <summary>
        /// 取得或設定心跳訊息。
        /// 預設值為空字串。
        /// </summary>
        public string HeartbeatMessage { get; set; } = string.Empty;

        /// <summary>
        /// 取得或設定心跳逾時時間（毫秒）。
        /// 如果在此時間內沒有收到回應，則視為連線異常。
        /// 預設值為 10000 毫秒 (10 秒)。
        /// </summary>
        public int HeartbeatTimeout { get; set; } = 10000;

        /// <summary>
        /// 取得或設定 ASCII 模式的文字編碼。
        /// 預設為 <see cref="TextEncoding.Ascii"/>。
        /// </summary>
        public TextEncoding TextEncoding { get; set; } = TextEncoding.Ascii;

        /// <summary>
        /// 取得或設定 ASCII 行結尾字串。
        /// 常見有 "\r\n" 、 "\r" 或 "\n"。
        /// 預設為 "\r\n"。
        /// </summary>
        public string AsciiLineTerminator { get; set; } = "\r\n";

        /// <summary>
        /// 取得或設定接收時是否依 <see cref="AsciiLineTerminator"/> 切成一行一行觸發事件。
        /// 預設為 true。
        /// </summary>
        public bool EnableAsciiLineMode { get; set; } = true;

        /// <summary>
        /// 取得或設定 ASCII 接收緩衝的最大字元數。
        /// 超過時會截斷最舊資料避免無限成長。
        /// 預設為 8192。
        /// </summary>
        public int AsciiReceiveBufferLimit { get; set; } = 8192;

        #region Transmission Verification Settings

        /// <summary>
        /// 取得或設定是否在連線後自動執行傳輸驗證。
        /// 預設值為 true。
        /// </summary>
        /// <remarks>
        /// 啟用後，Open() 會在連線成功後自動發送測試訊息並等待回應，
        /// 以驗證串口參數（BaudRate、DataBits、Parity 等）是否正確。
        /// </remarks>
        public bool EnableTransmissionVerification { get; set; } = true;

        /// <summary>
        /// 取得或設定傳輸驗證的測試訊息。
        /// 預設為空字串。
        /// </summary>
        /// <remarks>
        /// 若為空，則僅等待接收任何資料作為驗證。
        /// 若設備支援，建議設定為設備的查詢指令（如 "PING\r\n"）。
        /// </remarks>
        public string TransmissionTestMessage { get; set; } = "PING\r\n";

        /// <summary>
        /// 取得或設定傳輸驗證的逾時時間（毫秒）。
        /// 預設值為 2000 毫秒 (2 秒)。
        /// </summary>
        public int TransmissionTestTimeout { get; set; } = 2000;

        #endregion Transmission Verification Settings

        /// <summary>
        /// 取得此設定所對應的 <see cref="System.Text.Encoding"/>。
        /// </summary>
        public System.Text.Encoding GetTextEncoding()
        {
            switch (TextEncoding)
            {
                case TextEncoding.Ascii:
                    return System.Text.Encoding.ASCII;
                case TextEncoding.Utf8:
                    return System.Text.Encoding.UTF8;
                default:
                    return System.Text.Encoding.ASCII;
            }
        }

        /// <summary>
        /// 複製設定。
        /// </summary>
        public SerialPortConfig Clone()
        {
            return new SerialPortConfig
            {
                PortName = this.PortName,
                BaudRate = this.BaudRate,
                DataBits = this.DataBits,
                Parity = this.Parity,
                StopBits = this.StopBits,
                Handshake = this.Handshake,
                ReadTimeout = this.ReadTimeout,
                WriteTimeout = this.WriteTimeout,
                RtsEnable = this.RtsEnable,
                DtrEnable = this.DtrEnable,
                EnableAutoReconnect = this.EnableAutoReconnect,
                ReconnectInterval = this.ReconnectInterval,
                EnableHeartbeat = this.EnableHeartbeat,
                HeartbeatInterval = this.HeartbeatInterval,
                HeartbeatMessage = this.HeartbeatMessage,
                HeartbeatTimeout = this.HeartbeatTimeout,
                TextEncoding = this.TextEncoding,
                AsciiLineTerminator = this.AsciiLineTerminator,
                EnableAsciiLineMode = this.EnableAsciiLineMode,
                AsciiReceiveBufferLimit = this.AsciiReceiveBufferLimit,
                EnableTransmissionVerification = this.EnableTransmissionVerification,
                TransmissionTestMessage = this.TransmissionTestMessage,
                TransmissionTestTimeout = this.TransmissionTestTimeout
            };
        }
    }
}
