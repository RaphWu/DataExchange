﻿//using System;
//using System.Collections.Generic;
//using RJCP.IO.Ports;

//namespace Calin.SerialPort
//{
//    public class SerialPortParameters
//    {
//        private SerialPortParameters() { }
//        private static readonly Lazy<SerialPortParameters> _instance = new Lazy<SerialPortParameters>(() => new SerialPortParameters());
//        public static SerialPortParameters Instance => _instance.Value;

//        /********************
//         * 基本參數
//         ********************/
//        /// <summary>
//        /// SerialPort名稱。
//        /// </summary>
//        public string PortName { get; set; }

//        /// <summary>
//        /// 鮑率。
//        /// </summary>
//        public int BaudRate { get; set; }

//        /// <summary>
//        /// 同位位元ID。
//        /// </summary>
//        public int ParityId { get; set; }

//        /// <summary>
//        /// 同位位元。
//        /// </summary>
//        public Parity Parity
//        {
//            get => Enum.TryParse(ParityId.ToString(), out Parity Parity) ? Parity : Parity.Odd;
//            set => ParityId = (int)value;
//        }

//        /// <summary>
//        /// 資料位元
//        /// </summary>
//        public int DataBits { get; set; }

//        /// <summary>
//        /// 停止位元ID。
//        /// </summary>
//        public int StopBitsId { get; set; }

//        /// <summary>
//        /// 停止位元。
//        /// </summary>
//        public StopBits StopBits
//        {
//            get => Enum.TryParse(StopBitsId.ToString(), out StopBits StopBits) ? StopBits : StopBits.One;
//            set => StopBitsId = (int)value;
//        }

//        /// <summary>
//        /// 交握模式ID。
//        /// </summary>
//        public int HandshakeId { get; set; }

//        /// <summary>
//        /// 交握模式。
//        /// </summary>
//        public Handshake Handshake
//        {
//            get => Enum.TryParse(HandshakeId.ToString(), out Handshake Handshake) ? Handshake : Handshake.None;
//            set => HandshakeId = (int)value;
//        }

//        //public bool DtrEnable { get; set; }

//        //public bool RtsEnable { get; set; }

//        /********************
//         * 狀態
//         ********************/
//        /// <summary>
//        /// SerialPort是否開啟。
//        /// </summary>
//        public bool IsOpen { get; set; }

//        /********************
//         * 列表
//         ********************/
//        /// <summary>
//        /// SerialPort名稱列表。
//        /// </summary>
//        public List<string> PortNameList { get; set; }

//        /// <summary>
//        /// 鮑率列表。
//        /// </summary>
//        public List<int> BaudRateList { get; set; } = new List<int>() { 1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200 };

//        /// <summary>
//        /// 資料位元列表。
//        /// </summary>
//        public List<int> DataBitsList { get; set; } = new List<int>() { 5, 6, 7, 8, 9 };

//        /********************
//         * 通訊
//         ********************/
//        /// <summary>
//        /// 接收的訊息。
//        /// </summary>
//        public string ReceivedMessages { get; set; }
//    }
//}
