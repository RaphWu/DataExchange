using System;

namespace Calin.SerialPort
{
    /// <summary>
    /// SerialPort �A�Ȥu�t��@�C
    /// �t�d�إ� SerialPortService ��ҡC
    /// </summary>
    /// <remarks>
    /// �����O�� Singleton�A�i�Q Autofac ���U�� SingleInstance�C
    /// �u�t�������������� SerialPortService ��Ҫ��ѦҡC
    /// </remarks>
    public class SerialPortServiceFactory : ISerialPortServiceFactory
    {
        /// <summary>
        /// �إ� SerialPortService ��ҡC
        /// </summary>
        /// <param name="config">SerialPort �]�w�C</param>
        /// <returns>�s�إߪ� SerialPortService ��ҡC</returns>
        /// <exception cref="ArgumentNullException">�� config �� null �ɩߥX�C</exception>
        public ISerialPortService Create(SerialPortConfig config)
        {
            if (config == null)
            {
                throw new ArgumentNullException(nameof(config));
            }

            return new SerialPortService(config.Clone());
        }

        /// <summary>
        /// �إ� SerialPortService ��Ҩæ۰ʶ}�ҳs�u�C
        /// </summary>
        /// <param name="config">SerialPort �]�w�C</param>
        /// <returns>�w�}�ҳs�u�� SerialPortService ��ҡC</returns>
        /// <exception cref="ArgumentNullException">�� config �� null �ɩߥX�C</exception>
        /// <exception cref="InvalidOperationException">���L�k�}�ҳs�u�ɩߥX�C</exception>
        public ISerialPortService CreateAndOpen(SerialPortConfig config)
        {
            var service = Create(config);

            try
            {
                if (!service.Open())
                {
                    service.Dispose();
                    throw new InvalidOperationException($"Failed to open SerialPort: {config.PortName}");
                }

                return service;
            }
            catch
            {
                service.Dispose();
                throw;
            }
        }

        /// <summary>
        /// �ϥιw�]�]�w�إ� SerialPortService ��ҡC
        /// </summary>
        /// <param name="portName">COM Port �W�١]�Ҧp "COM1"�^�C</param>
        /// <param name="baudRate">�j�v�]�w�] 9600�^�C</param>
        /// <returns>�s�إߪ� SerialPortService ��ҡC</returns>
        public ISerialPortService Create(string portName, int baudRate = 9600)
        {
            var config = new SerialPortConfig
            {
                PortName = portName,
                BaudRate = baudRate
            };

            return Create(config);
        }
    }
}
