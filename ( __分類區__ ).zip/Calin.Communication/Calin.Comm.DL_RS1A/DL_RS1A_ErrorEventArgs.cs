﻿using System;

namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// DL-RS1A 錯誤事件參數。
    /// </summary>
    public class DL_RS1A_ErrorEventArgs : EventArgs
    {
        /// <summary>
        /// 取得 COM Port 名稱。
        /// </summary>
        public string PortName { get; }

        /// <summary>
        /// 取得錯誤類型。
        /// </summary>
        public string ErrorType { get; }

        /// <summary>
        /// 取得錯誤訊息。
        /// </summary>
        public string ErrorMessage { get; }

        /// <summary>
        /// 取得例外物件（如果有）。
        /// </summary>
        public Exception Exception { get; }

        /// <summary>
        /// 取得錯誤發生的時間戳記。
        /// </summary>
        public DateTime Timestamp { get; }

        /// <summary>
        /// 建立 DL-RS1A 錯誤事件參數。
        /// </summary>
        /// <param name="portName">COM Port 名稱。</param>
        /// <param name="errorType">錯誤類型。</param>
        /// <param name="errorMessage">錯誤訊息。</param>
        /// <param name="exception">例外物件。</param>
        /// <param name="timestamp">時間戳記。</param>
        public DL_RS1A_ErrorEventArgs(
            string portName,
            string errorType,
            string errorMessage,
            Exception exception = null,
            DateTime? timestamp = null)
        {
            PortName = portName;
            ErrorType = errorType;
            ErrorMessage = errorMessage;
            Exception = exception;
            Timestamp = timestamp ?? DateTime.Now;
        }
    }
}
