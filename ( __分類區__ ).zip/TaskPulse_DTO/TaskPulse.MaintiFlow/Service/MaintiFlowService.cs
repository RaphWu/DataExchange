﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Autofac;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.Helper;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    /// <summary>
    /// 維護工單服務。
    /// </summary>
    public partial class MaintiFlowService : IDisposable, IMaintiFlow
    {
        #region fields

        private ILifetimeScope _rootScope;
        private ILifetimeScope _currentScope;
        private UIForm _currentForm;

        private readonly CoreContext _context;
        private readonly CurrentUserContext _user;
        private readonly IMail _mail;
        private readonly CoreData _coreData;
        private readonly MaintiFlowData _flowData;

        private bool _isInitialized = false;

        #endregion fields

        public MaintiFlowService(ILifetimeScope lifetimeScope,
                                 CoreContext coreContext,
                                 CurrentUserContext currentUserContext,
                                 IMail mail,
                                 CoreData coreData,
                                 MaintiFlowData maintiFlowData)
        {
            _rootScope = lifetimeScope;
            _context = coreContext;
            _user = currentUserContext;
            _mail = mail;
            _coreData = coreData;
            _flowData = maintiFlowData;
        }

        /// <summary>
        /// 釋放註冊的事件。
        /// </summary>
        public void Dispose()
        {
            _currentScope?.Dispose();
            WeakReferenceMessenger.Default.Unregister<NotifyEmployeeCacheUpdated>(this);
            WeakReferenceMessenger.Default.Unregister<NotifyMaintiFlowDataUpdated>(this);
        }

        /// <inheritdoc/>
        public async Task Initialize()
        {
            if (_isInitialized)
                return;

            //UpdateModelsCache();

            //_flowData.EngineerEntity = _coreData.Employees
            //    .Where(e => e.IsEngineer)
            //    .Select(e => new EngineerEntity
            //    {
            //        Id = e.Id,
            //        UnitName = e.UnitName,
            //        DepartmentEntity = e.DepartmentEntity,
            //        Title = e.Title
            //    })
            //    .ToList();

            PropertyText.Name.TaskOrderId = nameof(TaskOrderEntity.Id);
            PropertyText.Name.WorkOrderNo = nameof(TaskOrderEntity.WorkOrderNo);
            PropertyText.Name.OrderStatus = nameof(TaskOrderEntity.Status);
            PropertyText.Name.OrderStatusId = nameof(TaskOrderEntity.StatusId);
            PropertyText.Name.OrderStatusString = nameof(TaskOrderEntity.StatusString);
            PropertyText.Name.Machine = nameof(TaskOrderEntity.Machine);
            PropertyText.Name.MachineCode = nameof(TaskOrderEntity.MachineCode);
            PropertyText.Name.FullMachineName = nameof(TaskOrderEntity.FullMachineName);
            PropertyText.Name.ModelName = nameof(ModelEntity.ModelName);
            PropertyText.Name.ModelStatus = nameof(ModelEntity.ModelStatus);
            PropertyText.Name.Workstation = nameof(TaskOrderEntity.Workstation);
            PropertyText.Name.WorkstationName = nameof(TaskOrderEntity.WorkstationName);
            PropertyText.Name.ModelWorkstationName = nameof(TaskOrderEntity.ModelWorkstationName);
            PropertyText.Name.Creator = nameof(TaskOrderEntity.Creator);
            PropertyText.Name.CreatorName = nameof(TaskOrderEntity.CreatorName);
            PropertyText.Name.CreatorHalfName = nameof(TaskOrderEntity.CreatorHalfName);
            PropertyText.Name.CreatorFullName = nameof(TaskOrderEntity.CreatorFullName);
            PropertyText.Name.CreationDateTime = nameof(TaskOrderEntity.CreationDateTime);
            PropertyText.Name.CreationDateTimeString = nameof(TaskOrderEntity.CreationDateTimeString);
            PropertyText.Name.CreationDateString = nameof(TaskOrderEntity.CreationDateString);

            PropertyText.Name.MaintenanceUnit = nameof(TaskOrderEntity.MaintenanceUnit);
            PropertyText.Name.MaintenanceUnitId = nameof(TaskOrderEntity.MaintenanceUnitId);
            PropertyText.Name.MaintenanceUnitString = nameof(TaskOrderEntity.MaintenanceUnitString);
            PropertyText.Name.UnitString = nameof(TaskOrderEntity.MaintenanceUnitString);
            PropertyText.Name.Engineers = nameof(TaskOrderEntity.Engineers);
            PropertyText.Name.EngineerString = nameof(TaskOrderEntity.EngineerString);
            PropertyText.Name.EngineerMultiString = nameof(TaskOrderEntity.EngineerMultiString);
            PropertyText.Name.AcceptedTime = nameof(TaskOrderEntity.AcceptedTime);
            PropertyText.Name.AcceptedTimeString = nameof(TaskOrderEntity.AcceptedTimeString);
            PropertyText.Name.IssueCategory = nameof(TaskOrderEntity.IssueCategory);
            PropertyText.Name.IssueCategoryId = nameof(TaskOrderEntity.IssueCategoryId);
            PropertyText.Name.IssueCategoryString = nameof(TaskOrderEntity.IssueCategoryString);
            PropertyText.Name.IssueDescription = nameof(TaskOrderEntity.IssueDescription);
            PropertyText.Name.Details = nameof(TaskOrderEntity.Details);
            PropertyText.Name.RepairStarted = nameof(TaskOrderEntity.RepairStarted);
            PropertyText.Name.RepairStartedString = nameof(TaskOrderEntity.RepairStartedString);
            PropertyText.Name.RepairCompleted = nameof(TaskOrderEntity.RepairCompleted);
            PropertyText.Name.RepairCompletedString = nameof(TaskOrderEntity.RepairCompletedString);
            PropertyText.Name.RepairDurationTick = nameof(TaskOrderEntity.RepairDurationTick);
            PropertyText.Name.RepairDuration = nameof(TaskOrderEntity.RepairDuration);
            PropertyText.Name.RepairDurationString = nameof(TaskOrderEntity.RepairDurationString);
            PropertyText.Name.FillingTime = nameof(TaskOrderEntity.FillingTime);
            PropertyText.Name.FillingTimeString = nameof(TaskOrderEntity.FillingTimeString);

            PropertyText.Name.RequestingUnit = nameof(TaskOrderEntity.RequestingUnit);
            PropertyText.Name.RequestingUnitString = nameof(TaskOrderEntity.RequestingUnitString);
            PropertyText.Name.FeedbackEmployee = nameof(TaskOrderEntity.FeedbackEmployee);
            PropertyText.Name.FeedbackEmployeeString = nameof(TaskOrderEntity.FeedbackEmployeeString);
            PropertyText.Name.Feedback = nameof(TaskOrderEntity.Feedback);
            PropertyText.Name.OutageStarted = nameof(TaskOrderEntity.OutageStarted);
            PropertyText.Name.OutageStartedString = nameof(TaskOrderEntity.OutageStartedString);
            PropertyText.Name.OutageEnded = nameof(TaskOrderEntity.OutageEnded);
            PropertyText.Name.OutageEndedString = nameof(TaskOrderEntity.OutageEndedString);
            PropertyText.Name.OutageDurationTick = nameof(TaskOrderEntity.OutageDurationTick);
            PropertyText.Name.OutageDuration = nameof(TaskOrderEntity.OutageDuration);
            PropertyText.Name.OutageDurationString = nameof(TaskOrderEntity.OutageDurationString);

            PropertyText.Name.Responsible = nameof(TaskOrderEntity.Responsible);

            PropertyText.Title.TaskOrderId = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.TaskOrderId);
            PropertyText.Title.WorkOrderNo = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.WorkOrderNo);
            PropertyText.Title.Status = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.OrderStatus);
            PropertyText.Title.Machine = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.Machine);
            PropertyText.Title.ModelName = EnumHelper.GetDescription<ModelEntity>(PropertyText.Name.ModelName);
            PropertyText.Title.ModelStatus = EnumHelper.GetDescription<ModelEntity>(PropertyText.Name.ModelStatus);
            PropertyText.Title.Workstation = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.Workstation);
            PropertyText.Title.ModelWorkstationName = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.ModelWorkstationName);
            PropertyText.Title.Creator = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.Creator);
            PropertyText.Title.CreationDate = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.CreationDateTime);

            PropertyText.Title.MaintenanceUnit = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.MaintenanceUnit);
            PropertyText.Title.Engineer = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.Engineers);
            PropertyText.Title.AcceptedTime = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.AcceptedTime);
            PropertyText.Title.IssueCategory = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.IssueCategory);
            PropertyText.Title.IssueDescription = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.IssueDescription);
            PropertyText.Title.Details = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.Details);
            PropertyText.Title.RepairStarted = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.RepairStarted);
            PropertyText.Title.RepairCompleted = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.RepairCompleted);
            PropertyText.Title.RepairDuration = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.RepairDuration);
            PropertyText.Title.FillingTime = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.FillingTime);

            PropertyText.Title.RequestingUnit = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.RequestingUnit);
            PropertyText.Title.FeedbackEmployee = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.FeedbackEmployee);
            PropertyText.Title.Feedback = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.Feedback);
            PropertyText.Title.OutageStarted = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.OutageStarted);
            PropertyText.Title.OutageEnded = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.OutageEnded);
            PropertyText.Title.OutageDuration = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.OutageDuration);

            PropertyText.Title.Responsible = EnumHelper.GetDescription<TaskOrderEntity>(PropertyText.Name.Responsible);

            // 註冊核心共用資料更新訊息。
            WeakReferenceMessenger.Default.Register<NotifyEmployeeCacheUpdated>(this, (r, m) =>
            {
                _ = Task.Run(async () =>
                {
                    try
                    {
                        await UpdateCache();
                    }
                    catch (Exception ex)
                    {
                        // 記錄 log 或處理錯誤
                    }
                });
            });
            WeakReferenceMessenger.Default.Register<NotifyMaintiFlowDataUpdated>(this, (r, m) =>
            {
                _ = Task.Run(async () =>
                {
                    try
                    {
                        await UpdateCache();
                    }
                    catch (Exception ex)
                    {
                        // 記錄 log 或處理錯誤
                    }
                });
            });

            await UpdateCache();
            _isInitialized = true;
        }

        /// <inheritdoc/>
        public async Task UpdateCache()
        {
            _flowData.TaskOrders = await _context.TaskOrders
                //.Include(t => t.Creator.DepartmentEntity)
                //.Include(t => t.Creator.Title)
                .Include(t => t.Creator)
                .Include(t => t.Engineers)
                .Include(t => t.Machine)
                .Include(t => t.Workstation)
                .Include(t => t.MaintenanceUnit)
                .Include(t => t.IssueCategory)
                .Include(t => t.RequestingUnit)
                .Include(t => t.FeedbackEmployee)
                .OrderByDescending(to => to.WorkOrderNo)
                .AsNoTracking()
                .ToListAsync();

            _ = WeakReferenceMessenger.Default.Send(NotifyMaintiFlowCacheUpdated.Instance);
        }
    }
}
