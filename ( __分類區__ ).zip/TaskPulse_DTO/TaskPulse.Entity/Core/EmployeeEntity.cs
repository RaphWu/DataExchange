﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 員工清單。
    /// </summary>
    public class EmployeeEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 工號。
        /// </summary>
        [Description("工號")]
        [Required, MaxLength(6)]
        [Index(IsUnique = true)]
        public string EmployeeId { get; set; }

        /// <summary>
        /// 姓名。
        /// </summary>
        [Description("姓名")]
        [Required]
        [MaxLength(20)]
        public string EmployeeName { get; set; }

        /// <summary>
        /// 密碼。
        /// </summary>
        [Description("密碼")]
        [MaxLength(100)]
        public string PasswordHash { get; set; }

        /// <summary>
        /// 部門。
        /// </summary>
        [Description("部門")]
        public virtual DepartmentEntity Department { get; set; }
        public int? DepartmentId { get; set; } // FK

        /// <summary>
        /// 職稱。
        /// </summary>
        [Description("職稱")]
        public virtual JobTitleEntity JobTitle { get; set; }
        public int? JobTitleId { get; set; } // FK

        /// <summary>
        /// 電子郵件。
        /// </summary>
        [Description("Email")]
        public string Email { get; set; }

        /// <summary>
        /// 副本人員。
        /// </summary>
        [Description("副本人員")]
        public virtual ICollection<EmployeeEntity> CarbonCopies { get; set; }
        public virtual ICollection<EmployeeEntity> CarbonCopiedBy { get; set; }

        /// <summary>
        /// 是否為維護工程師。
        /// </summary>
        [Description("維護工程師")]
        public bool IsEngineer { get; set; } = false;

        /// <summary>
        /// 在職/離職/調職...等狀態。
        /// </summary>
        [Description("狀態")]
        public EmployeeStatusEntity Status { get; set; }
        public int StatusId { get; set; } // FK

        /// <summary>
        /// 狀態變更日期。
        /// </summary>
        [Description("日期")]
        public DateTime? StatusChangeAt { get; set; }

        //[MaxLength(512)]
        //public string SensitiveData { get; set; } // AES

        public virtual ICollection<TaskOrderEntity> CreaterTaskOrders { get; set; }
        public virtual ICollection<TaskOrderEntity> EngineerTaskOrders { get; set; }
        public virtual ICollection<TaskOrderEntity> FeedbackEmployeeTaskOrders { get; set; }
        public virtual ICollection<PermissionEntity> Permissions { get; set; }
        public virtual ICollection<UserGroupEntity> UserGroups { get; set; }

        public EmployeeEntity()
        {
            Permissions = new HashSet<PermissionEntity>();
            UserGroups = new HashSet<UserGroupEntity>();

            CreaterTaskOrders = new HashSet<TaskOrderEntity>();
            EngineerTaskOrders = new HashSet<TaskOrderEntity>();
            FeedbackEmployeeTaskOrders = new HashSet<TaskOrderEntity>();

            CarbonCopies = new HashSet<EmployeeEntity>();
            CarbonCopiedBy = new HashSet<EmployeeEntity>();
        }
    }
}
