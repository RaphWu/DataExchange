﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 廠牌。
    /// </summary>
    public class BrandEntity
    {
        /// <summary>
        /// 廠牌代號。
        /// </summary>
        [Description("廠牌代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        public int OrderNo { get; set; }

        /// <summary>
        /// 廠牌。
        /// </summary>
        [Description("廠牌")]
        [MaxLength(30)]
        public string BrandName { get; set; }

        public virtual ICollection<MachineEntity> MachineBrands { get; set; } // 廠牌
    }
}
