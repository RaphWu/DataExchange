﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機台資料。
    /// </summary>
    public class MachineEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 機台編號。
        /// </summary>
        [Description("編號")]
        [Index(IsUnique = true)]
        [MaxLength(10)]
        public string MachineCode { get; set; }

        /// <summary>
        /// 機台名稱。
        /// </summary>
        [Description("名稱")]
        public virtual MachineNameEntity MachineName { get; set; }
        public int MachineNameId { get; set; } // FK

        /// <summary>
        /// 機台狀態。
        /// </summary>
        [Description("狀態")]
        public virtual ConditionEntity Condition { get; set; }
        public int ConditionId { get; set; } // FK

        /// <summary>
        /// 廠牌。
        /// </summary>
        [Description("廠牌")]
        public virtual BrandEntity Brand { get; set; }
        public int? BrandId { get; set; } // FK

        /// <summary>
        /// 位置。
        /// </summary>
        [Description("位置")]
        public virtual LocationEntity Location { get; set; }
        public int? LocationId { get; set; } // FK

        /// <summary>
        /// 資產編號。
        /// </summary>
        [Description("資產編號")]
        public virtual string Assets { get; set; }

        /// <summary>
        /// 機台序號。
        /// </summary>
        [Description("序號")]
        [MaxLength(20)]
        public string SerialNumber { get; set; }

        /// <summary>
        /// 條碼。
        /// </summary>
        [Description("條碼")]
        [MaxLength(50)]
        public string Barcode { get; set; }

        /// <summary>
        /// 能否連網。
        /// </summary>
        [Description("連網")]
        public bool Connected { get; set; }

        /// <summary>
        /// 機台是否已被處置 (除帳/報廢...)。
        /// </summary>
        [Description("處置")]
        public bool Disposal { get; set; }

        /// <summary>
        /// 備註。
        /// </summary>
        [Description("備註")]
        public string Remark { get; set; }

        /// <summary>
        /// 工站。
        /// </summary>
        [Description("工站")]
        public virtual ICollection<WorkstationEntity> Workstations { get; set; }
    }
}
