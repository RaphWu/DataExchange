﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 工站。
    /// </summary>
    public class WorkstationEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        public int OrderNo { get; set; }

        /// <summary>
        /// 工站名稱。
        /// </summary>
        [Description("工站")]
        [MaxLength(20)]
        public string WorkstationName { get; set; }

        /// <summary>
        /// 機種。
        /// </summary>
        [Description("機種")]
        public virtual ModelEntity Model { get; set; }
        public int? ModelId { get; set; } // FK 

        public virtual ICollection<MachineEntity> Machines { get; set; }
        public virtual ICollection<TaskOrderEntity> TaskOrders { get; set; }
    }
}
