﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 維護工程師。
    /// </summary>
    public class EngineerEntity
    {
        /// <summary>
        /// 工號。
        /// </summary>
        [Description("工號")]
        [Required]
        [MaxLength(6)]
        public string EmployeeId { get; set; }

        /// <summary>
        /// 姓名。
        /// </summary>
        [Description("姓名")]
        [Required]
        [MaxLength(12)]
        public string Name { get; set; }

        /// <summary>
        /// 部門。
        /// </summary>
        [Description("部門")]
        public DepartmentEntity Department { get; set; }

        /// <summary>
        /// 職稱。
        /// </summary>
        [Description("職稱")]
        public JobTitleEntity Title { get; set; }
    }
}
