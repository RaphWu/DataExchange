﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機台設備別。
    /// </summary>
    public class MachineTypeEntity
    {
        /// <summary>
        /// 機台型式代號。
        /// </summary>
        [Description("型式代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        public int OrderNo { get; set; }

        /// <summary>
        /// 機台設備別名稱。
        /// </summary>
        [Description("設備別")]
        [Required]
        [MaxLength(30)]
        public string TypeName { get; set; }

        /// <summary>
        /// 機台分類。
        /// </summary>
        [Description("分類")]
        public CategoryEntity Category { get; set; }
        public int CategoryId { get; set; } // FK

        public virtual ICollection<MachineNameEntity> MachineNames { get; set; }
    }
}
