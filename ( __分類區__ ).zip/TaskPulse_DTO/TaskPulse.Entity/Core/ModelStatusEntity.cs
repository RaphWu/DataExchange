﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機種狀態。
    /// </summary>
    public class ModelStatusEntity
    {
        /// <summary>
        /// 狀態代號。
        /// </summary>
        [Description("機種狀態")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        public int OrderNo { get; set; }

        /// <summary>
        /// 狀態名稱。
        /// </summary>
        [Description("狀態")]
        public string Status { get; set; }

        public virtual ICollection<ModelEntity> Models { get; set; }
    }
}
