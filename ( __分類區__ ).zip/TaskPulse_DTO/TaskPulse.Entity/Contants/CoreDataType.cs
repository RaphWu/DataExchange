﻿//namespace Calin.TaskPulse.Entity.Contants
//{
//    public enum CoreDataType
//    {
//        AllCoreData,
//        EmployeeEntity,
//        MachineEntity,
//        ModelEntity,
//        WorkstationEntity,
//    }
//}
