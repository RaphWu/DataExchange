﻿namespace Calin.TaskPulse.Core.Views
{
    partial class SetupPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.TreeView_SetupMenu = new Sunny.UI.UITreeView();
            this.SetupRegion = new System.Windows.Forms.Panel();
            this.uiLine1 = new Sunny.UI.UILine();
            this.tableLayoutPanel_Page.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.ColumnCount = 3;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 190F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Page.Controls.Add(this.TreeView_SetupMenu, 0, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.SetupRegion, 2, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.uiLine1, 1, 0);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Page.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 1;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(1117, 676);
            this.tableLayoutPanel_Page.TabIndex = 0;
            // 
            // TreeView_SetupMenu
            // 
            this.TreeView_SetupMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TreeView_SetupMenu.FillColor = System.Drawing.Color.White;
            this.TreeView_SetupMenu.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.TreeView_SetupMenu.Location = new System.Drawing.Point(3, 6);
            this.TreeView_SetupMenu.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.TreeView_SetupMenu.MinimumSize = new System.Drawing.Size(1, 1);
            this.TreeView_SetupMenu.Name = "TreeView_SetupMenu";
            this.TreeView_SetupMenu.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.TreeView_SetupMenu.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.TreeView_SetupMenu.ScrollBarStyleInherited = false;
            this.TreeView_SetupMenu.ShowText = false;
            this.TreeView_SetupMenu.Size = new System.Drawing.Size(184, 664);
            this.TreeView_SetupMenu.TabIndex = 0;
            this.TreeView_SetupMenu.Text = null;
            this.TreeView_SetupMenu.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.TreeView_SetupMenu.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.TreeView_SetupMenu_AfterSelect);
            this.TreeView_SetupMenu.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.TreeView_SetupMenu_NodeMouseClick);
            // 
            // SetupRegion
            // 
            this.SetupRegion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SetupRegion.Location = new System.Drawing.Point(202, 3);
            this.SetupRegion.Name = "SetupRegion";
            this.SetupRegion.Size = new System.Drawing.Size(912, 670);
            this.SetupRegion.TabIndex = 1;
            // 
            // uiLine1
            // 
            this.uiLine1.BackColor = System.Drawing.Color.Transparent;
            this.uiLine1.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiLine1.Dock = System.Windows.Forms.DockStyle.Left;
            this.uiLine1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine1.LineSize = 3;
            this.uiLine1.Location = new System.Drawing.Point(193, 3);
            this.uiLine1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.Size = new System.Drawing.Size(3, 670);
            this.uiLine1.TabIndex = 2;
            // 
            // SetupPage
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "SetupPage";
            this.Size = new System.Drawing.Size(1117, 676);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
        private Sunny.UI.UITreeView TreeView_SetupMenu;
        private System.Windows.Forms.Panel SetupRegion;
        private Sunny.UI.UILine uiLine1;
    }
}