﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Contracts
{
    public interface IUserGroupService
    {
        Task<UserGroupEntity> CreateAsync(UserGroupEntity group, string currentUserId);
        Task<UserGroupEntity> UpdateAsync(UserGroupEntity group, string currentUserId);
        Task DeleteAsync(int groupId, string currentUserId);
        Task<UserGroupEntity> GetByIdAsync(int groupId);
        Task<List<UserGroupEntity>> GetAllAsync();
        Task AssignUsersAsync(int groupId, List<int> userIds, string currentUserId);
        Task AssignPermissionsAsync(int groupId, List<int> permissionIds, string currentUserId);
    }
}
