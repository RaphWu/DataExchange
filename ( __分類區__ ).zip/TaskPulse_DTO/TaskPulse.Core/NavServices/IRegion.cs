﻿using System.Windows.Forms;

namespace Calin.TaskPulse.Core.NavServices
{
    public interface IRegion
    {
        string Name { get; }
        Control HostControl { get; }

        void ShowView(object view);
        void Clear();
    }
}
