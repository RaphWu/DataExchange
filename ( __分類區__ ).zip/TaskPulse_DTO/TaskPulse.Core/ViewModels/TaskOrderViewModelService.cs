﻿namespace Calin.TaskPulse.Core.ViewModels
{
    public class TaskOrderViewModelService : ITaskOrderViewModel
    {
    }
}
