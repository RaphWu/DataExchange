﻿using System;
using System.Collections.Generic;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.ViewModels
{
    public class EmployeeViewModel
    {
        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public int DepartmentId { get; set; }
        public string Department { get; set; }
        public int JobTitleId { get; set; }
        public string JobTitle { get; set; }
        public string Email { get; set; }
        public ICollection<EmployeeEntity> CarbonCopies { get; set; }
        public string CarbonCopyString { get; set; }
        public string CarbonCopyList { get; set; }
        public bool IsEngineer { get; set; }
        public string IsEngineerString { get; set; }
        public int StatusId { get; set; }
        public string StatusName { get; set; }
        public bool StatusBoolean { get; set; }
        public DateTime StatusChangeAt { get; set; }
        public string StatusChangeAtString { get; set; }
    }
}
