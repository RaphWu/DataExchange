﻿namespace Calin.TaskPulse.Core.ViewModels
{
    public interface IEmployeeViewModel
    {
    }
}
