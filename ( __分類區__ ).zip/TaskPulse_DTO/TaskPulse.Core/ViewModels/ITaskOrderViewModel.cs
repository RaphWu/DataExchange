﻿namespace Calin.TaskPulse.Core.ViewModels
{
    public interface ITaskOrderViewModel
    {
    }
}
