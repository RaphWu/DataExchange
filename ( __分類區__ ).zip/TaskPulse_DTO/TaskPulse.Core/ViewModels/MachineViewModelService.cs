﻿namespace Calin.TaskPulse.Core.ViewModels
{
    public class MachineViewModelService : IMachineViewMode
    {
    }
}
