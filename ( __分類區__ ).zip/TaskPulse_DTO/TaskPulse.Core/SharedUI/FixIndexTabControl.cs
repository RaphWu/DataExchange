﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.SharedUI
{
    public class FixIndexTabControl : TabControl
    {
        private const int TCM_SETCURSEL = 0x130C;
        private bool _suppressIndexChange = false;

        /// <summary>
        /// 是否使用標籤列。
        /// </summary>
        public bool HideTabHeaders { get; set; } = true;

        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);

        protected override void WndProc(ref Message m)
        {
            // 防止 TabControl 自動滾動
            if (m.Msg == TCM_SETCURSEL)
            {
                if (_suppressIndexChange)
                {
                    base.WndProc(ref m);
                    return;
                }

                int oldIndex = this.SelectedIndex;
                base.WndProc(ref m);

                if (this.SelectedIndex != oldIndex)
                {
                    _suppressIndexChange = true;
                    try
                    {
                        SendMessage(this.Handle, TCM_SETCURSEL, oldIndex, 0);
                        this.SelectedIndex = oldIndex;
                    }
                    finally
                    {
                        _suppressIndexChange = false;
                    }
                }
                return;
            }

            // 隱藏標籤列
            if (HideTabHeaders && m.Msg == 0x1328 && !DesignMode)
            {
                m.Result = (IntPtr)1;
                return;
            }

            base.WndProc(ref m);
        }
    }
}