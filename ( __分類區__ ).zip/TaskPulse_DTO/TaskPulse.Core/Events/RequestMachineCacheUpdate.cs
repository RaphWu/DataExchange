﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 要求更新機台快取。
    /// </summary>
    public class RequestMachineCacheUpdate
    {
        public static readonly RequestMachineCacheUpdate Instance = new RequestMachineCacheUpdate();
        private RequestMachineCacheUpdate() { }
    }
}
