using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// ���x�������� DTO�C
    /// </summary>
    public class MachineCategoryDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string CategoryName { get; set; }

        // ���X�ɯ��ݩ�
        public ICollection<MachineTypeSummaryDto> MachineTypes { get; set; } = new List<MachineTypeSummaryDto>();
    }
}