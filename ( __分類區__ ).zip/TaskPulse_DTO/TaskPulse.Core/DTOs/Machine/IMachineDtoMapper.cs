using System.Collections.Generic;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// Machine ���� Entity �P DTO �������ഫ�������C
    /// </summary>
    /// <remarks><code><![CDATA[�ϥνd�ҡG
    /// 
    /// ]></code></remarks>
    public interface IMachineDtoMapper
    {
        MachineDto ToDto(MachineEntity machine);
        List<MachineDto> ToDtoList(IEnumerable<MachineEntity> machines);
        
        MachineNameDto ToDto(MachineNameEntity machineName);
        ConditionDto ToDto(ConditionEntity condition);
        BrandDto ToDto(BrandEntity brand);
        LocationDto ToDto(LocationEntity location);
        MachineTypeDto ToDto(MachineTypeEntity machineType);
        MachineCategoryDto ToDto(CategoryEntity category);
        WorkstationDto ToDto(WorkstationEntity workstation);
        ModelDto ToDto(ModelEntity model);
        ModelStatusDto ToDto(ModelStatusEntity modelStatus);
    }
}