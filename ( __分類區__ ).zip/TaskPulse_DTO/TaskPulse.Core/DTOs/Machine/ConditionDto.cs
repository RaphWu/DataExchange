using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// ���x���A���� DTO�C
    /// </summary>
    public class ConditionDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string ConditionName { get; set; }

        // ���X�ɯ��ݩ�
        public ICollection<MachineSummaryDto> Machines { get; set; } = new List<MachineSummaryDto>();
    }
}