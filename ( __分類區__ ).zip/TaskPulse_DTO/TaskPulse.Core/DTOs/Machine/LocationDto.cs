using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// ���x��m���� DTO�C
    /// </summary>
    public class LocationDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string LocationName { get; set; }

        public ICollection<MachineSummaryDto> MachineLocations { get; set; } = new List<MachineSummaryDto>();
    }
}