using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// �u������ DTO�C
    /// </summary>
    public class WorkstationDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string WorkstationName { get; set; }

        // ��@�ɯ��ݩ�
        public ModelDto Model { get; set; }
        public int? ModelId { get; set; }

        // ���X�ɯ��ݩ�
        public ICollection<MachineSummaryDto> Machines { get; set; } = new List<MachineSummaryDto>();
    }
}