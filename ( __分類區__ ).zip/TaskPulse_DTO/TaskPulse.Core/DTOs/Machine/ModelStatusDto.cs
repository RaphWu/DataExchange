using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// ���ت��A���� DTO�C
    /// </summary>
    public class ModelStatusDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string Status { get; set; }

        // ���X�ɯ��ݩ�
        public ICollection<ModelSummaryDto> Models { get; set; } = new List<ModelSummaryDto>();
    }
}