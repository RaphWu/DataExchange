using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// ���x�]�ƧO���� DTO�C
    /// </summary>
    public class MachineTypeDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string TypeName { get; set; }

        // ��@�ɯ��ݩ�
        public MachineCategoryDto Category { get; set; }
        public int CategoryId { get; set; }

        // ���X�ɯ��ݩ�
        public ICollection<MachineNameSummaryDto> MachineNames { get; set; } = new List<MachineNameSummaryDto>();
    }
}