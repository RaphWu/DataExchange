using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// ���ا��� DTO�C
    /// </summary>
    public class ModelDto
    {
        public int Id { get; set; }
        public string ModelName { get; set; }

        // ��@�ɯ��ݩ�
        public ModelStatusDto ModelStatus { get; set; }
        public int ModelStatusId { get; set; }

        // ���X�ɯ��ݩ�
        public ICollection<WorkstationSummaryDto> Workstations { get; set; } = new List<WorkstationSummaryDto>();
    }
}