using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// ���x�t�P���� DTO�C
    /// </summary>
    public class BrandDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string BrandName { get; set; }

        public ICollection<MachineSummaryDto> MachineBrands { get; set; } = new List<MachineSummaryDto>();
    }
}