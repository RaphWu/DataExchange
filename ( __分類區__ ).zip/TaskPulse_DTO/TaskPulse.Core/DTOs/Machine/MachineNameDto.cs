using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// ���x�W�٧��� DTO�C
    /// </summary>
    public class MachineNameDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string ModelName { get; set; }

        // ��@�ɯ��ݩ�
        public MachineTypeDto MachineType { get; set; }
        public int? TypeId { get; set; }

        // ���X�ɯ��ݩ�
        public ICollection<MachineSummaryDto> Machines { get; set; } = new List<MachineSummaryDto>();
    }
}