using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// ���x���� DTO�C
    /// </summary>
    public class MachineDto
    {
        public int Id { get; set; }
        public string MachineCode { get; set; }
        public string Assets { get; set; }
        public string SerialNumber { get; set; }
        public string Barcode { get; set; }
        public bool Connected { get; set; }
        public bool Disposal { get; set; }
        public string Remark { get; set; }

        // ��@�ɯ��ݩ� - �ϥΧ��� DTO
        public MachineNameDto MachineName { get; set; }
        public int MachineNameId { get; set; }

        public ConditionDto Condition { get; set; }
        public int ConditionId { get; set; }

        public BrandDto Brand { get; set; }
        public int? BrandId { get; set; }

        public LocationDto Location { get; set; }
        public int? LocationId { get; set; }

        // ���X�ɯ��ݩ� - �ϥ� Summary DTO
        public ICollection<WorkstationSummaryDto> Workstations { get; set; } = new List<WorkstationSummaryDto>();
    }
}