using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// Machine ���� Entity �P DTO �������ഫ���C
    /// </summary>
    public class MachineDtoMapper : IMachineDtoMapper
    {
        #region Machine

        public MachineDto ToDto(MachineEntity machine)
        {
            if (machine == null) return null;

            return new MachineDto
            {
                Id = machine.Id,
                MachineCode = machine.MachineCode,
                Assets = machine.Assets,
                SerialNumber = machine.SerialNumber,
                Barcode = machine.Barcode,
                Connected = machine.Connected,
                Disposal = machine.Disposal,
                Remark = machine.Remark,

                MachineNameId = machine.MachineNameId,
                MachineName = ToDto(machine.MachineName),

                ConditionId = machine.ConditionId,
                Condition = ToDto(machine.Condition),

                BrandId = machine.BrandId,
                Brand = ToDto(machine.Brand),

                LocationId = machine.LocationId,
                Location = ToDto(machine.Location),

                Workstations = machine.Workstations?
                    .Select(w => new WorkstationSummaryDto
                    {
                        Id = w.Id,
                        WorkstationName = w.WorkstationName
                    })
                    .ToList() ?? new List<WorkstationSummaryDto>()
            };
        }

        public List<MachineDto> ToDtoList(IEnumerable<MachineEntity> machines)
        {
            return machines?.Select(m => ToDto(m)).ToList() ?? new List<MachineDto>();
        }

        #endregion

        #region MachineName

        public MachineNameDto ToDto(MachineNameEntity machineName)
        {
            if (machineName == null) return null;

            return new MachineNameDto
            {
                Id = machineName.Id,
                OrderNo = machineName.OrderNo,
                ModelName = machineName.ModelName,
                TypeId = machineName.TypeId,
                MachineType = ToDto(machineName.MachineType),
                Machines = machineName.Machines?
                    .Select(m => new MachineSummaryDto
                    {
                        Id = m.Id,
                        MachineCode = m.MachineCode,
                        ModelName = m.MachineName?.ModelName
                    })
                    .ToList() ?? new List<MachineSummaryDto>()
            };
        }

        #endregion

        #region Condition

        public ConditionDto ToDto(ConditionEntity condition)
        {
            if (condition == null) return null;

            return new ConditionDto
            {
                Id = condition.Id,
                OrderNo = condition.OrderNo,
                ConditionName = condition.ConditionName,
                Machines = condition.Machines?
                    .Select(m => new MachineSummaryDto
                    {
                        Id = m.Id,
                        MachineCode = m.MachineCode,
                        ModelName = m.MachineName?.ModelName
                    })
                    .ToList() ?? new List<MachineSummaryDto>()
            };
        }

        #endregion

        #region Brand

        public BrandDto ToDto(BrandEntity brand)
        {
            if (brand == null) return null;

            return new BrandDto
            {
                Id = brand.Id,
                OrderNo = brand.OrderNo,
                BrandName = brand.BrandName,
                MachineBrands = brand.MachineBrands?
                    .Select(m => new MachineSummaryDto
                    {
                        Id = m.Id,
                        MachineCode = m.MachineCode,
                        ModelName = m.MachineName?.ModelName
                    })
                    .ToList() ?? new List<MachineSummaryDto>()
            };
        }

        #endregion

        #region Location

        public LocationDto ToDto(LocationEntity location)
        {
            if (location == null) return null;

            return new LocationDto
            {
                Id = location.Id,
                OrderNo = location.OrderNo,
                LocationName = location.LocationName,
                MachineLocations = location.MachineLocations?
                    .Select(m => new MachineSummaryDto
                    {
                        Id = m.Id,
                        MachineCode = m.MachineCode,
                        ModelName = m.MachineName?.ModelName
                    })
                    .ToList() ?? new List<MachineSummaryDto>()
            };
        }

        #endregion

        #region MachineType

        public MachineTypeDto ToDto(MachineTypeEntity machineType)
        {
            if (machineType == null) return null;

            return new MachineTypeDto
            {
                Id = machineType.Id,
                OrderNo = machineType.OrderNo,
                TypeName = machineType.TypeName,
                CategoryId = machineType.CategoryId,
                Category = ToDto(machineType.Category),
                MachineNames = machineType.MachineNames?
                    .Select(mn => new MachineNameSummaryDto
                    {
                        Id = mn.Id,
                        ModelName = mn.ModelName
                    })
                    .ToList() ?? new List<MachineNameSummaryDto>()
            };
        }

        #endregion

        #region MachineCategory

        public MachineCategoryDto ToDto(CategoryEntity category)
        {
            if (category == null) return null;

            return new MachineCategoryDto
            {
                Id = category.Id,
                OrderNo = category.OrderNo,
                CategoryName = category.CategoryName,
                MachineTypes = category.MachineTypes?
                    .Select(mt => new MachineTypeSummaryDto
                    {
                        Id = mt.Id,
                        TypeName = mt.TypeName
                    })
                    .ToList() ?? new List<MachineTypeSummaryDto>()
            };
        }

        #endregion

        #region Workstation

        public WorkstationDto ToDto(WorkstationEntity workstation)
        {
            if (workstation == null) return null;

            return new WorkstationDto
            {
                Id = workstation.Id,
                OrderNo = workstation.OrderNo,
                WorkstationName = workstation.WorkstationName,
                ModelId = workstation.ModelId,
                Model = ToDto(workstation.Model),
                Machines = workstation.Machines?
                    .Select(m => new MachineSummaryDto
                    {
                        Id = m.Id,
                        MachineCode = m.MachineCode,
                        ModelName = m.MachineName?.ModelName
                    })
                    .ToList() ?? new List<MachineSummaryDto>()
            };
        }

        #endregion

        #region Model

        public ModelDto ToDto(ModelEntity model)
        {
            if (model == null) return null;

            return new ModelDto
            {
                Id = model.Id,
                ModelName = model.ModelName,
                ModelStatusId = model.ModelStatusId,
                ModelStatus = ToDto(model.ModelStatus),
                Workstations = model.Workstations?
                    .Select(w => new WorkstationSummaryDto
                    {
                        Id = w.Id,
                        WorkstationName = w.WorkstationName
                    })
                    .ToList() ?? new List<WorkstationSummaryDto>()
            };
        }

        #endregion

        #region ModelStatus

        public ModelStatusDto ToDto(ModelStatusEntity modelStatus)
        {
            if (modelStatus == null) return null;

            return new ModelStatusDto
            {
                Id = modelStatus.Id,
                OrderNo = modelStatus.OrderNo,
                Status = modelStatus.Status,
                Models = modelStatus.Models?
                    .Select(m => new ModelSummaryDto
                    {
                        Id = m.Id,
                        ModelName = m.ModelName
                    })
                    .ToList() ?? new List<ModelSummaryDto>()
            };
        }

        #endregion
    }
}