namespace Calin.TaskPulse.Core.DTOs.Machine
{
    /// <summary>
    /// ���x�K�n DTO�C
    /// </summary>
    public class MachineSummaryDto
    {
        public int Id { get; set; }
        public string MachineCode { get; set; }
        public string ModelName { get; set; }
    }

    /// <summary>
    /// ���x�W�ٺK�n DTO�C
    /// </summary>
    public class MachineNameSummaryDto
    {
        public int Id { get; set; }
        public string ModelName { get; set; }
    }

    /// <summary>
    /// ���x���A�K�n DTO�C
    /// </summary>
    public class MachineConditionSummaryDto
    {
        public int Id { get; set; }
        public string ConditionName { get; set; }
    }

    /// <summary>
    /// ���x�t�P�K�n DTO�C
    /// </summary>
    public class MachineBrandSummaryDto
    {
        public int Id { get; set; }
        public string BrandName { get; set; }
    }

    /// <summary>
    /// ���x��m�K�n DTO�C
    /// </summary>
    public class MachineLocationSummaryDto
    {
        public int Id { get; set; }
        public string LocationName { get; set; }
    }

    /// <summary>
    /// ���x�]�ƧO�K�n DTO�C
    /// </summary>
    public class MachineTypeSummaryDto
    {
        public int Id { get; set; }
        public string TypeName { get; set; }
    }

    /// <summary>
    /// ���x�����K�n DTO�C
    /// </summary>
    public class MachineCategorySummaryDto
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
    }

    /// <summary>
    /// �u���K�n DTO�C
    /// </summary>
    public class WorkstationSummaryDto
    {
        public int Id { get; set; }
        public string WorkstationName { get; set; }
    }

    /// <summary>
    /// ���غK�n DTO�C
    /// </summary>
    public class ModelSummaryDto
    {
        public int Id { get; set; }
        public string ModelName { get; set; }
    }

    /// <summary>
    /// ���ت��A�K�n DTO�C
    /// </summary>
    public class ModelStatusSummaryDto
    {
        public int Id { get; set; }
        public string Status { get; set; }
    }
}