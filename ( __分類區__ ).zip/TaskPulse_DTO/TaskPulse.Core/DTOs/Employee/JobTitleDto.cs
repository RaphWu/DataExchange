using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Employee
{
    /// <summary>
    /// ¾�٧��� DTO�C
    /// </summary>
    public class JobTitleDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string JobTitleName { get; set; }

        // ���X�ɯ��ݩ� - �ϥ� Summary DTO
        public ICollection<EmployeeSummaryDto> Employees { get; set; } = new List<EmployeeSummaryDto>();
    }
}