using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Employee
{
    /// <summary>
    /// �v������ DTO�C
    /// </summary>
    public class PermissionDto
    {
        public int Id { get; set; }
        public string Module { get; set; }
        public string Page { get; set; }
        public string Control { get; set; }
        public string Action { get; set; }

        // ���X�ɯ��ݩ� - �ϥ� Summary DTO
        public ICollection<DepartmentSummaryDto> Departments { get; set; } = new List<DepartmentSummaryDto>();
        public ICollection<UserGroupSummaryDto> UserGroups { get; set; } = new List<UserGroupSummaryDto>();
        public ICollection<EmployeeSummaryDto> Employees { get; set; } = new List<EmployeeSummaryDto>();
    }
}