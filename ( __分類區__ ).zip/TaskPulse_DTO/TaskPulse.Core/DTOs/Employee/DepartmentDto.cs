using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Employee
{
    /// <summary>
    /// �������� DTO�C
    /// </summary>
    public class DepartmentDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string DepartmentName { get; set; }

        // ���X�ɯ��ݩ� - �ϥ� Summary DTO
        public ICollection<EmployeeSummaryDto> Employees { get; set; } = new List<EmployeeSummaryDto>();
        public ICollection<PermissionSummaryDto> Permissions { get; set; } = new List<PermissionSummaryDto>();
    }
}