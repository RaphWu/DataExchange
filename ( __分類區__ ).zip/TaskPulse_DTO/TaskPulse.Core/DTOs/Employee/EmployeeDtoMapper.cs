using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DTOs;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DTOs.Employee
{
    /// <summary>
    /// EmployeeEntity Entity �P DTO �������ഫ���C
    /// </summary>
    public class EmployeeDtoMapper : IEmployeeDtoMapper
    {
        /// <summary>
        /// �ഫ��²�� DTO�]�Ω� UI �j�w�^�C
        /// </summary>
        public EmployeeDtoService ToSimpleDto(EmployeeEntity employee)
        {
            if (employee == null) return null;

            var dto = new EmployeeDtoService();
            dto.LoadFromEntity(employee);
            return dto;
        }

        /// <summary>
        /// �ഫ������_�� DTO�]�Ω� API �P�����޿�^�C
        /// </summary>
        public EmployeeDto ToFullDto(EmployeeEntity employee)
        {
            if (employee == null) return null;

            return new EmployeeDto
            {
                Id = employee.Id,
                EmployeeId = employee.EmployeeId,
                EmployeeName = employee.EmployeeName,
                PasswordHash = employee.PasswordHash,
                Email = employee.Email,
                IsEngineer = employee.IsEngineer,
                StatusChangeAt = employee.StatusChangeAt,

                DepartmentId = employee.DepartmentId,
                Department = ToDto(employee.Department),

                JobTitleId = employee.JobTitleId,
                JobTitle = ToDto(employee.JobTitle),

                StatusId = employee.StatusId,
                Status = ToDto(employee.Status),

                CarbonCopies = employee.CarbonCopies?
                    .Select(cc => new EmployeeSummaryDto
                    {
                        Id = cc.Id,
                        EmployeeId = cc.EmployeeId,
                        EmployeeName = cc.EmployeeName
                    })
                    .ToList() ?? new List<EmployeeSummaryDto>(),

                Permissions = employee.Permissions?
                    .Select(p => new PermissionSummaryDto
                    {
                        Id = p.Id,
                        Module = p.Module,
                        Page = p.Page,
                        Control = p.Control,
                        Action = p.Action
                    })
                    .ToList() ?? new List<PermissionSummaryDto>(),

                UserGroups = employee.UserGroups?
                    .Select(ug => new UserGroupSummaryDto
                    {
                        Id = ug.Id,
                        Name = ug.Name
                    })
                    .ToList() ?? new List<UserGroupSummaryDto>()
            };
        }

        /// <summary>
        /// DepartmentEntity �� DepartmentDto
        /// </summary>
        public DepartmentDto ToDto(DepartmentEntity department)
        {
            if (department == null) return null;

            return new DepartmentDto
            {
                Id = department.Id,
                OrderNo = department.OrderNo,
                DepartmentName = department.DepartmentName,
                Employees = department.Employees?
                    .Select(e => new EmployeeSummaryDto
                    {
                        Id = e.Id,
                        EmployeeId = e.EmployeeId,
                        EmployeeName = e.EmployeeName
                    })
                    .ToList() ?? new List<EmployeeSummaryDto>(),
                Permissions = department.Permissions?
                    .Select(p => new PermissionSummaryDto
                    {
                        Id = p.Id,
                        Module = p.Module,
                        Page = p.Page,
                        Control = p.Control,
                        Action = p.Action
                    })
                    .ToList() ?? new List<PermissionSummaryDto>()
            };
        }

        /// <summary>
        /// JobTitleEntity �� JobTitleDto
        /// </summary>
        public JobTitleDto ToDto(JobTitleEntity jobTitle)
        {
            if (jobTitle == null) return null;

            return new JobTitleDto
            {
                Id = jobTitle.Id,
                OrderNo = jobTitle.OrderNo,
                JobTitleName = jobTitle.JobTitleName,
                Employees = jobTitle.Employees?
                    .Select(e => new EmployeeSummaryDto
                    {
                        Id = e.Id,
                        EmployeeId = e.EmployeeId,
                        EmployeeName = e.EmployeeName
                    })
                    .ToList() ?? new List<EmployeeSummaryDto>()
            };
        }

        /// <summary>
        /// EmployeeStatusEntity �� EmployeeStatusDto
        /// </summary>
        public EmployeeStatusDto ToDto(EmployeeStatusEntity status)
        {
            if (status == null) return null;

            return new EmployeeStatusDto
            {
                Id = status.Id,
                OrderNo = status.OrderNo,
                StatusName = status.StatusName,
                Employees = status.Employees?
                    .Select(e => new EmployeeSummaryDto
                    {
                        Id = e.Id,
                        EmployeeId = e.EmployeeId,
                        EmployeeName = e.EmployeeName
                    })
                    .ToList() ?? new List<EmployeeSummaryDto>()
            };
        }

        /// <summary>
        /// PermissionEntity �� PermissionDto
        /// </summary>
        public PermissionDto ToDto(PermissionEntity permission)
        {
            if (permission == null) return null;

            return new PermissionDto
            {
                Id = permission.Id,
                Module = permission.Module,
                Page = permission.Page,
                Control = permission.Control,
                Action = permission.Action,
                Departments = permission.Departments?
                    .Select(d => new DepartmentSummaryDto
                    {
                        Id = d.Id,
                        DepartmentName = d.DepartmentName
                    })
                    .ToList() ?? new List<DepartmentSummaryDto>(),
                UserGroups = permission.UserGroups?
                    .Select(ug => new UserGroupSummaryDto
                    {
                        Id = ug.Id,
                        Name = ug.Name
                    })
                    .ToList() ?? new List<UserGroupSummaryDto>(),
                Employees = permission.Employees?
                    .Select(e => new EmployeeSummaryDto
                    {
                        Id = e.Id,
                        EmployeeId = e.EmployeeId,
                        EmployeeName = e.EmployeeName
                    })
                    .ToList() ?? new List<EmployeeSummaryDto>()
            };
        }

        /// <summary>
        /// UserGroupEntity �� UserGroupDto
        /// </summary>
        public UserGroupDto ToDto(UserGroupEntity userGroup)
        {
            if (userGroup == null) return null;

            return new UserGroupDto
            {
                Id = userGroup.Id,
                OrderNo = userGroup.OrderNo,
                Name = userGroup.Name,
                Members = userGroup.Members?
                    .Select(e => new EmployeeSummaryDto
                    {
                        Id = e.Id,
                        EmployeeId = e.EmployeeId,
                        EmployeeName = e.EmployeeName
                    })
                    .ToList() ?? new List<EmployeeSummaryDto>(),
                Permissions = userGroup.Permissions?
                    .Select(p => new PermissionSummaryDto
                    {
                        Id = p.Id,
                        Module = p.Module,
                        Page = p.Page,
                        Control = p.Control,
                        Action = p.Action
                    })
                    .ToList() ?? new List<PermissionSummaryDto>()
            };
        }

        /// <summary>
        /// �妸�ഫ��²�� DTO�C
        /// </summary>
        public List<EmployeeDtoService> ToSimpleDtoList(IEnumerable<EmployeeEntity> employees)
        {
            return employees?.Select(e => ToSimpleDto(e)).ToList() ?? new List<EmployeeDtoService>();
        }

        /// <summary>
        /// �妸�ഫ������ DTO�C
        /// </summary>
        public List<EmployeeDto> ToFullDtoList(IEnumerable<EmployeeEntity> employees)
        {
            return employees?.Select(e => ToFullDto(e)).ToList() ?? new List<EmployeeDto>();
        }
    }
}