using System.Collections.Generic;
using Calin.TaskPulse.Core.DTOs;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using DepartmentEntity = Calin.TaskPulse.Entity.Core.DepartmentEntity;
using Employee = Calin.TaskPulse.Entity.Core.EmployeeEntity;
using EmployeeStatusEntity = Calin.TaskPulse.Entity.Core.EmployeeStatusEntity;
using JobTitleEntity = Calin.TaskPulse.Entity.Core.JobTitleEntity;
using PermissionEntity = Calin.TaskPulse.Entity.Core.PermissionEntity;
using UserGroupEntity = Calin.TaskPulse.Entity.Core.UserGroupEntity;

namespace Calin.TaskPulse.Core.DTOs.Employee
{
    /// <summary>
    /// EmployeeEntity Entity �P DTO �������ഫ�������C
    /// </summary>
    /// <remarks><code><![CDATA[�ϥΤ覡�G
    /// 
    /// public class EmployeeService
    /// {
    ///     private readonly CoreContext _context;
    ///     private readonly IEmployeeDtoMapper _mapper;
    /// 
    ///     public EmployeeService(CoreContext context, IEmployeeDtoMapper mapper)
    ///     {
    ///         _context = context;
    ///         _mapper = mapper;
    ///     }
    /// 
    ///     public EmployeeDto GetEmployeeById(int id)
    ///     {
    ///         var employee = _context.Employees
    ///             .Include(e => e.Department)
    ///             .Include(e => e.JobTitle)
    ///             .Include(e => e.Status)
    ///             .FirstOrDefault(e => e.Id == id);
    /// 
    ///         // �z�L�`�J�� Mapper �ഫ
    ///         return _mapper.ToFullDto(employee);
    ///     }
    /// 
    ///     public List<EmployeeDtoService> GetAllEmployeesSimple()
    ///     {
    ///         var employees = _context.Employees.ToList();
    ///         return _mapper.ToSimpleDtoList(employees);
    ///     }
    /// }]]></code></remarks>
    public interface IEmployeeDtoMapper
    {
        /// <summary>
        /// �ഫ��²�� DTO�]�Ω� UI �j�w�^�C
        /// </summary>
        EmployeeDtoService ToSimpleDto(EmployeeEntity employee);

        /// <summary>
        /// �ഫ������_�� DTO�]�Ω� API �P�����޿�^�C
        /// </summary>
        EmployeeDto ToFullDto(EmployeeEntity employee);

        /// <summary>
        /// DepartmentEntity �� DepartmentDto
        /// </summary>
        DepartmentDto ToDto(DepartmentEntity department);

        /// <summary>
        /// JobTitleEntity �� JobTitleDto
        /// </summary>
        JobTitleDto ToDto(JobTitleEntity jobTitle);

        /// <summary>
        /// EmployeeStatusEntity �� EmployeeStatusDto
        /// </summary>
        EmployeeStatusDto ToDto(EmployeeStatusEntity status);

        /// <summary>
        /// PermissionEntity �� PermissionDto
        /// </summary>
        PermissionDto ToDto(PermissionEntity permission);

        /// <summary>
        /// UserGroupEntity �� UserGroupDto
        /// </summary>
        UserGroupDto ToDto(UserGroupEntity userGroup);

        /// <summary>
        /// �妸�ഫ��²�� DTO�C
        /// </summary>
        List<EmployeeDtoService> ToSimpleDtoList(IEnumerable<EmployeeEntity> employees);

        /// <summary>
        /// �妸�ഫ������ DTO�C
        /// </summary>
        List<EmployeeDto> ToFullDtoList(IEnumerable<EmployeeEntity> employees);
    }
}