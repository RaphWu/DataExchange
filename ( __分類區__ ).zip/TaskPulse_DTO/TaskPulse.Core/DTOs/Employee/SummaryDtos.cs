namespace Calin.TaskPulse.Core.DTOs.Employee
{
    /// <summary>
    /// ���u�K�n DTO�]�Ω��קK�`���ѷӡ^�C
    /// </summary>
    public class EmployeeSummaryDto
    {
        public int Id { get; set; }
        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
    }

    /// <summary>
    /// �����K�n DTO�C
    /// </summary>
    public class DepartmentSummaryDto
    {
        public int Id { get; set; }
        public string DepartmentName { get; set; }
    }

    /// <summary>
    /// ¾�ٺK�n DTO�C
    /// </summary>
    public class JobTitleSummaryDto
    {
        public int Id { get; set; }
        public string JobTitleName { get; set; }
    }

    /// <summary>
    /// ���u���A�K�n DTO�C
    /// </summary>
    public class EmployeeStatusSummaryDto
    {
        public int Id { get; set; }
        public string StatusName { get; set; }
    }

    /// <summary>
    /// �v���K�n DTO�C
    /// </summary>
    public class PermissionSummaryDto
    {
        public int Id { get; set; }
        public string Module { get; set; }
        public string Page { get; set; }
        public string Control { get; set; }
        public string Action { get; set; }
    }

    /// <summary>
    /// �ϥΪ̸s�պK�n DTO�C
    /// </summary>
    public class UserGroupSummaryDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}