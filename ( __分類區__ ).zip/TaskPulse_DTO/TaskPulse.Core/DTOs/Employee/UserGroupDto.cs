using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Employee
{
    /// <summary>
    /// �ϥΪ̸s�է��� DTO�C
    /// </summary>
    public class UserGroupDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string Name { get; set; }

        // ���X�ɯ��ݩ� - �ϥ� Summary DTO
        public ICollection<EmployeeSummaryDto> Members { get; set; } = new List<EmployeeSummaryDto>();
        public ICollection<PermissionSummaryDto> Permissions { get; set; } = new List<PermissionSummaryDto>();
    }
}