using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Employee
{
    /// <summary>
    /// ���u���A���� DTO�C
    /// </summary>
    public class EmployeeStatusDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string StatusName { get; set; }

        // ���X�ɯ��ݩ� - �ϥ� Summary DTO
        public ICollection<EmployeeSummaryDto> Employees { get; set; } = new List<EmployeeSummaryDto>();
    }
}