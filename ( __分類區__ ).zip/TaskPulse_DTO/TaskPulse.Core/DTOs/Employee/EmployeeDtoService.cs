﻿using System;
using System.ComponentModel;
using System.Threading.Tasks;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DTOs.Employee
{
    /// <summary>
    /// EmployeeEntity DTO 服務（簡化版，用於 UI 綁定）。
    /// </summary>
    public class EmployeeDtoService
    {
        public int Id { get; set; }

        [Description("工號")]
        public string EmployeeId { get; set; }

        [Description("姓名")]
        public string EmployeeName { get; set; }

        [Description("密碼")]
        public string PasswordHash { get; set; }

        [Description("Email")]
        public string Email { get; set; }

        [Description("維護工程師")]
        public bool IsEngineer { get; set; } = false;

        [Description("日期")]
        public DateTime? StatusChangeAt { get; set; }

        // 平面結構 - 僅 ID 與名稱
        public int? DepartmentId { get; set; }
        [Description("部門")]
        public string DepartmentName { get; set; }

        public int? JobTitleId { get; set; }
        [Description("職稱")]
        public string JobTitleName { get; set; }

        public int StatusId { get; set; }
        [Description("狀態")]
        public string StatusName { get; set; }

        /// <summary>
        /// 從 Entity 載入資料到 DTO。
        /// </summary>
        public void LoadFromEntity(EmployeeEntity employee)
        {
            if (employee == null)
                return;

            Id = employee.Id;
            EmployeeId = employee.EmployeeId;
            EmployeeName = employee.EmployeeName;
            PasswordHash = employee.PasswordHash;
            Email = employee.Email;
            IsEngineer = employee.IsEngineer;
            StatusChangeAt = employee.StatusChangeAt;

            DepartmentId = employee.DepartmentId;
            DepartmentName = employee.Department?.DepartmentName ?? string.Empty;

            JobTitleId = employee.JobTitleId;
            JobTitleName = employee.JobTitle?.JobTitleName ?? string.Empty;

            StatusId = employee.StatusId;
            StatusName = employee.Status?.StatusName ?? string.Empty;
        }
    }
}
