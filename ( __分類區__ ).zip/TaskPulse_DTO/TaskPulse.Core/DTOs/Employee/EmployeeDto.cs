using System;
using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.Employee
{
    /// <summary>
    /// ���u���� DTO�]�t�_�����p�^�C
    /// </summary>
    public class EmployeeDto
    {
        public int Id { get; set; }
        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string PasswordHash { get; set; }
        public string Email { get; set; }
        public bool IsEngineer { get; set; } = false;
        public DateTime? StatusChangeAt { get; set; }

        // ��@�ɯ��ݩ� - �ϥΧ��� DTO
        public DepartmentDto Department { get; set; }
        public int? DepartmentId { get; set; }

        public JobTitleDto JobTitle { get; set; }
        public int? JobTitleId { get; set; }

        public EmployeeStatusDto Status { get; set; }
        public int StatusId { get; set; }

        // ���X�ɯ��ݩ� - �ϥ� Summary DTO �קK�`�׻��j
        public ICollection<EmployeeSummaryDto> CarbonCopies { get; set; } = new List<EmployeeSummaryDto>();
        public ICollection<PermissionSummaryDto> Permissions { get; set; } = new List<PermissionSummaryDto>();
        public ICollection<UserGroupSummaryDto> UserGroups { get; set; } = new List<UserGroupSummaryDto>();
    }
}