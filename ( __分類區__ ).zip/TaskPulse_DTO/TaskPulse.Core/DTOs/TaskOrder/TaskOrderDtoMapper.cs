using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DTOs.Employee;
using Calin.TaskPulse.Core.DTOs.Machine;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.DTOs.TaskOrder
{
    /// <summary>
    /// TaskOrder ���� Entity �P DTO �������ഫ���C
    /// </summary>
    public class TaskOrderDtoMapper : ITaskOrderDtoMapper
    {
        private readonly IEmployeeDtoMapper _employeeMapper;
        private readonly IMachineDtoMapper _machineMapper;

        public TaskOrderDtoMapper(
            IEmployeeDtoMapper employeeMapper,
            IMachineDtoMapper machineMapper)
        {
            _employeeMapper = employeeMapper;
            _machineMapper = machineMapper;
        }

        #region TaskOrder

        public TaskOrderDto ToDto(TaskOrderEntity taskOrder)
        {
            if (taskOrder == null) return null;

            return new TaskOrderDto
            {
                Id = taskOrder.Id,
                WorkOrderNo = taskOrder.WorkOrderNo,
                Status = taskOrder.Status,
                CreationDateTime = taskOrder.CreationDateTime,

                // ���x�P�u��
                MachineId = taskOrder.MachineId,
                Machine = taskOrder.Machine != null ? _machineMapper.ToDto(taskOrder.Machine) : null,

                WorkstationId = taskOrder.WorkstationId,
                Workstation = taskOrder.Workstation != null ? _machineMapper.ToDto(taskOrder.Workstation) : null,

                // ���ɤH��
                CreatorId = taskOrder.CreatorId,
                Creator = taskOrder.Creator != null ? new EmployeeSummaryDto
                {
                    Id = taskOrder.Creator.Id,
                    EmployeeId = taskOrder.Creator.EmployeeId,
                    EmployeeName = taskOrder.Creator.EmployeeName
                } : null,

                // ���@����
                MaintenanceUnitId = taskOrder.MaintenanceUnitId,
                MaintenanceUnit = ToDto(taskOrder.MaintenanceUnit),

                Engineers = taskOrder.Engineers?
                    .Select(e => new EmployeeSummaryDto
                    {
                        Id = e.Id,
                        EmployeeId = e.EmployeeId,
                        EmployeeName = e.EmployeeName
                    })
                    .ToList() ?? new List<EmployeeSummaryDto>(),

                AcceptedTime = taskOrder.AcceptedTime,

                // ���@���e
                IssueCategoryId = taskOrder.IssueCategoryId,
                IssueCategory = ToDto(taskOrder.IssueCategory),

                IssueDescription = taskOrder.IssueDescription,
                Details = taskOrder.Details,
                RepairStarted = taskOrder.RepairStarted,
                RepairCompleted = taskOrder.RepairCompleted,
                RepairDurationTick = taskOrder.RepairDurationTick,
                FillingTime = taskOrder.FillingTime,

                // ���@�ӽи�T
                RequestingUnitId = taskOrder.RequestingUnitId,
                RequestingUnit = taskOrder.RequestingUnit != null ? new DepartmentSummaryDto
                {
                    Id = taskOrder.RequestingUnit.Id,
                    DepartmentName = taskOrder.RequestingUnit.DepartmentName
                } : null,

                FeedbackEmployeeId = taskOrder.FeedbackEmployeeId,
                FeedbackEmployee = taskOrder.FeedbackEmployee != null ? new EmployeeSummaryDto
                {
                    Id = taskOrder.FeedbackEmployee.Id,
                    EmployeeId = taskOrder.FeedbackEmployee.EmployeeId,
                    EmployeeName = taskOrder.FeedbackEmployee.EmployeeName
                } : null,

                Feedback = taskOrder.Feedback,
                OutageStarted = taskOrder.OutageStarted,
                OutageEnded = taskOrder.OutageEnded,
                OutageDurationTick = taskOrder.OutageDurationTick,

                // ��L
                Responsible = taskOrder.Responsible
            };
        }

        public List<TaskOrderDto> ToDtoList(IEnumerable<TaskOrderEntity> taskOrders)
        {
            return taskOrders?.Select(t => ToDto(t)).ToList() ?? new List<TaskOrderDto>();
        }

        #endregion

        #region MaintenanceUnit

        public MaintenanceUnitDto ToDto(MaintenanceUnitEntity maintenanceUnit)
        {
            if (maintenanceUnit == null) return null;

            return new MaintenanceUnitDto
            {
                Id = maintenanceUnit.Id,
                OrderNo = maintenanceUnit.OrderNo,
                UnitName = maintenanceUnit.UnitName,
                TaskOrders = maintenanceUnit.TaskOrders?
                    .Select(t => new TaskOrderSummaryDto
                    {
                        Id = t.Id,
                        WorkOrderNo = t.WorkOrderNo,
                        Status = t.Status.ToString(),
                        CreationDateTime = t.CreationDateTime
                    })
                    .ToList() ?? new List<TaskOrderSummaryDto>()
            };
        }

        #endregion

        #region IssueCategory

        public IssueCategoryDto ToDto(IssueCategoryEntity issueCategory)
        {
            if (issueCategory == null) return null;

            return new IssueCategoryDto
            {
                Id = issueCategory.Id,
                OrderNo = issueCategory.OrderNo,
                CategoryName = issueCategory.CategoryName,
                TaskOrders = issueCategory.TaskOrders?
                    .Select(t => new TaskOrderSummaryDto
                    {
                        Id = t.Id,
                        WorkOrderNo = t.WorkOrderNo,
                        Status = t.Status.ToString(),
                        CreationDateTime = t.CreationDateTime
                    })
                    .ToList() ?? new List<TaskOrderSummaryDto>()
            };
        }

        #endregion
    }
}