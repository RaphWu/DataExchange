using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.TaskOrder
{
    /// <summary>
    /// ���D�������� DTO�C
    /// </summary>
    public class IssueCategoryDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string CategoryName { get; set; }

        // ���X�ɯ��ݩ�
        public ICollection<TaskOrderSummaryDto> TaskOrders { get; set; } = new List<TaskOrderSummaryDto>();
    }
}