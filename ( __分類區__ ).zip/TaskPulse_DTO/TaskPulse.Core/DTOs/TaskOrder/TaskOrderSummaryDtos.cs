using System;

namespace Calin.TaskPulse.Core.DTOs.TaskOrder
{
    /// <summary>
    /// ���@�u��K�n DTO�C
    /// </summary>
    public class TaskOrderSummaryDto
    {
        public int Id { get; set; }
        public string WorkOrderNo { get; set; }
        public string Status { get; set; }
        public DateTime CreationDateTime { get; set; }
    }

    /// <summary>
    /// ���@���K�n DTO�C
    /// </summary>
    public class MaintenanceUnitSummaryDto
    {
        public int Id { get; set; }
        public string UnitName { get; set; }
    }

    /// <summary>
    /// ���D�����K�n DTO�C
    /// </summary>
    public class IssueCategorySummaryDto
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
    }
}