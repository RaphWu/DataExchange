using System.Collections.Generic;

namespace Calin.TaskPulse.Core.DTOs.TaskOrder
{
    /// <summary>
    /// ���@��짹�� DTO�C
    /// </summary>
    public class MaintenanceUnitDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string UnitName { get; set; }

        // ���X�ɯ��ݩ�
        public ICollection<TaskOrderSummaryDto> TaskOrders { get; set; } = new List<TaskOrderSummaryDto>();
    }
}