using System;
using System.Collections.Generic;
using Calin.TaskPulse.Core.DTOs.Employee;
using Calin.TaskPulse.Core.DTOs.Machine;
using Calin.TaskPulse.Entity.Contants;

namespace Calin.TaskPulse.Core.DTOs.TaskOrder
{
    /// <summary>
    /// ���@�u�槹�� DTO�C
    /// </summary>
    public class TaskOrderDto
    {
        public int Id { get; set; }

        // �u����
        public string WorkOrderNo { get; set; }
        public FlowStatus Status { get; set; }

        // ���x�P�u��
        public MachineDto Machine { get; set; }
        public int? MachineId { get; set; }

        public WorkstationDto Workstation { get; set; }
        public int? WorkstationId { get; set; }

        // ���ɤH��
        public EmployeeSummaryDto Creator { get; set; }
        public int CreatorId { get; set; }
        public DateTime CreationDateTime { get; set; }

        // ���@����
        public MaintenanceUnitDto MaintenanceUnit { get; set; }
        public int? MaintenanceUnitId { get; set; }

        public ICollection<EmployeeSummaryDto> Engineers { get; set; } = new List<EmployeeSummaryDto>();
        public DateTime AcceptedTime { get; set; }

        // ���@���e
        public IssueCategoryDto IssueCategory { get; set; }
        public int? IssueCategoryId { get; set; }

        public string IssueDescription { get; set; }
        public string Details { get; set; }
        public DateTime? RepairStarted { get; set; }
        public DateTime? RepairCompleted { get; set; }
        public long RepairDurationTick { get; set; }
        public DateTime? FillingTime { get; set; }

        // ���@�ӽи�T
        public DepartmentSummaryDto RequestingUnit { get; set; }
        public int? RequestingUnitId { get; set; }

        public EmployeeSummaryDto FeedbackEmployee { get; set; }
        public int? FeedbackEmployeeId { get; set; }

        public string Feedback { get; set; }
        public DateTime? OutageStarted { get; set; }
        public DateTime? OutageEnded { get; set; }
        public long OutageDurationTick { get; set; }

        // ��L
        public string Responsible { get; set; }
    }
}