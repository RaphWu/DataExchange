using System.Collections.Generic;
using Calin.TaskPulse.Entity.MaintiFlow;
using Sunny.UI;

namespace Calin.TaskPulse.Core.DTOs.TaskOrder
{
    /// <summary>
    /// TaskOrder ���� Entity �P DTO �������ഫ�������C
    /// </summary>
    /// <remarks><code><![CDATA[�ϥνd�ҡG
    /// 
    /// public class TaskOrderService
    /// {
    ///     private readonly MaintiFlowContext _context;
    ///     private readonly ITaskOrderDtoMapper _mapper;
    /// 
    ///     public TaskOrderService(MaintiFlowContext context, ITaskOrderDtoMapper mapper)
    ///     {
    ///         _context = context;
    ///         _mapper = mapper;
    ///     }
    /// 
    ///     public TaskOrderDto GetTaskOrderById(int id)
    ///     {
    ///         var taskOrder = _context.TaskOrders
    ///             .Include(t => t.Machine)
    ///             .Include(t => t.Workstation)
    ///             .Include(t => t.Creator)
    ///             .Include(t => t.MaintenanceUnit)
    ///             .Include(t => t.Engineers)
    ///             .Include(t => t.IssueCategory)
    ///             .Include(t => t.RequestingUnit)
    ///             .Include(t => t.FeedbackEmployee)
    ///             .FirstOrDefault(t => t.Id == id);
    /// 
    ///         return _mapper.ToDto(taskOrder);
    ///     }
    /// 
    ///     public List<TaskOrderDto> GetAllTaskOrders()
    ///     {
    ///         var taskOrders = _context.TaskOrders.ToList();
    ///         return _mapper.ToDtoList(taskOrders);
    ///     }
    /// }]]></code></remarks>
    public interface ITaskOrderDtoMapper
    {
        /// <summary>
        /// TaskOrderEntity �� TaskOrderDto
        /// </summary>
        TaskOrderDto ToDto(TaskOrderEntity taskOrder);

        /// <summary>
        /// �妸�ഫ
        /// </summary>
        List<TaskOrderDto> ToDtoList(IEnumerable<TaskOrderEntity> taskOrders);

        /// <summary>
        /// MaintenanceUnitEntity �� MaintenanceUnitDto
        /// </summary>
        MaintenanceUnitDto ToDto(MaintenanceUnitEntity maintenanceUnit);

        /// <summary>
        /// IssueCategoryEntity �� IssueCategoryDto
        /// </summary>
        IssueCategoryDto ToDto(IssueCategoryEntity issueCategory);
    }
}