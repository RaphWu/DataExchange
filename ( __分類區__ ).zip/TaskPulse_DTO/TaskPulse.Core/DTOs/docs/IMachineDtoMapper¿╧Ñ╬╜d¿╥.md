# 1. �򥻨ϥνd�ҡ]�b�A�Ȥ��`�J�ϥΡ^

```csharp
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Calin.TaskPulse.Core.DTOs.Machine;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Services
{
    /// <summary>
    /// ���x�A�Ƚd�ҡC
    /// </summary>
    public class MachineService
    {
        private readonly CoreContext _context;
        private readonly IMachineDtoMapper _machineMapper;

        // �z�L�غc�禡�`�J Mapper
        public MachineService(CoreContext context, IMachineDtoMapper machineMapper)
        {
            _context = context;
            _machineMapper = machineMapper;
        }

        /// <summary>
        /// ���o��@���x�����ơC
        /// </summary>
        public MachineDto GetMachineById(int id)
        {
            var machine = _context.Machines
                .Include(m => m.MachineName)
                .Include(m => m.MachineName.MachineType)
                .Include(m => m.MachineName.MachineType.Category)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Workstations)
                .FirstOrDefault(m => m.Id == id);

            // �ϥ� Mapper �ഫ�� DTO
            return _machineMapper.ToDto(machine);
        }

        /// <summary>
        /// ���o�Ҧ����x�M��C
        /// </summary>
        public List<MachineDto> GetAllMachines()
        {
            var machines = _context.Machines
                .Include(m => m.MachineName)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .ToList();

            // �妸�ഫ
            return _machineMapper.ToDtoList(machines);
        }

        /// <summary>
        /// �̪��A�z����x�C
        /// </summary>
        public List<MachineDto> GetMachinesByCondition(int conditionId)
        {
            var machines = _context.Machines
                .Where(m => m.ConditionId == conditionId)
                .Include(m => m.MachineName)
                .Include(m => m.Condition)
                .ToList();

            return _machineMapper.ToDtoList(machines);
        }

        /// <summary>
        /// ���o���x�W�ٲM��]�t�]�ƧO�P�����^�C
        /// </summary>
        public List<MachineNameDto> GetAllMachineNames()
        {
            var machineNames = _context.MachineNames
                .Include(mn => mn.MachineType)
                .Include(mn => mn.MachineType.Category)
                .Include(mn => mn.Machines)
                .ToList();

            // �ഫ�C�� MachineName
            return machineNames.Select(mn => _machineMapper.ToDto(mn)).ToList();
        }

        /// <summary>
        /// ���o��@���x���A��ơ]�t���p�����x�M��^�C
        /// </summary>
        public ConditionDto GetConditionById(int id)
        {
            var condition = _context.MachineConditions
                .Include(c => c.Machines)
                .Include(c => c.Machines.Select(m => m.MachineName))
                .FirstOrDefault(c => c.Id == id);

            return _machineMapper.ToDto(condition);
        }

        /// <summary>
        /// ���o���x�����𪬵��c�C
        /// </summary>
        public List<MachineCategoryDto> GetCategoryHierarchy()
        {
            var categories = _context.MachineCategories
                .Include(c => c.MachineTypes)
                .ToList();

            return categories.Select(c => _machineMapper.ToDto(c)).ToList();
        }
    }
}
```

---

# 2. �b ViewModel ���ϥ�

```csharp
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.DTOs.Machine;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace Calin.TaskPulse.Core.ViewModels
{
    public partial class MachineListViewModel : ObservableObject
    {
        private readonly IMachineDtoMapper _machineMapper;
        private readonly CoreContext _context;

        [ObservableProperty]
        private ObservableCollection<MachineDto> _machines;

        [ObservableProperty]
        private MachineDto _selectedMachine;

        public MachineListViewModel(CoreContext context, IMachineDtoMapper machineMapper)
        {
            _context = context;
            _machineMapper = machineMapper;
            Machines = new ObservableCollection<MachineDto>();
        }

        [RelayCommand]
        private async Task LoadMachinesAsync()
        {
            var machineEntities = await _context.Machines
                .Include(m => m.MachineName)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .ToListAsync();

            // �ഫ�� DTO �øj�w�� UI
            var machineDtos = _machineMapper.ToDtoList(machineEntities);
            
            Machines.Clear();
            foreach (var dto in machineDtos)
            {
                Machines.Add(dto);
            }
        }

        [RelayCommand]
        private void ViewMachineDetails(MachineDto machine)
        {
            SelectedMachine = machine;
            
            // �ϥ� DTO ��ܸ��
            var details = $@"
���x�s���G{machine.MachineCode}
���x�W�١G{machine.MachineName?.ModelName}
�]�ƧO�G{machine.MachineName?.MachineType?.TypeName}
���A�G{machine.Condition?.ConditionName}
�t�P�G{machine.Brand?.BrandName}
��m�G{machine.Location?.LocationName}
�Ǹ��G{machine.SerialNumber}
�s���G{(machine.Connected ? "�O" : "�_")}
�Ƶ��G{machine.Remark}
            ";
            
            // ��ܸԲӸ�T...
        }
    }
}
```

---

# 3. �b API Controller ���ϥΡ]�Y�� Web API�^

```csharp
using System.Web.Http;
using Calin.TaskPulse.Core.DTOs.Machine;

namespace Calin.TaskPulse.WebApi.Controllers
{
    [RoutePrefix("api/machines")]
    public class MachinesController : ApiController
    {
        private readonly CoreContext _context;
        private readonly IMachineDtoMapper _machineMapper;

        public MachinesController(CoreContext context, IMachineDtoMapper machineMapper)
        {
            _context = context;
            _machineMapper = machineMapper;
        }

        // GET: api/machines
        [HttpGet]
        [Route("")]
        public IHttpActionResult GetAll()
        {
            var machines = _context.Machines
                .Include(m => m.MachineName)
                .Include(m => m.Condition)
                .ToList();

            var dtos = _machineMapper.ToDtoList(machines);
            return Ok(dtos);
        }

        // GET: api/machines/5
        [HttpGet]
        [Route("{id:int}")]
        public IHttpActionResult GetById(int id)
        {
            var machine = _context.Machines
                .Include(m => m.MachineName)
                .Include(m => m.MachineName.MachineType)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .FirstOrDefault(m => m.Id == id);

            if (machine == null)
                return NotFound();

            var dto = _machineMapper.ToDto(machine);
            return Ok(dto);
        }

        // GET: api/machines/conditions
        [HttpGet]
        [Route("conditions")]
        public IHttpActionResult GetConditions()
        {
            var conditions = _context.MachineConditions
                .Include(c => c.Machines)
                .ToList();

            var dtos = conditions.Select(c => _machineMapper.ToDto(c)).ToList();
            return Ok(dtos);
        }
    }
}
```

---

# 4. �����d�߽d�ҡ]�h�� Mapper ��@�^

```csharp
using Calin.TaskPulse.Core.DTOs.Employee;
using Calin.TaskPulse.Core.DTOs.Machine;
using Calin.TaskPulse.Core.DTOs.TaskOrder;

namespace Calin.TaskPulse.Core.Services
{
    public class ReportService
    {
        private readonly CoreContext _context;
        private readonly IMachineDtoMapper _machineMapper;
        private readonly IEmployeeDtoMapper _employeeMapper;
        private readonly ITaskOrderDtoMapper _taskOrderMapper;

        public ReportService(
            CoreContext context,
            IMachineDtoMapper machineMapper,
            IEmployeeDtoMapper employeeMapper,
            ITaskOrderDtoMapper taskOrderMapper)
        {
            _context = context;
            _machineMapper = machineMapper;
            _employeeMapper = employeeMapper;
            _taskOrderMapper = taskOrderMapper;
        }

        /// <summary>
        /// ���o���x���@�����C
        /// </summary>
        public MachineMaintenanceReportDto GetMachineMaintenanceReport(int machineId)
        {
            // ���o���x���
            var machine = _context.Machines
                .Include(m => m.MachineName)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .FirstOrDefault(m => m.Id == machineId);

            var machineDto = _machineMapper.ToDto(machine);

            // ���o�Ӿ��x�����@�u��
            var taskOrders = _context.TaskOrders
                .Where(t => t.MachineId == machineId)
                .Include(t => t.Creator)
                .Include(t => t.Engineers)
                .Include(t => t.IssueCategory)
                .ToList();

            var taskOrderDtos = _taskOrderMapper.ToDtoList(taskOrders);

            // �զX����
            return new MachineMaintenanceReportDto
            {
                Machine = machineDto,
                TaskOrders = taskOrderDtos,
                TotalMaintenanceCount = taskOrderDtos.Count,
                AverageRepairTime = CalculateAverageRepairTime(taskOrderDtos)
            };
        }

        private double CalculateAverageRepairTime(List<TaskOrderDto> orders)
        {
            if (orders.Count == 0) return 0;
            
            var totalTicks = orders.Sum(o => o.RepairDurationTick);
            return TimeSpan.FromTicks(totalTicks / orders.Count).TotalHours;
        }
    }

    // ���� DTO
    public class MachineMaintenanceReportDto
    {
        public MachineDto Machine { get; set; }
        public List<TaskOrderDto> TaskOrders { get; set; }
        public int TotalMaintenanceCount { get; set; }
        public double AverageRepairTime { get; set; }
    }
}
```

---

# 5. �椸���սd�ҡ]�ϥ� Mock�^

```csharp
using Moq;
using NUnit.Framework;
using Calin.TaskPulse.Core.DTOs.Machine;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Tests.Services
{
    [TestFixture]
    public class MachineServiceTests
    {
        private Mock<CoreContext> _mockContext;
        private Mock<IMachineDtoMapper> _mockMapper;
        private MachineService _service;

        [SetUp]
        public void Setup()
        {
            _mockContext = new Mock<CoreContext>();
            _mockMapper = new Mock<IMachineDtoMapper>();
            _service = new MachineService(_mockContext.Object, _mockMapper.Object);
        }

        [Test]
        public void GetMachineById_ReturnsMachineDto()
        {
            // Arrange
            var machineEntity = new MachineEntity { Id = 1, MachineCode = "M001" };
            var expectedDto = new MachineDto { Id = 1, MachineCode = "M001" };

            _mockMapper.Setup(m => m.ToDto(machineEntity)).Returns(expectedDto);

            // Act
            var result = _mockMapper.Object.ToDto(machineEntity);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.Id, Is.EqualTo(1));
            Assert.That(result.MachineCode, Is.EqualTo("M001"));
            _mockMapper.Verify(m => m.ToDto(It.IsAny<MachineEntity>()), Times.Once);
        }
    }
}
```

---

# �ϥέn�I�`��

1. �L�غc�禡�`�J�G���n new�A�� Autofac �۰ʸѪR�̿�
2. �ϥ� Include �w�����p�G�קK N+1 �d�߰��D
3. �妸�ഫ�ϥ� ToDtoList�G�į��n
4. DTO �A�Ω��h�ǿ�GService �� ViewModel �� View
5. �i Mock �H�Q���աG�����]�p���椸���է�e��

�o�ǽd�Ҳ[�\�F IMachineDtoMapper �b��ڱM�פ����U�بϥγ����I