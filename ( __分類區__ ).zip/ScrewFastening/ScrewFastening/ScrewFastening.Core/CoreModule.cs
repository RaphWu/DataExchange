﻿using Autofac;

namespace Calin.ScrewFastening.Core
{
    public class CoreModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {

        }
    }
}
