﻿using Automation.BDaq;
using Calin.Abstractions.Logging;

namespace Calin.DAQ.USB4704
{
    public class Usb4704Streaming : IUsb4704Streaming
    {
        private readonly ICalinLogger _logger;
        private WaveformAiCtrl _waveformAiCtrl = new WaveformAiCtrl();

        public event EventHandler DataReady = null;

        //private int _streamingTotalData;
        private double[] _dataScaled;
        private List<double> _streamingPlotData_Time;
        private List<double> _streamingPlotData_Timestamp;
        private List<double> _streamingPlotData_Measure;
        private List<double> _streamingPlotData_Kalman;
        private List<double> _streamingPlotData_Lpf1_1;
        private List<double> _streamingPlotData_Lpf2_1;
        private List<double> _streamingPlotData_Lpf2_2;

        public Usb4704Streaming(ICalinLogger calinLogger)
        {
            _logger = calinLogger;
        }

        public void Usb4704StreamingInit(string deviceCode = "")
        {
            _waveformAiCtrl.SelectedDevice = new DeviceInformation(deviceCode);
            if (!_waveformAiCtrl.Initialized)
            {
                _logger.Warning($"裝置開啟失敗：{nameof(Usb4704StreamingInit)}");
                _waveformAiCtrl.Dispose();
                _waveformAiCtrl = null;
                return;
            }

            _waveformAiCtrl.Channels[0].SignalType = AiSignalType.Differential;
            _waveformAiCtrl.DataReady += WaveformAiCtrl_DataReady;
            _waveformAiCtrl.CacheOverflow += WaveformAiCtrl_CacheOverflow;
            _waveformAiCtrl.Overrun += WaveformAiCtrl_Overrun;
        }

        /// <inheritdoc/>
        public void Dispose()
        {
            _waveformAiCtrl.DataReady -= WaveformAiCtrl_DataReady;
            _waveformAiCtrl.CacheOverflow -= WaveformAiCtrl_CacheOverflow;
            _waveformAiCtrl.Overrun -= WaveformAiCtrl_Overrun;
            _waveformAiCtrl.Dispose();
            GC.SuppressFinalize(this);
        }

        private void WaveformAiCtrl_DataReady(object sender, BfdAiEventArgs args)
        {
            try
            {
                if (_waveformAiCtrl.State == ControlState.Idle)
                    return;

                if (_dataScaled.Length < args.Count)
                    _dataScaled = new double[args.Count];
                //_streamingTotalData += args.Count;

                ErrorCode err = ErrorCode.Success;
                err = _waveformAiCtrl.GetData(args.Count, _dataScaled);
                if (err != ErrorCode.Success && err != ErrorCode.WarningRecordEnd)
                {
                    HandleError(err);
                    return;
                }

                //foreach (var data in _dataScaled)
                //{
                //    _streamingPlotData_Measure.Add(Math.Round(data, 3));
                //    //_streamingPlotData_Kalman.Add(Math.Round(_filterKalman.Filter(data, 0.0), 3));
                //    //_streamingPlotData_Lpf1_1.Add(Math.Round(FilterLowPass.LPF1_1(data, CutoffFreq, ClockRate), 3));
                //    //_streamingPlotData_Lpf2_1.Add(Math.Round(FilterLowPass.LPF2_1(data, CutoffFreq, ClockRate), 3));
                //    //_streamingPlotData_Lpf2_2.Add(Math.Round(FilterLowPass.LPF2_2(data, CutoffFreq, ClockRate), 3));
                //} 
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
            }
        }

        private void WaveformAiCtrl_CacheOverflow(object sender, BfdAiEventArgs args)
        {
            throw new NotImplementedException();
        }

        private void WaveformAiCtrl_Overrun(object sender, BfdAiEventArgs args)
        {
            throw new NotImplementedException();
        }

        private void HandleError(ErrorCode err)
        {
            if ((err >= ErrorCode.ErrorHandleNotValid) && (err != ErrorCode.Success))
                _logger.Error(String.Concat("USB-4704異常！錯誤碼：0x", err.ToString("X8")));
        }
    }
}
