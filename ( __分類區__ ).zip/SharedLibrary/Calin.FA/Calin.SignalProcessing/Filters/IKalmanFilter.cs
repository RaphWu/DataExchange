﻿namespace Calin.SignalProcessing.Filters
{
    public interface IKalmanFilter
    {
        /// <summary>
        /// 濾波測量值。
        /// </summary>
        /// <param name="measurement">要濾波的測量值。</param>
        /// <param name="u">受控輸入值。</param>
        /// <returns>濾波後的值。</returns>
        double Filter(double measurement, double u);

        /// <summary>
        /// 濾波測量值。
        /// </summary>
        /// <param name="measurement">要濾波的測量值。</param>
        /// <returns>濾波後的值。</returns>
        double Filter(double measurement);

        /// <summary>
        /// 取得最後一次的濾波值。
        /// </summary>
        /// <returns>最後一次的濾波值。</returns>
        double LastMeasurement();

        /// <summary>
        /// 設定測量噪聲。
        /// </summary>
        /// <param name="noise">新的測量噪聲。</param>
        void SetMeasurementNoise(double noise);

        /// <summary>
        /// 設定過程噪聲。
        /// </summary>
        /// <param name="noise">新的過程噪聲。</param>
        void SetProcessNoise(double noise);
    }
}
