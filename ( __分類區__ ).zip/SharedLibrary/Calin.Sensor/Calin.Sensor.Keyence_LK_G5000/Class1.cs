﻿namespace Calin.Sensor.LK_G5000
{
    public class Class1
    {

    }
}
