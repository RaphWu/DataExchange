﻿namespace AcmDemo.Constants
{
    /// <summary>
    /// 外部驅動模式。
    /// </summary>
    public enum ExtDriveMode : ushort
    {
        Disable,
        Jog,
        MPG,
    }
}
