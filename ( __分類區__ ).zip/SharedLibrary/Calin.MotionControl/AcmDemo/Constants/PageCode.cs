﻿namespace AcmDemo.Constants
{
    public enum PageCode
    {
        MainPanel,
        Home,
        AxisTest,
        IoMonitor,
    }
}
