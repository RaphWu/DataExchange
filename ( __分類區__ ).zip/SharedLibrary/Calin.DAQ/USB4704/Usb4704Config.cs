﻿namespace Calin.DAQ.USB4704
{
    public class Usb4704Config
    {
        /// <summary>
        /// 取得或設定 COM Port 名稱。
        /// </summary>
        public string PortName { get; set; } = "COM1";

        /// <summary>
        /// 取得或設定鮑率。
        /// </summary>
        public int BaudRate { get; set; } = 19200;

        /// <summary>
        /// 取得或設定資料位元數。
        /// </summary>
        public int DataBits { get; set; } = 8;

        /// <summary>
        /// 取得或設定同位位元。
        /// </summary>
        public RJCP.IO.Ports.Parity Parity { get; set; } = RJCP.IO.Ports.Parity.None;

        /// <summary>
        /// 取得或設定停止位元。
        /// </summary>
        public RJCP.IO.Ports.StopBits StopBits { get; set; } = RJCP.IO.Ports.StopBits.One;

        /// <summary>
        /// 取得或設定讀取逾時（毫秒）。
        /// </summary>
        public int ReadTimeout { get; set; } = 1000;

        /// <summary>
        /// 取得或設定寫入逾時（毫秒）。
        /// </summary>
        public int WriteTimeout { get; set; } = 1000;

        /// <summary>
        /// 取得預設設定。
        /// </summary>
        public static Usb4704Config Default => new Usb4704Config();
    }
}
