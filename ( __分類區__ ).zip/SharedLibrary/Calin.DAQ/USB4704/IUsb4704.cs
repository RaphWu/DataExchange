﻿namespace Calin.DAQ.USB4704
{
    public interface IUsb4704
    {
    }
}
