﻿namespace Calin.DAQ.USB4704
{
    public class Usb4704Service : IUsb4704
    {
    }
}
