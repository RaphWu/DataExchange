﻿using Autofac;

namespace Calin.DAQ.USB4704
{
    /// <summary>
    /// 
    /// </summary>
    public class Usb4704Module : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<Usb4704Service>()
                .As<IUsb4704>()
                .SingleInstance();

            //builder.RegisterBuildCallback(async c =>
            //{
            //    var core = c.Resolve<ICore>();
            //    await core.Initialize();
            //});
        }
    }
}
