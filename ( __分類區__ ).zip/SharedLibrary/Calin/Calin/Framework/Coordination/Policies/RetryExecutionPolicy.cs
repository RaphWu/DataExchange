namespace Calin.Framework.Coordination.Policies
{
    /// <summary>
    /// �a���ժ����浦���C
    /// �b Task ���楢�Ѯɦ۰ʭ��ի��w���ơC
    /// </summary>
    public class RetryExecutionPolicy : ExecutionPolicyBase
    {
        private readonly int _maxRetries;
        private readonly TimeSpan _retryDelay;

        /// <inheritdoc/>
        public override string PolicyName => "Retry";

        /// <summary>
        /// ��l�ƭ��հ��浦���C
        /// </summary>
        /// <param name="maxRetries">�̤j���զ��ơC</param>
        /// <param name="retryDelay">���ն��j�ɶ��C</param>
        public RetryExecutionPolicy(int maxRetries = 3, TimeSpan? retryDelay = null)
        {
            _maxRetries = maxRetries > 0 ? maxRetries : 1;
            _retryDelay = retryDelay ?? TimeSpan.FromMilliseconds(500);
        }

        /// <inheritdoc/>
        public override async Task ExecuteAsync(
            CoordinationSession session,
            IEnumerable<TaskKey> taskKeys,
            Func<TaskKey, ITaskHandler> handlerResolver,
            CancellationToken cancellationToken = default)
        {
            foreach (var taskKey in taskKeys)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var handler = handlerResolver(taskKey);
                if (handler == null)
                {
                    session.MarkTaskFailed(taskKey,
                        new InvalidOperationException($"No handler registered for task '{taskKey}'."));
                    continue;
                }

                await ExecuteWithRetryAsync(session, taskKey, handler, cancellationToken);
            }
        }

        private async Task ExecuteWithRetryAsync(
            CoordinationSession session,
            TaskKey taskKey,
            ITaskHandler handler,
            CancellationToken cancellationToken)
        {
            Exception lastException = null;

            for (int attempt = 0; attempt <= _maxRetries; attempt++)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var context = new TaskExecutionContext(taskKey, session, cancellationToken);

                try
                {
                    await handler.ExecuteAsync(context);
                    session.MarkTaskCompleted(taskKey);
                    return; // ���\�h��^
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    lastException = ex;

                    // �p�G�٦����զ��ơA���ݫ᭫��
                    if (attempt < _maxRetries)
                    {
                        await Task.Delay(_retryDelay, cancellationToken);
                    }
                }
            }

            // �Ҧ����ճ�����
            session.MarkTaskFailed(taskKey, lastException);
        }
    }
}
