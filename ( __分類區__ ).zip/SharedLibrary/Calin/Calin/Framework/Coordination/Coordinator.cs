namespace Calin.Framework.Coordination
{
    /// <summary>
    /// ��ժ̪��֤߹�@�C
    /// �t�d�y�{��աA����@�����ڤu�@�C
    /// </summary>
    public class Coordinator : ICoordinator
    {
        private readonly IEnumerable<ITaskMappingStrategy> _mappingStrategies;
        private readonly ITaskHandlerResolver _handlerResolver;
        private readonly IExecutionPolicy _executionPolicy;
        private readonly IResultPublisher _resultPublisher;

        /// <summary>
        /// ��l�ƨ�ժ̡C
        /// </summary>
        /// <param name="mappingStrategies">�M�g�������X�C</param>
        /// <param name="handlerResolver">Handler �ѪR���C</param>
        /// <param name="executionPolicy">���浦���C</param>
        /// <param name="resultPublisher">���G�o���̡C</param>
        public Coordinator(
            IEnumerable<ITaskMappingStrategy> mappingStrategies,
            ITaskHandlerResolver handlerResolver,
            IExecutionPolicy executionPolicy,
            IResultPublisher resultPublisher = null)
        {
            _mappingStrategies = mappingStrategies ?? Enumerable.Empty<ITaskMappingStrategy>();
            _handlerResolver = handlerResolver ?? throw new ArgumentNullException(nameof(handlerResolver));
            _executionPolicy = executionPolicy ?? throw new ArgumentNullException(nameof(executionPolicy));
            _resultPublisher = resultPublisher ?? NullResultPublisher.Instance;
        }

        /// <inheritdoc/>
        public async Task<ICoordinationResult> CoordinateAsync(
            ICoordinationRequest request,
            CancellationToken cancellationToken = default)
        {
            if (request == null)
                throw new ArgumentNullException(nameof(request));

            // 1. �p��ݰ��檺 TaskKey ���X
            var requiredTasks = ComputeRequiredTasks(request);

            // 2. �إ� Session
            var session = new CoordinationSession(request, requiredTasks);

            // 3. �p�G�S�����Ȼݭn����A�����аO����
            if (!requiredTasks.Any())
            {
                session.MarkStarted();
                session.MarkCompleted();
                var emptyResult = new CoordinationResult(session);
                await _resultPublisher.PublishAsync(emptyResult);
                return emptyResult;
            }

            // 4. �����լy�{
            try
            {
                session.MarkStarted();

                await _executionPolicy.ExecuteAsync(
                    session,
                    requiredTasks,
                    _handlerResolver.Resolve,
                    cancellationToken);

                session.MarkCompleted();
            }
            catch (OperationCanceledException)
            {
                session.MarkCancelled();
            }
            catch
            {
                session.MarkFaulted();
            }

            // 5. �o�����G
            var result = new CoordinationResult(session);
            await _resultPublisher.PublishAsync(result);

            return result;
        }

        /// <summary>
        /// �p��ݰ��檺 TaskKey ���X�C
        /// �q�Ҧ��i�B�z�ӽШD���������� TaskKey �åh�����ơC
        /// </summary>
        private IReadOnlyList<TaskKey> ComputeRequiredTasks(ICoordinationRequest request)
        {
            var tasks = new HashSet<TaskKey>();

            foreach (var strategy in _mappingStrategies)
            {
                if (strategy.CanHandle(request))
                {
                    var strategyTasks = strategy.GetRequiredTasks(request);
                    foreach (var task in strategyTasks)
                    {
                        tasks.Add(task);
                    }
                }
            }

            return tasks.ToList();
        }
    }
}
