using Autofac;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Extensions.Logging;
using ILogger = Serilog.ILogger;

namespace Calin.Framework.Logging
{
    /// <summary>
    /// ��x�A�Ȫ� Autofac Module�C
    /// </summary>
    /// <remarks>
    /// <para>�� Module �t�d���U�Ҧ���x�����A�ȡC</para>
    /// <para>
    /// ���U���e�G
    /// <list type="bullet">
    /// <item><description>Serilog.ILogger�]SingleInstance�^</description></item>
    /// <item><description>Microsoft.Extensions.Logging.ILoggerFactory�]SingleInstance�^</description></item>
    /// <item><description>Microsoft.Extensions.Logging.ILogger�]InstancePerDependency�^</description></item>
    /// </list>
    /// </para>
    /// <para>
    /// �]�p��h�G
    /// <list type="bullet">
    /// <item><description>���]�t Sink�BFilter�B���|�� Rolling ����</description></item>
    /// <item><description>Logger ���H Autofac Container Dispose</description></item>
    /// <item><description>�ϥ� SerilogLoggerProvider ��X Microsoft.Extensions.Logging</description></item>
    /// </list>
    /// </para>
    /// </remarks>
    public class LoggingModule : Module
    {
        /// <summary>
        /// ���J��x�A�ȵ��U�C
        /// </summary>
        protected override void Load(ContainerBuilder builder)
        {
            // ���U Serilog.ILogger�]SingleInstance�^
            // �ϥΥ��� Log.Logger�A���� Autofac �޲z�ͩR�g��
            builder.Register(c => Log.Logger)
                .As<ILogger>()
                .SingleInstance()
                .ExternallyOwned();

            // ���U Microsoft.Extensions.Logging.ILoggerFactory�]SingleInstance�^
            // �ϥ� SerilogLoggerProvider
            builder.Register(c =>
                {
                    var factory = new LoggerFactory();
                    factory.AddProvider(new SerilogLoggerProvider(Log.Logger, dispose: false));
                    return factory;
                })
                .As<ILoggerFactory>()
                .SingleInstance()
                .ExternallyOwned();

            // ���U Microsoft.Extensions.Logging.ILogger�]InstancePerDependency�^
            builder.Register(c =>
                {
                    var factory = c.Resolve<ILoggerFactory>();
                    return factory.CreateLogger("Default");
                })
                .As<Microsoft.Extensions.Logging.ILogger>()
                .InstancePerDependency();
        }
    }
}
