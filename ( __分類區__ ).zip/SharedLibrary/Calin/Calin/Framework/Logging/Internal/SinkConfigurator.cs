using Serilog;
using Serilog.Formatting.Compact;

namespace Calin.Framework.Logging.Internal
{
    /// <summary>
    /// Sink �ո˾��A�t�d�]�w�U�ؤ�x��X�C
    /// </summary>
    /// <remarks>
    /// �Ȩ� Logging Infrastructure �����ϥΡC
    /// </remarks>
    internal static class SinkConfigurator
    {
        /// <summary>
        /// ��r�榡��X�ҪO�C
        /// </summary>
        private const string TextOutputTemplate =
            "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] [{SourceContext}] {Message:lj}{NewLine}{Exception}";

        /// <summary>
        /// �]�w�@���T�ƥ� Sink�C
        /// </summary>
        /// <remarks>
        /// - �ư� Category = UserActivity�BDatabase�BSystem
        /// - Text �榡
        /// - �C��@��
        /// - �O�d 15 ��
        /// - Level: Debug �H�W
        /// </remarks>
        internal static void ConfigureInformationSink(LoggerConfiguration configuration, string logDir)
        {
            var informationFilter = new CategoryExcludeFilter(
                LogCategories.UserActivity,
                LogCategories.Database,
                LogCategories.System);

            var filePath = Path.Combine(logDir, "information.txt");

            configuration.WriteTo.Logger(lc => lc
                .Filter.With(informationFilter)
                .WriteTo.File(
                    filePath,
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 15,
                    outputTemplate: TextOutputTemplate,
                    shared: true));
        }

        /// <summary>
        /// �]�w���~�P�ҥ~ Sink�C
        /// </summary>
        /// <remarks>
        /// - Text �榡
        /// - �C��@��
        /// - �O�d 90 ��
        /// - Level: Error �H�W
        /// </remarks>
        internal static void ConfigureErrorSink(LoggerConfiguration configuration, string logDir)
        {
            var filePath = Path.Combine(logDir, "error_log_.txt");

            configuration.WriteTo.Logger(lc => lc
                .MinimumLevel.Error()
                .WriteTo.File(
                    filePath,
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 90,
                    outputTemplate: TextOutputTemplate,
                    shared: true));
        }

        /// <summary>
        /// �]�w�ϥΪ̾ާ@ Sink�]Audit Log�^�C
        /// </summary>
        /// <remarks>
        /// - Category = UserActivity
        /// - Compact JSON �榡
        /// - �C��@��
        /// - �O�d 90 ��
        /// </remarks>
        internal static void ConfigureUserActivitySink(LoggerConfiguration configuration, string logDir)
        {
            var userActivityFilter = new CategoryIncludeFilter(LogCategories.UserActivity);

            var filePath = Path.Combine(logDir, "user_activity.json");

            configuration.WriteTo.Logger(lc => lc
                .Filter.With(userActivityFilter)
                .WriteTo.File(
                    new CompactJsonFormatter(),
                    filePath,
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 90,
                    shared: true));
        }

        /// <summary>
        /// �]�w��Ʈw�ƥ� Sink�C
        /// </summary>
        /// <remarks>
        /// - Category = Database
        /// - Compact JSON �榡
        /// - �C��@��
        /// - �O�d 90 ��
        /// </remarks>
        internal static void ConfigureDatabaseSink(LoggerConfiguration configuration, string logDir)
        {
            var databaseFilter = new CategoryIncludeFilter(LogCategories.Database);

            var filePath = Path.Combine(logDir, "database_event.json");

            configuration.WriteTo.Logger(lc => lc
                .Filter.With(databaseFilter)
                .WriteTo.File(
                    new CompactJsonFormatter(),
                    filePath,
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 90,
                    shared: true));
        }

        /// <summary>
        /// �]�w�t�ΥͩR�g���ƥ� Sink�C
        /// </summary>
        /// <remarks>
        /// - Category = System
        /// - Text �榡
        /// - �C��@��
        /// - �O�d 30 ��
        /// </remarks>
        internal static void ConfigureSystemLifecycleSink(LoggerConfiguration configuration, string logDir)
        {
            var systemFilter = new CategoryIncludeFilter(LogCategories.System);

            var filePath = Path.Combine(logDir, "system_lifecycle.txt");

            configuration.WriteTo.Logger(lc => lc
                .Filter.With(systemFilter)
                .WriteTo.File(
                    filePath,
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 30,
                    outputTemplate: TextOutputTemplate,
                    shared: true));
        }

        /// <summary>
        /// �]�w�P�R���~�ƥ� Sink�C
        /// </summary>
        /// <remarks>
        /// - Level: Fatal
        /// - Text �榡
        /// - �C��@��
        /// - �O�d 180 ��
        /// </remarks>
        internal static void ConfigureFatalSink(LoggerConfiguration configuration, string logDir)
        {
            var filePath = Path.Combine(logDir, "fatal.txt");

            configuration.WriteTo.Logger(lc => lc
                .MinimumLevel.Fatal()
                .WriteTo.File(
                    filePath,
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 180,
                    outputTemplate: TextOutputTemplate,
                    shared: true));
        }
    }
}
