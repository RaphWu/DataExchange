﻿using System.Security.Cryptography;
using System.Text;

namespace Calin.Infrastructure.Helper
{
    public static class SecurityHelper
    {
        private static readonly byte[] Key = Encoding.UTF8.GetBytes("Your32ByteLengthKeyHere!");
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("16ByteIVVector!");

        public static string EncryptAES(string plainText)
        {
            using (var aes = Aes.Create())
            {
                aes.Key = Key; aes.IV = IV;
                using (var ms = new MemoryStream())
                using (var cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
                using (var sw = new StreamWriter(cs))
                {
                    sw.Write(plainText); sw.Flush(); cs.FlushFinalBlock();
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }

        public static string DecryptAES(string cipherText)
        {
            var buffer = Convert.FromBase64String(cipherText);
            using (var aes = Aes.Create())
            {
                aes.Key = Key; aes.IV = IV;
                using (var ms = new MemoryStream(buffer))
                using (var cs = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read))
                using (var sr = new StreamReader(cs))
                {
                    return sr.ReadToEnd();
                }
            }
        }

        public static string HashPassword(string password)
        {
            using (var rfc = new Rfc2898DeriveBytes(password, 16, 10000))
            {
                var salt = rfc.Salt;
                var hash = rfc.GetBytes(32);
                var result = new byte[48];
                Buffer.BlockCopy(salt, 0, result, 0, 16);
                Buffer.BlockCopy(hash, 0, result, 16, 32);
                return Convert.ToBase64String(result);
            }
        }

        public static bool VerifyPassword(string password, string hashed)
        {
            var bytes = Convert.FromBase64String(hashed);
            var salt = new byte[16]; Buffer.BlockCopy(bytes, 0, salt, 0, 16);
            var hash = new byte[32]; Buffer.BlockCopy(bytes, 16, hash, 0, 32);
            using (var rfc = new Rfc2898DeriveBytes(password, salt, 10000))
            {
                return rfc.GetBytes(32).SequenceEqual(hash);
            }
        }
    }
}
