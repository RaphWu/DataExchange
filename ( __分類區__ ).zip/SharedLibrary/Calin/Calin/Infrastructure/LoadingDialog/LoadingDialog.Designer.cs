namespace Calin.Infrastructure.LoadingDialog
{
    partial class LoadingDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelSpinner = new System.Windows.Forms.Panel();
            this.lblMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panelSpinner
            // 
            this.panelSpinner.BackColor = System.Drawing.Color.Transparent;
            this.panelSpinner.Location = new System.Drawing.Point(100, 40);
            this.panelSpinner.Name = "panelSpinner";
            this.panelSpinner.Size = new System.Drawing.Size(100, 100);
            this.panelSpinner.TabIndex = 0;
            this.panelSpinner.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelSpinner_Paint);
            // 
            // lblMessage
            // 
            this.lblMessage.BackColor = System.Drawing.Color.Transparent;
            this.lblMessage.Font = new System.Drawing.Font("�L�n������", 11F);
            this.lblMessage.ForeColor = System.Drawing.Color.White;
            this.lblMessage.Location = new System.Drawing.Point(20, 150);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(260, 30);
            this.lblMessage.TabIndex = 1;
            this.lblMessage.Text = "���J���A�еy��...";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LoadingDialog
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.ClientSize = new System.Drawing.Size(300, 200);
            this.ControlBox = false;
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.panelSpinner);
            this.Font = new System.Drawing.Font("�L�n������", 11F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LoadingDialog";
            this.ShowIcon = false;
            this.Text = "LoadingDialog";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSpinner;
        private System.Windows.Forms.Label lblMessage;
    }
}
