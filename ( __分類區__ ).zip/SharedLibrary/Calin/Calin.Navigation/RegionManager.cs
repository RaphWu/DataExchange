﻿using System.Collections.Concurrent;
using Calin.Abstractions.Logging;

namespace Calin.Navigation
{
    /// <summary>
    /// Region 管理器，負責區域的註冊、反註冊以及狀態管理
    /// </summary>
    public class RegionManager : IRegionManager
    {
        private readonly ConcurrentDictionary<string, IRegion> _regions = new ConcurrentDictionary<string, IRegion>(StringComparer.OrdinalIgnoreCase);
        private readonly ICalinLogger _logger;
        private bool _disposed;

        /// <summary>
        /// 初始化 RegionManager 類別的新執行個體
        /// </summary>
        /// <param name="logger">記錄器物件</param>
        public RegionManager(ICalinLogger logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <inheritdoc />
        public IEnumerable<string> RegionNames => _regions.Keys.ToList();

        /// <inheritdoc />
        public IRegion RegisterRegion(string regionName, Action<object> activationHandler, Action<object> deactivationHandler = null)
        {
            if (string.IsNullOrEmpty(regionName))
                throw new ArgumentNullException(nameof(regionName));

            if (activationHandler == null)
                throw new ArgumentNullException(nameof(activationHandler));

            ThrowIfDisposed();

            if (_regions.ContainsKey(regionName))
            {
                throw new InvalidOperationException($"Region '{regionName}' 已經被註冊過了");
            }

            var region = new Region(regionName)
            {
                ViewActivationHandler = activationHandler,
                ViewDeactivationHandler = deactivationHandler
            };

            if (!_regions.TryAdd(regionName, region))
            {
                throw new InvalidOperationException($"無法註冊 Region '{regionName}'");
            }

            _logger.Debug($"已註冊 Region: {regionName}");
            return region;
        }

        /// <inheritdoc />
        public void UnregisterRegion(string regionName)
        {
            if (string.IsNullOrEmpty(regionName))
                throw new ArgumentNullException(nameof(regionName));

            ThrowIfDisposed();

            if (_regions.TryRemove(regionName, out var region))
            {
                region.Dispose();
                _logger.Debug($"已取消註冊 Region: {regionName}");
            }
        }

        /// <inheritdoc />
        public IRegion GetRegion(string regionName)
        {
            if (string.IsNullOrEmpty(regionName))
                return null;

            _regions.TryGetValue(regionName, out var region);
            return region;
        }

        /// <inheritdoc />
        public bool ContainsRegion(string regionName)
        {
            if (string.IsNullOrEmpty(regionName))
                return false;

            return _regions.ContainsKey(regionName);
        }

        /// <inheritdoc />
        public int? GetActivePageId(string regionName)
        {
            var region = GetRegion(regionName);
            return region?.ActivePageId;
        }

        /// <inheritdoc />
        public IReadOnlyDictionary<string, int?> GetAllActivePageIds()
        {
            return _regions.ToDictionary(
                kvp => kvp.Key,
                kvp => kvp.Value.ActivePageId,
                StringComparer.OrdinalIgnoreCase);
        }

        /// <inheritdoc />
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// 釋放資源
        /// </summary>
        /// <param name="disposing">指示是否為手動釋放資源</param>
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
                return;

            if (disposing)
            {
                foreach (var region in _regions.Values)
                {
                    region.Dispose();
                }
                _regions.Clear();
            }

            _disposed = true;
        }

        private void ThrowIfDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(nameof(RegionManager));
        }
    }
}



