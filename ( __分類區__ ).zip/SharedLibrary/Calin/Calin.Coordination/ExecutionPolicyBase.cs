namespace Calin.Coordination
{
    /// <summary>
    /// ���浦������H�����O�C
    /// </summary>
    public abstract class ExecutionPolicyBase : IExecutionPolicy
    {
        /// <inheritdoc/>
        public abstract string PolicyName { get; }

        /// <inheritdoc/>
        public abstract Task ExecuteAsync(
            CoordinationSession session,
            IEnumerable<TaskKey> taskKeys,
            Func<TaskKey, ITaskHandler> handlerResolver,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// �����@ Task �ç�s Session ���A�C
        /// </summary>
        /// <param name="session">��� Session�C</param>
        /// <param name="taskKey">�n���檺 TaskKey�C</param>
        /// <param name="handler">������ Handler�C</param>
        /// <param name="cancellationToken">�����O�P�C</param>
        protected async Task ExecuteSingleTaskAsync(
            CoordinationSession session,
            TaskKey taskKey,
            ITaskHandler handler,
            CancellationToken cancellationToken)
        {
            var context = new TaskExecutionContext(taskKey, session, cancellationToken);

            try
            {
                await handler.ExecuteAsync(context);
                session.MarkTaskCompleted(taskKey);
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                session.MarkTaskFailed(taskKey, ex);
            }
        }
    }
}
