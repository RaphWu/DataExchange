﻿using Calin.SerialPort;

namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// DL-RS1A 設定。
    /// </summary>
    public class DL_RS1A_Config
    {
        /// <summary>
        /// 取得或設定感測器類型。
        /// </summary>
        public KeyenceSensorType SensorType { get; set; } = KeyenceSensorType.None;

        /// <summary>
        /// 取得或設定設備 ID 編號。
        /// </summary>
        public int IdNumber { get; set; } = 1;

        /// <summary>
        /// 取得或設定 COM Port 名稱。
        /// </summary>
        public string PortName { get; set; } = "COM1";

        /// <summary>
        /// 取得或設定鮑率。
        /// </summary>
        public int BaudRate { get; set; } = 9600;

        /// <summary>
        /// 取得或設定資料位元數。
        /// </summary>
        public int DataBits { get; set; } = 8;

        /// <summary>
        /// 取得或設定同位位元。
        /// </summary>
        public Parity Parity { get; set; } = Parity.None;

        /// <summary>
        /// 取得或設定停止位元。
        /// </summary>
        public StopBits StopBits { get; set; } = StopBits.One;

        /// <summary>
        /// 取得或設定讀取逾時（毫秒）。
        /// </summary>
        public int ReadTimeout { get; set; } = 1000;

        /// <summary>
        /// 取得或設定寫入逾時（毫秒）。
        /// </summary>
        public int WriteTimeout { get; set; } = 1000;

        /// <summary>
        /// 取得預設設定。
        /// </summary>
        public static DL_RS1A_Config Default => new DL_RS1A_Config();
    }
}
