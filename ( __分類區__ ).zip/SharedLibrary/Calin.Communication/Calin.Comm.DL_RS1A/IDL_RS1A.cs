﻿using System;
using System.Collections.Generic;

namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// Keyence DL-RS1A RS-232 通訊介面。
    /// </summary>
    public interface IDL_RS1A : IDL_RS1A_GT2_Commands, IDisposable
    {
        /// <summary>
        /// 取得是否已連線。
        /// </summary>
        bool IsConnected { get; }

        /// <summary>
        /// 取得傳輸驗證是否已通過。
        /// </summary>
        /// <remarks>
        /// 當底層 SerialPort 的 EnableTransmissionVerification 為 true 且驗證成功時為 true。
        /// 當未啟用傳輸驗證時，此屬性會在 IsConnected 為 true 時返回 true。
        /// </remarks>
        bool IsTransmissionVerified { get; }

        /// <summary>
        /// 開啟連線。
        /// </summary>
        /// <returns>是否成功開啟。</returns>
        bool Open();

        /// <summary>
        /// 關閉連線。
        /// </summary>
        void Close();

        /// <summary>
        /// 取得系統上所有可用的 SerialPort 名稱。
        /// </summary>
        /// <returns>可用的 SerialPort 名稱列表。</returns>
        List<string> GetAvailablePorts();

        /// <summary>
        /// 回應接收事件。
        /// </summary>
        event EventHandler<DL_RS1A_ResponseEventArgs> ResponseReceived;

        /// <summary>
        /// 錯誤發生事件。
        /// </summary>
        event EventHandler<DL_RS1A_ErrorEventArgs> ErrorOccurred;
    }
}
