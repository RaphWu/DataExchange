﻿using Calin.SerialPort;

namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// DL-RS1A 服務工廠介面。
    /// 用於建立 DL-RS1A 實例。
    /// </summary>
    public interface IDL_RS1A_ServiceFactory
    {
        /// <summary>
        /// 使用 SerialPort 設定建立 DL-RS1A 實例。
        /// </summary>
        /// <param name="dlrs1aConfig">DL_RS1A 設定。</param>
        /// <returns>新建立的 DL-RS1A 實例。</returns>
        IDL_RS1A Create(DL_RS1A_Config dlrs1aConfig);

        /// <summary>
        /// 使用 SerialPort 設定建立 DL-RS1A 實例並自動開啟連線。
        /// </summary>
        /// <param name="dlrs1aConfig">DL_RS1A 設定。</param>
        /// <returns>已開啟連線的 DL-RS1A 實例。</returns>
        IDL_RS1A CreateAndOpen(DL_RS1A_Config dlrs1aConfig);
    }
}
