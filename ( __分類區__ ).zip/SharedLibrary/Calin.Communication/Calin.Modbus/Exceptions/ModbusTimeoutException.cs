using System;

namespace Calin.Modbus.Exceptions
{
    /// <summary>
    /// MODBUS �q�T�O�ɨҥ~�C
    /// </summary>
    [Serializable]
    public class ModbusTimeoutException : ModbusException
    {
        /// <summary>
        /// ���o�O�ɮɶ��]�@���^�C
        /// </summary>
        public int TimeoutMilliseconds { get; }

        /// <summary>
        /// ���o���զ��ơC
        /// </summary>
        public int RetryCount { get; }

        /// <summary>
        /// �إ� ModbusTimeoutException ��ҡC
        /// </summary>
        /// <param name="timeoutMs">�O�ɮɶ��]�@���^�C</param>
        public ModbusTimeoutException(int timeoutMs)
            : base($"MODBUS communication timeout after {timeoutMs}ms.")
        {
            TimeoutMilliseconds = timeoutMs;
            RetryCount = 0;
        }

        /// <summary>
        /// �إ� ModbusTimeoutException ��ҡC
        /// </summary>
        /// <param name="timeoutMs">�O�ɮɶ��]�@���^�C</param>
        /// <param name="retryCount">���զ��ơC</param>
        public ModbusTimeoutException(int timeoutMs, int retryCount)
            : base($"MODBUS communication timeout after {timeoutMs}ms with {retryCount} retries.")
        {
            TimeoutMilliseconds = timeoutMs;
            RetryCount = retryCount;
        }

        /// <summary>
        /// �إ� ModbusTimeoutException ��ҡC
        /// </summary>
        /// <param name="message">���~�T���C</param>
        /// <param name="timeoutMs">�O�ɮɶ��]�@���^�C</param>
        public ModbusTimeoutException(string message, int timeoutMs)
            : base(message)
        {
            TimeoutMilliseconds = timeoutMs;
            RetryCount = 0;
        }
    }
}
