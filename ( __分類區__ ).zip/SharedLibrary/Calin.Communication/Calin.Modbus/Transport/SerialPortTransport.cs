using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Calin.SerialPort;

namespace Calin.Modbus.Transport
{
    /// <summary>
    /// �ϥ� SerialPort �� MODBUS �ǿ�h��@�C
    /// �ϥ� Calin.SerialPort �Ҳնi���ڪ���C��q�T�C
    /// </summary>
    public class SerialPortTransport : IModbusTransport
    {
        private readonly ISerialPortService _serialPortService;
        private readonly object _lockObject = new object();
        private string _receivedData;
        private readonly AutoResetEvent _dataReceivedEvent;
        private bool _disposed;

        /// <summary>
        /// ���o�ǿ�h�O�_�w�}�ҡC
        /// </summary>
        public bool IsOpen => _serialPortService?.IsOpen ?? false;

        /// <summary>
        /// ���o�ǿ����ҬO�_�w�q�L�C
        /// </summary>
        public bool IsTransmissionVerified => _serialPortService?.IsTransmissionVerified ?? false;

        /// <summary>
        /// ���o�γ]�w�q�T�O�ɮɶ��]�@���^�C
        /// </summary>
        public int Timeout { get; set; } = 1000;

        /// <summary>
        /// ���o�γ]�w���զ��ơC
        /// </summary>
        public int RetryCount { get; set; } = 3;

        /// <summary>
        /// ���o�γ]�w���ն��j�]�@���^�C
        /// </summary>
        public int RetryDelay { get; set; } = 100;

        /// <summary>
        /// �إ� SerialPortTransport ��ҡC
        /// </summary>
        /// <param name="serialPortService">SerialPort �A�ȡC</param>
        /// <exception cref="ArgumentNullException">�� serialPortService �� null �ɩߥX�C</exception>
        public SerialPortTransport(ISerialPortService serialPortService)
        {
            _serialPortService = serialPortService ?? throw new ArgumentNullException(nameof(serialPortService));
            _dataReceivedEvent = new AutoResetEvent(false);

            // �q�\��Ʊ����ƥ�
            _serialPortService.DataReceived += OnDataReceived;
        }

        /// <summary>
        /// �}�Ҷǿ�s�u�C
        /// </summary>
        public bool Open()
        {
            return _serialPortService.Open();
        }

        /// <summary>
        /// �����ǿ�s�u�C
        /// </summary>
        public void Close()
        {
            _serialPortService.Close();
        }

        /// <summary>
        /// �ǰe MODBUS ASCII Frame �õ��ݦ^���C
        /// </summary>
        /// <param name="requestFrame">���㪺 MODBUS ASCII �ШD Frame�C</param>
        /// <returns>���㪺 MODBUS ASCII �^�� Frame�C</returns>
        public string SendAndReceive(string requestFrame)
        {
            if (!IsOpen)
            {
                throw new InvalidOperationException("Transport is not open.");
            }

            // �ˬd�ǿ����Ҫ��A
            if (!IsTransmissionVerified)
            {
                throw new InvalidOperationException("Transmission verification failed. Please check serial port parameters.");
            }

            Exception lastException = null;

            for (int attempt = 0; attempt <= RetryCount; attempt++)
            {
                try
                {
                    lock (_lockObject)
                    {
                        // �M�Ť��e�����
                        _receivedData = null;
                        _dataReceivedEvent.Reset();
                        ClearBuffer();

                        // �ǰe�ШD
                        if (!_serialPortService.SendAscii(requestFrame))
                        {
                            throw new InvalidOperationException("Failed to send data.");
                        }

                        // ���ݦ^��
                        if (!_dataReceivedEvent.WaitOne(Timeout))
                        {
                            throw new TimeoutException($"No response received within {Timeout}ms.");
                        }

                        // �ˬd�O�_�����㪺�^��
                        if (string.IsNullOrEmpty(_receivedData))
                        {
                            throw new TimeoutException("Received empty response.");
                        }

                        // ���Ҧ^���榡
                        if (!_receivedData.StartsWith(":") || !_receivedData.EndsWith("\r\n"))
                        {
                            // ���ݧ�h���
                            Thread.Sleep(50);
                            if (!_receivedData.EndsWith("\r\n"))
                            {
                                throw new InvalidOperationException("Incomplete response received.");
                            }
                        }

                        return _receivedData;
                    }
                }
                catch (TimeoutException ex)
                {
                    lastException = ex;
                    if (attempt < RetryCount)
                    {
                        Thread.Sleep(RetryDelay);
                    }
                }
                catch (Exception ex)
                {
                    lastException = ex;
                    if (attempt < RetryCount)
                    {
                        Thread.Sleep(RetryDelay);
                    }
                }
            }

            throw lastException ?? new TimeoutException($"Communication failed after {RetryCount} retries.");
        }

        /// <summary>
        /// ���o�t�ΤW�Ҧ��i�Ϊ� SerialPort �W�١C
        /// </summary>
        /// <returns>�i�Ϊ� SerialPort �W�٦C���C</returns>
        public List<string> GetAvailablePorts()
        {
            return _serialPortService?.GetAvailablePorts() ?? new List<string>();
        }

        /// <summary>
        /// �M�ű����w�İϡC
        /// </summary>
        public void ClearBuffer()
        {
            lock (_lockObject)
            {
                _receivedData = null;
            }
        }

        /// <summary>
        /// �B�z��Ʊ����ƥ�C
        /// </summary>
        private void OnDataReceived(object sender, SerialPortDataReceivedEventArgs e)
        {
            lock (_lockObject)
            {
                if (_receivedData == null)
                {
                    _receivedData = string.Empty;
                }

                // �ھڱ����쪺��������B�z
                // �u���ϥΦr���ơA�p�G�S���h�ϥέ�l�줸�ո��
                if (!string.IsNullOrEmpty(e.Data))
                {
                    _receivedData += e.Data;
                }
                else if (e.RawData != null && e.RawData.Length > 0)
                {
                    _receivedData += Encoding.ASCII.GetString(e.RawData);
                }

                // �ˬd�O�_���짹�㪺 MODBUS ASCII Frame
                if (_receivedData.Contains("\r\n"))
                {
                    _dataReceivedEvent.Set();
                }
            }
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    if (_serialPortService != null)
                    {
                        _serialPortService.DataReceived -= OnDataReceived;
                    }
                    _dataReceivedEvent?.Dispose();
                }
                _disposed = true;
            }
        }

        /// <summary>
        /// �Ѻc�禡�C
        /// </summary>
        ~SerialPortTransport()
        {
            Dispose(false);
        }
    }
}
