using System;
using Calin.Modbus.Transport;
using Calin.SerialPort;

namespace Calin.Modbus.Core
{
    /// <summary>
    /// MODBUS �Ȥ�ݤu�t��@�C
    /// �t�d�إ� ModbusClient ��ҡC
    /// </summary>
    /// <remarks>
    /// �����O�� Singleton�A�i�Q Autofac ���U�� SingleInstance�C
    /// �u�t�������������� ModbusClient ��Ҫ��ѦҡC
    /// </remarks>
    public class ModbusClientFactory : IModbusClientFactory
    {
        private readonly ISerialPortServiceFactory _serialPortServiceFactory;

        /// <summary>
        /// �إ� ModbusClientFactory ��ҡC
        /// </summary>
        /// <param name="serialPortServiceFactory">SerialPort �A�Ȥu�t�]�i��^�C</param>
        public ModbusClientFactory(ISerialPortServiceFactory serialPortServiceFactory = null)
        {
            _serialPortServiceFactory = serialPortServiceFactory;
        }

        /// <summary>
        /// �ϥβ{���� Transport �إ� ModbusClient�C
        /// </summary>
        /// <param name="transport">MODBUS �ǿ�h�C</param>
        /// <param name="config">�Ȥ�ݳ]�w�]�i��^�C</param>
        /// <returns>�s�إߪ� ModbusClient ��ҡC</returns>
        public IModbus Create(IModbusTransport transport, ModbusClientConfig config = null)
        {
            if (transport == null)
            {
                throw new ArgumentNullException(nameof(transport));
            }

            config = config ?? ModbusClientConfig.Default;

            var client = new ModbusClient(transport)
            {
                RetryCount = config.RetryCount,
                RetryDelay = config.RetryDelay
            };

            if (transport.Timeout == 0)
            {
                transport.Timeout = config.Timeout;
            }

            return client;
        }

        /// <summary>
        /// �ϥ� SerialPortService �إ� ModbusClient�]�ϥ� SerialPortTransport�^�C
        /// </summary>
        /// <param name="serialPortService">SerialPort �A�ȡC</param>
        /// <param name="config">�Ȥ�ݳ]�w�]�i��^�C</param>
        /// <returns>�s�إߪ� ModbusClient ��ҡC</returns>
        public IModbus CreateWithSerialPort(ISerialPortService serialPortService, ModbusClientConfig config = null)
        {
            if (serialPortService == null)
            {
                throw new ArgumentNullException(nameof(serialPortService));
            }

            config = config ?? ModbusClientConfig.Default;

            var transport = new SerialPortTransport(serialPortService)
            {
                Timeout = config.Timeout
            };

            return Create(transport, config);
        }

        /// <summary>
        /// �ϥ� SerialPortConfig �إߧ��㪺 ModbusClient�C
        /// </summary>
        /// <param name="serialPortConfig">SerialPort �]�w�C</param>
        /// <param name="config">�Ȥ�ݳ]�w�]�i��^�C</param>
        /// <returns>�s�إߪ� ModbusClient ��ҡC</returns>
        public IModbus CreateWithSerialPortConfig(SerialPortConfig serialPortConfig, ModbusClientConfig config = null)
        {
            if (serialPortConfig == null)
            {
                throw new ArgumentNullException(nameof(serialPortConfig));
            }

            ISerialPortService serialPortService;

            if (_serialPortServiceFactory != null)
            {
                serialPortService = _serialPortServiceFactory.Create(serialPortConfig);
            }
            else
            {
                serialPortService = new SerialPortService(serialPortConfig.Clone());
            }

            return CreateWithSerialPort(serialPortService, config);
        }

        /// <summary>
        /// �إߨϥ� MockTransport �� ModbusClient�]�Ω���ա^�C
        /// </summary>
        /// <param name="slaveAddress">������ Slave ��}�C</param>
        /// <param name="config">�Ȥ�ݳ]�w�]�i��^�C</param>
        /// <returns>�s�إߪ� ModbusClient ��ҡC</returns>
        public IModbus CreateMock(byte slaveAddress = 1, ModbusClientConfig config = null)
        {
            return CreateMock(out _, slaveAddress, config);
        }

        /// <summary>
        /// �إߨϥ� MockTransport �� ModbusClient�A�æ^�� MockTransport ��ҡC
        /// </summary>
        /// <param name="mockTransport">��X�� MockTransport ��ҡC</param>
        /// <param name="slaveAddress">������ Slave ��}�C</param>
        /// <param name="config">�Ȥ�ݳ]�w�]�i��^�C</param>
        /// <returns>�s�إߪ� ModbusClient ��ҡC</returns>
        public IModbus CreateMock(out MockTransport mockTransport, byte slaveAddress = 1, ModbusClientConfig config = null)
        {
            config = config ?? ModbusClientConfig.Default;

            mockTransport = new MockTransport
            {
                SlaveAddress = slaveAddress,
                Timeout = config.Timeout
            };

            return Create(mockTransport, config);
        }
    }
}
