﻿using System;

namespace Calin.SerialPort
{
    /// <summary>
    /// SerialPort 服務介面。
    /// 此介面設計用於 Autofac 依賴注入。
    /// </summary>
    public interface ISerialPortService : IDisposable
    {
        #region Events

        /// <summary>
        /// 當狀態改變時觸發。
        /// </summary>
        event EventHandler<SerialPortStateChangedEventArgs> StateChanged;

        /// <summary>
        /// 當接收到資料時觸發。
        /// </summary>
        event EventHandler<SerialPortDataReceivedEventArgs> DataReceived;

        /// <summary>
        /// 當發生錯誤時觸發。
        /// </summary>
        event EventHandler<SerialPortErrorEventArgs> ErrorOccurred;

        #endregion Events

        #region Properties

        /// <summary>
        /// 取得 SerialPort 的名稱。
        /// </summary>
        string PortName { get; }

        /// <summary>
        /// 取得目前的連線狀態。
        /// </summary>
        SerialPortState State { get; }

        /// <summary>
        /// 取得 SerialPort 是否已開啟並就緒。
        /// </summary>
        bool IsReady { get; }

        /// <summary>
        /// 取得 SerialPort 是否已開啟。
        /// </summary>
        bool IsOpen { get; }

        /// <summary>
        /// 取得傳輸驗證是否已通過。
        /// </summary>
        /// <remarks>
        /// 當 EnableTransmissionVerification 為 true 且連線後傳輸測試成功時為 true。
        /// 當 EnableTransmissionVerification 為 false 時，此屬性會在 IsOpen 為 true 時返回 true。
        /// </remarks>
        bool IsTransmissionVerified { get; }

        /// <summary>
        /// 取得設定資訊。
        /// </summary>
        SerialPortConfig Config { get; }

        #endregion Properties

        #region Methods

        /// <summary>
        /// 開啟 SerialPort 連線。
        /// </summary>
        /// <returns>是否成功開啟。</returns>
        bool Open();

        /// <summary>
        /// 關閉 SerialPort 連線。
        /// </summary>
        void Close();

        /// <summary>
        /// 傳送字串資料。
        /// </summary>
        /// <param name="data">要傳送的字串資料。</param>
        /// <returns>是否成功傳送。</returns>
        bool SendData(string data);

        /// <summary>
        /// 傳送位元組資料。
        /// </summary>
        /// <param name="data">要傳送的位元組陣列。</param>
        /// <returns>是否成功傳送。</returns>
        bool SendData(byte[] data);

        /// <summary>
        /// 傳送 ASCII 字串資料（不自動加行結尾）。
        /// </summary>
        /// <param name="data">要傳送的 ASCII 字串資料。</param>
        /// <returns>是否成功傳送。</returns>
        bool SendAscii(string data);

        /// <summary>
        /// 傳送 ASCII 字串資料並自動加上行結尾（預設 \r\n，可由 Config.AsciiLineTerminator 變更）。
        /// </summary>
        /// <param name="line">要傳送的一行 ASCII 字串。</param>
        /// <returns>是否成功傳送。</returns>
        bool SendAsciiLine(string line);

        /// <summary>
        /// 儲存目前配置到 JSON 檔案。
        /// </summary>
        /// <param name="filePath">檔案路徑。</param>
        /// <returns>是否成功儲存。</returns>
        bool SaveConfig(string filePath);

        /// <summary>
        /// 從 JSON 檔案載入配置並更新設定。
        /// </summary>
        /// <param name="filePath">檔案路徑。</param>
        /// <returns>是否成功載入。</returns>
        bool LoadConfig(string filePath);

        #endregion Methods
    }
}
