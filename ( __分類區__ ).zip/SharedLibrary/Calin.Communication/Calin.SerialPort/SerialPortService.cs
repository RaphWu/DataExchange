using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Calin.Helper;
using RJCPPort = RJCP.IO.Ports;

namespace Calin.SerialPort
{
    /// <summary>
    /// Thread-safe �� SerialPort �A�ȡA�䴩�۰ʭ��s�B�߸��˴��M���A�޲z�C
    /// </summary>
    public class SerialPortService : ISerialPortService, IDisposable
    {
        #region Fields

        private readonly SerialPortConfig _config;
        private readonly object _lock = new object();
        private RJCPPort.SerialPortStream _port;
        private SerialPortState _state = SerialPortState.Disconnected;

        private CancellationTokenSource _reconnectCts;
        private CancellationTokenSource _heartbeatCts;
        private CancellationTokenSource _readLoopCts;

        private Task _reconnectTask;
        private Task _heartbeatTask;
        private Task _readLoopTask;

        private DateTime _lastHeartbeatResponse = DateTime.MinValue;
        private bool _disposed = false;

        private readonly StringBuilder _asciiRxBuffer = new StringBuilder();

        // �ǿ����Ҭ������
        private bool _isTransmissionVerified = false;
        private volatile bool _isVerificationPending = false;
        private readonly ManualResetEventSlim _verificationEvent = new ManualResetEventSlim(false);

        #endregion Fields

        #region Events

        /// <inheritdoc/>
        public event EventHandler<SerialPortStateChangedEventArgs> StateChanged;

        /// <inheritdoc/>
        public event EventHandler<SerialPortDataReceivedEventArgs> DataReceived;

        /// <inheritdoc/>
        public event EventHandler<SerialPortErrorEventArgs> ErrorOccurred;

        #endregion Events

        #region Properties

        /// <inheritdoc/>
        public string PortName => _config.PortName;

        /// <inheritdoc/>
        public SerialPortState State
        {
            get
            {
                lock (_lock)
                {
                    return _state;
                }
            }
            private set
            {
                SerialPortState oldState;
                lock (_lock)
                {
                    if (_state == value)
                        return;

                    oldState = _state;
                    _state = value;
                }

                OnStateChanged(oldState, value);
            }
        }

        /// <inheritdoc/>
        public bool IsReady => State == SerialPortState.Ready;

        /// <inheritdoc/>
        public bool IsOpen
        {
            get
            {
                lock (_lock)
                {
                    return _port != null && _port.IsOpen;
                }
            }
        }

        /// <inheritdoc/>
        public bool IsTransmissionVerified
        {
            get
            {
                lock (_lock)
                {
                    // �Y���ҥ����ҡA�h�H IsOpen ����
                    if (!_config.EnableTransmissionVerification)
                        return _port != null && _port.IsOpen;

                    return _isTransmissionVerified;
                }
            }
            private set
            {
                lock (_lock)
                {
                    _isTransmissionVerified = value;
                }
            }
        }

        /// <inheritdoc/>
        public SerialPortConfig Config => _config.Clone();

        #endregion Properties

        #region Constructor

        /// <summary>
        /// �إ� SerialPort �A�ȡC
        /// </summary>
        /// <param name="config">SerialPort �]�w�C</param>
        public SerialPortService(SerialPortConfig config)
        {
            _config = config ?? throw new ArgumentNullException(nameof(config));

            if (string.IsNullOrWhiteSpace(_config.PortName))
                throw new ArgumentException("PortName ���i����", nameof(config));
        }

        #endregion Constructor

        #region Public Methods

        /// <inheritdoc/>
        public bool Open()
        {
            try
            {
                lock (_lock)
                {
                    if (IsOpen)
                        return true;

                    State = SerialPortState.Connecting;
                    _isTransmissionVerified = false;
                }

                if (!OpenPortInternal())
                {
                    State = SerialPortState.Fault;
                    return false;
                }

                // �Ұ�Ū���j��
                StartReadLoop();

                // ����ǿ����ҡ]�Y�ҥΡ^
                if (_config.EnableTransmissionVerification)
                {
                    if (!PerformTransmissionVerification())
                    {
                        OnError("Open", "�ǿ����ҥ��ѡA�Ѽƥi�ण���T", null);
                        State = SerialPortState.Fault;
                        // �������s�u�A���~���M�w�O�_����
                    }
                    else
                    {
                        State = SerialPortState.Ready;
                    }
                }
                else
                {
                    State = SerialPortState.Ready;
                }

                // �Ұʦ۰ʭ��s�ʱ�
                if (_config.EnableAutoReconnect)
                {
                    StartReconnectMonitor();
                }

                // �Ұʤ߸��˴�
                if (_config.EnableHeartbeat)
                {
                    StartHeartbeat();
                }

                return true;
            }
            catch (Exception ex)
            {
                OnError("Open", $"�}�� SerialPort ����: {ex.Message}", ex);
                State = SerialPortState.Fault;
                return false;
            }
        }

        /// <inheritdoc/>
        public void Close()
        {
            try
            {
                // ����Ҧ��I������
                StopAllTasks();

                lock (_lock)
                {
                    ClosePortInternal();
                    _isTransmissionVerified = false;
                    State = SerialPortState.Disconnected;
                }
            }
            catch (Exception ex)
            {
                OnError("Close", $"���� SerialPort �ɵo�Ϳ��~: {ex.Message}", ex);
            }
        }

        /// <inheritdoc/>
        public bool SendData(string data)
        {
            if (string.IsNullOrEmpty(data))
                return false;

            // �̳]�w�s�X�e�X�]�w�] ASCII�^
            var encoding = _config.GetTextEncoding();
            return SendDataInternal(encoding.GetBytes(data));
        }

        /// <inheritdoc/>
        public bool SendData(byte[] data)
        {
            return SendDataInternal(data);
        }

        /// <summary>
        /// �ǰe�줸�ո�ơC
        /// </summary>
        /// <param name="data">�n�ǰe���줸�ո�ơC</param>
        /// <returns>�O�_���\�ǰe�C</returns>
        private bool SendDataInternal(byte[] data)
        {
            if (data == null || data.Length == 0)
                return false;

            try
            {
                lock (_lock)
                {
                    if (_port == null || !_port.IsOpen)
                        return false;

                    _port.Write(data, 0, data.Length);
                    return true;
                }
            }
            catch (Exception ex)
            {
                OnError("SendData", $"�ǰe��ƥ���: {ex.Message}", ex);
                State = SerialPortState.Fault;
                return false;
            }
        }

        /// <inheritdoc/>
        public bool SendAscii(string data)
        {
            if (string.IsNullOrEmpty(data))
                return false;

            return SendData(Encoding.ASCII.GetBytes(data));
        }

        /// <inheritdoc/>
        public bool SendAsciiLine(string line)
        {
            if (line == null)
                return false;

            var terminator = _config.AsciiLineTerminator ?? string.Empty;
            return SendAscii(line + terminator);
        }

        /// <inheritdoc/>
        public List<string> GetAvailablePorts()
        {
            try
            {
                using (var tempPort = new RJCPPort.SerialPortStream())
                {
                    var ports = new List<string>(tempPort.GetPortNames());
                    ports.Sort();
                    return ports;
                }
            }
            catch (Exception)
            {
                return new List<string>();
            }
        }

        #endregion Public Methods

        #region Transmission Verification

        /// <summary>
        /// ����ǿ����ҡC
        /// </summary>
        /// <returns>���ҬO�_���\�C</returns>
        private bool PerformTransmissionVerification()
        {
            try
            {
                _verificationEvent.Reset();
                _isVerificationPending = true;

                // �o�e���հT���]�Y���]�w�^
                if (!string.IsNullOrEmpty(_config.TransmissionTestMessage))
                {
                    if (!SendData(_config.TransmissionTestMessage))
                    {
                        _isVerificationPending = false;
                        return false;
                    }
                }

                // ���ݦ��������
                var result = _verificationEvent.Wait(_config.TransmissionTestTimeout);

                _isVerificationPending = false;
                IsTransmissionVerified = result;
                return result;
            }
            catch (Exception ex)
            {
                OnError("PerformTransmissionVerification", $"�ǿ����ҵo�Ϳ��~: {ex.Message}", ex);
                _isVerificationPending = false;
                return false;
            }
        }

        #endregion Transmission Verification

        #region Configuration Persistence

        /// <inheritdoc/>
        public bool SaveConfig(string filePath)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(filePath))
                {
                    OnError("SaveConfig", "�ɮ׸��|���i����", null);
                    return false;
                }

                var config = _config.Clone();
                JsonFileHelper.Save(filePath, config);
                return true;
            }
            catch (Exception ex)
            {
                OnError("SaveConfig", $"�x�s�t�m����: {ex.Message}", ex);
                return false;
            }
        }

        /// <inheritdoc/>
        public bool LoadConfig(string filePath)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(filePath))
                {
                    OnError("LoadConfig", "�ɮ׸��|���i����", null);
                    return false;
                }

                var loadedConfig = JsonFileHelper.Read<SerialPortConfig>(filePath);
                if (loadedConfig == null)
                {
                    OnError("LoadConfig", "���J���t�m����", null);
                    return false;
                }

                // ��s�t�m�]�O�d PortName�^
                _config.BaudRate = loadedConfig.BaudRate;
                _config.DataBits = loadedConfig.DataBits;
                _config.Parity = loadedConfig.Parity;
                _config.StopBits = loadedConfig.StopBits;
                _config.Handshake = loadedConfig.Handshake;
                _config.ReadTimeout = loadedConfig.ReadTimeout;
                _config.WriteTimeout = loadedConfig.WriteTimeout;
                _config.RtsEnable = loadedConfig.RtsEnable;
                _config.DtrEnable = loadedConfig.DtrEnable;
                _config.EnableAutoReconnect = loadedConfig.EnableAutoReconnect;
                _config.ReconnectInterval = loadedConfig.ReconnectInterval;
                _config.EnableHeartbeat = loadedConfig.EnableHeartbeat;
                _config.HeartbeatMessage = loadedConfig.HeartbeatMessage;
                _config.HeartbeatInterval = loadedConfig.HeartbeatInterval;
                _config.HeartbeatTimeout = loadedConfig.HeartbeatTimeout;
                _config.EnableTransmissionVerification = loadedConfig.EnableTransmissionVerification;
                _config.TransmissionTestMessage = loadedConfig.TransmissionTestMessage;
                _config.TransmissionTestTimeout = loadedConfig.TransmissionTestTimeout;

                return true;
            }
            catch (Exception ex)
            {
                OnError("LoadConfig", $"���J�t�m����: {ex.Message}", ex);
                return false;
            }
        }

        #endregion Configuration Persistence

        #region Private Methods - Port Operations

        /// <summary>
        /// �}�� SerialPort �s�u�C
        /// </summary>
        /// <returns>�O�_���\�}�ҳs�u�C</returns>
        private bool OpenPortInternal()
        {
            try
            {
                lock (_lock)
                {
                    if (_port != null)
                    {
                        ClosePortInternal();
                    }

                    _port = new RJCPPort.SerialPortStream
                    {
                        PortName = _config.PortName,
                        BaudRate = _config.BaudRate,
                        DataBits = _config.DataBits,
                        Parity = _config.Parity.ToRJCP(),
                        StopBits = _config.StopBits.ToRJCP(),
                        Handshake = _config.Handshake.ToRJCP(),
                        ReadTimeout = _config.ReadTimeout,
                        WriteTimeout = _config.WriteTimeout,
                        RtsEnable = _config.RtsEnable,
                        DtrEnable = _config.DtrEnable
                    };

                    _port.Open();

                    if (!_port.IsOpen)
                    {
                        ClosePortInternal();
                        return false;
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                OnError("OpenPortInternal", $"�}�� Port ����: {ex.Message}", ex);
                ClosePortInternal();
                return false;
            }
        }

        /// <summary>
        /// ���� SerialPort �s�u�C
        /// </summary>
        private void ClosePortInternal()
        {
            try
            {
                if (_port != null)
                {
                    if (_port.IsOpen)
                    {
                        _port.Close();
                    }
                    _port.Dispose();
                    _port = null;
                }
            }
            catch (Exception ex)
            {
                OnError("ClosePortInternal", $"���� Port �ɵo�Ϳ��~: {ex.Message}", ex);
            }
        }

        #endregion Private Methods - Port Operations

        #region Private Methods - Read Loop

        /// <summary>
        /// �Ұ�Ū���j��C
        /// </summary>
        private void StartReadLoop()
        {
            StopReadLoop();

            _readLoopCts = new CancellationTokenSource();
            var token = _readLoopCts.Token;

            _readLoopTask = Task.Run(async () =>
            {
                var buffer = new byte[4096];

                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        bool hasData = false;
                        int bytesToRead = 0;
                        byte[] received = null;

                        lock (_lock)
                        {
                            if (_port == null || !_port.IsOpen)
                            {
                                // Port not ready
                            }
                            else
                            {
                                bytesToRead = _port.BytesToRead;
                                hasData = bytesToRead > 0;

                                if (hasData)
                                {
                                    int bytesRead = _port.Read(buffer, 0, Math.Min(buffer.Length, bytesToRead));
                                    if (bytesRead > 0)
                                    {
                                        received = new byte[bytesRead];
                                        Array.Copy(buffer, received, bytesRead);

                                        // ��s�߸��^���ɶ�
                                        if (_config.EnableHeartbeat)
                                        {
                                            _lastHeartbeatResponse = DateTime.Now;
                                        }

                                        // Ĳ�o�ǿ����Ҩƥ�
                                        if (_isVerificationPending)
                                        {
                                            _verificationEvent.Set();
                                        }
                                    }
                                    else
                                    {
                                        hasData = false;
                                    }
                                }
                            }
                        }

                        if (received != null)
                        {
                            HandleReceivedBytes(received);
                        }

                        if (!hasData)
                        {
                            await Task.Delay(10, token);
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    catch (Exception ex)
                    {
                        OnError("ReadLoop", $"Ū����Ʈɵo�Ϳ��~: {ex.Message}", ex);

                        if (!IsOpen)
                        {
                            State = SerialPortState.Fault;
                            break;
                        }

                        await Task.Delay(100, token);
                    }
                }
            }, token);
        }

        /// <summary>
        /// �B�z�����쪺�줸�ո�ơC
        /// </summary>
        /// <param name="data">�����쪺�줸�ո�ơC</param>
        private void HandleReceivedBytes(byte[] data)
        {
            if (data == null || data.Length == 0)
                return;

            // ��r�]ASCII/UTF8�^�B�z�G�� terminator ����
            var encoding = _config.GetTextEncoding();
            var chunk = encoding.GetString(data);

            if (!_config.EnableAsciiLineMode)
            {
                OnDataReceived(chunk, data);
                return;
            }

            var terminator = _config.AsciiLineTerminator ?? "\r\n";
            if (terminator.Length == 0)
            {
                OnDataReceived(chunk, data);
                return;
            }

            List<string> linesToRaise = null;

            lock (_lock)
            {
                _asciiRxBuffer.Append(chunk);

                // �קK�L���w��
                var limit = _config.AsciiReceiveBufferLimit;
                if (limit > 0 && _asciiRxBuffer.Length > limit)
                {
                    _asciiRxBuffer.Remove(0, _asciiRxBuffer.Length - limit);
                }

                var all = _asciiRxBuffer.ToString();
                int idx;
                while ((idx = all.IndexOf(terminator, StringComparison.Ordinal)) >= 0)
                {
                    var line = all.Substring(0, idx);
                    if (linesToRaise == null) linesToRaise = new List<string>();
                    linesToRaise.Add(line);

                    all = all.Substring(idx + terminator.Length);
                }

                _asciiRxBuffer.Clear();
                _asciiRxBuffer.Append(all);
            }

            if (linesToRaise == null || linesToRaise.Count == 0)
                return;

            foreach (var line in linesToRaise)
            {
                OnDataReceived(line, data);
            }
        }

        /// <summary>
        /// ����Ū���j��C
        /// </summary>
        private void StopReadLoop()
        {
            try
            {
                _readLoopCts?.Cancel();
                _readLoopTask?.Wait(TimeSpan.FromSeconds(2));
            }
            catch
            {
                // Ignore
            }
            finally
            {
                _readLoopCts?.Dispose();
                _readLoopCts = null;
                _readLoopTask = null;
            }
        }

        #endregion Private Methods - Read Loop

        #region Private Methods - Auto Reconnect

        /// <summary>
        /// �Ұʭ��s�ʱ��C
        /// </summary>
        private void StartReconnectMonitor()
        {
            StopReconnectMonitor();

            _reconnectCts = new CancellationTokenSource();
            var token = _reconnectCts.Token;

            _reconnectTask = Task.Run(async () =>
            {
                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        await Task.Delay(_config.ReconnectInterval, token);

                        // �ˬd�s�u���A
                        if (State == SerialPortState.Fault || State == SerialPortState.Disconnected)
                        {
                            if (!IsOpen)
                            {
                                State = SerialPortState.Connecting;
                                _isTransmissionVerified = false;

                                if (OpenPortInternal())
                                {
                                    // ���s�Ұ�Ū���j��
                                    StartReadLoop();

                                    // ����ǿ����ҡ]�Y�ҥΡ^
                                    if (_config.EnableTransmissionVerification)
                                    {
                                        if (PerformTransmissionVerification())
                                        {
                                            State = SerialPortState.Ready;
                                        }
                                        else
                                        {
                                            OnError("ReconnectMonitor", "���s��ǿ����ҥ���", null);
                                            State = SerialPortState.Fault;
                                        }
                                    }
                                    else
                                    {
                                        State = SerialPortState.Ready;
                                    }
                                }
                                else
                                {
                                    State = SerialPortState.Fault;
                                }
                            }
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    catch (Exception ex)
                    {
                        OnError("ReconnectMonitor", $"���s�ʱ��ɵo�Ϳ��~: {ex.Message}", ex);
                    }
                }
            }, token);
        }

        /// <summary>
        /// ����s�ʱ��C
        /// </summary>
        private void StopReconnectMonitor()
        {
            try
            {
                _reconnectCts?.Cancel();
                _reconnectTask?.Wait(TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {
                // Ignore
            }
            finally
            {
                _reconnectCts?.Dispose();
                _reconnectCts = null;
                _reconnectTask = null;
            }
        }

        #endregion Private Methods - Auto Reconnect

        #region Private Methods - Heartbeat

        /// <summary>
        /// �Ұʤ߸��˴��C
        /// </summary>
        private void StartHeartbeat()
        {
            if (string.IsNullOrEmpty(_config.HeartbeatMessage))
                return;

            StopHeartbeat();

            _heartbeatCts = new CancellationTokenSource();
            var token = _heartbeatCts.Token;
            _lastHeartbeatResponse = DateTime.Now;

            _heartbeatTask = Task.Run(async () =>
            {
                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        await Task.Delay(_config.HeartbeatInterval, token);

                        if (State == SerialPortState.Ready)
                        {
                            // �ǰe�߸��T��
                            if (!SendData(_config.HeartbeatMessage))
                            {
                                OnError("Heartbeat", "�ǰe�߸��T������", null);
                                continue;
                            }

                            // ���ݨ��ˬd�߸��^��
                            await Task.Delay(TimeSpan.FromMilliseconds(_config.HeartbeatTimeout), token);

                            var timeSinceLastResponse = DateTime.Now - _lastHeartbeatResponse;
                            if (timeSinceLastResponse.TotalMilliseconds > _config.HeartbeatTimeout)
                            {
                                OnError("Heartbeat", $"�߸��O�� ({timeSinceLastResponse.TotalMilliseconds:F0} ms)", null);
                                State = SerialPortState.Fault;
                            }
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    catch (Exception ex)
                    {
                        OnError("Heartbeat", $"�߸��˴��ɵo�Ϳ��~: {ex.Message}", ex);
                    }
                }
            }, token);
        }

        /// <summary>
        /// ����߸��˴��C
        /// </summary>
        private void StopHeartbeat()
        {
            try
            {
                _heartbeatCts?.Cancel();
                _heartbeatTask?.Wait(TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {
                // Ignore
            }
            finally
            {
                _heartbeatCts?.Dispose();
                _heartbeatCts = null;
                _heartbeatTask = null;
            }
        }

        #endregion Private Methods - Heartbeat

        #region Private Methods - Task Management

        /// <summary>
        /// ����Ҧ��I�����ȡC
        /// </summary>
        private void StopAllTasks()
        {
            StopReadLoop();
            StopReconnectMonitor();
            StopHeartbeat();
        }

        #endregion Private Methods - Task Management

        #region Event Handlers

        /// <summary>
        /// ���A�ܧ�ƥ�B�z�C
        /// </summary>
        private void OnStateChanged(SerialPortState oldState, SerialPortState newState)
        {
            try
            {
                StateChanged?.Invoke(this, new SerialPortStateChangedEventArgs(
                    _config.PortName,
                    oldState,
                    newState));
            }
            catch (Exception ex)
            {
                OnError("OnStateChanged", $"���A�ܧ�ƥ�B�z�ɵo�Ϳ��~: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// ��Ʊ����ƥ�B�z�C
        /// </summary>
        private void OnDataReceived(string data, byte[] rawData)
        {
            try
            {
                DataReceived?.Invoke(this, new SerialPortDataReceivedEventArgs(
                    _config.PortName,
                    data,
                    rawData));
            }
            catch (Exception ex)
            {
                OnError("OnDataReceived", $"��Ʊ����ƥ�B�z�ɵo�Ϳ��~: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// ���~�ƥ�B�z�C
        /// </summary>
        private void OnError(string errorType, string errorMessage, Exception exception = null)
        {
            try
            {
                ErrorOccurred?.Invoke(this, new SerialPortErrorEventArgs(
                    _config.PortName,
                    errorType,
                    errorMessage,
                    exception));
            }
            catch
            {
                // �קK�ƥ�B�z���������~�y�����D
            }
        }

        #endregion Event Handlers

        #region IDisposable

        /// <summary>
        /// ����귽�C
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
                return;

            if (disposing)
            {
                Close();
                _verificationEvent?.Dispose();
            }

            _disposed = true;
        }

        #endregion IDisposable
    }
}

