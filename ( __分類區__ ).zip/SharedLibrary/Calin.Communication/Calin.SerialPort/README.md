﻿# Calin.SerialPort

## 簡介

`Calin.SerialPort` 是一個 Thread-safe，用於管理 SerialPort 的 .NET 函式庫，提供了高效能、易於擴展的 API，支援多設備管理，並支援多執行緒操作、自動重連、心跳檢測和完整的狀態管理。

## 功能說明

1. **多 SerialPort 管理器** - 可同時管理多個串列埠設備。
2. **Thread-safe 設計** - 所有操作都是執行緒安全的。
3. **支援 ASCII 與 UTF-8 編碼** - 可根據需求選擇編碼方式。
4. **自動斷線重連機制** - 當連線中斷時自動嘗試重新連線。
5. **心跳/保持連線** - 定期發送心跳訊息確保連線正常。
6. **非同步背景監控** - 使用背景執行緒進行自動重連和心跳檢測。
7. **讀取迴圈 + 事件模型** - 持續讀取資料並透過事件通知。
8. **設備狀態機** - 完整的狀態管理（Disconnected / Connecting / Ready / Fault）。
9. **完整的例外處理** - 包含大部分可能的錯誤情況處理。
10. **支援 Autofac 依賴注入** - 方便應用層整合。
11. **設定檔持久化** - 使用 JSON 格式記錄各設備參數值。
12. **Factory 模式** - 透過工廠建立設備實例，支援多設備同時存在。
13. **傳輸驗證** - 連線後自動驗證串口參數是否正確（v0.0.3 新增）。
14. **抽象化底層依賴** - 應用程式不需直接引用 RJCP.SerialPortStream（v0.0.6 新增）。
15. **查詢可用串口** - 透過介面查詢系統上所有可用的 SerialPort（v0.0.7 新增）。

## 目標框架

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0

## 相依套件

### 必要

- `Calin.Abstractions`：提供基礎介面與共用型別。

### 選用

- `Autofac`：依賴注入容器，用於管理日誌元件的生命週期與解析。
  - 專案有提供模組註冊檔，可透過 `SerialPortModule` 快速完成註冊。

> **注意**：從 v0.0.6 開始，應用程式不需要直接引用 `RJCP.SerialPortStream`。
> 所有 SerialPort 相關的枚舉（`Parity`、`StopBits`、`Handshake`）均由 `Calin.SerialPort` 提供。

### 內部依賴（由套件自動處理）

- RJCP.SerialPortStream ( [NuGet](https://www.nuget.org/packages/RJCP.SerialPortStream/3.0.4) ) ( [GitHub](https://github.com/jcurl/serialportstream) )
  - 相關文章：[If you must use .NET System.IO.Ports.SerialPort](https://sparxeng.com/blog/software/must-use-net-system-io-ports-serialport)

## 架構設計

```mermaid
graph TB
    subgraph Application Layer
        App[應用程式]
    end
    
    subgraph DI Container
        Module[SerialPortModule]
        Factory[ISerialPortServiceFactory]
        Manager[ISerialPortManager]
    end
    
    
    subgraph Instance Layer
        Service1[SerialPortService COM1]
        Service2[SerialPortService COM2]
        Service3[SerialPortService COM3]
    end
    
    subgraph Hardware
        COM1[COM1 硬體]
        COM2[COM2 硬體]
        COM3[COM3 硬體]
    end
    
    App --> Module
    Module --> Factory
    Module --> Manager
    Factory --> Service1
    Factory --> Service2
    Manager --> Service1
    Manager --> Service2
    Manager --> Service3
    Service1 --> COM1
    Service2 --> COM2
    Service3 --> COM3
```

### 設計原則

| 類別                          | 生命週期                  | 說明                                   |
| --------------------------- | --------------------- | ------------------------------------ |
| `SerialPortModule`          | -                     | Autofac 模組，僅負責型別註冊                   |
| `ISerialPortServiceFactory` | SingleInstance        | 工廠，負責建立 SerialPortService            |
| `ISerialPortManager`        | SingleInstance        | 管理器，負責管理多個 SerialPortService         |
| `SerialPortService`         | InstancePerDependency | 代表單一 COM Port，由 Factory 或 Manager 建立 |

> **重要**：代表設備或連線的類別不可為 Singleton；管理或建立設備的類別才可為 Singleton。

## 檔案結構

```markdown
Calin.SerialPort/
├── SerialPortEnums.cs          // Parity、StopBits、Handshake 枚舉定義
├── SerialPortConfig.cs         // 設定類別
├── ISerialPortService.cs       // 單一 Port 介面
├── SerialPortService.cs        // 單一 Port 服務
├── ISerialPortServiceFactory.cs // 工廠介面
├── SerialPortServiceFactory.cs  // 工廠實作
├── ISerialPortManager.cs       // 多 Port 管理器介面
├── SerialPortManager.cs        // 多 Port 管理器
├── SerialPortState.cs          // 狀態機定義
├── SerialPortEventArgs.cs      // 事件參數
├── SerialPortModule.cs         // Autofac 模組
└── README.md                   // 說明文件
```

## 自定義枚舉

從 v0.0.6 開始，`Calin.SerialPort` 提供自定義的 `Parity`、`StopBits`、`Handshake` 枚舉，
這些枚舉直接對應於  `RJCP.SerialPortStream` 中的原始定義（相同整數值），
但對外僅暴露 `Calin.Serial.Port` 命名空間，應用程式不需要引用 `RJCP.IO.Ports`。

### Parity（同位位元）

| 值 | 說明 |
|---|------|
| `Parity.None` | 無同位位元 |
| `Parity.Odd` | 奇同位位元 |
| `Parity.Even` | 偶同位位元 |
| `Parity.Mark` | 標記同位位元 |
| `Parity.Space` | 空間同位位元 |

### StopBits（停止位元）

| 值 | 說明 |
|---|------|
| `StopBits.None` | 無停止位元（不建議使用） |
| `StopBits.One` | 1 個停止位元 |
| `StopBits.OnePointFive` | 1.5 個停止位元 |
| `StopBits.Two` | 2 個停止位元 |

### Handshake（交握模式）

| 值 | 說明 |
|---|------|
| `Handshake.None` | 無交握 |
| `Handshake.XOn` | 軟體交握 |
| `Handshake.Rts` | 硬體交握 (RTS/CTS) |
| `Handshake.Dtr` | 硬體交握 (DTR/DSR) (不常見) |
| `Handshake.RtsXOn` | RTS 和軟體交握 |
| `Handshake.DtrXOn` | DTR 和軟體交握 (不常見) |
| `Handshake.DtrRts` | 硬體交握，包含 RTS/CTS 和 DTR/DSR (不常見) |
| `Handshake.DtrRtsXOn` | 硬體交握，包含 RTS/CTS、DTR/DSR 和軟體交握 (不常見) |

## 類別與介面

### ISerialPortServiceFactory

工廠介面，用於建立 SerialPortService 實例。

| 方法                                                          | 說明                   |
| ----------------------------------------------------------- | -------------------- |
| `ISerialPortService Create(SerialPortConfig config)`        | 建立 SerialPortService |
| `ISerialPortService CreateAndOpen(SerialPortConfig config)` | 建立並開啟連線              |
| `ISerialPortService Create(string portName, int baudRate)`  | 使用預設設定建立             |

### ISerialPortService

單一 SerialPort 服務介面。

| 方法 / 屬性                    | 型別                | 說明                              |
| ---------------------------- | ----------------- | ------------------------------- |
| `PortName`                   | string            | SerialPort 名稱                   |
| `State`                      | SerialPortState   | 目前連線狀態                          |
| `IsReady`                    | bool              | 是否已就緒（State == Ready）           |
| `IsOpen`                     | bool              | SerialPort 是否已開啟                |
| `IsTransmissionVerified`     | bool              | 傳輸驗證是否已通過                       |
| `Config`                     | SerialPortConfig  | 設定資訊（複本）                        |
| `Open()`                     | bool              | 開啟 SerialPort 連線                |
| `Close()`                    | void              | 關閉 SerialPort 連線                |
| `SendData(string)`           | bool              | 傳送字串資料                          |
| `SendData(byte[])`           | bool              | 傳送位元組資料                         |
| `SendAscii(string)`          | bool              | 傳送 ASCII 字串（不加行結尾）              |
| `SendAsciiLine(string)`      | bool              | 傳送 ASCII 字串並加上行結尾               |
| `GetAvailablePorts()`        | List\<string\>    | 取得系統上所有可用的 SerialPort 名稱        |
| `SaveConfig(string)`         | bool              | 儲存配置到 JSON 檔案                   |
| `LoadConfig(string)`         | bool              | 從 JSON 檔案載入配置                   |

### ISerialPortManager

多 SerialPort 管理器介面。

| 方法 / 屬性                                  | 型別                                   | 說明                              |
| ------------------------------------------ | ------------------------------------ | ------------------------------- |
| `PortCount`                                | int                                  | 已註冊的 SerialPort 數量              |
| `RegisteredPorts`                          | IReadOnlyList\<string\>              | 所有已註冊的 SerialPort 名稱            |
| `RegisterPort(SerialPortConfig)`           | bool                                 | 註冊並開啟新的 SerialPort              |
| `UnregisterPort(string)`                   | bool                                 | 取消註冊並關閉指定的 SerialPort           |
| `GetPort(string)`                          | SerialPortService                    | 取得指定的 SerialPort 服務             |
| `IsPortRegistered(string)`                 | bool                                 | 檢查是否已註冊                         |
| `GetPortState(string)`                     | SerialPortState                      | 取得指定 SerialPort 的狀態             |
| `OpenPort(string)`                         | bool                                 | 開啟指定的 SerialPort                |
| `ClosePort(string)`                        | void                                 | 關閉指定的 SerialPort                |
| `OpenAllPorts()`                           | int                                  | 開啟所有已註冊的 SerialPort             |
| `CloseAllPorts()`                          | void                                 | 關閉所有已註冊的 SerialPort             |
| `SendData(string, string)`                 | bool                                 | 傳送字串資料到指定 Port                  |
| `SendData(string, byte[])`                 | bool                                 | 傳送位元組資料到指定 Port                 |
| `SendAscii(string, string)`                | bool                                 | 傳送 ASCII 字串到指定 Port             |
| `SendAsciiLine(string, string)`            | bool                                 | 傳送 ASCII 字串並加行結尾到指定 Port        |
| `BroadcastData(string)`                    | int                                  | 廣播字串到所有已就緒的 Port               |
| `BroadcastData(byte[])`                    | int                                  | 廣播位元組到所有已就緒的 Port              |
| `GetAllPortStates()`                       | Dictionary\<string, SerialPortState\> | 取得所有 Port 狀態摘要                  |
| `GetAvailablePorts()`                      | List\<string\>                       | 取得系統上所有可用的 SerialPort 名稱        |
| `SaveAllConfigs(string)`                   | bool                                 | 儲存所有配置到 JSON 檔案                 |
| `LoadAllConfigs(string, bool)`             | int                                  | 從 JSON 檔案載入多個配置                 |
| `SavePortConfig(string, string)`           | bool                                 | 儲存特定 Port 的配置                   |
| `LoadPortConfig(string, string)`           | bool                                 | 載入特定 Port 的配置                   |

### SerialPortConfig

- 用於配置 SerialPort 的類別，包含所有 SerialPort 參數。
- 自動重連、心跳檢測相關設定。
- 傳輸驗證相關設定。
- 提供 `Clone()` 方法用於複製設定。

| 參數                               | 型別           | 說明                                         | 預設值    |  單位   |
| -------------------------------- | ------------ | ------------------------------------------ | ------ | :---: |
| `PortName`                       | string       | SerialPort 名稱                              | "COM1" |       |
| `BaudRate`                       | int          | 鮑率                                         | 9600   |       |
| `DataBits`                       | int          | 資料位元數                                      | 8      |       |
| `Parity`                         | Parity       | 同位位元                                       | None   |       |
| `StopBits`                       | StopBits     | 停止位元                                       | One    |       |
| `Handshake`                      | Handshake    | 交握模式                                       | None   |       |
| `ReadTimeout`                    | int          | 讀取逾時                                       | 1000   |  ms   |
| `WriteTimeout`                   | int          | 寫入逾時                                       | 1000   |  ms   |
| `RtsEnable`                      | bool         | 啟用 RTS 信號                                  | false  |       |
| `DtrEnable`                      | bool         | 啟用 DTR 信號                                  | false  |       |
| `EnableAutoReconnect`            | bool         | 啟用自動重連                                     | false  |       |
| `ReconnectInterval`              | int          | 重連間隔                                       | 5000   |  ms   |
| `EnableHeartbeat`                | bool         | 啟用心跳檢測                                     | false  |       |
| `HeartbeatInterval`              | int          | 心跳間隔                                       | 30000  |  ms   |
| `HeartbeatMessage`               | string       | 心跳訊息                                       | ""     |       |
| `HeartbeatTimeout`               | int          | 心跳逾時                                       | 10000  |  ms   |
| `TextEncoding`                   | TextEncoding | 取得或設定 ASCII 模式的文字編碼                        | Ascii  |       |
| `AsciiLineTerminator`            | string       | 取得或設定 ASCII 行結尾字串                          | "\r\n" |       |
| `EnableAsciiLineMode`            | bool         | 取得或設定接收時是否依 AsciiLineTerminator 切成一行一行觸發事件 | true   |       |
| `AsciiReceiveBufferLimit`        | int          | 取得或設定 ASCII 接收緩衝的最大字元數                     | 8192   | bytes |
| `EnableTransmissionVerification` | bool         | 是否在連線後自動執行傳輸驗證                             | true   |       |
| `TransmissionTestMessage`        | string       | 傳輸驗證的測試訊息                                  | ""     |       |
| `TransmissionTestTimeout`        | int          | 傳輸驗證的逾時時間                                  | 2000   |  ms   |

### SerialPortService 屬性

| 屬性                       | 型別               | 說明                    |
| ------------------------ | ---------------- | --------------------- |
| `PortName`               | string           | SerialPort 名稱         |
| `State`                  | SerialPortState  | 目前連線狀態                |
| `IsReady`                | bool             | 是否已就緒（State == Ready） |
| `IsOpen`                 | bool             | SerialPort 是否已開啟      |
| `IsTransmissionVerified` | bool             | 傳輸驗證是否已通過             |
| `Config`                 | SerialPortConfig | 設定資訊（複本）              |

### 傳輸驗證 (Transmission Verification)

當 `EnableTransmissionVerification` 為 `true`（預設）時，`Open()` 方法會在成功開啟 SerialPort 後自動執行傳輸驗證：

1. 若有設定 `TransmissionTestMessage`，會先發送該測試訊息
2. 等待在 `TransmissionTestTimeout` 時間內收到任何回應資料
3. 若收到回應，`IsTransmissionVerified` 設為 `true`，狀態變為 `Ready`
4. 若逾時未收到回應，`IsTransmissionVerified` 為 `false`，狀態變為 `Fault`

**狀態判斷邏輯：**

| 條件         | `IsOpen` | `IsTransmissionVerified` | `State`      |
| ---------- | -------- | ------------------------ | ------------ |
| 未開啟        | false    | false                    | Disconnected |
| 開啟成功，驗證通過  | true     | true                     | Ready        |
| 開啟成功，驗證失敗  | true     | false                    | Fault        |
| 未啟用驗證，開啟成功 | true     | true                     | Ready        |

### SerialPortModule

Autofac 模組，僅負責型別註冊。

```csharp
public class SerialPortModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        // 註冊 Factory (SingleInstance)
        builder.RegisterType<SerialPortServiceFactory>()
            .As<ISerialPortServiceFactory>()
            .SingleInstance();

        // 註冊 Manager (SingleInstance)
        builder.RegisterType<SerialPortManager>()
            .As<ISerialPortManager>()
            .SingleInstance();
    }
}
```

> **注意**：Module 不再包含 `RegisterManager`、`RegisterService`、`DefaultServiceConfig` 等屬性。這些業務邏輯已移至 Factory 和 Manager。

## 快速開始

### 1. 查詢可用的 SerialPort

```csharp
using Autofac;
using Calin.SerialPort;

var builder = new ContainerBuilder();
builder.RegisterModule<SerialPortModule>();
var container = builder.Build();

// 方式一：透過 Manager 查詢
var manager = container.Resolve<ISerialPortManager>();
var availablePorts = manager.GetAvailablePorts();
Console.WriteLine("可用的 SerialPort:");
foreach (var port in availablePorts)
{
    Console.WriteLine($"  - {port}");
}

// 方式二：透過 Factory 建立 Service 後查詢
var factory = container.Resolve<ISerialPortServiceFactory>();
var service = factory.Create("COM1");
var ports = service.GetAvailablePorts();
```

### 2. 使用 Factory 建立單一 SerialPort

```csharp
using Autofac;
using Calin.SerialPort;

// 建立 Autofac 容器
var builder = new ContainerBuilder();
builder.RegisterModule<SerialPortModule>();
var container = builder.Build();

// 取得 Factory
var factory = container.Resolve<ISerialPortServiceFactory>();

// 建立 SerialPort
var service = factory.Create(new SerialPortConfig
{
    PortName = "COM1",
    BaudRate = 9600,
    EnableAutoReconnect = true,
    ReconnectInterval = 5000,
    
    // 傳輸驗證設定（預設已啟用）
    EnableTransmissionVerification = true,
    TransmissionTestMessage = "PING\r\n",
    TransmissionTestTimeout = 3000
});

// 訂閱事件
service.StateChanged += (s, e) =>
{
    Console.WriteLine($"狀態: {e.OldState} -> {e.NewState}");
};

service.DataReceived += (s, e) =>
{
    Console.WriteLine($"收到資料: {e.Data}");
};

service.ErrorOccurred += (s, e) =>
{
    Console.WriteLine($"錯誤: {e.ErrorMessage}");
};

// 開啟連線
if (service.Open())
{
    Console.WriteLine($"IsOpen: {service.IsOpen}");
    Console.WriteLine($"IsTransmissionVerified: {service.IsTransmissionVerified}");

    if (service.IsTransmissionVerified)
    {
        service.SendData("Hello!");
    }
}

// 使用完畢後釋放
service.Dispose();
```

### 3. 使用 Factory 建立多個 SerialPort

```csharp
using Autofac;
using Calin.SerialPort;

var builder = new ContainerBuilder();
builder.RegisterModule<SerialPortModule>();
var container = builder.Build();

var factory = container.Resolve<ISerialPortServiceFactory>();

// 建立多個 SerialPort（各自獨立的實例）
var com1 = factory.Create(new SerialPortConfig 
{ 
    PortName = "COM1", 
    BaudRate = 9600 
});

var com2 = factory.Create(new SerialPortConfig 
{ 
    PortName = "COM2", 
    BaudRate = 115200 
});

// 訂閱事件
com1.DataReceived += (s, e) => Console.WriteLine($"[COM1] {e.Data}");
com2.DataReceived += (s, e) => Console.WriteLine($"[COM2] {e.Data}");

// 開啟連線
com1.Open();
com2.Open();

// 檢查傳輸驗證狀態
Console.WriteLine($"COM1 驗證: {com1.IsTransmissionVerified}");
Console.WriteLine($"COM2 驗證: {com2.IsTransmissionVerified}");

// 傳送資料
if (com1.IsTransmissionVerified)
    com1.SendData("Hello COM1!");

if (com2.IsTransmissionVerified)
    com2.SendData("Hello COM2!");

// 使用完畢後釋放
com1.Dispose();
com2.Dispose();
```

### 4. 使用 Manager 管理多個 SerialPort

```csharp
using Autofac;
using Calin.SerialPort;

var builder = new ContainerBuilder();
builder.RegisterModule<SerialPortModule>();
var container = builder.Build();

// 取得 Manager
var manager = container.Resolve<ISerialPortManager>();

// 註冊多個 SerialPort
manager.RegisterPort(new SerialPortConfig { PortName = "COM1", BaudRate = 9600 });
manager.RegisterPort(new SerialPortConfig { PortName = "COM2", BaudRate = 115200 });
manager.RegisterPort(new SerialPortConfig { PortName = "COM3", BaudRate = 9600 });

// 訂閱全域事件
manager.StateChanged += (s, e) =>
{
    Console.WriteLine($"[{e.PortName}] 狀態: {e.OldState} -> {e.NewState}");
};

manager.DataReceived += (s, e) => 
{
    Console.WriteLine($"[{e.PortName}] 收到: {e.Data}");
};

manager.ErrorOccurred += (s, e) =>
{
    Console.WriteLine($"[{e.PortName}] 錯誤: {e.ErrorMessage}");
};

// 傳送資料到特定 Port
manager.SendData("COM1", "Hello!");

// 廣播到所有 Port
int successCount = manager.BroadcastData("Broadcast Message");
Console.WriteLine($"廣播成功傳送到 {successCount} 個設備");

// 取得所有狀態
var states = manager.GetAllPortStates();
foreach (var kvp in states)
{
    Console.WriteLine($"{kvp.Key}: {kvp.Value}");
}
```

### 5. 使用心跳檢測

```csharp
using Autofac;
using Calin.SerialPort;

var builder = new ContainerBuilder();
builder.RegisterModule<SerialPortModule>();
var container = builder.Build();

var factory = container.Resolve<ISerialPortServiceFactory>();

var service = factory.Create(new SerialPortConfig
{
    PortName = "COM1",
    BaudRate = 9600,
    EnableAutoReconnect = true,
    EnableHeartbeat = true,
    HeartbeatInterval = 30000,      // 30 秒發送一次
    HeartbeatMessage = "PING\r\n",  // 心跳訊息
    HeartbeatTimeout = 10000        // 10 秒內沒收到回應視為異常
});

service.StateChanged += (s, e) =>
{
    if (e.NewState == SerialPortState.Fault)
    {
        Console.WriteLine("偵測到連線異常，將自動重連...");
    }
    else if (e.NewState == SerialPortState.Ready)
    {
        Console.WriteLine("連線已就緒");
    }
};

service.DataReceived += (s, e) =>
{
    if (e.Data.Contains("PONG"))
    {
        Console.WriteLine("心跳正常");
    }
};

service.Open();
```

### 6. 停用傳輸驗證

若設備無法在連線後立即回傳資料，可停用傳輸驗證：

```csharp
var factory = container.Resolve<ISerialPortServiceFactory>();

var service = factory.Create(new SerialPortConfig
{
    PortName = "COM1",
    BaudRate = 9600,
    EnableTransmissionVerification = false  // 停用傳輸驗證
});
```

### 7. 使用 CreateAndOpen 快速建立

```csharp
var factory = container.Resolve<ISerialPortServiceFactory>();

// 建立並自動開啟連線
try
{
    using (var service = factory.CreateAndOpen(new SerialPortConfig 
    { 
        PortName = "COM1" 
    }))
    {
        if (service.IsTransmissionVerified)
        {
            service.SendData("Hello!");
        }
    }
}
catch (InvalidOperationException ex)
{
    Console.WriteLine($"無法開啟連線: {ex.Message}");
}
```

### 8. 在應用程式中使用依賴注入

```csharp
public class DeviceController
{
    private readonly ISerialPortServiceFactory _factory;
    private readonly ISerialPortManager _manager;

    public DeviceController(
        ISerialPortServiceFactory factory,
        ISerialPortManager manager)
    {
        _factory = factory;
        _manager = manager;
    }

    public void InitializeDevices()
    {
        // 查詢可用的 SerialPort
        var availablePorts = _manager.GetAvailablePorts();
        Console.WriteLine($"找到 {availablePorts.Count} 個可用的 SerialPort");

        // 使用 Manager 管理多個設備
        _manager.RegisterPort(new SerialPortConfig { PortName = "COM1" });
        _manager.RegisterPort(new SerialPortConfig { PortName = "COM2" });
    }

    public ISerialPortService CreateTemporaryConnection(string portName)
    {
        // 使用 Factory 建立臨時連線
        return _factory.Create(portName);
    }
}
```

## Autofac 依賴注入

### 標準註冊方式

```csharp
var builder = new ContainerBuilder();
builder.RegisterModule<SerialPortModule>();
var container = builder.Build();

// Factory 和 Manager 都是 SingleInstance
var factory = container.Resolve<ISerialPortServiceFactory>();
var manager = container.Resolve<ISerialPortManager>();
```

### 在應用程式中使用

```csharp
public class DeviceController
{
    private readonly ISerialPortServiceFactory _factory;
    private readonly ISerialPortManager _manager;

    public DeviceController(
        ISerialPortServiceFactory factory,
        ISerialPortManager manager)
    {
        _factory = factory;
        _manager = manager;
    }

    public void InitializeDevices()
    {
        // 使用 Manager 管理多個設備
        _manager.RegisterPort(new SerialPortConfig { PortName = "COM1" });
        _manager.RegisterPort(new SerialPortConfig { PortName = "COM2" });
    }

    public ISerialPortService CreateTemporaryConnection(string portName)
    {
        // 使用 Factory 建立臨時連線
        return _factory.Create(portName);
    }
}
```

## 測試建議

1. **單元測試**: 測試狀態轉換邏輯。
2. **整合測試**: 使用虛擬 COM Port 測試。
3. **壓力測試**: 模擬多設備同時運作。
4. **斷線測試**: 測試自動重連機制。
5. **心跳測試**: 驗證心跳逾時處理。
6. **傳輸驗證測試**: 測試不同參數設定的驗證結果。

## 效能考量

- 使用 `ConcurrentDictionary` 提升多執行緒效能。
- 讀取迴圈使用小延遲 (10ms) 避免 CPU 過載。
- 事件處理建議非同步執行，避免阻塞讀取迴圈。

## 注意事項

- 從 v0.0.6 開始，應用程式**不需要**直接引用 `RJCP.SerialPortStream` 套件。
- 使用 `Calin.SerialPort.Parity`、`Calin.SerialPort.StopBits`、`Calin.SerialPort.Handshake` 枚舉。
- 使用心跳檢測時，請設定適當的 `HeartbeatInterval` 和 `HeartbeatTimeout`。
- 使用完畢後請記得呼叫 `Dispose()` 或使用 `using` 語句。
- Factory 建立的實例需由呼叫者負責 Dispose。
- Manager 會在 Dispose 時自動釋放所有已註冊的 SerialPort。
- 傳輸驗證預設為啟用，若設備無法立即回應，請停用或設定適當的測試訊息。

## 版本歷史

### v0.0.7

2026.01.26

- **API 變更**：`GetAvailablePorts()` 從靜態方法改為實例方法
  - 新增 `ISerialPortService.GetAvailablePorts()` 方法
  - 新增 `ISerialPortManager.GetAvailablePorts()` 方法
  - 應用程式可透過介面查詢系統上所有可用的 SerialPort
  - 此變更讓未直接引用 `Calin.SerialPort` 的模組也能查詢可用串口

### v0.0.6

2026.01.25

- **重大更新**：抽象化 RJCP.SerialPortStream 依賴
  - 新增 `SerialPortEnums.cs`，提供自定義的 `Parity`、`StopBits`、`Handshake` 枚舉
  - 應用程式不再需要直接引用 `RJCP.SerialPortStream` 套件
  - 內部使用 `SerialPortEnumConverter` 進行枚舉轉換
- 使用方式變更：
  - 舊：`RJCP.IO.Ports.Parity.None`
  - 新：`Calin.SerialPort.Parity.None`

### v0.0.5

2026.01.23

- 移除對 `Newtonsoft.Json` 的依賴。
- 新增 NuGet `Calin`、`Calin.Abstractions`。
- 移除 `JsonFileHelper`，參數存檔交由 NuGet `Calin` 處理。

### v0.0.4

2026.01.20

- 修改 `IsTransmissionVerified` 屬性無法設定為 `true` 的問題

### v0.0.3

2026.01.20

- 新增傳輸驗證功能（Transmission Verification）
- 新增 `IsTransmissionVerified` 屬性
- 新增 `EnableTransmissionVerification`、`TransmissionTestMessage`、`TransmissionTestTimeout` 設定
- `Open()` 後自動執行傳輸驗證，確認串口參數是否正確
- 自動重連時也會執行傳輸驗證

### v0.0.2

2026.01.17

- 新增 `ISerialPortServiceFactory` 介面與實作
- 重構 `SerialPortModule`，移除業務狀態屬性
- Module 現在是 Idempotent，可安全重複註冊

### v0.0.1

2025.12.18

- ASCII 傳送（Service + Manager 都有）
  - SerialPortService.SendAscii(string data)：以 ASCII 編碼送出（不加行尾）
  - SerialPortService.SendAsciiLine(string line)：送出並自動加上行尾（預設 "\n"）
  - SerialPortManager.SendAscii(portName, data) / SendAsciiLine(portName, line)：代理呼叫，符合 SendData 風格
- ASCII 接收（行模式 / 非行模式）
  - 預設啟用 行模式：收到資料後會依 AsciiLineTerminator 分割成多行，每一行都會觸發一次 DataReceived
  - 若關閉行模式：就維持「收到一段就觸發一次」(不切行)
- 可設定項目（放在 SerialPortConfig）
    新增：
  - TextEncoding：Ascii / Utf8（預設 Ascii）
  - AsciiLineTerminator：預設 "\n"
  - EnableAsciiLineMode：預設 true
  - AsciiReceiveBufferLimit：預設 8192，避免一直累積導致記憶體成長
  - GetTextEncoding()：取得對應的 System.Text.Encoding
    並已更新 Clone() 將上述參數一起複製。
- 介面已補齊
  - ISerialPortService：加入 SendAscii、SendAsciiLine
  - ISerialPortManager：加入 SendAscii、SendAsciiLine

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.

