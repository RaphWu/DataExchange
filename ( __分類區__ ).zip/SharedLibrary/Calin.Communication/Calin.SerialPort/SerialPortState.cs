namespace Calin.SerialPort
{
    /// <summary>
    /// SerialPort �s�u���A�C
    /// </summary>
    public enum SerialPortState
    {
        /// <summary>
        /// �w�_�u�C
        /// </summary>
        Disconnected = 0,

        /// <summary>
        /// �s�u���C
        /// </summary>
        Connecting = 1,

        /// <summary>
        /// �w�N���C
        /// </summary>
        Ready = 2,

        /// <summary>
        /// �G�١C
        /// </summary>
        Fault = 3
    }
}
