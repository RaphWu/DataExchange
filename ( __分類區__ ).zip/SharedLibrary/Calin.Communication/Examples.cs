﻿#if DEBUG

using System;

public class Examples
{
	public ExampleA()
	{
        // 建立 Autofac 容器
        var builder = new ContainerBuilder();
        builder.RegisterModule<SerialPortModule>();
        builder.RegisterModule<ModbusModule>();
        var container = builder.Build();

        // 取得 Factory 和 Manager
        var factory = container.Resolve<IModbusClientFactory>();
        var manager = container.Resolve<IModbusClientManager>();

        // 建立兩個 ModbusClient，使用不同 SerialPort
        var modbus1 = factory.CreateWithSerialPortConfig(
            new SerialPortConfig { PortName = "COM1", BaudRate = 9600 }
        );

        var modbus2 = factory.CreateWithSerialPortConfig(
            new SerialPortConfig { PortName = "COM2", BaudRate = 115200 }
        );

        // 使用 Manager 管理
        manager.Register("PLC_A", modbus1);
        manager.Register("PLC_B", modbus2);
        manager.ConnectAll();

        // 各自獨立操作
        var resp1 = modbus1.ReadHoldingRegisters(1, 0, 10);
        var resp2 = modbus2.ReadHoldingRegisters(2, 0, 10);
    }
}

#endif