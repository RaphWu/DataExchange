﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QPC
{
    /// <summary>
    /// 表單的主類別，負責初始化計時器和處理高解析度計時相關邏輯。
    /// </summary>
    public partial class Form1 : Form
    {
        private CancellationTokenSource _cts;
        private CancellationToken Token => _cts.Token;
        private readonly Stopwatch _stopwatch = new Stopwatch();

        private UltraHighAccurateTimer _ultraHighAccurateTimer;
        private HighAccurateTimer _highAccurateTimer;
        private WinTimer _timerWinForm;

        /// <summary>
        /// 指示是否支援高解析度計時。
        /// </summary>
        private bool _isHighResolution = false;

        /// <summary>
        /// 計時器的頻率（每秒的計數）。
        /// </summary>
        private long _frequency;

        /// <summary>
        /// 每個計數對應的奈秒數。
        /// </summary>
        private long _nanosecPerTick;

        public Form1()
        {
            InitializeComponent();

            _isHighResolution = Stopwatch.IsHighResolution;
            _frequency = Stopwatch.Frequency;
            _nanosecPerTick = (1000L * 1000L * 1000L) / _frequency;

            var dgvWinTimer = new BufferedDataGridView()
            {
                Dock = DockStyle.Fill
            };
            panel1.Controls.Add(dgvWinTimer);
            dgvWinTimer.VirtualMode = true;
            dgvWinTimer.ReadOnly = true;
            dgvWinTimer.AllowUserToAddRows = false;
            dgvWinTimer.AllowUserToDeleteRows = false;
            dgvWinTimer.RowHeadersVisible = false;
            dgvWinTimer.AutoGenerateColumns = false;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _cts?.Cancel();
            _cts?.Dispose();
            base.OnFormClosing(e);
        }

        private void CreateNewCts()
        {
            _cts?.Dispose();
            _cts = new CancellationTokenSource();
        }

        private void CreateWorkers()
        {
            _timerWinForm = new WinTimer(Token);
            _timerWinForm.Tick += (sender) =>
            {
                // Handle WinTimer tick event
            };

            _ultraHighAccurateTimer = new UltraHighAccurateTimer(Token);

            _highAccurateTimer = new HighAccurateTimer(Token);
        }

        private void StartAll()
        {
            CreateNewCts();
            CreateWorkers();

            _timerWinForm.Start();
            _ultraHighAccurateTimer.Start();
            _highAccurateTimer.Start();
        }

        private void CancelAll()
        {
            if (_cts != null && _cts.IsCancellationRequested)
                return;

            _cts?.Cancel();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            StartAll();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            CancelAll();
        }
    }
}
