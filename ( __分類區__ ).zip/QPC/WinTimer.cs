﻿using System;
using System.Threading;

namespace QPC
{
    public class WinTimer : CtsBase
    {
        private readonly System.Windows.Forms.Timer _timer;

        public delegate void WinTimerEventHandler(object sender);
        public event WinTimerEventHandler Tick;

        public int WinTick { get; set; } = 1;

        public WinTimer(CancellationToken token) : base(token)
        {
            _timer = new System.Windows.Forms.Timer();
            _timer.Tick += OnTimerTick;
        }

        private void OnTimerTick(object sender, EventArgs e)
        {
            if (Token.IsCancellationRequested)
                _timer.Stop();

            Tick?.Invoke(this);
        }

        public override void Start()
        {
            if (Token.IsCancellationRequested)
                return;

            _timer.Interval = WinTick;
            _timer.Start();
        }

        //public void Stop()
        //{
        //    if (_cts == null)
        //        return;

        //    _cts.Cancel();
        //    _timer.Stop();
        //}
    }
}
