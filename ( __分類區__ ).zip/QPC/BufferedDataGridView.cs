﻿using System;
using System.Reflection;
using System.Windows.Forms;

namespace QPC
{
    public class BufferedDataGridView : DataGridView
    {
        public BufferedDataGridView()
        {
            if (!DesignMode)
            {
                EnableDoubleBuffer();
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);

            if (!DesignMode)
            {
                EnableDoubleBuffer();
            }
        }

        private void EnableDoubleBuffer()
        {
            typeof(DataGridView)
                .GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic)
                ?.SetValue(this, true, null);
        }
    }
}
