﻿using System.Diagnostics;
using System.Threading;

namespace QPC
{
    public class HighAccurateTimer : CtsBase
    {
        private Thread _thread;

        public delegate void TimerEventHandler(object sender);
        public event TimerEventHandler Tick;

        public HighAccurateTimer(CancellationToken token) : base(token)
        {
        }

        public override void Start()
        {
            if (Token.IsCancellationRequested)
                return;

            _thread = new Thread(() => ThreadProc(Token));
            _thread.Name = "HighAccurateTimer";
            _thread.IsBackground = true;
            _thread.Priority = ThreadPriority.Highest;
            _thread.Start();
        }

        private void ThreadProc(CancellationToken token)
        {
            var sw = Stopwatch.StartNew();
            long ticksPerMs = Stopwatch.Frequency / 1000;
            long nextTick = sw.ElapsedTicks;

            while (!token.IsCancellationRequested)
            {
                long now = sw.ElapsedTicks;

                if (now >= nextTick)
                {
                    nextTick += ticksPerMs;
                    Tick?.Invoke(this);
                }
                else
                {
                    Thread.SpinWait(20);
                }
            }
        }
    }
}
