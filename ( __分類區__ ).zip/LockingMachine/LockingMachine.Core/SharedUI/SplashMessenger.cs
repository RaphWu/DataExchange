﻿namespace Calin.LockingMachine.Core.SharedUI
{
    /// <summary>
    /// 提供一個靜態類別，用於給 SplashScreen 傳遞訊息。
    /// </summary>
    public static class SplashMessenger
    {
        private static SynchronizationContext _uiContext;
        private static Action<string> _messageHandler;

        /// <summary>
        /// 初始化 <see cref="SplashMessenger"/> 類別，設定同步內容與訊息處理程序。
        /// </summary>
        /// <param name="context">UI 的同步內容。</param>
        /// <param name="handler">處理訊息的委派。</param>
        public static void Initialize(SynchronizationContext context, Action<string> handler)
        {
            _uiContext = context;
            _messageHandler = handler;
        }

        /// <summary>
        /// 傳遞一則訊息至 UI 執行緒。
        /// </summary>
        /// <param name="message">要傳遞的訊息內容。</param>
        public static void Post(string message)
        {
            if (_uiContext == null)
                return;

            _uiContext.Post(_ =>
            {
                _messageHandler?.Invoke(message);
            }, null);
        }

        /// <summary>
        /// 關閉 <see cref="SplashMessenger"/>。
        /// </summary>
        public static void Shutdown()
        {
            _messageHandler = null;
            _uiContext = null;
        }
    }
}
