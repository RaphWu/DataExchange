﻿using Calin.Comm.DL_RS1A;

namespace Calin.LockingMachine.Models
{
    public class Dlrs1aData
    {
        internal DL_RS1A_Config dlrs1aConfig = new DL_RS1A_Config();

        // 高度計
        internal double heightDispLimitH = 20.0;
        internal double heightDispLimitL = 10.0;
    }
}
