﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calin.Comm.DL_RS1A;

namespace Calin.LockingMachine.Models
{
    public class DeviceData
    {
        internal List<string> comPortList = new List<string>();

        internal IDL_RS1A dl_RS1A = default;
        internal DL_RS1A_Config dl_RS1A_Config = null;
    }
}
