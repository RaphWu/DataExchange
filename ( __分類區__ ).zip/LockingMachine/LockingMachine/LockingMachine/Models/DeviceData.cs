﻿namespace Calin.LockingMachine.Models
{
    public class DeviceData
    {
        // Serial Port
        internal List<string> comPortList = new List<string>();
    }
}
