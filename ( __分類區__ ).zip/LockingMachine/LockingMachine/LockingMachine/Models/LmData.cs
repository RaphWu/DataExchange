﻿using Calin.Comm.DL_RS1A;
using Calin.DAQ.USB4704;

namespace Calin.LockingMachine.Models
{
    /// <summary>
    /// 表示設備相關的資料模型。
    /// </summary>
    /// <remarks>這裡存放的資料是不存檔的。</remarks>
    public class LmData
    {
        internal List<string> comPortList = new List<string>();
        internal IDL_RS1A dlrs1a = default;
        internal IUsb4704Dio dio = default;
    }
}
