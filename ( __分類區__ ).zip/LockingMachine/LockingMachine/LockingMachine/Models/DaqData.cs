﻿using Calin.DAQ.USB4704;

namespace Calin.LockingMachine.Models
{
    /// <summary>
    /// 表示資料擷取裝置 (DAQ) 的相關資料。
    /// </summary>
    public class DaqData
    {
        internal string deviceCode = "USB-4704,BID#0";

        // 扭力計上下限設定
        internal double torqueLimitH = 20.0;
        internal double torqueLimitL = 10.0;

        // 尋邊
        internal int GetMarkPort = 0;
    }
}
