﻿using Calin.DAQ.USB4704;
using Calin.LockingMachine.Services;

namespace Calin.LockingMachine.Models
{
    /// <summary>
    /// 表示資料擷取裝置 (DAQ) 的相關資料。
    /// </summary>
    public class DaqData
    {
        internal IUsb4704 daq = default;
        internal Usb4704Config daqConfig = new Usb4704Config();

        // 扭力計上下限設定
        internal double torqueLimitH = 20.0;
        internal double torqueLimitL = 10.0;
    }
}
