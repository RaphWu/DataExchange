﻿namespace Calin.LockingMachine.Constants
{
    public enum PageCode
    {
        None,

        MainPage,
        WorkSetup,
        Monitor,
        Setup,
    }
}
