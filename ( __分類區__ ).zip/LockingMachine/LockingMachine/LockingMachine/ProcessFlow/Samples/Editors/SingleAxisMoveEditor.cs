﻿#if DEBUG

using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Samples.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Samples.Editors
{
    /// <summary>
    /// 單軸移動參數編輯器。
    /// </summary>
    public class SingleAxisMoveEditor : ProcessEditorBase
    {
        private ComboBox _cmbAxisId;
        private NumericUpDown _numTargetPosition;
        private NumericUpDown _numSpeed;
        private NumericUpDown _numAcceleration;

        public override string ProcessId => ProcessIds.SINGLE_AXIS_MOVE;

        public SingleAxisMoveEditor()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.SuspendLayout();

            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 5,
                Padding = new Padding(10)
            };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            // 軸代號
            layout.Controls.Add(new Label { Text = "軸代號：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 0);
            _cmbAxisId = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            _cmbAxisId.Items.AddRange(new[] { "X", "Y", "Z", "A", "B", "C" });
            _cmbAxisId.SelectedIndexChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_cmbAxisId, 1, 0);

            // 目標座標
            layout.Controls.Add(new Label { Text = "目標座標：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 1);
            _numTargetPosition = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = -999999,
                Maximum = 999999,
                DecimalPlaces = 3,
                Increment = 1
            };
            _numTargetPosition.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numTargetPosition, 1, 1);

            // 速度
            layout.Controls.Add(new Label { Text = "速度 (mm/s)：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 2);
            _numSpeed = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = 1,
                Maximum = 10000,
                DecimalPlaces = 1,
                Value = 100
            };
            _numSpeed.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numSpeed, 1, 2);

            // 加速度
            layout.Controls.Add(new Label { Text = "加速度 (mm/s²)：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 3);
            _numAcceleration = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = 1,
                Maximum = 50000,
                DecimalPlaces = 1,
                Value = 500
            };
            _numAcceleration.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numAcceleration, 1, 3);

            this.Controls.Add(layout);

            this.ResumeLayout(false);
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new SingleAxisMoveParam()
                : JsonConvert.DeserializeObject<SingleAxisMoveParam>(paramJson) ?? new SingleAxisMoveParam();

            _cmbAxisId.SelectedItem = param.AxisId ?? "X";
            _numTargetPosition.Value = (decimal)param.TargetPosition;
            _numSpeed.Value = (decimal)param.Speed;
            _numAcceleration.Value = (decimal)param.Acceleration;
        }

        public override string Save()
        {
            var param = new SingleAxisMoveParam
            {
                AxisId = _cmbAxisId.SelectedItem?.ToString() ?? "X",
                TargetPosition = (double)_numTargetPosition.Value,
                Speed = (double)_numSpeed.Value,
                Acceleration = (double)_numAcceleration.Value
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            if (_numSpeed.Value <= 0)
                return "速度必須大於 0";

            if (_numAcceleration.Value <= 0)
                return "加速度必須大於 0";

            return null;
        }
    }
}

#endif