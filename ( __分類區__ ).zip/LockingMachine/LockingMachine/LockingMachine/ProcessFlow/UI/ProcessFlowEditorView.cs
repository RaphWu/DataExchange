using Autofac;
using Calin.LockingMachine.Constants;
using Calin.LockingMachine.ProcessFlow.Core;
using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Registry;

namespace Calin.LockingMachine.ProcessFlow.UI
{
    /// <summary>
    /// �u�Ǭy�{�s��D���ϡC
    /// </summary>
    /// <remarks>
    /// �T�ϳ]�p�G
    /// - �����GProcess Source�]�u�Ǩӷ��^
    /// - �����GProcess List�]�y�{�M��^
    /// - �k���GProcess Editor�]�Ѽƽs�边�^
    /// </remarks>
    public class ProcessFlowEditorView : UserControl
    {
        private readonly ILifetimeScope _scope;
        private readonly IProcessRegistry _registry;

        // UI Controls
        private SplitContainer _mainSplitter;
        private SplitContainer _leftSplitter;

        // �����G�u�Ǩӷ�
        private ListBox _lstProcessSource;

        // �����G�y�{�M��
        private DataGridView _dgvProcessList;
        private Button _btnAdd;
        private Button _btnRemove;
        private Button _btnMoveUp;
        private Button _btnMoveDown;

        // �k���G�Ѽƽs�边
        private Panel _pnlEditorHost;
        private Label _lblEditorTitle;

        // ���
        private List<ProcessStepEntity> _processSteps = new List<ProcessStepEntity>();
        private IProcessEditor _currentEditor;
        private ProcessStepEntity _selectedStep;
        private bool _isLoading;

        /// <summary>
        /// �y�{�ܧ�ƥ�C
        /// </summary>
        public event EventHandler FlowChanged;

        public ProcessFlowEditorView(ILifetimeScope scope, IProcessRegistry registry)
        {
            _scope = scope ?? throw new ArgumentNullException(nameof(scope));
            _registry = registry ?? throw new ArgumentNullException(nameof(registry));

            InitializeComponents();
            LoadProcessSource();
        }

        /// <summary>
        /// ���o�ثe���y�{�B�J�C
        /// </summary>
        public IReadOnlyList<ProcessStepEntity> GetSteps()
        {
            return _processSteps.AsReadOnly();
        }

        /// <summary>
        /// ���J�y�{�B�J�C
        /// </summary>
        public void LoadSteps(IEnumerable<ProcessStepEntity> steps)
        {
            _processSteps = steps?.Select(s => s.Clone()).ToList() ?? new List<ProcessStepEntity>();
            RefreshProcessList();
        }

        /// <summary>
        /// �M���y�{�C
        /// </summary>
        public void ClearSteps()
        {
            _processSteps.Clear();
            RefreshProcessList();
            ClearEditor();
        }

        private void InitializeComponents()
        {
            this.SuspendLayout();

            // �D���ξ��]�� | �k�^
            _mainSplitter = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                SplitterDistance = 100
            };

            // �������ξ��]�u�Ǩӷ� | �y�{�M��^
            _leftSplitter = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                SplitterDistance = 20
            };

            // �����G�u�Ǩӷ�
            var pnlSource = CreateProcessSourcePanel();
            _leftSplitter.Panel1.Controls.Add(pnlSource);

            // �����G�y�{�M��
            var pnlList = CreateProcessListPanel();
            _leftSplitter.Panel2.Controls.Add(pnlList);

            _mainSplitter.Panel1.Controls.Add(_leftSplitter);

            // �k���G�Ѽƽs�边
            var pnlEditor = CreateEditorPanel();
            _mainSplitter.Panel2.Controls.Add(pnlEditor);

            this.Controls.Add(_mainSplitter);

            this.ResumeLayout(false);
        }

        private Panel CreateProcessSourcePanel()
        {
            var panel = new Panel { Dock = DockStyle.Fill };

            var lblTitle = new Label
            {
                Text = "�u�ǦC��",
                Dock = DockStyle.Top,
                Height = 25,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = CommonStyle.TextFontBold,
                BackColor = CommonStyle.BgHeader,
                ForeColor = CommonStyle.FgHeader,
                Padding = new Padding(5, 0, 0, 0)
            };

            _lstProcessSource = new ListBox
            {
                Dock = DockStyle.Fill,
                DisplayMember = "DisplayName"
            };
            _lstProcessSource.DoubleClick += LstProcessSource_DoubleClick;

            panel.Controls.Add(_lstProcessSource);
            panel.Controls.Add(lblTitle);

            return panel;
        }

        private Panel CreateProcessListPanel()
        {
            var panel = new Panel { Dock = DockStyle.Fill };

            var lblTitle = new Label
            {
                Text = "�y�{�M��",
                Dock = DockStyle.Top,
                Height = 25,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = CommonStyle.TextFontBold,
                BackColor = CommonStyle.BgHeader,
                ForeColor = CommonStyle.FgHeader,
                Padding = new Padding(5, 0, 0, 0)
            };

            // ���s���O
            var pnlButtons = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 35,
                FlowDirection = FlowDirection.LeftToRight,
                Padding = new Padding(2)
            };

            _btnAdd = new Button { Text = "�s�W", Width = 60 };
            _btnRemove = new Button { Text = "�R��", Width = 60 };
            _btnMoveUp = new Button { Text = "�W��", Width = 60 };
            _btnMoveDown = new Button { Text = "�U��", Width = 60 };

            _btnAdd.Click += BtnAdd_Click;
            _btnRemove.Click += BtnRemove_Click;
            _btnMoveUp.Click += BtnMoveUp_Click;
            _btnMoveDown.Click += BtnMoveDown_Click;

            pnlButtons.Controls.AddRange(new Control[] { _btnAdd, _btnRemove, _btnMoveUp, _btnMoveDown });

            // DataGridView
            _dgvProcessList = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                ReadOnly = false,
                AutoGenerateColumns = false,
                RowHeadersVisible = false
            };

            _dgvProcessList.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "OrderNo",
                HeaderText = "#",
                DataPropertyName = "OrderNo",
                Width = 40,
                ReadOnly = true
            });

            _dgvProcessList.Columns.Add(new DataGridViewCheckBoxColumn
            {
                Name = "Enabled",
                HeaderText = "�ҥ�",
                DataPropertyName = "Enabled",
                Width = 50
            });

            _dgvProcessList.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ProcessId",
                HeaderText = "�u��",
                DataPropertyName = "ProcessId",
                Width = 100,
                ReadOnly = true
            });

            _dgvProcessList.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Summary",
                HeaderText = "�K�n",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
                ReadOnly = true
            });

            _dgvProcessList.SelectionChanged += DgvProcessList_SelectionChanged;
            _dgvProcessList.CellValueChanged += DgvProcessList_CellValueChanged;
            _dgvProcessList.CurrentCellDirtyStateChanged += DgvProcessList_CurrentCellDirtyStateChanged;

            panel.Controls.Add(_dgvProcessList);
            panel.Controls.Add(pnlButtons);
            panel.Controls.Add(lblTitle);

            return panel;
        }

        private Panel CreateEditorPanel()
        {
            var panel = new Panel { Dock = DockStyle.Fill };

            _lblEditorTitle = new Label
            {
                Text = "�Ѽƽs��",
                Dock = DockStyle.Top,
                Height = 25,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = CommonStyle.TextFontBold,
                BackColor = CommonStyle.BgHeader,
                ForeColor = CommonStyle.FgHeader,
                Padding = new Padding(5, 0, 0, 0)
            };

            _pnlEditorHost = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true
            };

            panel.Controls.Add(_pnlEditorHost);
            panel.Controls.Add(_lblEditorTitle);

            return panel;
        }

        private void LoadProcessSource()
        {
            var descriptors = _registry.GetAll();
            _lstProcessSource.Items.Clear();
            foreach (var desc in descriptors)
            {
                _lstProcessSource.Items.Add(desc);
            }
        }

        private void RefreshProcessList()
        {
            _isLoading = true;
            try
            {
                _dgvProcessList.Rows.Clear();

                foreach (var step in _processSteps)
                {
                    var rowIndex = _dgvProcessList.Rows.Add();
                    var row = _dgvProcessList.Rows[rowIndex];
                    row.Tag = step;
                    row.Cells["OrderNo"].Value = step.OrderNo;
                    row.Cells["Enabled"].Value = step.Enabled;
                    row.Cells["ProcessId"].Value = GetDisplayName(step.ProcessId);
                    row.Cells["Summary"].Value = GetParamSummary(step);
                }

                UpdateButtonStates();
            }
            finally
            {
                _isLoading = false;
            }
        }

        private string GetDisplayName(string processId)
        {
            var desc = _registry.GetById(processId);
            return desc?.DisplayName ?? processId;
        }

        private string GetParamSummary(ProcessStepEntity step)
        {
            // ²����ܡG�I���e 50 �Ӧr��
            if (string.IsNullOrEmpty(step.ParamJson))
                return "";

            var summary = step.ParamJson.Replace("{", "").Replace("}", "").Replace("\"", "");
            return summary.Length > 50 ? summary.Substring(0, 47) + "..." : summary;
        }

        private void RecalculateOrderNo()
        {
            for (int i = 0; i < _processSteps.Count; i++)
            {
                _processSteps[i].OrderNo = i + 1;
            }
        }

        private void UpdateButtonStates()
        {
            var hasSelection = _dgvProcessList.SelectedRows.Count > 0;
            var selectedIndex = hasSelection ? _dgvProcessList.SelectedRows[0].Index : -1;

            _btnRemove.Enabled = hasSelection;
            _btnMoveUp.Enabled = hasSelection && selectedIndex > 0;
            _btnMoveDown.Enabled = hasSelection && selectedIndex < _processSteps.Count - 1;
            _btnAdd.Enabled = _lstProcessSource.SelectedItem != null;
        }

        #region Event Handlers

        private void LstProcessSource_DoubleClick(object sender, EventArgs e)
        {
            AddSelectedProcess();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            AddSelectedProcess();
        }

        private void AddSelectedProcess()
        {
            if (_lstProcessSource.SelectedItem is ProcessDescriptor descriptor)
            {
                var step = new ProcessStepEntity
                {
                    OrderNo = _processSteps.Count + 1,
                    ProcessId = descriptor.ProcessId,
                    ParamJson = descriptor.DefaultParamJson,
                    Enabled = true
                };

                _processSteps.Add(step);
                RefreshProcessList();
                OnFlowChanged();

                // ����s�W������
                _dgvProcessList.ClearSelection();
                _dgvProcessList.Rows[_dgvProcessList.Rows.Count - 1].Selected = true;
            }
        }

        private void BtnRemove_Click(object sender, EventArgs e)
        {
            if (_dgvProcessList.SelectedRows.Count > 0)
            {
                var index = _dgvProcessList.SelectedRows[0].Index;
                _processSteps.RemoveAt(index);
                RecalculateOrderNo();
                RefreshProcessList();
                ClearEditor();
                OnFlowChanged();
            }
        }

        private void BtnMoveUp_Click(object sender, EventArgs e)
        {
            if (_dgvProcessList.SelectedRows.Count > 0)
            {
                var index = _dgvProcessList.SelectedRows[0].Index;
                if (index > 0)
                {
                    var temp = _processSteps[index];
                    _processSteps[index] = _processSteps[index - 1];
                    _processSteps[index - 1] = temp;
                    RecalculateOrderNo();
                    RefreshProcessList();
                    OnFlowChanged();

                    _dgvProcessList.ClearSelection();
                    _dgvProcessList.Rows[index - 1].Selected = true;
                }
            }
        }

        private void BtnMoveDown_Click(object sender, EventArgs e)
        {
            if (_dgvProcessList.SelectedRows.Count > 0)
            {
                var index = _dgvProcessList.SelectedRows[0].Index;
                if (index < _processSteps.Count - 1)
                {
                    var temp = _processSteps[index];
                    _processSteps[index] = _processSteps[index + 1];
                    _processSteps[index + 1] = temp;
                    RecalculateOrderNo();
                    RefreshProcessList();
                    OnFlowChanged();

                    _dgvProcessList.ClearSelection();
                    _dgvProcessList.Rows[index + 1].Selected = true;
                }
            }
        }

        private void DgvProcessList_SelectionChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;

            UpdateButtonStates();

            if (_dgvProcessList.SelectedRows.Count > 0)
            {
                var row = _dgvProcessList.SelectedRows[0];
                _selectedStep = row.Tag as ProcessStepEntity;
                LoadEditor(_selectedStep);
            }
            else
            {
                _selectedStep = null;
                ClearEditor();
            }
        }

        private void DgvProcessList_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            // �ߧY���� CheckBox ���ܧ�
            if (_dgvProcessList.CurrentCell is DataGridViewCheckBoxCell)
            {
                _dgvProcessList.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void DgvProcessList_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (_isLoading || e.RowIndex < 0) return;

            if (_dgvProcessList.Columns[e.ColumnIndex].Name == "Enabled")
            {
                var row = _dgvProcessList.Rows[e.RowIndex];
                var step = row.Tag as ProcessStepEntity;
                if (step != null)
                {
                    step.Enabled = (bool)row.Cells["Enabled"].Value;
                    OnFlowChanged();
                }
            }
        }

        #endregion

        #region Editor Management

        private void LoadEditor(ProcessStepEntity step)
        {
            if (step == null)
            {
                ClearEditor();
                return;
            }

            try
            {
                // �M���ª� Editor
                if (_currentEditor != null)
                {
                    _currentEditor.ParamChanged -= CurrentEditor_ParamChanged;
                    if (_currentEditor is Control ctrl)
                    {
                        _pnlEditorHost.Controls.Remove(ctrl);
                        ctrl.Dispose();
                    }
                }

                // �ϥ� Keyed �ѪR������ Editor
                _currentEditor = _scope.ResolveKeyed<IProcessEditor>(step.ProcessId);

                if (_currentEditor is Control editorControl)
                {
                    editorControl.Dock = DockStyle.Fill;
                    _pnlEditorHost.Controls.Add(editorControl);
                }

                _currentEditor.Load(step.ParamJson);
                _currentEditor.ParamChanged += CurrentEditor_ParamChanged;

                var desc = _registry.GetById(step.ProcessId);
                _lblEditorTitle.Text = $"�Ѽƽs�� - {desc?.DisplayName ?? step.ProcessId}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"���J�s�边����: {ex.Message}", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearEditor()
        {
            if (_currentEditor != null)
            {
                _currentEditor.ParamChanged -= CurrentEditor_ParamChanged;
                if (_currentEditor is Control ctrl)
                {
                    _pnlEditorHost.Controls.Remove(ctrl);
                    ctrl.Dispose();
                }
                _currentEditor = null;
            }

            _lblEditorTitle.Text = "�Ѽƽs��";
            _selectedStep = null;
        }

        private void CurrentEditor_ParamChanged(object sender, EventArgs e)
        {
            if (_selectedStep != null && _currentEditor != null)
            {
                _selectedStep.ParamJson = _currentEditor.Save();

                // ��s�K�n���
                foreach (DataGridViewRow row in _dgvProcessList.Rows)
                {
                    if (row.Tag == _selectedStep)
                    {
                        row.Cells["Summary"].Value = GetParamSummary(_selectedStep);
                        break;
                    }
                }

                OnFlowChanged();
            }
        }

        #endregion

        protected virtual void OnFlowChanged()
        {
            FlowChanged?.Invoke(this, EventArgs.Empty);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                ClearEditor();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // ProcessFlowEditorView
            // 
            this.Font = new System.Drawing.Font("�L�n������", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Name = "ProcessFlowEditorView";
            this.ResumeLayout(false);

        }
    }
}
