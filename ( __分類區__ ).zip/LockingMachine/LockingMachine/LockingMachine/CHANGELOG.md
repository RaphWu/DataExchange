﻿# Calin.LockingMachine

# V0.0.1 - Initial release
