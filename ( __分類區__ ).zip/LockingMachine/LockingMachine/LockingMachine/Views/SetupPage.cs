﻿using Calin.Framework.Navigation;
using Calin.LockingMachine.Models;
using Calin.LockingMachine.Services;
using RJCP.IO.Ports;

namespace Calin.LockingMachine.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class SetupPage : UserControl, INavigationAware
    {
        #region Fields

        private readonly IDevice _device;
        private readonly DeviceData _deviceData;

        #endregion Fields

        #region INavigationAware

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            DL_RS1A_Load();
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        public bool OnNavigatingFrom(INavigationParameters parameters)
        {
            return true;
        }

        #endregion INavigationAware

        #region ctor

        public SetupPage(
            IDevice device,
            DeviceData deviceHandle)
        {
            _device = device;
            _deviceData = deviceHandle;

            InitializeComponent();

            CbDlrs1aBaudRate.Items.AddRange(new string[] { "2400", "4800", "9600", "19200", "38400", "57600", "115200" });
            CbDlrs1aDataBits.Items.AddRange(new string[] { "5", "6", "7", "8" });
            CbDlrs1aParity.Items.AddRange(new string[] { Parity.None.ToString(), Parity.Odd.ToString(), Parity.Even.ToString(), Parity.Mark.ToString(), Parity.Space.ToString() });
            CbDlrs1aStopBits.Items.AddRange(new string[] { StopBits.One.ToString(), StopBits.One5.ToString(), StopBits.Two.ToString() });

            DL_RS1A_Load();
        }

        #endregion ctor

        #region Displacement

        private void DL_RS1A_Load()
        {
            var dev = _deviceData.dl_RS1A;
            CbDlrs1aCom.Items.Clear();
            if (dev != null && dev.IsConnected)
            {
                CbDlrs1aCom.Items.AddRange(_deviceData.comPortList.ToArray());

                CbDlrs1aCom.Text = _deviceData.dl_RS1A_Config.PortName;
                CbDlrs1aBaudRate.Text = _deviceData.dl_RS1A_Config.BaudRate.ToString();
                CbDlrs1aDataBits.Text = _deviceData.dl_RS1A_Config.DataBits.ToString();
                CbDlrs1aParity.Text = _deviceData.dl_RS1A_Config.Parity.ToString();
                CbDlrs1aStopBits.Text = _deviceData.dl_RS1A_Config.StopBits.ToString();
            }
        }

        private void CbDlrs1aCom_SelectedIndexChanged(object sender, EventArgs e)
        {
            _deviceData.dl_RS1A_Config.PortName = CbDlrs1aCom.Text;
            _device.DL_RS1A_SaveConfig();
        }

        private void CbDlrs1aBaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            _deviceData.dl_RS1A_Config.BaudRate = int.Parse(CbDlrs1aBaudRate.Text);
            _device.DL_RS1A_SaveConfig();
        }

        private void CbDlrs1aParity_SelectedIndexChanged(object sender, EventArgs e)
        {
            _deviceData.dl_RS1A_Config.Parity = (Parity)Enum.Parse(typeof(Parity), CbDlrs1aParity.Text);
            _device.DL_RS1A_SaveConfig();
        }

        private void CbDlrs1aDataBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            _deviceData.dl_RS1A_Config.DataBits = int.Parse(CbDlrs1aDataBits.Text);
            _device.DL_RS1A_SaveConfig();
        }

        private void CbDlrs1aStopBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            _deviceData.dl_RS1A_Config.StopBits = (StopBits)Enum.Parse(typeof(StopBits), CbDlrs1aStopBits.Text);
            _device.DL_RS1A_SaveConfig();
        }

        private void BtnDlrs1aReconnect_Click(object sender, EventArgs e)
        {
            _device.DL_RS1A_Close();
            _device.DL_RS1A_Init();
        }

        private void BtnUpdatePortNames_Click(object sender, EventArgs e)
        {
            _device.UpdateComPortList();

            var com = CbDlrs1aCom.Text;
            if (_deviceData.comPortList.Count > 0)
            {
                CbDlrs1aCom.Items.Clear();
                CbDlrs1aCom.Items.AddRange(_deviceData.comPortList.ToArray());
            }

            if (_deviceData.comPortList.Contains(com))
                CbDlrs1aCom.Text = com;
        }

        #endregion Displacement
    }
}
