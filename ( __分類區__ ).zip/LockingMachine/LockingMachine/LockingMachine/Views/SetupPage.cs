﻿using Calin.Comm.DL_RS1A;
using Calin.LockingMachine.Models;
using Calin.LockingMachine.Services;
using Calin.Navigation;
using Calin.SerialPort;

namespace Calin.LockingMachine.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class SetupPage : UserControl, INavigationAware
    {
        #region Fields

        private readonly ILockingMachine _lockingMachine;
        //private readonly IDL_RS1A _dlrs1a;
        private readonly LmData _lmData;
        private readonly Dlrs1aData _dlrs1aData;

        #endregion Fields

        #region INavigationAware

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            //Dlrs1aLoad();
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        public bool OnNavigatingFrom(INavigationParameters parameters)
        {
            return true;
        }

        #endregion INavigationAware

        #region ctor

        public SetupPage(
            ILockingMachine device,
            //IDL_RS1A dL_RS1A,
            LmData lmData,
            Dlrs1aData dlrs1AData)
        {
            _lockingMachine = device;
            //_dlrs1a = dL_RS1A;
            _lmData = lmData;
            _dlrs1aData = dlrs1AData;

            InitializeComponent();

            //CbDlrs1aBaudRate.Items.AddRange(_dispData.heightDispConfig.BaudRateList.Select(x => x.ToString()).ToArray());
            //CbDlrs1aDataBits.Items.AddRange(_dispData.heightDispConfig.DataBitsList.Select(x => x.ToString()).ToArray());
            CbHeightDispBaudRate.Items.AddRange([4800, 9600, 19200, 38400, 57600, 115200]);
            CbHeightDispDataBits.Items.AddRange([5, 6, 7, 8, 9]);
            CbHeightDispParity.Items.AddRange(Enum.GetNames(typeof(Parity)));
            CbHeightDispStopBits.Items.AddRange(Enum.GetNames(typeof(StopBits)));

            Dlrs1aLoad();
        }

        #endregion ctor

        #region Height Displacement

        private void Dlrs1aLoad()
        {
            var dev = _lmData.dlrs1a;
            CbHeightDispCom.Items.Clear();
            if (dev != null && dev.IsConnected)
            {
                CbHeightDispCom.Items.AddRange(_lmData.comPortList.ToArray());

                CbHeightDispCom.Text = _dlrs1aData.dlrs1aConfig.PortName;
                CbHeightDispBaudRate.Text = _dlrs1aData.dlrs1aConfig.BaudRate.ToString();
                CbHeightDispDataBits.Text = _dlrs1aData.dlrs1aConfig.DataBits.ToString();
                CbHeightDispParity.Text = _dlrs1aData.dlrs1aConfig.Parity.ToString();
                CbHeightDispStopBits.Text = _dlrs1aData.dlrs1aConfig.StopBits.ToString();
            }
        }

        private void CbHeightDispCom_SelectedIndexChanged(object sender, EventArgs e)
        {
            _dlrs1aData.dlrs1aConfig.PortName = CbHeightDispCom.Text;
            _lockingMachine.Dlrs1aSaveConfig(_dlrs1aData.dlrs1aConfig);
        }

        private void CbHeightDispBaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            _dlrs1aData.dlrs1aConfig.BaudRate = int.Parse(CbHeightDispBaudRate.Text);
            _lockingMachine.Dlrs1aSaveConfig(_dlrs1aData.dlrs1aConfig);
        }

        private void CbHeightDispParity_SelectedIndexChanged(object sender, EventArgs e)
        {
            _dlrs1aData.dlrs1aConfig.Parity = (Parity)Enum.Parse(typeof(Parity), CbHeightDispParity.Text);
            _lockingMachine.Dlrs1aSaveConfig(_dlrs1aData.dlrs1aConfig);
        }

        private void CbHeightDispDataBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            _dlrs1aData.dlrs1aConfig.DataBits = int.Parse(CbHeightDispDataBits.Text);
            _lockingMachine.Dlrs1aSaveConfig(_dlrs1aData.dlrs1aConfig);
        }

        private void CbHeightDispStopBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            _dlrs1aData.dlrs1aConfig.StopBits = (StopBits)Enum.Parse(typeof(StopBits), CbHeightDispStopBits.Text);
            _lockingMachine.Dlrs1aSaveConfig(_dlrs1aData.dlrs1aConfig);
        }

        private void BtnHeightDispReconnect_Click(object sender, EventArgs e)
        {
            _lockingMachine.Dlrs1aClose();
            _lockingMachine.Dlrs1aInit();
        }

        private void BtnUpdatePortNames_Click(object sender, EventArgs e)
        {
            _lockingMachine.UpdateComPortList();

            var com = CbHeightDispCom.Text;
            if (_lmData.comPortList.Count > 0)
            {
                CbHeightDispCom.Items.Clear();
                CbHeightDispCom.Items.AddRange(_lmData.comPortList.ToArray());
            }

            if (_lmData.comPortList.Contains(com))
                CbHeightDispCom.Text = com;
        }

        #endregion Height Displacement

        #region 尋邊

        private void CbGateMarkCylinder_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        #endregion 尋邊

        private void button1_Click(object sender, EventArgs e)
        {
            var gm = cbGateMarkCylinder.SelectedIndex;
            _lmData.dio.WriteDigital(0, (byte)(1 << gm));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            _lmData.dio.WriteDigital(0, 0);
        }
    }
}
