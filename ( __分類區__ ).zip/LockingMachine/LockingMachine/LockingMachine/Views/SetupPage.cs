﻿using Calin.Framework.Navigation;
using Calin.LockingMachine.Models;
using Calin.LockingMachine.Services;
using RJCP.IO.Ports;

namespace Calin.LockingMachine.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class SetupPage : UserControl, INavigationAware
    {
        #region Fields

        private readonly ILockingMachine _lockingMachine;
        private readonly DeviceData _deviceData;
        private readonly Dlrs1aData _dlrs1aData;

        #endregion Fields

        #region INavigationAware

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            //Dlrs1aLoad();
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        public bool OnNavigatingFrom(INavigationParameters parameters)
        {
            return true;
        }

        #endregion INavigationAware

        #region ctor

        public SetupPage(
            ILockingMachine device,
            DeviceData deviceData,
            Dlrs1aData dlrs1AData)
        {
            _lockingMachine = device;
            _deviceData = deviceData;
            _dlrs1aData = dlrs1AData;

            InitializeComponent();

            //CbDlrs1aBaudRate.Items.AddRange(_dispData.heightDispConfig.BaudRateList.Select(x => x.ToString()).ToArray());
            //CbDlrs1aDataBits.Items.AddRange(_dispData.heightDispConfig.DataBitsList.Select(x => x.ToString()).ToArray());
            CbHeightDispBaudRate.Items.AddRange([4800, 9600, 19200, 38400, 57600, 115200]);
            CbHeightDispDataBits.Items.AddRange([5, 6, 7, 8, 9]);
            CbHeightDispParity.Items.AddRange(Enum.GetNames(typeof(Parity)));
            CbHeightDispStopBits.Items.AddRange(Enum.GetNames(typeof(StopBits)));

            Dlrs1aLoad();
        }

        #endregion ctor

        #region Height Displacement

        private void Dlrs1aLoad()
        {
            var dev = _dlrs1aData.dlrs1a;
            CbHeightDispCom.Items.Clear();
            if (dev != null && dev.IsConnected)
            {
                CbHeightDispCom.Items.AddRange(_deviceData.comPortList.ToArray());

                CbHeightDispCom.Text = _dlrs1aData.dlrs1aConfig.PortName;
                CbHeightDispBaudRate.Text = _dlrs1aData.dlrs1aConfig.BaudRate.ToString();
                CbHeightDispDataBits.Text = _dlrs1aData.dlrs1aConfig.DataBits.ToString();
                CbHeightDispParity.Text = _dlrs1aData.dlrs1aConfig.Parity.ToString();
                CbHeightDispStopBits.Text = _dlrs1aData.dlrs1aConfig.StopBits.ToString();
            }
        }

        private void CbHeightDispCom_SelectedIndexChanged(object sender, EventArgs e)
        {
            _dlrs1aData.dlrs1aConfig.PortName = CbHeightDispCom.Text;
            _lockingMachine.Dlrs1aSaveConfig(_dlrs1aData.dlrs1aConfig);
        }

        private void CbHeightDispBaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            _dlrs1aData.dlrs1aConfig.BaudRate = int.Parse(CbHeightDispBaudRate.Text);
            _lockingMachine.Dlrs1aSaveConfig(_dlrs1aData.dlrs1aConfig);
        }

        private void CbHeightDispParity_SelectedIndexChanged(object sender, EventArgs e)
        {
            _dlrs1aData.dlrs1aConfig.Parity = (Parity)Enum.Parse(typeof(Parity), CbHeightDispParity.Text);
            _lockingMachine.Dlrs1aSaveConfig(_dlrs1aData.dlrs1aConfig);
        }

        private void CbHeightDispDataBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            _dlrs1aData.dlrs1aConfig.DataBits = int.Parse(CbHeightDispDataBits.Text);
            _lockingMachine.Dlrs1aSaveConfig(_dlrs1aData.dlrs1aConfig);
        }

        private void CbHeightDispStopBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            _dlrs1aData.dlrs1aConfig.StopBits = (StopBits)Enum.Parse(typeof(StopBits), CbHeightDispStopBits.Text);
            _lockingMachine.Dlrs1aSaveConfig(_dlrs1aData.dlrs1aConfig);
        }

        private void BtnHeightDispReconnect_Click(object sender, EventArgs e)
        {
            _lockingMachine.Dlrs1aClose();
            _lockingMachine.Dlrs1aInit(_dlrs1aData.dlrs1aConfig);
        }

        private void BtnUpdatePortNames_Click(object sender, EventArgs e)
        {
            _lockingMachine.UpdateComPortList();

            var com = CbHeightDispCom.Text;
            if (_deviceData.comPortList.Count > 0)
            {
                CbHeightDispCom.Items.Clear();
                CbHeightDispCom.Items.AddRange(_deviceData.comPortList.ToArray());
            }

            if (_deviceData.comPortList.Contains(com))
                CbHeightDispCom.Text = com;
        }

        #endregion Height Displacement
    }
}
