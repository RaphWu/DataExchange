﻿namespace Calin.LockingMachine.Views
{
    partial class Monitor
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.DI0 = new System.Windows.Forms.PictureBox();
            this.DI1 = new System.Windows.Forms.PictureBox();
            this.DI3 = new System.Windows.Forms.PictureBox();
            this.DI2 = new System.Windows.Forms.PictureBox();
            this.DI7 = new System.Windows.Forms.PictureBox();
            this.DI6 = new System.Windows.Forms.PictureBox();
            this.DI5 = new System.Windows.Forms.PictureBox();
            this.DI4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.DI0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI4)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(516, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "DI0";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(516, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 21);
            this.label3.TabIndex = 3;
            this.label3.Text = "DI1";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(516, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 21);
            this.label5.TabIndex = 5;
            this.label5.Text = "DI2";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(516, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 21);
            this.label7.TabIndex = 11;
            this.label7.Text = "DI5";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(516, 157);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 21);
            this.label9.TabIndex = 9;
            this.label9.Text = "DI4";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(516, 135);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 21);
            this.label11.TabIndex = 7;
            this.label11.Text = "DI3";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(516, 223);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(42, 21);
            this.label13.TabIndex = 15;
            this.label13.Text = "DI7";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(516, 201);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 21);
            this.label15.TabIndex = 13;
            this.label15.Text = "DI6";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // DI0
            // 
            this.DI0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DI0.Location = new System.Drawing.Point(493, 69);
            this.DI0.Name = "DI0";
            this.DI0.Size = new System.Drawing.Size(21, 21);
            this.DI0.TabIndex = 16;
            this.DI0.TabStop = false;
            // 
            // DI1
            // 
            this.DI1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DI1.Location = new System.Drawing.Point(493, 91);
            this.DI1.Name = "DI1";
            this.DI1.Size = new System.Drawing.Size(21, 21);
            this.DI1.TabIndex = 17;
            this.DI1.TabStop = false;
            // 
            // DI3
            // 
            this.DI3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DI3.Location = new System.Drawing.Point(493, 135);
            this.DI3.Name = "DI3";
            this.DI3.Size = new System.Drawing.Size(21, 21);
            this.DI3.TabIndex = 19;
            this.DI3.TabStop = false;
            // 
            // DI2
            // 
            this.DI2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DI2.Location = new System.Drawing.Point(493, 113);
            this.DI2.Name = "DI2";
            this.DI2.Size = new System.Drawing.Size(21, 21);
            this.DI2.TabIndex = 18;
            this.DI2.TabStop = false;
            // 
            // DI7
            // 
            this.DI7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DI7.Location = new System.Drawing.Point(493, 223);
            this.DI7.Name = "DI7";
            this.DI7.Size = new System.Drawing.Size(21, 21);
            this.DI7.TabIndex = 23;
            this.DI7.TabStop = false;
            // 
            // DI6
            // 
            this.DI6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DI6.Location = new System.Drawing.Point(493, 201);
            this.DI6.Name = "DI6";
            this.DI6.Size = new System.Drawing.Size(21, 21);
            this.DI6.TabIndex = 22;
            this.DI6.TabStop = false;
            // 
            // DI5
            // 
            this.DI5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DI5.Location = new System.Drawing.Point(493, 179);
            this.DI5.Name = "DI5";
            this.DI5.Size = new System.Drawing.Size(21, 21);
            this.DI5.TabIndex = 21;
            this.DI5.TabStop = false;
            // 
            // DI4
            // 
            this.DI4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DI4.Location = new System.Drawing.Point(493, 157);
            this.DI4.Name = "DI4";
            this.DI4.Size = new System.Drawing.Size(21, 21);
            this.DI4.TabIndex = 20;
            this.DI4.TabStop = false;
            // 
            // Monitor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.DI7);
            this.Controls.Add(this.DI6);
            this.Controls.Add(this.DI5);
            this.Controls.Add(this.DI4);
            this.Controls.Add(this.DI3);
            this.Controls.Add(this.DI2);
            this.Controls.Add(this.DI1);
            this.Controls.Add(this.DI0);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Monitor";
            this.Size = new System.Drawing.Size(1000, 660);
            ((System.ComponentModel.ISupportInitialize)(this.DI0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DI4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Label label2;
        private Label label3;
        private Label label5;
        private Label label7;
        private Label label9;
        private Label label11;
        private Label label13;
        private Label label15;
        private PictureBox DI0;
        private PictureBox DI1;
        private PictureBox DI3;
        private PictureBox DI2;
        private PictureBox DI7;
        private PictureBox DI6;
        private PictureBox DI5;
        private PictureBox DI4;
    }
}
