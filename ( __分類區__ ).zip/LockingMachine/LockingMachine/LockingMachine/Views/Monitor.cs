﻿namespace Calin.LockingMachine.Views
{
    public partial class Monitor : UserControl
    {
        public Monitor()
        {
            InitializeComponent();
        }
    }
}
