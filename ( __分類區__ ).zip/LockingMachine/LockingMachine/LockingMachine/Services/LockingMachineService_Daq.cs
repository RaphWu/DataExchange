﻿using Calin.Helper;
using Calin.LockingMachine.Models;

namespace Calin.LockingMachine.Services
{
    public partial class LockingMachineService : ILockingMachine_DAQ
    {
        #region Fields

        private readonly string _daqFile = "DAQ.json";

        #endregion Fields

        /// <inheritdoc/>
        public void DaqInit()
        {
            try
            {
                _bindingData.TorqueMeterActive = _lmData.dio.Usb4704DioInit(_daqData.deviceCode);
            }
            catch (Exception ex)
            {
                _bindingData.TorqueMeterActive = false;
            }
        }

        /// <inheritdoc/>
        public void DaqClose()
        {
            _lmData.dio.Dispose();
            _bindingData.TorqueMeterActive = false;
        }

        /// <inheritdoc/>
        public void DaqSaveConfig(DaqData config)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _daqFile);
            JsonFileHelper.Save(path, _daqData);
        }

        /// <inheritdoc/>
        public void DaqLoadConfig()
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _daqFile);
            if (File.Exists(path))
            {
                var dd = JsonFileHelper.Read<DaqData>(path);
                _daqData.deviceCode = dd.deviceCode;
                _daqData.torqueLimitH = dd.torqueLimitH;
                _daqData.torqueLimitL = dd.torqueLimitL;
                _daqData.GetMarkPort = dd.GetMarkPort;
            }

            DaqSaveConfig(_daqData);
        }
    }
}
