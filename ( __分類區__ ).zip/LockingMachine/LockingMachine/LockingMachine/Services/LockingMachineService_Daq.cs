﻿namespace Calin.LockingMachine.Services
{
    public partial class LockingMachineService
    {
    }
}
