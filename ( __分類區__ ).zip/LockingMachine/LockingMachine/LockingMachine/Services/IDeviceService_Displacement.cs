﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calin.Comm.DL_RS1A;
using Calin.LockingMachine.Models;
using Newtonsoft.Json;

namespace Calin.LockingMachine.Services
{
    /// <summary>
    /// 設備服務 - 位移計介面
    /// </summary>
    public interface IDeviceService_Displacement
    {
        #region DL_RS1A

        /// <summary>
        /// 儲存 DL_RS1A 配置。
        /// </summary>
        void DL_RS1A_SaveConfig();

        /// <summary>
        /// 載入 DL_RS1A 配置。
        /// </summary>
        /// <returns></returns>
        void DL_RS1A_LoadConfig();

        /// <summary>
        /// 初始化 DL_RS1A 位移計。
        /// </summary>
        void DL_RS1A_Init();

        /// <summary>
        /// 關閉 DL_RS1A 位移計。
        /// </summary>
        void DL_RS1A_Close();
    }

    #endregion DL_RS1A
}
