﻿using System;
using System.Diagnostics;
using Calin.MotionControl.Advantech.Contracts;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace Calin.LockingMachine.Services
{
    public partial class LockingMachineService
    {
        #region Fields

        private Thread _monitoringThread;
        private CancellationTokenSource _pollingCts;

        #endregion Fields

        #region Methods

        /// <inheritdoc/>
        public void PollingStop()
        {
            _pollingCts?.Cancel();
        }

        /// <inheritdoc/>
        public void PollingStart()
        {
            _pollingCts = new CancellationTokenSource();

            _monitoringThread = new Thread(() => MonitoringProc(_pollingCts.Token));
            _monitoringThread.IsBackground = true;
            _monitoringThread.Priority = ThreadPriority.Highest;
            _monitoringThread.Start();
        }

        #endregion Methods

        #region Polling Procedures

        private void MonitoringProc(CancellationToken token)
        {
            var sw = Stopwatch.StartNew();
            long ticksPerMs = Stopwatch.Frequency / 1000;
            long nextTick = sw.ElapsedTicks;
            var spin = new SpinWait();

            bool dispActive = false;
            bool torqueActive = false;
            int slowLoopCounter = 0;

            while (!token.IsCancellationRequested)
            {
                // 每 10,000 次迴圈檢查一次裝置狀態
                if (slowLoopCounter++ % 10000 == 0)
                {
                    dispActive = _dispData.dlrs1a != null;
                    torqueActive = false;
                }

                long now = sw.ElapsedTicks;
                if (now >= nextTick)
                {
                    nextTick += ticksPerMs;
                    spin.Reset();

                    if (dispActive)
                        _dispData.dlrs1a.ReadAll();

                    // 用於須快速反應的停止條件
                    //if (torque >= TorqueLimit)
                    //{
                    //    EmergencyStop();
                    //}
                }
                else
                {
                    spin.SpinOnce();
                }
            }
        }

        #endregion Polling Procedures
    }
}
