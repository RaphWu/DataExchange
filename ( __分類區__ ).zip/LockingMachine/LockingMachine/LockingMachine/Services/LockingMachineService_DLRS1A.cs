﻿using Autofac;
using Calin.Comm.DL_RS1A;
using Calin.Helper;
using Calin.LockingMachine.Models;
using Calin.SerialPort;
using Newtonsoft.Json;

namespace Calin.LockingMachine.Services
{
    // 高度計
    public partial class LockingMachineService : ILockingMachine_Dlrs1a
    {
        #region Fields

        private readonly string _heightDisplacementFile = "HeightDisplacement.json";

        #endregion Fields

        /// <inheritdoc/>
        public void Dlrs1aInit()
        {
            if (_lmData.dlrs1a != null)
                _lmData.dlrs1a.ResponseReceived -= Dlrs1aReceived;

            _bindingData.HeightDisplacementValue = 0.0;

            if (_dispData.dlrs1aConfig == null)
                _dispData.dlrs1aConfig = Dlrs1aLoadConfig();

            var fac = _scope.Resolve<IDL_RS1A_ServiceFactory>();
            {
                _lmData.dlrs1a = fac.CreateAndOpen(_dispData.dlrs1aConfig);
                if (_lmData.dlrs1a != null && _lmData.dlrs1a.IsTransmissionVerified)
                {
                    _lmData.comPortList = _lmData.dlrs1a.GetAvailablePorts();
                    _lmData.dlrs1a.ResponseReceived += Dlrs1aReceived;
                    _bindingData.HeightDisplacementActive = true;
                }
            }
        }

        /// <inheritdoc/>
        public void Dlrs1aClose()
        {
            if (_lmData.dlrs1a != null)
            {
                _lmData.dlrs1a.ResponseReceived -= Dlrs1aReceived;
                _lmData.dlrs1a.Close();
                _lmData.dlrs1a.Dispose();
                _lmData.dlrs1a = null;
            }
            _bindingData.HeightDisplacementActive = false;
        }

        /// <inheritdoc/>
        public void Dlrs1aSaveConfig(DL_RS1A_Config config)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _heightDisplacementFile);
            JsonFileHelper.Save(path, _dispData.dlrs1aConfig);
        }

        /// <inheritdoc/>
        public DL_RS1A_Config Dlrs1aLoadConfig()
        {
            DL_RS1A_Config config = null;

            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _heightDisplacementFile);
            if (File.Exists(path))
            {
                config = JsonFileHelper.Read<DL_RS1A_Config>(path);
                config.SensorType = KeyenceSensorType.GT2;
                config.IdNumber = 1;
            }

            if (config == null && _lmData.comPortList.Count > 0)
            {
                config = new DL_RS1A_Config
                {
                    SensorType = KeyenceSensorType.GT2,
                    IdNumber = 1,
                    PortName = _lmData.comPortList.First(),
                    BaudRate = 38400,
                    DataBits = 8,
                    Parity = Parity.None,
                    StopBits = StopBits.One,
                };
                Dlrs1aSaveConfig(config);
            }

            return config;
        }

        /// <summary>
        /// 高度計回應接收事件處理程式。
        /// </summary>
        private void Dlrs1aReceived(object sender, DL_RS1A_ResponseEventArgs e)
        {
            if (e.Response.IsSuccess)
            {
                _bindingData.HeightDisplacementValue = e.Response.Values[0];
                if (!_bindingData.HeightDisplacementActive)
                    _bindingData.HeightDisplacementActive = true;
            }
        }
    }
}
