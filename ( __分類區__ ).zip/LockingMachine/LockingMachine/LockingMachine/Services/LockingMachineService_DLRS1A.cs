﻿using Autofac;
using Calin.Comm.DL_RS1A;
using Calin.LockingMachine.Models;
using Newtonsoft.Json;

namespace Calin.LockingMachine.Services
{
    // 高度計
    public partial class LockingMachineService : ILockingMachine_Dlrs1a
    {
        #region Fields

        private readonly string _heightDisplacementFile = "HeightDisplacement.json";

        #endregion Fields

        /// <inheritdoc/>
        public void Dlrs1aInit(DL_RS1A_Config config)
        {
            if (_dispData.dlrs1a != null)
                _dispData.dlrs1a.ResponseReceived -= Dlrs1aReceived;

            _mainFormData.HeightDisplacementValue = 0.0;

            if (config == null)
                config = _dispData.dlrs1aConfig;

            var fac = _scope.Resolve<IDL_RS1A_ServiceFactory>();
            {
                _dispData.dlrs1a = fac.CreateAndOpen(config);
                if (_dispData.dlrs1a != null && _dispData.dlrs1a.IsTransmissionVerified)
                {
                    _dispData.dlrs1a.ResponseReceived += Dlrs1aReceived;
                    _mainFormData.HeightDisplacementActive = true;
                }
            }
        }

        /// <inheritdoc/>
        public void Dlrs1aClose()
        {
            if (_dispData.dlrs1a != null)
            {
                _dispData.dlrs1a.ResponseReceived -= Dlrs1aReceived;
                _dispData.dlrs1a.Close();
                _dispData.dlrs1a.Dispose();
                _dispData.dlrs1a = null;
            }
            _mainFormData.HeightDisplacementActive = false;
        }

        /// <inheritdoc/>
        public void Dlrs1aSaveConfig(DL_RS1A_Config config)
        {
            string json = JsonConvert.SerializeObject(_dispData.dlrs1aConfig, Formatting.Indented);
            File.WriteAllText(_heightDisplacementFile, json);
        }

        /// <inheritdoc/>
        public DL_RS1A_Config Dlrs1aLoadConfig()
        {
            DL_RS1A_Config config = null;

            if (File.Exists(_heightDisplacementFile))
            {
                string json = File.ReadAllText(_heightDisplacementFile);
                config = JsonConvert.DeserializeObject<DL_RS1A_Config>(json);
                config.SensorType = KeyenceSensorType.GT2;
                config.IdNumber = 1;
            }

            if (config == null && _deviceData.comPortList.Count > 0)
            {
                config = new DL_RS1A_Config
                {
                    SensorType = KeyenceSensorType.GT2,
                    IdNumber = 1,
                    PortName = _deviceData.comPortList.First(),
                    BaudRate = 38400,
                    DataBits = 8,
                    Parity = RJCP.IO.Ports.Parity.None,
                    StopBits = RJCP.IO.Ports.StopBits.One,
                };
                Dlrs1aSaveConfig(config);
            }

            return config;
        }

        /// <summary>
        /// 高度計回應接收事件處理程式。
        /// </summary>
        private void Dlrs1aReceived(object sender, DL_RS1A_ResponseEventArgs e)
        {
            if (e.Response.IsSuccess)
            {
                _dispData.heightDisplacementValue = e.Response.Values[0];
                if (!_mainFormData.HeightDisplacementActive)
                    _mainFormData.HeightDisplacementActive = true;
            }
        }
    }
}
