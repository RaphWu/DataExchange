﻿using Autofac;
using Calin.LockingMachine.Models;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Services;
using System;

namespace Calin.LockingMachine.Services
{
    /// <summary>
    /// 鎖付機服務。
    /// </summary>
    public partial class LockingMachineService : ILockingMachine, IDisposable
    {
        #region Fields

        private readonly ILifetimeScope _scope;
        private readonly IAcm _acm;
        private readonly MainFormData _mainFormData;
        private readonly DeviceData _deviceData;
        private readonly Dlrs1aData _dispData;
        private readonly DaqData _daqData;
        private readonly System.Timers.Timer _uiTimer;

        private bool _disposedValue = false;

        #endregion Fields

        #region ctor

        public LockingMachineService(
            ILifetimeScope lifetimeScope,
            IAcm acm,
            MainFormData mainFormData,
            DeviceData deviceData,
            Dlrs1aData dispData,
            DaqData daqData)
        {
            _scope = lifetimeScope;
            _acm = acm;
            _mainFormData = mainFormData;
            _deviceData = deviceData;
            _dispData = dispData;
            _daqData = daqData;

            // 更新可用的 COM 埠列表
            UpdateComPortList();

            // 高度計
            _dispData.dlrs1aConfig = Dlrs1aLoadConfig();
            Dlrs1aInit(_dispData.dlrs1aConfig);

            // 扭力計

            // 初始化設備計時器
            _uiTimer = new System.Timers.Timer();
            _uiTimer.Interval = 25;
            _uiTimer.Elapsed += UiTimer_Tick;
            _uiTimer.Start();

            PollingStart();

            // 訂閱 Advantech ACM 狀態更新事件
            _acm.AcmStatusUpdated += AcmStatusUpdated;
        }

        #endregion ctor

        #region Methods

        /// <inheritdoc/>
        public void UpdateComPortList()
        {
            using (var serialPortStream = new RJCP.IO.Ports.SerialPortStream())
            {
                _deviceData.comPortList = serialPortStream.GetPortNames().ToList();
            }
        }

        #endregion Methods

        #region Events

        private void UiTimer_Tick(object sender, EventArgs e)
        {
            if (_mainFormData.HeightDisplacementActive)
                _mainFormData.HeightDisplacementValue = _dispData.heightDisplacementValue;
        }

        private void AcmStatusUpdated(object sender, AcmStatusUpdatedEventArgs e)
        {
        }

        #endregion Events

        #region IDisposable Members

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    // 釋放受控資源
                    _uiTimer?.Dispose();
                    _scope?.Dispose();

                    // 解除事件訂閱
                    if (_acm != null)
                        _acm.AcmStatusUpdated -= AcmStatusUpdated;
                }

                // 釋放非受控資源（如果有）

                // TODO: 釋出非受控資源 (非受控物件) 並覆寫完成項
                // TODO: 將大型欄位設為 Null

                _disposedValue = true;
            }
        }

        // // TODO: 僅有當 'Dispose(bool disposing)' 具有會釋出非受控資源的程式碼時，才覆寫完成項
        // ~LockingMachineService()
        // {
        //     // 請勿變更此程式碼。請將清除程式碼放入 'Dispose(bool disposing)' 方法
        //     Dispose(disposing: false);
        // }

        public void Dispose()
        {
            // 請勿變更此程式碼。請將清除程式碼放入 'Dispose(bool disposing)' 方法
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        #endregion IDisposable Members
    }
}
