﻿namespace Calin.LockingMachine.Services
{
    public interface ILockingMachine : ILockingMachine_Dlrs1a
    {
        /// <summary>
        /// 取得系統可用的 COM 埠清單。
        /// </summary>
        void UpdateComPortList();
    }
}
