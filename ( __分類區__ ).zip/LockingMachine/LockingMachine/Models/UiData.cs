﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.LockingMachine.Models
{
    public class UiData : ObservableObject
    {
        // Z軸
        /// <summary>
        /// 
        /// </summary>
        public double ZAxisCoor
        {
            get { return _zAxisCoor; }
            set { SetProperty(ref _zAxisCoor, value); }
        }
        private double _zAxisCoor;


        // R軸
        // 轉速
        /// <summary>
        /// 
        /// </summary>
        public double RPM
        {
            get { return _rpm; }
            set { SetProperty(ref _rpm, value); }
        }
        private double _rpm;

        // 角度
        /// <summary>
        /// 
        /// </summary>
        public double Angle
        {
            get { return _angle; }
            set { SetProperty(ref _angle, value); }
        }
        private double _angle;

        // 扭力
        /// <summary>
        /// 扭力。
        /// </summary>
        public double Torque
        {
            get { return _torque; }
            set { SetProperty(ref _torque, value); }
        }
        private double _torque;

        // 高度
        /// <summary>
        /// 
        /// </summary>
        public double Height
        {
            get { return _height; }
            set { SetProperty(ref _height, value); }
        }
        private double _height;

    }
}
