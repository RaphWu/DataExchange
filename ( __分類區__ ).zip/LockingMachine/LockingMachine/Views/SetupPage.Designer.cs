﻿namespace Calin.LockingMachine.Views
{
    partial class SetupPage
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.VelSetupPanel = new System.Windows.Forms.GroupBox();
            this.NumVelL = new System.Windows.Forms.NumericUpDown();
            this.NumVelH = new System.Windows.Forms.NumericUpDown();
            this.NumAcc = new System.Windows.Forms.NumericUpDown();
            this.NumDec = new System.Windows.Forms.NumericUpDown();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.RbTCurver = new System.Windows.Forms.RadioButton();
            this.RbSCurver = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox_SerialPort = new System.Windows.Forms.GroupBox();
            this.cbDataBits = new System.Windows.Forms.ComboBox();
            this.btnUpdatePortNames = new System.Windows.Forms.Button();
            this.label_StopBits = new System.Windows.Forms.Label();
            this.cbStopBits = new System.Windows.Forms.ComboBox();
            this.label_DataBits = new System.Windows.Forms.Label();
            this.label_Parity = new System.Windows.Forms.Label();
            this.cbParity = new System.Windows.Forms.ComboBox();
            this.label_BaudRate = new System.Windows.Forms.Label();
            this.cbBaudRate = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cbCom = new System.Windows.Forms.ComboBox();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.VelSetupPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumAcc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDec)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox_SerialPort.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1000, 650);
            this.tabControl.TabIndex = 50;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.VelSetupPanel);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(992, 621);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Controls.Add(this.numericUpDown2);
            this.groupBox1.Controls.Add(this.numericUpDown3);
            this.groupBox1.Controls.Add(this.numericUpDown4);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(252, 109);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(181, 216);
            this.groupBox1.TabIndex = 54;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "轉動軸速率設定 (PPU/sec)";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(72, 26);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown1.TabIndex = 43;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown2.Location = new System.Drawing.Point(72, 57);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown2.TabIndex = 42;
            this.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown2.Value = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown3.Location = new System.Drawing.Point(72, 88);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown3.TabIndex = 41;
            this.numericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown3.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown4.Location = new System.Drawing.Point(72, 117);
            this.numericUpDown4.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown4.TabIndex = 40;
            this.numericUpDown4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown4.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Location = new System.Drawing.Point(8, 150);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(164, 53);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "速度曲線類型";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(10, 23);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(68, 20);
            this.radioButton1.TabIndex = 35;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "T型曲線";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(88, 23);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(68, 20);
            this.radioButton2.TabIndex = 36;
            this.radioButton2.Text = "S型曲線";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 121);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 16);
            this.label1.TabIndex = 32;
            this.label1.Text = "減速度";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 90);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 30;
            this.label2.Text = "加速度";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 59);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 16);
            this.label3.TabIndex = 28;
            this.label3.Text = "運轉速度";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 28);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 26;
            this.label4.Text = "起始速度";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // VelSetupPanel
            // 
            this.VelSetupPanel.Controls.Add(this.NumVelL);
            this.VelSetupPanel.Controls.Add(this.NumVelH);
            this.VelSetupPanel.Controls.Add(this.NumAcc);
            this.VelSetupPanel.Controls.Add(this.NumDec);
            this.VelSetupPanel.Controls.Add(this.groupBox11);
            this.VelSetupPanel.Controls.Add(this.label16);
            this.VelSetupPanel.Controls.Add(this.label17);
            this.VelSetupPanel.Controls.Add(this.label18);
            this.VelSetupPanel.Controls.Add(this.label19);
            this.VelSetupPanel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.VelSetupPanel.Location = new System.Drawing.Point(63, 109);
            this.VelSetupPanel.Margin = new System.Windows.Forms.Padding(4);
            this.VelSetupPanel.Name = "VelSetupPanel";
            this.VelSetupPanel.Padding = new System.Windows.Forms.Padding(4);
            this.VelSetupPanel.Size = new System.Drawing.Size(181, 216);
            this.VelSetupPanel.TabIndex = 53;
            this.VelSetupPanel.TabStop = false;
            this.VelSetupPanel.Text = "旋入軸速率設定 (PPU/sec)";
            // 
            // NumVelL
            // 
            this.NumVelL.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumVelL.Location = new System.Drawing.Point(72, 26);
            this.NumVelL.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.NumVelL.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumVelL.Name = "NumVelL";
            this.NumVelL.Size = new System.Drawing.Size(100, 23);
            this.NumVelL.TabIndex = 43;
            this.NumVelL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumVelL.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // NumVelH
            // 
            this.NumVelH.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumVelH.Location = new System.Drawing.Point(72, 57);
            this.NumVelH.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.NumVelH.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumVelH.Name = "NumVelH";
            this.NumVelH.Size = new System.Drawing.Size(100, 23);
            this.NumVelH.TabIndex = 42;
            this.NumVelH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumVelH.Value = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            // 
            // NumAcc
            // 
            this.NumAcc.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumAcc.Location = new System.Drawing.Point(72, 88);
            this.NumAcc.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NumAcc.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumAcc.Name = "NumAcc";
            this.NumAcc.Size = new System.Drawing.Size(100, 23);
            this.NumAcc.TabIndex = 41;
            this.NumAcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumAcc.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // NumDec
            // 
            this.NumDec.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumDec.Location = new System.Drawing.Point(72, 117);
            this.NumDec.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NumDec.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumDec.Name = "NumDec";
            this.NumDec.Size = new System.Drawing.Size(100, 23);
            this.NumDec.TabIndex = 40;
            this.NumDec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumDec.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.RbTCurver);
            this.groupBox11.Controls.Add(this.RbSCurver);
            this.groupBox11.Location = new System.Drawing.Point(8, 150);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(164, 53);
            this.groupBox11.TabIndex = 37;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "速度曲線類型";
            // 
            // RbTCurver
            // 
            this.RbTCurver.AutoSize = true;
            this.RbTCurver.Checked = true;
            this.RbTCurver.Location = new System.Drawing.Point(10, 23);
            this.RbTCurver.Margin = new System.Windows.Forms.Padding(4);
            this.RbTCurver.Name = "RbTCurver";
            this.RbTCurver.Size = new System.Drawing.Size(68, 20);
            this.RbTCurver.TabIndex = 35;
            this.RbTCurver.TabStop = true;
            this.RbTCurver.Text = "T型曲線";
            this.RbTCurver.UseVisualStyleBackColor = true;
            // 
            // RbSCurver
            // 
            this.RbSCurver.AutoSize = true;
            this.RbSCurver.Location = new System.Drawing.Point(88, 23);
            this.RbSCurver.Margin = new System.Windows.Forms.Padding(4);
            this.RbSCurver.Name = "RbSCurver";
            this.RbSCurver.Size = new System.Drawing.Size(68, 20);
            this.RbSCurver.TabIndex = 36;
            this.RbSCurver.Text = "S型曲線";
            this.RbSCurver.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(20, 121);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 16);
            this.label16.TabIndex = 32;
            this.label16.Text = "減速度";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 90);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 16);
            this.label17.TabIndex = 30;
            this.label17.Text = "加速度";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 59);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 16);
            this.label18.TabIndex = 28;
            this.label18.Text = "運轉速度";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 28);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 16);
            this.label19.TabIndex = 26;
            this.label19.Text = "起始速度";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox_SerialPort);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(992, 621);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox_SerialPort
            // 
            this.groupBox_SerialPort.Controls.Add(this.cbDataBits);
            this.groupBox_SerialPort.Controls.Add(this.btnUpdatePortNames);
            this.groupBox_SerialPort.Controls.Add(this.label_StopBits);
            this.groupBox_SerialPort.Controls.Add(this.cbStopBits);
            this.groupBox_SerialPort.Controls.Add(this.label_DataBits);
            this.groupBox_SerialPort.Controls.Add(this.label_Parity);
            this.groupBox_SerialPort.Controls.Add(this.cbParity);
            this.groupBox_SerialPort.Controls.Add(this.label_BaudRate);
            this.groupBox_SerialPort.Controls.Add(this.cbBaudRate);
            this.groupBox_SerialPort.Controls.Add(this.label9);
            this.groupBox_SerialPort.Controls.Add(this.cbCom);
            this.groupBox_SerialPort.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox_SerialPort.Location = new System.Drawing.Point(21, 17);
            this.groupBox_SerialPort.Name = "groupBox_SerialPort";
            this.groupBox_SerialPort.Size = new System.Drawing.Size(173, 231);
            this.groupBox_SerialPort.TabIndex = 77;
            this.groupBox_SerialPort.TabStop = false;
            this.groupBox_SerialPort.Text = "高度計參數設定";
            // 
            // cbDataBits
            // 
            this.cbDataBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDataBits.FormattingEnabled = true;
            this.cbDataBits.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbDataBits.Location = new System.Drawing.Point(76, 116);
            this.cbDataBits.Name = "cbDataBits";
            this.cbDataBits.Size = new System.Drawing.Size(82, 25);
            this.cbDataBits.TabIndex = 158;
            // 
            // btnUpdatePortNames
            // 
            this.btnUpdatePortNames.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnUpdatePortNames.Location = new System.Drawing.Point(13, 185);
            this.btnUpdatePortNames.Name = "btnUpdatePortNames";
            this.btnUpdatePortNames.Size = new System.Drawing.Size(145, 31);
            this.btnUpdatePortNames.TabIndex = 157;
            this.btnUpdatePortNames.Text = "更新埠列表";
            this.btnUpdatePortNames.UseVisualStyleBackColor = true;
            // 
            // label_StopBits
            // 
            this.label_StopBits.AutoSize = true;
            this.label_StopBits.Location = new System.Drawing.Point(10, 150);
            this.label_StopBits.Name = "label_StopBits";
            this.label_StopBits.Size = new System.Drawing.Size(63, 17);
            this.label_StopBits.TabIndex = 156;
            this.label_StopBits.Text = "停止位元:";
            this.label_StopBits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbStopBits
            // 
            this.cbStopBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbStopBits.FormattingEnabled = true;
            this.cbStopBits.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbStopBits.Location = new System.Drawing.Point(76, 147);
            this.cbStopBits.Name = "cbStopBits";
            this.cbStopBits.Size = new System.Drawing.Size(82, 25);
            this.cbStopBits.TabIndex = 155;
            // 
            // label_DataBits
            // 
            this.label_DataBits.AutoSize = true;
            this.label_DataBits.Location = new System.Drawing.Point(10, 119);
            this.label_DataBits.Name = "label_DataBits";
            this.label_DataBits.Size = new System.Drawing.Size(63, 17);
            this.label_DataBits.TabIndex = 154;
            this.label_DataBits.Text = "資料位元:";
            this.label_DataBits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Parity
            // 
            this.label_Parity.AutoSize = true;
            this.label_Parity.Location = new System.Drawing.Point(10, 88);
            this.label_Parity.Name = "label_Parity";
            this.label_Parity.Size = new System.Drawing.Size(63, 17);
            this.label_Parity.TabIndex = 152;
            this.label_Parity.Text = "同位位元:";
            this.label_Parity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbParity
            // 
            this.cbParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbParity.FormattingEnabled = true;
            this.cbParity.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbParity.Location = new System.Drawing.Point(76, 85);
            this.cbParity.Name = "cbParity";
            this.cbParity.Size = new System.Drawing.Size(82, 25);
            this.cbParity.TabIndex = 151;
            // 
            // label_BaudRate
            // 
            this.label_BaudRate.AutoSize = true;
            this.label_BaudRate.Location = new System.Drawing.Point(35, 57);
            this.label_BaudRate.Name = "label_BaudRate";
            this.label_BaudRate.Size = new System.Drawing.Size(37, 17);
            this.label_BaudRate.TabIndex = 150;
            this.label_BaudRate.Text = "鮑率:";
            this.label_BaudRate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbBaudRate
            // 
            this.cbBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBaudRate.FormattingEnabled = true;
            this.cbBaudRate.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbBaudRate.Location = new System.Drawing.Point(76, 54);
            this.cbBaudRate.Name = "cbBaudRate";
            this.cbBaudRate.Size = new System.Drawing.Size(82, 25);
            this.cbBaudRate.TabIndex = 149;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(35, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 17);
            this.label9.TabIndex = 148;
            this.label9.Text = "Port:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbCom
            // 
            this.cbCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCom.FormattingEnabled = true;
            this.cbCom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbCom.Location = new System.Drawing.Point(76, 23);
            this.cbCom.Name = "cbCom";
            this.cbCom.Size = new System.Drawing.Size(82, 25);
            this.cbCom.TabIndex = 145;
            // 
            // SetupPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SetupPage";
            this.Size = new System.Drawing.Size(1000, 650);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.VelSetupPanel.ResumeLayout(false);
            this.VelSetupPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumAcc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDec)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox_SerialPort.ResumeLayout(false);
            this.groupBox_SerialPort.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl tabControl;
        private TabPage tabPage1;
        private GroupBox groupBox1;
        private NumericUpDown numericUpDown1;
        private NumericUpDown numericUpDown2;
        private NumericUpDown numericUpDown3;
        private NumericUpDown numericUpDown4;
        private GroupBox groupBox2;
        public RadioButton radioButton1;
        public RadioButton radioButton2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private GroupBox VelSetupPanel;
        private NumericUpDown NumVelL;
        private NumericUpDown NumVelH;
        private NumericUpDown NumAcc;
        private NumericUpDown NumDec;
        private GroupBox groupBox11;
        public RadioButton RbTCurver;
        public RadioButton RbSCurver;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private TabPage tabPage2;
        private GroupBox groupBox_SerialPort;
        private ComboBox cbDataBits;
        private Button btnUpdatePortNames;
        private Label label_StopBits;
        private ComboBox cbStopBits;
        private Label label_DataBits;
        private Label label_Parity;
        private ComboBox cbParity;
        private Label label_BaudRate;
        private ComboBox cbBaudRate;
        private Label label9;
        private ComboBox cbCom;
    }
}
