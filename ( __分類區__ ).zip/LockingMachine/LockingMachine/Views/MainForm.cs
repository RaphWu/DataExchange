using Calin.Framework.Navigation;
using Calin.LockingMachine.Constants;
using Calin.LockingMachine.Models;
using Calin.LockingMachine.Views;

namespace Calin.LockingMachine
{
    public partial class MainForm : Form
    {
        #region Fields

        private readonly IRegionManager _region;
        private readonly INavigationService _nav;
        private readonly UiData _uiData = new UiData();

        // ���A�C�T���p�ɾ��A�w�ɲM���T��
        private System.Windows.Forms.Timer _messageTimer = new System.Windows.Forms.Timer();

        private PageCode _currentPageCode = PageCode.None;

        #endregion Fields

        #region ctor

        public MainForm(
            IRegionManager regionManager,
            INavigationService navigationService
            )
        {
            _region = regionManager;
            _nav = navigationService;

            InitializeComponent();

            // Region ���U
            _region.RegisterRegion(nameof(ContentPanel), view =>
            {
                ContentPanel.SuspendLayout();
                ContentPanel.Controls.Clear();
                if (view is Control control)
                {
                    control.Dock = DockStyle.Fill;
                    ContentPanel.Controls.Add(control);
                }
                ContentPanel.ResumeLayout();
            });

            // Status Bar
            _uiData.PropertyChanged += (s, e) =>
            {
                if (e.PropertyName == nameof(UiData.ZAxisCoor))
                    SbZ.Text = _uiData.ZAxisCoor.ToString("F3");

                if (e.PropertyName == nameof(UiData.Angle))
                    SbR.Text = _uiData.Angle.ToString("F1");

                if (e.PropertyName == nameof(UiData.Torque))
                    SbTorque.Text = _uiData.Torque.ToString("F3");

                if (e.PropertyName == nameof(UiData.Height))
                    SbHeight.Text = _uiData.Height.ToString("F3");
            };
        }

        #endregion ctor

        #region Form Events

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // ����Ҧ� Timer
            _messageTimer?.Stop();
            _messageTimer?.Dispose();

            ClockTimer?.Stop();
            ClockTimer?.Dispose();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            ResizeScreen();
        }

        #endregion Form Events

        #region Form Methods

        /// <summary>
        /// �վ�����j�p�C
        /// </summary>
        private void ResizeScreen()
        {
            const int TARGET_WIDTH = 1024;
            const int TARGET_HEIGHT = 768;
            var screenArea = Screen.PrimaryScreen.WorkingArea;

            if (screenArea.Width > TARGET_WIDTH)
            {
                WindowState = FormWindowState.Normal;
                StartPosition = FormStartPosition.CenterScreen;
                Width = TARGET_WIDTH;
                Height = TARGET_HEIGHT;
                Left = (screenArea.Width - TARGET_WIDTH) / 2;
                Top = (screenArea.Height - TARGET_HEIGHT) / 2;
            }
            else
            {
                WindowState = FormWindowState.Maximized;
            }
        }

        #endregion Form Methods

        #region Timer

        private void ClockTimer_Tick(object sender, EventArgs e)
        {
            SbClock.Text = DateTime.Now.ToString();
        }

        #endregion Timer

        #region Navigation

        /// <summary>
        /// �����ާ@�����C
        /// </summary>
        /// <param name="pageCode">�������ޡC</param>
        private void SwitchPage(PageCode pageCode)
        {
            if (_currentPageCode == pageCode) return;

            switch (pageCode)
            {
                case PageCode.MainPage:
                    _nav.NavigateTo<MainPage>(nameof(ContentPanel), (int)PageCode.MainPage);
                    break;
                //case PageCode.WorkSetup:
                //    _nav.NavigateTo<WorkSetupPage>(nameof(ContainerPanel), (int)PageCode.WorkSetup);
                //    break;
                //case PageCode.Monitor:
                //    _nav.NavigateTo<MonitorPage>(nameof(ContainerPanel), (int)PageCode.Monitor);
                //    break;
                case PageCode.Setup:
                    _nav.NavigateTo<SetupPage>(nameof(ContentPanel), (int)PageCode.Setup);
                    break;
                default:
                    return;
            }
            _currentPageCode = pageCode;
        }

        private void MenuMain_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.MainPage);
        }

        private void MenuWorkSetup_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.WorkSetup);
        }

        private void MenuMonitor_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Monitor);
        }

        private void MenuSetup_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Setup);
        }

        #endregion Navigation
    }
}
