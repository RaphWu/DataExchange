﻿using Calin.Framework.Navigation;

namespace Calin.LockingMachine.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class SetupPage : UserControl
    {
        public SetupPage()
        {
            InitializeComponent();
        }


        private void SetLds()
        {

        }
    }
}
