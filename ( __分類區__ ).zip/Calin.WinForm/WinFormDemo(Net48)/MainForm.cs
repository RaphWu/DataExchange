using Calin.Framework.Navigation;

namespace Calin.WinFormDemo_Net48
{
    public partial class MainForm : Form
    {
        #region Fields

        private readonly IRegionManager _region;
        private readonly INavigationService _nav;

        #endregion Fields

        public MainForm(IRegionManager regionManager, INavigationService navigationService)
        {
            InitializeComponent();

            _region = regionManager;
            _nav = navigationService;

            _region.RegisterRegion(nameof(ContentPanel), view =>
            {
                ContentPanel.SuspendLayout();
                ContentPanel.Controls.Clear();
                if (view is Control control)
                {
                    control.Dock = DockStyle.Fill;
                    ContentPanel.Controls.Add(control);
                }
                ContentPanel.ResumeLayout();
            });
        }

        private void RbView1_Click(object sender, EventArgs e)
        {
            _nav.NavigateTo<View1>(nameof(ContentPanel), 1);
        }

        private void RbView2_Click(object sender, EventArgs e)
        {
            _nav.NavigateTo<View2>(nameof(ContentPanel), 2);
        }

        private void RbView3_Click(object sender, EventArgs e)
        {
            _nav.NavigateTo<View3>(nameof(ContentPanel), 3);
        }
    }
}
