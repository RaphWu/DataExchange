﻿namespace Calin.WinFormDemo_Net48
{
    public partial class View1 : UserControl
    {
        public View1()
        {
            InitializeComponent();
        }
    }
}
