﻿namespace Calin.WinFormDemo_Net48
{
    public partial class View2 : UserControl
    {
        public View2()
        {
            InitializeComponent();
        }
    }
}
