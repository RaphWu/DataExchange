﻿namespace Calin.WinFormDemo_Net48
{
    public partial class View3 : UserControl
    {
        public View3()
        {
            InitializeComponent();
        }
    }
}
