namespace Calin.WinFormDemo_Net48.ProcessFlow.Samples.Parameters
{
    /// <summary>
    /// ���𵥫ݰѼơC
    /// </summary>
    public class DelayParam
    {
        /// <summary>
        /// ����ɶ��]�@���^�C
        /// </summary>
        public int DelayMilliseconds { get; set; } = 1000;

        /// <summary>
        /// ���𻡩��C
        /// </summary>
        public string Description { get; set; } = "";
    }
}
