namespace Calin.WinFormDemo_Net48.ProcessFlow.Editor
{
    /// <summary>
    /// �u�ǽs�边�����O�C
    /// </summary>
    public abstract class ProcessEditorBase : UserControl, IProcessEditor
    {
        /// <inheritdoc />
        public abstract string ProcessId { get; }

        /// <inheritdoc />
        public event EventHandler ParamChanged;

        /// <summary>
        /// Ĳ�o ParamChanged �ƥ�C
        /// </summary>
        protected virtual void OnParamChanged()
        {
            ParamChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <inheritdoc />
        public abstract void Load(string paramJson);

        /// <inheritdoc />
        public abstract string Save();

        /// <inheritdoc />
        public virtual string Validate()
        {
            return null; // �w�]������
        }
    }
}
