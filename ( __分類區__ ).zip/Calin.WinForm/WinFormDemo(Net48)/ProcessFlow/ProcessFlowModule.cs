using System.Text.Json;
using Autofac;
using Calin.WinFormDemo_Net48.ProcessFlow.Core;
using Calin.WinFormDemo_Net48.ProcessFlow.Editor;
using Calin.WinFormDemo_Net48.ProcessFlow.Engine;
using Calin.WinFormDemo_Net48.ProcessFlow.Registry;
using Calin.WinFormDemo_Net48.ProcessFlow.Samples;
using Calin.WinFormDemo_Net48.ProcessFlow.Samples.Editors;
using Calin.WinFormDemo_Net48.ProcessFlow.Samples.Handlers;
using Calin.WinFormDemo_Net48.ProcessFlow.Samples.Parameters;

namespace Calin.WinFormDemo_Net48.ProcessFlow
{
    /// <summary>
    /// ProcessFlow �ҲաA�t�d���U�Ҧ��u�Ǭ������A�ȡC
    /// </summary>
    public class ProcessFlowModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // ���U ProcessRegistry
            builder.Register(c =>
            {
                var registry = new ProcessRegistry();
                RegisterDefaultProcesses(registry);
                return registry;
            })
            .As<IProcessRegistry>()
            .SingleInstance();

            // ���U ProcessRunner
            builder.RegisterType<ProcessRunner>()
                .AsSelf()
                .InstancePerDependency();

            // �ϥ� Keyed ���U Handler
            builder.RegisterType<SingleAxisMoveHandler>()
                .Keyed<IProcessHandler>(ProcessIds.SINGLE_AXIS_MOVE)
                .InstancePerDependency();

            builder.RegisterType<DualAxisMoveHandler>()
                .Keyed<IProcessHandler>(ProcessIds.DUAL_AXIS_MOVE)
                .InstancePerDependency();

            builder.RegisterType<SensorCheckHandler>()
                .Keyed<IProcessHandler>(ProcessIds.SENSOR_CHECK)
                .InstancePerDependency();

            builder.RegisterType<DelayHandler>()
                .Keyed<IProcessHandler>(ProcessIds.DELAY)
                .InstancePerDependency();

            // �ϥ� Keyed ���U Editor
            builder.RegisterType<SingleAxisMoveEditor>()
                .Keyed<IProcessEditor>(ProcessIds.SINGLE_AXIS_MOVE)
                .InstancePerDependency();

            builder.RegisterType<DualAxisMoveEditor>()
                .Keyed<IProcessEditor>(ProcessIds.DUAL_AXIS_MOVE)
                .InstancePerDependency();

            builder.RegisterType<SensorCheckEditor>()
                .Keyed<IProcessEditor>(ProcessIds.SENSOR_CHECK)
                .InstancePerDependency();

            builder.RegisterType<DelayEditor>()
                .Keyed<IProcessEditor>(ProcessIds.DELAY)
                .InstancePerDependency();
        }

        /// <summary>
        /// ���U�w�]���u�Ǵy�z���C
        /// </summary>
        private void RegisterDefaultProcesses(ProcessRegistry registry)
        {
            registry.Register(new ProcessDescriptor
            {
                ProcessId = ProcessIds.SINGLE_AXIS_MOVE,
                DisplayName = "��b����",
                Description = "��b�̫��w�t�ײ��ʨ���w�y��",
                HandlerType = typeof(SingleAxisMoveHandler),
                EditorType = typeof(SingleAxisMoveEditor),
                DefaultParamJson = JsonSerializer.Serialize(new SingleAxisMoveParam())
            });

            registry.Register(new ProcessDescriptor
            {
                ProcessId = ProcessIds.DUAL_AXIS_MOVE,
                DisplayName = "���b�P��",
                Description = "��b�P�ʨ̫��w�t�ײ��ʨ���w�y��",
                HandlerType = typeof(DualAxisMoveHandler),
                EditorType = typeof(DualAxisMoveEditor),
                DefaultParamJson = JsonSerializer.Serialize(new DualAxisMoveParam())
            });

            registry.Register(new ProcessDescriptor
            {
                ProcessId = ProcessIds.SENSOR_CHECK,
                DisplayName = "�P�����P�_",
                Description = "Ū���P�����ȡA�P�_�O�_���b���w�d��",
                HandlerType = typeof(SensorCheckHandler),
                EditorType = typeof(SensorCheckEditor),
                DefaultParamJson = JsonSerializer.Serialize(new SensorCheckParam())
            });

            registry.Register(new ProcessDescriptor
            {
                ProcessId = ProcessIds.DELAY,
                DisplayName = "���𵥫�",
                Description = "������w�ɶ����~�����",
                HandlerType = typeof(DelayHandler),
                EditorType = typeof(DelayEditor),
                DefaultParamJson = JsonSerializer.Serialize(new DelayParam())
            });
        }
    }
}
