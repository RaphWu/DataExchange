using Calin.WinFormDemo_Net48.ProcessFlow.Editor;

namespace Calin.WinFormDemo_Net48.ProcessFlow.UI
{
    /// <summary>
    /// �ťսs�边�A�Ω���ܵL�����s�边�ɪ����ܡC
    /// </summary>
    public class EmptyEditor : ProcessEditorBase
    {
        private string _processId;
        private Label _lblMessage;

        public override string ProcessId => _processId ?? "EMPTY";

        public EmptyEditor()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            _lblMessage = new Label
            {
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Text = "�L�������Ѽƽs�边",
                ForeColor = SystemColors.GrayText
            };

            this.Controls.Add(_lblMessage);
        }

        public void SetProcessId(string processId)
        {
            _processId = processId;
            _lblMessage.Text = $"�u�� [{processId}] �L�������Ѽƽs�边";
        }

        public override void Load(string paramJson)
        {
            // �ťսs�边���������
        }

        public override string Save()
        {
            return "{}";
        }
    }
}
