﻿# Calin.WinForm

Calin.WinForm 是佳凌科技關於 Windows Forms 應用程式開發的組件庫，旨在提供一套高效、易用且功能豐富的工具，幫助開發者快速構建現代化的桌面應用程式。

# 目標框架

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0

# NuGet 依賴

- AutoFac

# 主要功能

## Navigation

提供靈活的導航系統，支持多種導航模式，方便用戶在應用程式中切換不同的視圖和頁面。

詳細說明請參考 [Navigation README](./Navigation/README.md)。

使用範例請參考 `Navigation\Examples\NavigationUsageExamples.cs`。

## ThreadExtensions

提供一組擴展方法，簡化多執行緒操作，提升應用程式的響應速度和穩定性。

|函數|說明|
|---|---|
| `InvokeIfRequired` | 如果控制項需要跨執行緒呼叫，則在 UI 執行緒上執行指定的動作。 |
| `BeginInvokeIfRequired` | 在 UI 執行緒上執行指定的動作。 |

## LoadingDialog

提供一個簡單易用的載入對話框，方便在長時間操作時向用戶顯示等待動畫。
