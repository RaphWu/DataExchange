﻿using Autofac;
using Calin.WinForm.Framework.Dialog;
using Calin.WinForm.Framework.Navigation;
using Calin.WinForm.Service;

namespace Calin.WinForm
{
    public class WinFormModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // Modules
            builder.RegisterModule<NavigationModule>();
            builder.RegisterModule<DialogModule>();

            // services
            builder.RegisterType<WinFormService>().As<IWinForm>().SingleInstance();
        }
    }
}
