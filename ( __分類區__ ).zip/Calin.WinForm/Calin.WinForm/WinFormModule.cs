﻿using Autofac;
using Calin.Service;

namespace Calin
{
    public class WinFormModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // Modules

            // services
            builder.RegisterType<WinFormService>().As<IWinForm>().SingleInstance();
        }
    }
}
