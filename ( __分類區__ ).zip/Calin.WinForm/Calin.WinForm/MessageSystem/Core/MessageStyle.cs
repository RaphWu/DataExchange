using System.Drawing;
using System.Windows.Forms;

namespace Calin.MessageSystem.Core
{
    /// <summary>
    /// �T����ı�˦��]�w�A�i�Q Toast�BDialog�BMessageTip �@�ΡC
    /// </summary>
    public class MessageStyle
    {
        #region ���D�˦�

        /// <summary>
        /// ���D�r��]�i�� null ���ܤ���ܼ��D�^�C
        /// </summary>
        public Font TitleFont { get; set; }

        /// <summary>
        /// ���D�I����C
        /// </summary>
        public Color TitleBackColor { get; set; }

        /// <summary>
        /// ���D�e����C
        /// </summary>
        public Color TitleForeColor { get; set; }

        /// <summary>
        /// ���D�ϰ찪�ס]0 ���ܦ۰ʭp��^�C
        /// </summary>
        public int TitleHeight { get; set; }

        #endregion

        #region ���e�˦�

        /// <summary>
        /// ���e�r��C
        /// </summary>
        public Font ContentFont { get; set; }

        /// <summary>
        /// ���e�I����C
        /// </summary>
        public Color ContentBackColor { get; set; }

        /// <summary>
        /// ���e�e����C
        /// </summary>
        public Color ContentForeColor { get; set; }

        #endregion

        #region ���s�˦�

        /// <summary>
        /// ���s�r��C
        /// </summary>
        public Font ButtonFont { get; set; }

        /// <summary>
        /// ���s�e����C
        /// </summary>
        public Color ButtonForeColor { get; set; }

        /// <summary>
        /// ���s�I����C
        /// </summary>
        public Color ButtonBackColor { get; set; }

        /// <summary>
        /// ���s�ƹ��a���I����C
        /// </summary>
        public Color ButtonHoverBackColor { get; set; }

        /// <summary>
        /// ���s�ϭI����C
        /// </summary>
        public Color ButtonAreaBackColor { get; set; }

        /// <summary>
        /// ���s���סC
        /// </summary>
        public int ButtonHeight { get; set; }

        /// <summary>
        /// ���s���Z�C
        /// </summary>
        public int ButtonSpacing { get; set; }

        #endregion

        #region �ϥܼ˦�

        /// <summary>
        /// �ϥܡ]�w�d�A�ثe���ϥΡ^�C
        /// </summary>
        public Image Icon { get; set; }

        /// <summary>
        /// �ϥܤؤo�C
        /// </summary>
        public Size IconSize { get; set; }

        /// <summary>
        /// �ϥܦ�m�]Left �� Right�^�C
        /// </summary>
        public IconPosition IconPosition { get; set; }

        #endregion

        #region �G���˦�

        /// <summary>
        /// ���e�ϰ쪺����Z�C
        /// </summary>
        public Padding Padding { get; set; }

        /// <summary>
        /// �������������Z�]�p Icon �P��r�B���D�P���e�����^�C
        /// </summary>
        public int Spacing { get; set; }

        /// <summary>
        /// �̤p�e�סC
        /// </summary>
        public int MinWidth { get; set; }

        /// <summary>
        /// �̤j�e�סC
        /// </summary>
        public int MaxWidth { get; set; }

        /// <summary>
        /// ����C��C
        /// </summary>
        public Color BorderColor { get; set; }

        /// <summary>
        /// ��ؼe�סC
        /// </summary>
        public int BorderWidth { get; set; }

        #endregion

        #region �u�t��k

        /// <summary>
        /// �إ߹w�] Toast �˦��C
        /// </summary>
        public static MessageStyle CreateToastDefault()
        {
            return new MessageStyle
            {
                TitleFont = null,
                ContentFont = SystemFonts.DefaultFont,
                ButtonFont = null,
                TitleBackColor = Color.FromArgb(50, 50, 50),
                TitleForeColor = Color.White,
                TitleHeight = 0,
                ContentBackColor = Color.FromArgb(50, 50, 50),
                ContentForeColor = Color.White,
                ButtonForeColor = Color.White,
                ButtonBackColor = Color.FromArgb(70, 70, 70),
                ButtonHoverBackColor = Color.FromArgb(90, 90, 90),
                ButtonAreaBackColor = Color.FromArgb(50, 50, 50),
                ButtonHeight = 28,
                ButtonSpacing = 8,
                Icon = null,
                IconSize = new Size(24, 24),
                IconPosition = IconPosition.Left,
                Padding = new Padding(16),
                Spacing = 8,
                MinWidth = 150,
                MaxWidth = 350,
                BorderColor = Color.FromArgb(80, 80, 80),
                BorderWidth = 0
            };
        }

        /// <summary>
        /// �إ߹w�] Dialog �˦��C
        /// </summary>
        public static MessageStyle CreateDialogDefault()
        {
            return new MessageStyle
            {
                TitleFont = new Font(SystemFonts.DefaultFont.FontFamily, 10f, FontStyle.Bold),
                ContentFont = SystemFonts.DefaultFont,
                ButtonFont = SystemFonts.DefaultFont,
                TitleBackColor = Color.FromArgb(45, 45, 48),
                TitleForeColor = Color.White,
                TitleHeight = 36,
                ContentBackColor = Color.FromArgb(60, 60, 60),
                ContentForeColor = Color.White,
                ButtonForeColor = Color.White,
                ButtonBackColor = Color.FromArgb(70, 70, 70),
                ButtonHoverBackColor = Color.FromArgb(100, 100, 100),
                ButtonAreaBackColor = Color.FromArgb(45, 45, 48),
                ButtonHeight = 32,
                ButtonSpacing = 10,
                Icon = null,
                IconSize = new Size(32, 32),
                IconPosition = IconPosition.Left,
                Padding = new Padding(16),
                Spacing = 12,
                MinWidth = 300,
                MaxWidth = 500,
                BorderColor = Color.FromArgb(100, 100, 100),
                BorderWidth = 1
            };
        }

        /// <summary>
        /// �إ߹w�] MessageTip �˦��C
        /// </summary>
        public static MessageStyle CreateMessageTipDefault()
        {
            return new MessageStyle
            {
                TitleFont = null,
                ContentFont = SystemFonts.DefaultFont,
                ButtonFont = null,
                TitleBackColor = Color.FromArgb(255, 255, 225),
                TitleForeColor = Color.Black,
                TitleHeight = 0,
                ContentBackColor = Color.FromArgb(255, 255, 225),
                ContentForeColor = Color.Black,
                ButtonForeColor = Color.Black,
                ButtonBackColor = Color.FromArgb(230, 230, 200),
                ButtonHoverBackColor = Color.FromArgb(210, 210, 180),
                ButtonAreaBackColor = Color.FromArgb(255, 255, 225),
                ButtonHeight = 24,
                ButtonSpacing = 6,
                Icon = null,
                IconSize = new Size(16, 16),
                IconPosition = IconPosition.Left,
                Padding = new Padding(9, 5, 9, 5),
                Spacing = 6,
                MinWidth = 100,
                MaxWidth = 300,
                BorderColor = Color.FromArgb(150, 150, 100),
                BorderWidth = 1
            };
        }

        #endregion

        /// <summary>
        /// �ƻs�˦��C
        /// </summary>
        public MessageStyle Clone()
        {
            return new MessageStyle
            {
                TitleFont = TitleFont,
                ContentFont = ContentFont,
                ButtonFont = ButtonFont,
                TitleBackColor = TitleBackColor,
                TitleForeColor = TitleForeColor,
                TitleHeight = TitleHeight,
                ContentBackColor = ContentBackColor,
                ContentForeColor = ContentForeColor,
                ButtonForeColor = ButtonForeColor,
                ButtonBackColor = ButtonBackColor,
                ButtonHoverBackColor = ButtonHoverBackColor,
                ButtonAreaBackColor = ButtonAreaBackColor,
                ButtonHeight = ButtonHeight,
                ButtonSpacing = ButtonSpacing,
                Icon = Icon,
                IconSize = IconSize,
                IconPosition = IconPosition,
                Padding = Padding,
                Spacing = Spacing,
                MinWidth = MinWidth,
                MaxWidth = MaxWidth,
                BorderColor = BorderColor,
                BorderWidth = BorderWidth
            };
        }
    }

    /// <summary>
    /// �ϥܦ�m�C
    /// </summary>
    public enum IconPosition
    {
        /// <summary>
        /// �����C
        /// </summary>
        Left,

        /// <summary>
        /// �k���C
        /// </summary>
        Right
    }
}
