using System;
using System.Drawing;
using System.Windows.Forms;

namespace Calin.MessageSystem.Core
{
    /// <summary>
    /// �T���G���p������A�­p���޿�A���̿�S�w UI ����C
    /// </summary>
    public static class MessageLayoutEngine
    {
        /// <summary>
        /// �p�⧹��G���]�t���D�B���e�B�ϥܡB���s�^�C
        /// </summary>
        public static MessageLayoutResult CalculateFull(
            MessageStyle style,
            string title,
            string content,
            MessageIcon icon,
            DialogButtonSet buttonSet)
        {
            if (style == null)
            {
                throw new ArgumentNullException(nameof(style));
            }

            content = content ?? string.Empty;

            var result = new MessageLayoutResult();
            var padding = style.Padding;
            var spacing = style.Spacing;
            var currentY = 0;

            // �p��i�Ϊ��̤j���e�e��
            var maxContentWidth = style.MaxWidth - padding.Left - padding.Right;

            // �ϥܳB�z
            var hasIcon = icon != null && icon.HasIcon;
            var iconSize = hasIcon ? style.IconSize : Size.Empty;
            if (hasIcon)
            {
                maxContentWidth -= iconSize.Width + spacing;
            }

            // === ���D�ϰ� ===
            var hasTitle = !string.IsNullOrEmpty(title) && style.TitleFont != null;
            var titleHeight = 0;

            if (hasTitle)
            {
                var titleSize = MeasureText(title, style.TitleFont, maxContentWidth);
                titleHeight = style.TitleHeight > 0 ? style.TitleHeight : titleSize.Height + padding.Top + padding.Bottom;

                result.TitleAreaBounds = new Rectangle(0, currentY, style.MaxWidth, titleHeight);

                var titleTextY = currentY + (titleHeight - titleSize.Height) / 2;
                var titleTextX = padding.Left;
                result.TitleBounds = new Rectangle(titleTextX, titleTextY, titleSize.Width, titleSize.Height);

                currentY += titleHeight;
            }

            // === ���e�ϰ� ===
            var contentStartY = currentY;
            var contentTextX = padding.Left;

            if (hasIcon && style.IconPosition == IconPosition.Left)
            {
                contentTextX = padding.Left + iconSize.Width + spacing;
            }

            var contentSize = MeasureText(content, style.ContentFont, maxContentWidth);

            // �p�⤺�e�ϰ찪�ס]�Ҽ{�ϥܰ��ס^
            var contentAreaHeight = Math.Max(contentSize.Height, iconSize.Height) + padding.Top + padding.Bottom;

            result.ContentAreaBounds = new Rectangle(0, contentStartY, style.MaxWidth, contentAreaHeight);

            var contentTextY = contentStartY + padding.Top;
            if (contentSize.Height < iconSize.Height)
            {
                contentTextY = contentStartY + padding.Top + (iconSize.Height - contentSize.Height) / 2;
            }
            result.ContentBounds = new Rectangle(contentTextX, contentTextY, contentSize.Width, contentSize.Height);

            // �ϥܦ�m
            if (hasIcon)
            {
                var iconX = style.IconPosition == IconPosition.Left
                    ? padding.Left
                    : style.MaxWidth - padding.Right - iconSize.Width;
                var iconY = contentStartY + padding.Top;
                if (iconSize.Height < contentSize.Height)
                {
                    iconY = contentStartY + padding.Top + (contentSize.Height - iconSize.Height) / 2;
                }
                result.IconBounds = new Rectangle(iconX, iconY, iconSize.Width, iconSize.Height);
            }

            currentY = contentStartY + contentAreaHeight;

            // === ���s�ϰ� ===
            var hasButtons = buttonSet != null && buttonSet.Count > 0;
            if (hasButtons)
            {
                var buttonAreaHeight = style.ButtonHeight + padding.Top + padding.Bottom;
                result.ButtonAreaBounds = new Rectangle(0, currentY, style.MaxWidth, buttonAreaHeight);

                // �p����s��m�]�m���ƦC�^
                var buttonBounds = CalculateButtonBounds(style, buttonSet, currentY);
                result.ButtonBounds = buttonBounds;

                currentY += buttonAreaHeight;
            }
            else
            {
                result.ButtonBounds = new Rectangle[0];
            }

            // === �p���`�ؤo ===
            var totalWidth = CalculateTotalWidth(style, hasIcon, iconSize, contentSize, hasTitle, title);
            result.TotalSize = new Size(totalWidth, currentY);

            // ��s�Ҧ��ϰ쪺�e��
            result.TitleAreaBounds = new Rectangle(0, result.TitleAreaBounds.Y, totalWidth, result.TitleAreaBounds.Height);
            result.ContentAreaBounds = new Rectangle(0, result.ContentAreaBounds.Y, totalWidth, result.ContentAreaBounds.Height);
            result.ButtonAreaBounds = new Rectangle(0, result.ButtonAreaBounds.Y, totalWidth, result.ButtonAreaBounds.Height);

            // ���s�p����s��m�]�ϥι�ڼe�ס^
            if (hasButtons)
            {
                result.ButtonBounds = CalculateButtonBoundsWithWidth(style, buttonSet, result.ButtonAreaBounds.Y, totalWidth);
            }

            return result;
        }

        /// <summary>
        /// �p��G���]�t���D�M���e�^�C
        /// </summary>
        public static MessageLayoutResult Calculate(MessageStyle style, string title, string content)
        {
            return CalculateFull(style, title, content, null, null);
        }

        /// <summary>
        /// �p��Ȧ����e��²��G���]Toast �M�Χֱ���k�^�C
        /// </summary>
        public static MessageLayoutResult CalculateContentOnly(MessageStyle style, string content)
        {
            return CalculateFull(style, null, content, null, null);
        }

        /// <summary>
        /// �p���ܮاG���C
        /// </summary>
        public static MessageLayoutResult CalculateDialog(
            MessageStyle style,
            string title,
            string content,
            MessageIcon icon,
            DialogButtonSet buttonSet)
        {
            return CalculateFull(style, title, content, icon, buttonSet);
        }

        private static int CalculateTotalWidth(
            MessageStyle style,
            bool hasIcon,
            Size iconSize,
            Size contentSize,
            bool hasTitle,
            string title)
        {
            var padding = style.Padding;
            var spacing = style.Spacing;

            var contentWidth = contentSize.Width;
            if (hasIcon)
            {
                contentWidth += iconSize.Width + spacing;
            }

            var titleWidth = 0;
            if (hasTitle && style.TitleFont != null)
            {
                var titleSize = MeasureText(title, style.TitleFont, style.MaxWidth - padding.Left - padding.Right);
                titleWidth = titleSize.Width;
            }

            var maxContentWidth = Math.Max(contentWidth, titleWidth);
            var totalWidth = padding.Left + maxContentWidth + padding.Right;

            return Math.Max(style.MinWidth, Math.Min(style.MaxWidth, totalWidth));
        }

        private static Rectangle[] CalculateButtonBounds(MessageStyle style, DialogButtonSet buttonSet, int buttonAreaY)
        {
            return CalculateButtonBoundsWithWidth(style, buttonSet, buttonAreaY, style.MaxWidth);
        }

        private static Rectangle[] CalculateButtonBoundsWithWidth(MessageStyle style, DialogButtonSet buttonSet, int buttonAreaY, int totalWidth)
        {
            var buttons = buttonSet.Buttons;
            var buttonCount = buttons.Count;
            var bounds = new Rectangle[buttonCount];

            if (buttonCount == 0)
            {
                return bounds;
            }

            var buttonHeight = style.ButtonHeight;
            var buttonSpacing = style.ButtonSpacing;
            var padding = style.Padding;

            // �p��C�ӫ��s�e��
            var buttonWidths = new int[buttonCount];
            var totalButtonWidth = 0;

            for (var i = 0; i < buttonCount; i++)
            {
                var button = buttons[i];
                var font = button.Font ?? style.ButtonFont ?? SystemFonts.DefaultFont;
                var textSize = MeasureText(button.Text, font, 200);
                var buttonWidth = Math.Max(button.MinWidth, textSize.Width + 20);
                buttonWidths[i] = buttonWidth;
                totalButtonWidth += buttonWidth;
            }

            totalButtonWidth += (buttonCount - 1) * buttonSpacing;

            // �p��_�l X ��m�]�m���^
            var startX = (totalWidth - totalButtonWidth) / 2;
            var buttonY = buttonAreaY + (style.Padding.Top + style.Padding.Bottom + buttonHeight - buttonHeight) / 2;

            var currentX = startX;
            for (var i = 0; i < buttonCount; i++)
            {
                bounds[i] = new Rectangle(currentX, buttonY + padding.Top, buttonWidths[i], buttonHeight);
                currentX += buttonWidths[i] + buttonSpacing;
            }

            return bounds;
        }

        /// <summary>
        /// �q����r�ؤo�C
        /// </summary>
        private static Size MeasureText(string text, Font font, int maxWidth)
        {
            if (string.IsNullOrEmpty(text) || font == null)
            {
                return Size.Empty;
            }

            return TextRenderer.MeasureText(
                text,
                font,
                new Size(maxWidth, int.MaxValue),
                GetTextFormatFlags());
        }

        /// <summary>
        /// ���o�Τ@����r�榡�X�СC
        /// </summary>
        public static TextFormatFlags GetTextFormatFlags()
        {
            return TextFormatFlags.WordBreak | TextFormatFlags.TextBoxControl;
        }
    }
}
