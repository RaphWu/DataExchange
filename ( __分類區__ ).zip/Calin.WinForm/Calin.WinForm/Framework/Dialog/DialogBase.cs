using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Calin.WinForm.Framework.Dialog
{
    /// <summary>
    /// ��ܮذ����O�A���� IDialogAware ���򥻹�@�C
    /// </summary>
    /// <remarks>
    /// <para>�~�Ӧ����O�H�ֳt�إߦ۩w�q��ܮءC</para>
    /// <para>
    /// �ϥνd�ҡG
    /// <code>
    /// public class MyDialog : DialogBase
    /// {
    ///     private Button btnOK;
    ///     private Button btnCancel;
    ///     private TextBox txtInput;
    ///     
    ///     public MyDialog()
    ///     {
    ///         Title = "��J���";
    ///         InitializeComponents();
    ///     }
    ///     
    ///     protected override void OnDialogOpenedCore(IDialogParameters parameters)
    ///     {
    ///         var defaultValue = parameters.GetValue&lt;string&gt;("DefaultValue");
    ///         txtInput.Text = defaultValue;
    ///     }
    ///     
    ///     private void btnOK_Click(object sender, EventArgs e)
    ///     {
    ///         var resultParams = new DialogParameters();
    ///         resultParams.Add("InputValue", txtInput.Text);
    ///         CloseDialog(ButtonResult.OK, resultParams);
    ///     }
    ///     
    ///     private void btnCancel_Click(object sender, EventArgs e)
    ///     {
    ///         CloseDialog(ButtonResult.Cancel);
    ///     }
    /// }
    /// </code>
    /// </para>
    /// </remarks>
    public abstract class DialogBase : UserControl, IDialogAware
    {
        private string _title;

        /// <inheritdoc />
        [Browsable(true)]
        [Category("��ܮ�")]
        [Description("��ܮؼ��D�C")]
        public string Title
        {
            get => _title;
            set => _title = value;
        }

        /// <inheritdoc />
        public event EventHandler<DialogCloseRequestedEventArgs> CloseRequested;

        /// <summary>
        /// ��l�ƹ�ܮذ����O�C
        /// </summary>
        protected DialogBase()
        {
            _title = string.Empty;
        }

        /// <inheritdoc />
        public void OnDialogOpened(IDialogParameters parameters)
        {
            OnDialogOpenedCore(parameters ?? new DialogParameters());
        }

        /// <inheritdoc />
        public virtual bool CanCloseDialog()
        {
            return true;
        }

        /// <inheritdoc />
        public void OnDialogClosed()
        {
            OnDialogClosedCore();
        }

        /// <summary>
        /// ����ܮض}�ҮɩI�s�A�l���O�i�мg����k�i���l�ơC
        /// </summary>
        /// <param name="parameters">��ܮذѼơC</param>
        protected virtual void OnDialogOpenedCore(IDialogParameters parameters)
        {
        }

        /// <summary>
        /// ����ܮ������ɩI�s�A�l���O�i�мg����k�i��M�z�C
        /// </summary>
        protected virtual void OnDialogClosedCore()
        {
        }

        /// <summary>
        /// �ШD������ܮءC
        /// </summary>
        /// <param name="result">���G�����C</param>
        protected void CloseDialog(ButtonResult result)
        {
            CloseDialog(result, null);
        }

        /// <summary>
        /// �ШD������ܮء]�t�Ѽơ^�C
        /// </summary>
        /// <param name="result">���G�����C</param>
        /// <param name="parameters">��^�ѼơC</param>
        protected void CloseDialog(ButtonResult result, IDialogParameters parameters)
        {
            var dialogResult = new DialogResult(result, parameters);
            CloseRequested?.Invoke(this, new DialogCloseRequestedEventArgs(dialogResult));
        }

        /// <summary>
        /// �ШD������ܮء]�ϥ� IDialogResult�^�C
        /// </summary>
        /// <param name="dialogResult">��ܮص��G�C</param>
        protected void CloseDialog(IDialogResult dialogResult)
        {
            CloseRequested?.Invoke(this, new DialogCloseRequestedEventArgs(dialogResult));
        }
    }
}
