namespace Calin.WinForm.Framework.Dialog
{
    /// <summary>
    /// ��ܮص��G�����C
    /// </summary>
    public enum ButtonResult
    {
        /// <summary>
        /// �L���G�C
        /// </summary>
        None = 0,

        /// <summary>
        /// �T�{�C
        /// </summary>
        OK = 1,

        /// <summary>
        /// �����C
        /// </summary>
        Cancel = 2,

        /// <summary>
        /// �O�C
        /// </summary>
        Yes = 3,

        /// <summary>
        /// �_�C
        /// </summary>
        No = 4,

        /// <summary>
        /// ���աC
        /// </summary>
        Retry = 5,

        /// <summary>
        /// �����C
        /// </summary>
        Ignore = 6,

        /// <summary>
        /// ����C
        /// </summary>
        Abort = 7
    }

    /// <summary>
    /// ��ܮت�^���G�����C
    /// </summary>
    /// <remarks>
    /// <para>�ʸ˹�ܮت�^���G�A�䴩�h�ص��G�����C</para>
    /// <para>
    /// �ϥνd�ҡG
    /// <code>
    /// var result = dialogService.ShowDialog&lt;ConfirmDialog&gt;(parameters);
    /// if (result.Result == ButtonResult.OK)
    /// {
    ///     var data = result.Parameters.GetValue&lt;string&gt;("SelectedItem");
    /// }
    /// </code>
    /// </para>
    /// </remarks>
    public interface IDialogResult
    {
        /// <summary>
        /// ���o��ܮص��G�C
        /// </summary>
        ButtonResult Result { get; }

        /// <summary>
        /// ���o��ܮت�^���ѼơC
        /// </summary>
        IDialogParameters Parameters { get; }
    }

    /// <summary>
    /// ��ܮت�^���G��@�C
    /// </summary>
    public class DialogResult : IDialogResult
    {
        /// <inheritdoc />
        public ButtonResult Result { get; }

        /// <inheritdoc />
        public IDialogParameters Parameters { get; }

        /// <summary>
        /// ��l�ƹ�ܮت�^���G�C
        /// </summary>
        /// <param name="result">���G�����C</param>
        public DialogResult(ButtonResult result)
            : this(result, new DialogParameters())
        {
        }

        /// <summary>
        /// ��l�ƹ�ܮت�^���G�C
        /// </summary>
        /// <param name="result">���G�����C</param>
        /// <param name="parameters">��^�ѼơC</param>
        public DialogResult(ButtonResult result, IDialogParameters parameters)
        {
            Result = result;
            Parameters = parameters ?? new DialogParameters();
        }

        /// <summary>
        /// �إ߽T�{���G�C
        /// </summary>
        public static IDialogResult OK() => new DialogResult(ButtonResult.OK);

        /// <summary>
        /// �إ߽T�{���G�]�t�Ѽơ^�C
        /// </summary>
        public static IDialogResult OK(IDialogParameters parameters) => new DialogResult(ButtonResult.OK, parameters);

        /// <summary>
        /// �إߨ������G�C
        /// </summary>
        public static IDialogResult Cancel() => new DialogResult(ButtonResult.Cancel);

        /// <summary>
        /// �إߨ������G�]�t�Ѽơ^�C
        /// </summary>
        public static IDialogResult Cancel(IDialogParameters parameters) => new DialogResult(ButtonResult.Cancel, parameters);

        /// <summary>
        /// �إߡu�O�v���G�C
        /// </summary>
        public static IDialogResult Yes() => new DialogResult(ButtonResult.Yes);

        /// <summary>
        /// �إߡu�_�v���G�C
        /// </summary>
        public static IDialogResult No() => new DialogResult(ButtonResult.No);
    }
}
