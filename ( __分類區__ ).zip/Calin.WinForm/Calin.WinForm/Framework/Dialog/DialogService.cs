using System;
using System.Collections.Concurrent;
using System.Windows.Forms;
using Autofac;

namespace Calin.Framework.Dialog
{
    /// <summary>
    /// ��ܮتA�ȹ�@�C
    /// </summary>
    public class DialogService : IDialogService
    {
        private readonly ILifetimeScope _lifetimeScope;
        private readonly IDialogWindowFactory _windowFactory;

        // �l�ܫD�ҺA��ܮ�
        private readonly ConcurrentDictionary<IDialogWindow, ILifetimeScope> _modelessDialogs = new ConcurrentDictionary<IDialogWindow, ILifetimeScope>();

        /// <summary>
        /// ��l�ƹ�ܮتA�ȡC
        /// </summary>
        /// <param name="lifetimeScope">Autofac �ͩR�g���d��C</param>
        /// <param name="windowFactory">��ܮص����u�t�C</param>
        public DialogService(ILifetimeScope lifetimeScope, IDialogWindowFactory windowFactory)
        {
            _lifetimeScope = lifetimeScope ?? throw new ArgumentNullException(nameof(lifetimeScope));
            _windowFactory = windowFactory ?? throw new ArgumentNullException(nameof(windowFactory));
        }

        /// <inheritdoc />
        public IDialogResult ShowDialog<TDialog>(IDialogParameters parameters = null) where TDialog : class, IDialogAware
        {
            return ShowDialog<TDialog>(null, parameters);
        }

        /// <inheritdoc />
        public IDialogResult ShowDialog(Type dialogType, IDialogParameters parameters = null)
        {
            return ShowDialogInternal(dialogType, null, parameters);
        }

        /// <inheritdoc />
        public IDialogResult ShowDialog<TDialog>(object owner, IDialogParameters parameters = null) where TDialog : class, IDialogAware
        {
            return ShowDialogInternal(typeof(TDialog), owner, parameters);
        }

        /// <inheritdoc />
        public void ShowModeless<TDialog>(IDialogParameters parameters = null, Action<IDialogResult> callback = null) where TDialog : class, IDialogAware
        {
            ShowModeless<TDialog>(null, parameters, callback);
        }

        /// <inheritdoc />
        public void ShowModeless(Type dialogType, IDialogParameters parameters = null, Action<IDialogResult> callback = null)
        {
            ShowModelessInternal(dialogType, null, parameters, callback);
        }

        /// <inheritdoc />
        public void ShowModeless<TDialog>(object owner, IDialogParameters parameters = null, Action<IDialogResult> callback = null) where TDialog : class, IDialogAware
        {
            ShowModelessInternal(typeof(TDialog), owner, parameters, callback);
        }

        /// <inheritdoc />
        public ButtonResult ShowMessage(string message, string title = null, MessageDialogButtons buttons = MessageDialogButtons.OK)
        {
            var messageBoxButtons = ConvertToMessageBoxButtons(buttons);
            var result = MessageBox.Show(message, title ?? string.Empty, messageBoxButtons);

            return ConvertToButtonResult(result);
        }

        /// <inheritdoc />
        public bool ShowConfirm(string message, string title = null)
        {
            var result = ShowMessage(message, title ?? "�T�{", MessageDialogButtons.YesNo);
            return result == ButtonResult.Yes;
        }

        /// <summary>
        /// ��ܼҺA��ܮت�������@�C
        /// </summary>
        private IDialogResult ShowDialogInternal(Type dialogType, object owner, IDialogParameters parameters)
        {
            if (dialogType == null)
                throw new ArgumentNullException(nameof(dialogType));

            IDialogResult dialogResult = new DialogResult(ButtonResult.None);
            ILifetimeScope scope = null;

            try
            {
                // �إ� LifetimeScope �øѪR��ܮ�
                scope = _lifetimeScope.BeginLifetimeScope();
                var dialogContent = scope.Resolve(dialogType) as IDialogAware;

                if (dialogContent == null)
                {
                    throw new InvalidOperationException($"���� {dialogType.Name} ����@ IDialogAware �����C");
                }

                // �إ߹�ܮص���
                var dialogWindow = _windowFactory.CreateDialogWindow();
                dialogWindow.Content = dialogContent;
                dialogWindow.Owner = owner;

                // �]�w���D
                if (!string.IsNullOrEmpty(dialogContent.Title))
                {
                    dialogWindow.Title = dialogContent.Title;
                }

                // �q�\�����ШD�ƥ�
                dialogContent.CloseRequested += (s, e) =>
                {
                    if (dialogContent.CanCloseDialog())
                    {
                        dialogWindow.Result = e.DialogResult;
                        dialogWindow.Close();
                    }
                };

                // �q����ܮؤw�}��
                dialogContent.OnDialogOpened(parameters ?? new DialogParameters());

                // ��ܹ�ܮ�
                dialogResult = dialogWindow.ShowDialog();

                // �q����ܮؤw����
                dialogContent.OnDialogClosed();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                scope?.Dispose();
            }

            return dialogResult ?? new DialogResult(ButtonResult.None);
        }

        /// <summary>
        /// ��ܫD�ҺA��ܮت�������@�C
        /// </summary>
        private void ShowModelessInternal(Type dialogType, object owner, IDialogParameters parameters, Action<IDialogResult> callback)
        {
            if (dialogType == null)
                throw new ArgumentNullException(nameof(dialogType));

            try
            {
                // �إ� LifetimeScope �øѪR��ܮ�
                var scope = _lifetimeScope.BeginLifetimeScope();
                var dialogContent = scope.Resolve(dialogType) as IDialogAware;

                if (dialogContent == null)
                {
                    scope.Dispose();
                    throw new InvalidOperationException($"���� {dialogType.Name} ����@ IDialogAware �����C");
                }

                // �إ߹�ܮص���
                var dialogWindow = _windowFactory.CreateDialogWindow();
                dialogWindow.Content = dialogContent;
                dialogWindow.Owner = owner;

                // �]�w���D
                if (!string.IsNullOrEmpty(dialogContent.Title))
                {
                    dialogWindow.Title = dialogContent.Title;
                }

                // �l�ܫD�ҺA��ܮ�
                _modelessDialogs[dialogWindow] = scope;

                // �q�\�����ШD�ƥ�
                dialogContent.CloseRequested += (s, e) =>
                {
                    if (dialogContent.CanCloseDialog())
                    {
                        dialogWindow.Result = e.DialogResult;
                        dialogWindow.Close();
                    }
                };

                // �q�\���������ƥ�
                dialogWindow.Closed += (s, e) =>
                {
                    dialogContent.OnDialogClosed();

                    var result = dialogWindow.Result ?? new DialogResult(ButtonResult.None);

                    // ����^�I
                    callback?.Invoke(result);

                    // �M�z�귽
                    if (_modelessDialogs.TryRemove(dialogWindow, out var removedScope))
                    {
                        removedScope.Dispose();
                    }

                    dialogWindow.Dispose();
                };

                // �q����ܮؤw�}��
                dialogContent.OnDialogOpened(parameters ?? new DialogParameters());

                // ��ܫD�ҺA��ܮ�
                dialogWindow.Show();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// �ഫ�� MessageBoxButtons�C
        /// </summary>
        private MessageBoxButtons ConvertToMessageBoxButtons(MessageDialogButtons buttons)
        {
            switch (buttons)
            {
                case MessageDialogButtons.OK:
                    return MessageBoxButtons.OK;
                case MessageDialogButtons.OKCancel:
                    return MessageBoxButtons.OKCancel;
                case MessageDialogButtons.YesNo:
                    return MessageBoxButtons.YesNo;
                case MessageDialogButtons.YesNoCancel:
                    return MessageBoxButtons.YesNoCancel;
                case MessageDialogButtons.RetryCancel:
                    return MessageBoxButtons.RetryCancel;
                case MessageDialogButtons.AbortRetryIgnore:
                    return MessageBoxButtons.AbortRetryIgnore;
                default:
                    return MessageBoxButtons.OK;
            }
        }

        /// <summary>
        /// �ഫ DialogResult �� ButtonResult�C
        /// </summary>
        private ButtonResult ConvertToButtonResult(System.Windows.Forms.DialogResult result)
        {
            switch (result)
            {
                case System.Windows.Forms.DialogResult.OK:
                    return ButtonResult.OK;
                case System.Windows.Forms.DialogResult.Cancel:
                    return ButtonResult.Cancel;
                case System.Windows.Forms.DialogResult.Yes:
                    return ButtonResult.Yes;
                case System.Windows.Forms.DialogResult.No:
                    return ButtonResult.No;
                case System.Windows.Forms.DialogResult.Retry:
                    return ButtonResult.Retry;
                case System.Windows.Forms.DialogResult.Ignore:
                    return ButtonResult.Ignore;
                case System.Windows.Forms.DialogResult.Abort:
                    return ButtonResult.Abort;
                default:
                    return ButtonResult.None;
            }
        }
    }
}
