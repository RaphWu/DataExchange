using System;
using System.Collections.Concurrent;
using System.Reflection;
using Autofac;
using Calin.WinForm.Service;

namespace Calin.WinForm.Framework.Navigation
{
    /// <summary>
    /// �ɯ�A�ȹ�@�A���Ѹ� Region ���Τ@�����ɯ�C
    /// </summary>
    public class NavigationService : INavigationService
    {
        private readonly IRegionManager _regionManager;
        private readonly ILifetimeScope _lifetimeScope;
        private readonly IWinForm _winForm;

        // �֨� IsAlive = true �� View ���
        private readonly ConcurrentDictionary<Type, object> _aliveViewCache = new ConcurrentDictionary<Type, object>();

        // �l�� View ������ LifetimeScope�]�Ω� IsAlive = false �� View�^
        private readonly ConcurrentDictionary<object, ILifetimeScope> _viewScopes = new ConcurrentDictionary<object, ILifetimeScope>();

        /// <summary>
        /// ��l�ƾɯ�A�ȡC
        /// </summary>
        /// <param name="regionManager">Region �޲z���C</param>
        /// <param name="lifetimeScope">Autofac �ͩR�g���d��C</param>
        /// <param name="winForm">WinForm �A�ȡC</param>
        public NavigationService(IRegionManager regionManager, ILifetimeScope lifetimeScope, IWinForm winForm)
        {
            _regionManager = regionManager ?? throw new ArgumentNullException(nameof(regionManager));
            _lifetimeScope = lifetimeScope ?? throw new ArgumentNullException(nameof(lifetimeScope));
            _winForm = winForm ?? throw new ArgumentNullException(nameof(winForm));
        }

        /// <inheritdoc />
        public NavigationResult NavigateTo<TView>(string regionName, int pageId, INavigationParameters parameters = null) where TView : class
        {
            return NavigateTo(typeof(TView), regionName, pageId, parameters);
        }

        /// <inheritdoc />
        public NavigationResult NavigateTo(Type viewType, string regionName, int pageId, INavigationParameters parameters = null)
        {
            if (viewType == null)
                return NavigationResult.Failed("View �������i�� null�C");

            if (string.IsNullOrEmpty(regionName))
                return NavigationResult.Failed("Region �W�٤��i���šC");

            try
            {
                var region = _regionManager.GetRegion(regionName);
                if (region == null)
                {
                    return NavigationResult.Failed($"Region '{regionName}' ���s�b�C");
                }

                parameters = parameters ?? new NavigationParameters();

                // �ˬd�ثe View �O�_���\���}
                if (!CanNavigateFrom(region.ActiveView, parameters))
                {
                    _winForm.SetError(1, $"�ɯ�Q�ثe View ����: {regionName}", $"{nameof(NavigationService)}.{nameof(NavigateTo)}");
                    return NavigationResult.Failed("�ɯ�Q�ثe���������C");
                }

                // �q���ثe View �Y�N���}
                NotifyNavigatedFrom(region.ActiveView, parameters);

                // ���o�Ϋإ߷s�� View
                var view = ResolveView(viewType);

                // �Ұʷs View
                region.Activate(view, pageId);

                // �O���ɯ���v
                var entry = new NavigationJournalEntry(pageId, viewType, parameters);
                region.NavigationJournal.RecordNavigation(entry);

                // �q���s View �w�ɯ��
                NotifyNavigatedTo(view, parameters);

                _winForm.ClearErr();
                return NavigationResult.Succeeded();
            }
            catch (Exception ex)
            {
                _winForm.SetError(1, $"�ɯ襢��: {regionName} -> {viewType?.Name}", $"{nameof(NavigationService)}.{nameof(NavigateTo)}");
                return NavigationResult.Failed(ex);
            }
        }

        /// <inheritdoc />
        public NavigationResult GoBack(string regionName, INavigationParameters parameters = null)
        {
            if (string.IsNullOrEmpty(regionName))
                return NavigationResult.Failed("Region �W�٤��i���šC");

            try
            {
                var region = _regionManager.GetRegion(regionName);
                if (region == null)
                {
                    return NavigationResult.Failed($"Region '{regionName}' ���s�b�C");
                }

                if (!region.NavigationJournal.CanGoBack)
                {
                    return NavigationResult.Failed("�L�k��h�A�w�b���v�������_�l��m�C");
                }

                parameters = parameters ?? new NavigationParameters();

                // �ˬd�ثe View �O�_���\���}
                if (!CanNavigateFrom(region.ActiveView, parameters))
                {
                    return NavigationResult.Failed("�ɯ�Q�ثe���������C");
                }

                // �q���ثe View �Y�N���}
                NotifyNavigatedFrom(region.ActiveView, parameters);

                // ���o�W�@�Ӷ���
                var entry = region.NavigationJournal.GoBack();

                // ���o�Ϋإ� View
                var view = ResolveView(entry.ViewType);

                // �Ұ� View
                region.Activate(view, entry.PageId);

                // �X�ְѼ�
                var mergedParameters = MergeParameters(entry.Parameters, parameters);

                // �q���s View �w�ɯ��
                NotifyNavigatedTo(view, mergedParameters);

                _winForm.ClearErr();
                return NavigationResult.Succeeded();
            }
            catch (Exception ex)
            {
                _winForm.SetError(1, $"��h����: {regionName}", $"{nameof(NavigationService)}.{nameof(GoBack)}");
                return NavigationResult.Failed(ex);
            }
        }

        /// <inheritdoc />
        public NavigationResult GoForward(string regionName, INavigationParameters parameters = null)
        {
            if (string.IsNullOrEmpty(regionName))
                return NavigationResult.Failed("Region �W�٤��i���šC");

            try
            {
                var region = _regionManager.GetRegion(regionName);
                if (region == null)
                {
                    return NavigationResult.Failed($"Region '{regionName}' ���s�b�C");
                }

                if (!region.NavigationJournal.CanGoForward)
                {
                    return NavigationResult.Failed("�L�k�e�i�A�w�b���v�������̫��m�C");
                }

                parameters = parameters ?? new NavigationParameters();

                // �ˬd�ثe View �O�_���\���}
                if (!CanNavigateFrom(region.ActiveView, parameters))
                {
                    return NavigationResult.Failed("�ɯ�Q�ثe���������C");
                }

                // �q���ثe View �Y�N���}
                NotifyNavigatedFrom(region.ActiveView, parameters);

                // ���o�U�@�Ӷ���
                var entry = region.NavigationJournal.GoForward();

                // ���o�Ϋإ� View
                var view = ResolveView(entry.ViewType);

                // �Ұ� View
                region.Activate(view, entry.PageId);

                // �X�ְѼ�
                var mergedParameters = MergeParameters(entry.Parameters, parameters);

                // �q���s View �w�ɯ��
                NotifyNavigatedTo(view, mergedParameters);

                _winForm.ClearErr();
                return NavigationResult.Succeeded();
            }
            catch (Exception ex)
            {
                _winForm.SetError(1, $"�e�i����: {regionName}", $"{nameof(NavigationService)}.{nameof(GoForward)}");
                return NavigationResult.Failed(ex);
            }
        }

        /// <inheritdoc />
        public bool CanGoBack(string regionName)
        {
            var region = _regionManager.GetRegion(regionName);
            return region?.NavigationJournal.CanGoBack ?? false;
        }

        /// <inheritdoc />
        public bool CanGoForward(string regionName)
        {
            var region = _regionManager.GetRegion(regionName);
            return region?.NavigationJournal.CanGoForward ?? false;
        }

        /// <inheritdoc />
        public int? GetActivePageId(string regionName)
        {
            return _regionManager.GetActivePageId(regionName);
        }

        /// <inheritdoc />
        public object GetActiveView(string regionName)
        {
            var region = _regionManager.GetRegion(regionName);
            return region?.ActiveView;
        }

        /// <inheritdoc />
        public void ReleaseView(object view)
        {
            if (view == null)
                return;

            var viewType = view.GetType();

            // �q�֨�����
            _aliveViewCache.TryRemove(viewType, out _);

            // ���� LifetimeScope
            if (_viewScopes.TryRemove(view, out var scope))
            {
                scope.Dispose();
            }

            // �p�G View ��@ IDisposable�A�]����
            if (view is IDisposable disposable)
            {
                disposable.Dispose();
            }
        }

        /// <summary>
        /// �ѪR�Ϋإ� View ��ҡC
        /// </summary>
        private object ResolveView(Type viewType)
        {
            var isAlive = GetIsAlive(viewType);

            if (isAlive)
            {
                // �q�֨����o�Ϋإ߷s��
                return _aliveViewCache.GetOrAdd(viewType, type =>
                {
                    return _lifetimeScope.Resolve(type);
                });
            }
            else
            {
                // �إ߷s�� LifetimeScope �øѪR View
                var scope = _lifetimeScope.BeginLifetimeScope();
                var view = scope.Resolve(viewType);
                _viewScopes[view] = scope;

                return view;
            }
        }

        /// <summary>
        /// ���o View �� IsAlive �]�w�C
        /// </summary>
        private bool GetIsAlive(Type viewType)
        {
            var attribute = viewType.GetCustomAttribute<ViewLifetimeAttribute>();
            return attribute?.IsAlive ?? false;
        }

        /// <summary>
        /// �ˬd�O�_�i�H�q�ثe View �ɯ����}�C
        /// </summary>
        private bool CanNavigateFrom(object view, INavigationParameters parameters)
        {
            if (view is INavigationAware aware)
            {
                return aware.OnNavigatingFrom(parameters);
            }
            return true;
        }

        /// <summary>
        /// �q�� View �w�ɯ����}�C
        /// </summary>
        private void NotifyNavigatedFrom(object view, INavigationParameters parameters)
        {
            if (view is INavigationAware aware)
            {
                aware.OnNavigatedFrom(parameters);
            }
        }

        /// <summary>
        /// �q�� View �w�ɯ�ܡC
        /// </summary>
        private void NotifyNavigatedTo(object view, INavigationParameters parameters)
        {
            if (view is INavigationAware aware)
            {
                aware.OnNavigatedTo(parameters);
            }
        }

        /// <summary>
        /// �X�־ɯ�ѼơC
        /// </summary>
        private INavigationParameters MergeParameters(INavigationParameters original, INavigationParameters additional)
        {
            var merged = new NavigationParameters();

            if (original != null)
            {
                foreach (var key in original.Keys)
                {
                    merged.Add(key, original.GetValue<object>(key));
                }
            }

            if (additional != null)
            {
                foreach (var key in additional.Keys)
                {
                    merged.Add(key, additional.GetValue<object>(key));
                }
            }

            return merged;
        }
    }
}
