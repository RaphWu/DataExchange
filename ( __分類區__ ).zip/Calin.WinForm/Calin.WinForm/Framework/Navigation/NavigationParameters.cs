using System;
using System.Collections.Generic;

namespace Calin.Framework.Navigation
{
    /// <summary>
    /// �ɯ�Ѽƹ�@�C
    /// </summary>
    public class NavigationParameters : INavigationParameters
    {
        private readonly Dictionary<string, object> _parameters = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// ��l�ƾɯ�ѼơC
        /// </summary>
        public NavigationParameters()
        {
        }

        /// <summary>
        /// �ϥβ{���r���l�ƾɯ�ѼơC
        /// </summary>
        /// <param name="parameters">�ѼƦr��C</param>
        public NavigationParameters(IDictionary<string, object> parameters)
        {
            if (parameters != null)
            {
                foreach (var kvp in parameters)
                {
                    _parameters[kvp.Key] = kvp.Value;
                }
            }
        }

        /// <inheritdoc />
        public void Add(string key, object value)
        {
            if (string.IsNullOrEmpty(key))
                throw new ArgumentNullException(nameof(key));

            _parameters[key] = value;
        }

        /// <inheritdoc />
        public T GetValue<T>(string key)
        {
            if (TryGetValue<T>(key, out var value))
            {
                return value;
            }

            return default;
        }

        /// <inheritdoc />
        public bool TryGetValue<T>(string key, out T value)
        {
            value = default;

            if (string.IsNullOrEmpty(key))
                return false;

            if (!_parameters.TryGetValue(key, out var obj))
                return false;

            if (obj == null)
            {
                value = default;
                return true;
            }

            if (obj is T typedValue)
            {
                value = typedValue;
                return true;
            }

            try
            {
                value = (T)Convert.ChangeType(obj, typeof(T));
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <inheritdoc />
        public bool ContainsKey(string key)
        {
            if (string.IsNullOrEmpty(key))
                return false;

            return _parameters.ContainsKey(key);
        }

        /// <inheritdoc />
        public IEnumerable<string> Keys => _parameters.Keys;

        /// <inheritdoc />
        public int Count => _parameters.Count;

        /// <summary>
        /// ���o�γ]�w�ѼƭȡC
        /// </summary>
        /// <param name="key">�Ѽ���C</param>
        /// <returns>�ѼƭȡC</returns>
        public object this[string key]
        {
            get => _parameters.TryGetValue(key, out var value) ? value : null;
            set => _parameters[key] = value;
        }
    }
}
