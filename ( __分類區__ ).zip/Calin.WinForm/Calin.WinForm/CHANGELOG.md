﻿# Calin.WinForm

## 2026-01-13 v0.0.3

- 所以共用模組的版本號重新編排
- 合併 TaskPulse V1 建立的基礎架構庫
	- 合併 Extensions 及 Helpers 的函數庫
	- 新璔 Calin.CSharp.Infrastructure.Dialogs;
	- 新璔 Calin.CSharp.Infrastructure.Navigation;


# 2026-01-08 v0.0.2

- 新增 Navigation
- NuGet 新增依賴 AutoFac、Serilog
- 補充 README 文件

