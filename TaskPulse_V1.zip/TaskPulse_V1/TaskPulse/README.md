﻿# TaskPulse 專案說明檔

TaskPulse 是工具/設計課的任務管理系統，旨在提升生產效率和協作能力。此專案包含多個模組，每個模組負責不同的功能範疇。

# 模組說明

- **Calin.TaskPulse.Entity**：資料實體模組，定義資料庫的實體結構。
- **Calin.TaskPulse.Core**：核心模組，包含主要的商業邏輯、服務及共用元件。
- **Calin.TaskPulse.MaintiFlow**：維護流程模組，管理維護相關的工作流程。
- **Calin.TaskPulse.MechaTrack**：
- **Calin.TaskPulse.ToolQuest**：
- **Calin.TaskPulse**：啟動模組，負責應用程式的啟動和配置，以及整合其他模組。

```mermaid
classDiagram
    Calin.TaskPulse.Entity <|-- Calin.TaskPulse.Core
    Calin.TaskPulse.Core <|-- Calin.TaskPulse.MaintiFlow
    Calin.TaskPulse.Core <|-- Calin.TaskPulse.MechaTrack
    Calin.TaskPulse.Core <|-- Calin.TaskPulse.ToolQuest
    Calin.TaskPulse.Core <|-- Calin.TaskPulse
    Calin.TaskPulse.MaintiFlow <|-- Calin.TaskPulse
    Calin.TaskPulse.MechaTrack <|-- Calin.TaskPulse
    Calin.TaskPulse.ToolQuest <|-- Calin.TaskPulse
    
    Calin.TaskPulse.Entity : CoreContext
    Calin.TaskPulse.Entity : MaintiFlowContext
```

# 目標框架

- 所有模組均以 .NET Framework 4.6.2 為目標框架。<br>(注意：若要升級至更新版本，請確保產線與各辦公室使用的電腦均支援該版本)

# NuGet 套件

此處所列的 NuGet 套件為各模組均需安裝的共同套件，各模組各自所需的套件列表請參閱各模組的 README 檔案。

- Serilog
- AutoFac (Calin.TaskPulse.Entity 模組不需要)
- CommunityToolkit.Mvvm
- SunnyUI (Calin.TaskPulse.Entity 模組不需要)

# 程式啟動流程說明

```mermaid
flowchart TD

    A[啟動應用程式<br>Program.cs] --> B[顯示啟動畫面<br>SplashScreen]
    B --> C[初始化日誌服務<br>LoggingBootstrapper]
    C --> D[初始化核心模組<br>ContainerBuilder]
    D --> E[顯示主畫面<br>MainForm]
```