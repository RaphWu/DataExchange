﻿using Calin.Framework.Coordination;

namespace Calin.TaskPulse.Coordination
{
    public static class MaintiFlowTaskKeys
    {
        public static readonly TaskKey WorkOrderUpdate = new TaskKey("TaskPulse.MaintiFlow.WorkOrderUpdate");
    }
}
