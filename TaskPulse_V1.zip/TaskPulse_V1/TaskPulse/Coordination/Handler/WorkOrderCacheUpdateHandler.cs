﻿using System.Threading.Tasks;
using Calin.Framework.Coordination;
using Calin.TaskPulse.MaintiFlow.Service;

namespace Calin.TaskPulse.Coordination.Handler
{
    public class WorkOrderCacheUpdateHandler : TaskHandlerBase<CacheUpdateRequest>
    {
        private readonly IMaintiFlow _maintiFlow;

        public override TaskKey TaskKey => MaintiFlowTaskKeys.WorkOrderUpdate;

        public WorkOrderCacheUpdateHandler(IMaintiFlow maintiFlow)
        {
            _maintiFlow = maintiFlow;
        }

        protected override async Task ExecuteAsync(ITaskExecutionContext context, CacheUpdateRequest request)
        {
            await _maintiFlow.UpdateWorkOrdersCacheAsync();
        }
    }
}
