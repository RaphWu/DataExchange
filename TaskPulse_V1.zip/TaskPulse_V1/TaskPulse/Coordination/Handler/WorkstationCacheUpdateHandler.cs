﻿using System.Threading.Tasks;
using Calin.Framework.Coordination;
using Calin.TaskPulse.Core.Services;

namespace Calin.TaskPulse.Coordination.Handler
{
    public class WorkstationCacheUpdateHandler : TaskHandlerBase<CacheUpdateRequest>
    {
        private readonly ICore _core;

        public override TaskKey TaskKey => CoreTaskKeys.WorkstationUpdate;

        public WorkstationCacheUpdateHandler(ICore core)
        {
            _core = core;
        }

        protected override async Task ExecuteAsync(ITaskExecutionContext context, CacheUpdateRequest request)
        {
            await _core.UpdateWorkstationsCacheAsync();
        }
    }
}
