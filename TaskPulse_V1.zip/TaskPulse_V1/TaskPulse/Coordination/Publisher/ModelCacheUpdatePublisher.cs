﻿using System.Threading.Tasks;
using Calin.Framework.Coordination;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Services;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Coordination.Publisher
{
    public class ModelCacheUpdatePublisher : ISelectiveResultPublisher
    {
        private readonly ICore _core;

        public string TargetName => nameof(ModelCacheUpdatePublisher);

        public ModelCacheUpdatePublisher(ICore core)
        {
            _core = core;
        }

        public async Task PublishAsync(TaskKey taskKey, ICoordinationResult result)
        {
            await _core.UpdateModelsCacheAsync();
        }
    }
}
