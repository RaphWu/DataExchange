﻿using System.Threading.Tasks;
using Calin.Framework.Coordination;
using Calin.TaskPulse.Core.Services;

namespace Calin.TaskPulse.Coordination.Publisher
{
    public class EmployeeCacheUpdatePublisher : ISelectiveResultPublisher
    {
        private readonly ICore _core;

        public string TargetName => nameof(EmployeeCacheUpdatePublisher);

        public EmployeeCacheUpdatePublisher(ICore core)
        {
            _core = core;
        }

        public async Task PublishAsync(TaskKey taskKey, ICoordinationResult result)
        {
            await _core.UpdateEmployeesCacheAsync();
        }
    }
}
