﻿using System.Threading.Tasks;
using Calin.Framework.Coordination;
using Calin.TaskPulse.MaintiFlow.Service;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Coordination.Publisher
{
    public class WorkOrderCacheUpdatePublisher : ISelectiveResultPublisher
    {
        private IMaintiFlow _maintiFlow;

        public string TargetName => nameof(WorkOrderCacheUpdatePublisher);

        public WorkOrderCacheUpdatePublisher(IMaintiFlow maintiFlow)
        {
            _maintiFlow = maintiFlow;
        }

        public async Task PublishAsync(TaskKey taskKey, ICoordinationResult result)
        {
            await _maintiFlow.UpdateWorkOrdersCacheAsync();
        }
    }
}
