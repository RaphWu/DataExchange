﻿using System.Collections.Generic;
using Calin.Framework.Coordination;

namespace Calin.TaskPulse.Coordination
{
    public class CacheUpdateMappingStrategy : TaskMappingStrategyBase<CacheUpdateRequest>
    {
        protected override IEnumerable<TaskKey> GetRequiredTasks(CacheUpdateRequest request)
        {
            return request.RequiredTaskKeys;
        }
    }
}
