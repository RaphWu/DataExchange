﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Autofac;
using Calin.Framework.Navigation;
using Calin.Infrastructure.Helper;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Permission;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.Core.WinForms;
using Calin.TaskPulse.MaintiFlow.Views;
using Calin.TaskPulse.MechaTrack.Views;
using Calin.TaskPulse.ToolQuest.Views;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Views
{
    public partial class MainForm : UIForm
    {
        #region fields

        private readonly Serilog.ILogger _logger;
        private readonly ILifetimeScope _scope;
        private readonly IRegionManager _region;
        private readonly INavigationService _nav;
        private readonly CurrentUserContext _user;
        private readonly ICurrentUserService _currentUser;
        private readonly IPermissionService _permission;

        // 鍵盤與滑鼠掛鉤
#pragma warning disable IDE0044 // 新增唯讀修飾元
        private const int WH_KEYBOARD_LL = 13; // 全局鍵盤掛鉤
        private const int WH_MOUSE_LL = 14;    // 全局滑鼠掛鉤

        private IntPtr _keyboardHookId = IntPtr.Zero;
        private IntPtr _mouseHookId = IntPtr.Zero;

        private delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);

        private HookProc _keyboardProc;
        private HookProc _mouseProc;
#pragma warning restore IDE0044 // 新增唯讀修飾元

        [DllImport("user32.dll")]
        private static extern IntPtr SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll")]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll")]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        // 目前頁面及有效選單
        private PageCode _currentPageCode = PageCode.None;
        private HashSet<PageCode> _availablePageCode = new HashSet<PageCode>();

        // 計時器
        private readonly System.Windows.Forms.Timer _messageTimer = new Timer(); // 狀態列訊息計時器，定時清除訊息
        private readonly System.Windows.Forms.Timer _idleTimer = new Timer(); // 無動作計時器
        private bool _idleTriggered = false; // 是否已經觸發過

        #endregion fields

        public MainForm(
            Serilog.ILogger logger,
            ILifetimeScope lifetimeScope,
            IRegionManager regionManager,
            INavigationService navigationService,
            CurrentUserContext currentUserContext,
            ICurrentUserService currentUserService,
            IPermissionService permissionService
            )
        {
            InitializeComponent();

            _logger = logger;
            _scope = lifetimeScope;
            _region = regionManager;
            _nav = navigationService;
            _user = currentUserContext;
            _currentUser = currentUserService;
            _permission = permissionService;

            // 註冊頁面顯示區域
            _region.RegisterRegion(nameof(MainRegion), view =>
            {
                MainRegion.Controls.Clear();
                if (view is Control control)
                {
                    control.Dock = DockStyle.Fill;
                    MainRegion.Controls.Add(control);
                }
            });

            SBMessage.Text = "";
            ProgressBar.ShowValue = false;
            ProgressBar.Value = 0;
            DbInfo.Text = "";

            UISettings.ApplyGlobalFont(this);
            CommonStyles.SetStyles();
            ResizeScreen();

            //CustomizeTreeNodeColors(rNavBar.Menu);
            //CustomizeTreeNodeColors(lNavBar.Menu);
            rNavBar.MenuHoverColor = CommonStyles.HoverColor;
            lNavBar.MenuHoverColor = CommonStyles.HoverColor;

            // 固定的選單 (設定)
            const string userMenuName = "userMenuItem";
            int pageIndex = (int)PageCode.User;
            TreeNode node1 = rNavBar.CreateNode(PageCode.User.GetDescription(), pageIndex);
            rNavBar.SetNodePageIndex(node1, pageIndex);
            rNavBar.SetNodeSymbol(node1, 361459);
            node1.Name = userMenuName;
            node1.Tag = pageIndex;

            _messageTimer.Interval = 5000; // 5 秒後清除訊息
            _messageTimer.Tick += (s, e) =>
            {
                SBMessage.Text = "";
                _messageTimer.Stop();
            };

            _idleTimer = new Timer { Interval = 5000 }; // for Debug
            _idleTimer = _user.IsAdmin
                ? new Timer { Interval = 120 * 60 * 1000 } // 120 分鐘
                : new Timer { Interval = 30 * 60 * 1000 }; // 30 分鐘
            _idleTimer.Tick += IdleTimer_Tick;
            _idleTimer.Start();

#if !DEBUG && !OFFLINE
            // 鍵盤與滑鼠掛鉤
            _keyboardProc = KeyboardHookCallback;
            _mouseProc = MouseHookCallback;

            _keyboardHookId = SetHook(WH_KEYBOARD_LL, _keyboardProc);
            _mouseHookId = SetHook(WH_MOUSE_LL, _mouseProc);
#endif

            // 註冊使用者切換事件
            WeakReferenceMessenger.Default.Register<NotifyCurrentUserChanged>(this, (recipient, message) =>
            {
                RecreateMainMenu();
            });

            // 註冊狀態列訊息區顯示
            WeakReferenceMessenger.Default.Register<StatusBarMessage>(this, (recipient, message) =>
            {
                SBMessage.Text = message.Value;
                _messageTimer.ReStart();
            });

            //註冊狀態列進度條顯示
            WeakReferenceMessenger.Default.Register<ProcessBarMessage>(this, (recipient, message) =>
            {
                ProcessBarInfo info = message.Value;
                SetProcessBar(info.Percent);
                if (!string.IsNullOrWhiteSpace(info.Message))
                {
                    SBMessage.Text = info.Message;
                    _messageTimer.ReStart();
                }
                else
                {
                    SBMessage.Text = "";
                }
            });

            //註冊狀態列DB資料顯示訊息
            WeakReferenceMessenger.Default.Register<DbInfoMessage>(this, (recipient, message) =>
            {
                DbInfo.Text = message.Value;
            });
        }

        // 鍵盤與滑鼠掛鉤

#if !DEBUG && !OFFLINE

        private IntPtr SetHook(int idHook, HookProc proc)
        {
            using (var process = System.Diagnostics.Process.GetCurrentProcess())
            using (var module = process.MainModule)
            {
                return SetWindowsHookEx(idHook, proc, GetModuleHandle(module.ModuleName), 0);
            }
        }

        private IntPtr KeyboardHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                _idleTriggered = false;
                _idleTimer.ReStart();
            }
            return CallNextHookEx(_keyboardHookId, nCode, wParam, lParam);
        }

        private IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                _idleTriggered = false;
                _idleTimer.ReStart();
            }
            return CallNextHookEx(_mouseHookId, nCode, wParam, lParam);
        }

#endif

        /********************
         * Form Events
         ********************/
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            // 停止所有 Timer
            _messageTimer?.Stop();
            _messageTimer?.Dispose();

            _idleTimer?.Stop();
            _idleTimer?.Dispose();

            clockTimer?.Stop();
            clockTimer?.Dispose();

            // 解除訊息註冊
            WeakReferenceMessenger.Default.UnregisterAll(this);

            // 解除區域註冊
            _region.UnregisterRegion(nameof(MainRegion));
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            // 解除掛鉤
            if (_keyboardHookId != IntPtr.Zero)
            {
                UnhookWindowsHookEx(_keyboardHookId);
            }
            if (_mouseHookId != IntPtr.Zero)
            {
                UnhookWindowsHookEx(_mouseHookId);
            }
            base.OnFormClosed(e);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
#if DEBUG || OFFLINE
            // 管理員模式方便測試
            //_currentUser.AdminLogin();
#else
            // 訪客模式
            _currentUser.SwitchCurrentUserToGuest();
#endif
        }

        /********************
         * Other Events
         ********************/
        /// <summary>
        /// 調整視窗大小。
        /// </summary>
        private void ResizeScreen()
        {
            const int TARGET_WIDTH = 1440;
            const int TARGET_HEIGHT = 950;
            var screenArea = Screen.PrimaryScreen.WorkingArea;

            if (screenArea.Width > TARGET_WIDTH)
            {
                WindowState = FormWindowState.Normal;
                StartPosition = FormStartPosition.CenterScreen;
                Width = TARGET_WIDTH;
                Height = TARGET_HEIGHT;
                Left = (screenArea.Width - TARGET_WIDTH) / 2;
                Top = (screenArea.Height - TARGET_HEIGHT) / 2;
            }
            else
            {
                WindowState = FormWindowState.Maximized;
            }
        }

        /// <summary>
        /// 無動作計時器觸發。
        /// </summary>
        private void IdleTimer_Tick(object sender, EventArgs e)
        {
            _idleTriggered = true;
            _idleTimer.Stop();

            using (var dlg = _scope.Resolve<LogoutCountdown>())
                dlg.ShowDialog();

            _idleTriggered = false;
            _idleTimer.ReStart();
        }

        /// <summary>
        /// 時鐘更新。
        /// </summary>
        private void ClockTimer_Tick(object sender, EventArgs e)
        {
            Clock.Text = DateTime.Now.DateTimeString();
        }

        /********************
         * Status Bar Methods
         ********************/
        /// <summary>
        /// 設定進度條。
        /// </summary>
        /// <param name="value">進度值，範圍 0-100。</param>
        private void SetProcessBar(int value)
        {
            if (value >= 0 && value <= 100)
            {
                if (!ProgressBar.ShowValue)
                    ProgressBar.ShowValue = true;
                ProgressBar.Value = value;
            }
            else
            {
                ProgressBar.ShowValue = false;
            }
        }

        /********************
         * 操作模式 & 頁面載入
         ********************/
        /// <summary>
        /// 因應權限變更，設定相關選單與頁面。
        /// </summary>
        private void RecreateMainMenu()
        {
            TreeNode node1, node2;
            int pageIndex;

            /********************
             * 右側副選單
             ********************/
            // 使用者選單
            node1 = rNavBar.Nodes[0];
            node1.Text = _user.UserName;
            node1.Nodes.Clear();

            Console.WriteLine($"{_user.IsAdmin},{_user.IsGuest}");

            if (_user.IsAdmin)
            {
                //node1.BackColor = Color.Red;
                //node1.ForeColor = Color.Red;
                rNavBar.SetNodeSymbol(node1, 362718);
            }
            else if (_user.IsGuest)
            {
                //node1.ForeColor = Color.Gray;
                rNavBar.SetNodeSymbol(node1, 362720);
            }
            else
            {
                //node1.ForeColor = Color.Green;
                rNavBar.SetNodeSymbol(node1, 362716);
            }

            // 使用者選單 -> 登入/登出
            if (_user.IsGuest)
            {
                pageIndex = (int)PageCode.Login;
                node2 = rNavBar.CreateChildNode(node1, PageCode.Login.GetDescription(), pageIndex);
                rNavBar.SetNodeSymbol(node2, 560023);
                node2.Tag = pageIndex;
            }
            else
            {
                pageIndex = (int)PageCode.Logout;
                node2 = rNavBar.CreateChildNode(node1, PageCode.Logout.GetDescription(), pageIndex);
                rNavBar.SetNodeSymbol(node2, 559834);
                node2.Tag = pageIndex;

                pageIndex = (int)PageCode.SwitchUser;
                node2 = rNavBar.CreateChildNode(node1, PageCode.SwitchUser.GetDescription(), pageIndex);
                rNavBar.SetNodeSymbol(node2, 362720);
                node2.Tag = pageIndex;
            }

            //// 設定
            //if (_user.IsAdmin)
            //{
            //    pageIndex = (int)PageCode.Setup;
            //    _pageManager.AddOrReplacePage<SetupPage>(pageIndex);
            //    node2 = rNavBar.CreateChildNode(node1, PageCode.Setup.GetDescription(), pageIndex);
            //    rNavBar.SetNodeSymbol(node2, 361459);
            //    node2.Tag = pageIndex;
            //}

            rNavBar.Refresh();

            /********************
             * 左側主選單
             ********************/
            lNavBar.Nodes.Clear();
            _availablePageCode = new HashSet<PageCode>();

            bool hasToolQuest = _permission.HasControlAccess(PermissionWords.MODULE_TOOL_QUEST);
            bool hasMechaTrack = _permission.HasControlAccess(PermissionWords.MODULE_MECHA_TRACK);
            bool hasMaintiFlow = _permission.HasControlAccess(PermissionWords.MODULE_MAINTI_FLOW);
            bool hasSetup = _permission.HasControlAccess(PermissionWords.MODULE_SETUP);

            // 主頁面
            if (_user.IsGuest || !(hasToolQuest || hasMechaTrack || hasMaintiFlow || hasSetup))
            {
                pageIndex = (int)PageCode.MainPage;
                //_pageManager.AddOrReplacePage<MainPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.MainPage.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 559530);
                node1.Tag = pageIndex;
                _availablePageCode.Add(PageCode.MainPage);
            }

            // 維護工單
            if (hasMaintiFlow)
            {
                pageIndex = (int)PageCode.MaintiFlow;
                //_pageManager.AddOrReplacePage<MaintiFlowPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.MaintiFlow.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 361613);
                node1.Tag = pageIndex;
                _availablePageCode.Add(PageCode.MaintiFlow);
            }

            // 專案管理
            if (hasMechaTrack)
            {
                pageIndex = (int)PageCode.MechaTrack;
                //_pageManager.AddOrReplacePage<MechaTrackPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.MechaTrack.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 261474);
                node1.Tag = pageIndex;
                _availablePageCode.Add(PageCode.MechaTrack);
            }

            // 工具委託
            if (hasToolQuest)
            {
                pageIndex = (int)PageCode.ToolQuest;
                //_pageManager.AddOrReplacePage<ToolQuestPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.ToolQuest.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 362133);
                node1.Tag = pageIndex;
                _availablePageCode.Add(PageCode.ToolQuest);
            }

            // 顯示設定頁
            if (hasSetup)
            {
                pageIndex = (int)PageCode.Setup;
                //_pageManager.AddOrReplacePage<SetupPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.Setup.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 361459);
                node1.Tag = pageIndex;
                _availablePageCode.Add(PageCode.Setup);
            }

            if (lNavBar.SelectedIndex == -1)
                lNavBar.SelectedIndex = 0;

            lNavBar.SelectedIndex = 0;
            lNavBar.Refresh();

            if (_availablePageCode.Contains(_currentPageCode))
                SwitchPage(_currentPageCode);
            else
            {
                _currentPageCode = _availablePageCode.First();
                SwitchPage(_currentPageCode);
            }
        }

        /********************
         * 頁面導航
         ********************/
        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="pageCode">頁面代碼。</param>
        private void SwitchPage(PageCode pageCode)
        {
            if (_currentPageCode == pageCode && PageCode.Login != pageCode)
                return;

            string regionName = nameof(MainRegion);
            switch (pageCode)
            {
                case PageCode.MainPage:
                    _nav.NavigateTo<MainPage>(regionName, (int)PageCode.MainPage);
                    break;
                case PageCode.ToolQuest:
                    _nav.NavigateTo<ToolQuestPage>(regionName, (int)PageCode.ToolQuest);
                    break;
                case PageCode.MechaTrack:
                    _nav.NavigateTo<MechaTrackPage>(regionName, (int)PageCode.MechaTrack);
                    break;
                case PageCode.MaintiFlow:
                    _nav.NavigateTo<MaintiFlowPage>(regionName, (int)PageCode.MaintiFlow);
                    break;
                case PageCode.Setup:
                    _nav.NavigateTo<SetupPage>(regionName, (int)PageCode.Setup);
                    break;
                default:
                    return;
            }
            _currentPageCode = pageCode;
        }

        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="pageIndex">頁面索引。</param>
        private void SwitchPage(int pageIndex)
        {
            if (Enum.TryParse(pageIndex.ToString(), out PageCode pageCode))
            {
                SwitchPage(pageCode);
            }
        }

        /********************
         * 選單事件處理
         ********************/
        /// <summary>
        /// 登入對話框。
        /// </summary>
        private void Login()
        {
            using (var dlg = new LoginForm(_scope.Resolve<LoginControl>()))
                dlg.ShowDialog();
        }

        /// <summary>
        /// 登出。
        /// </summary>
        private void Logout()
        {
            _currentUser.SwitchCurrentUserToGuest();
        }

#pragma warning disable IDE0060 // 移除未使用的參數
        /// <summary>
        /// 點擊右選單。
        /// </summary>
        /// <param name="itemText">選單文字。</param>
        /// <param name="menuIndex">選項索引。</param>
        /// <param name="pageIndex">頁面索引。</param>
        private void NavBar_Right_MenuItemClick(string itemText, int menuIndex, int pageIndex)
        {
            if (Enum.TryParse(pageIndex.ToString(), out PageCode pageCode))
            {
                switch (pageCode)
                {
                    case PageCode.Login:
                        Login();
                        break;

                    case PageCode.Logout:
                        Logout();
                        break;

                    case PageCode.SwitchUser:
                        Login();
                        break;

                    case PageCode.Setup:
                        SwitchPage(pageIndex);
                        break;

                        //case PageCode.SetupTrigger:
                }
            }
        }

        /// <summary>
        /// 點擊導覽列選單。
        /// </summary>
        /// <param name="itemText">選單文字。</param>
        /// <param name="menuIndex">選項索引。</param>
        /// <param name="pageIndex">頁面索引。</param>
        private void NavBar_MenuItemClick(string itemText, int menuIndex, int pageIndex)
        {
            SwitchPage(pageIndex);
        }
#pragma warning restore IDE0060 // 移除未使用的參數
    }
}
