﻿using System.Windows.Forms;
using Calin.Infrastructure.Navigation;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.SharedUI;
using Sunny.UI;

namespace Calin.TaskPulse.Views
{
    [ViewLifetime(IsAlive = false)]
    public partial class LoginForm : UIForm
    {
        public LoginForm(LoginControl loginControl)
        {
            InitializeComponent();

            TitleColor = CommonStyles.BackColor;
            loginControl.Dock = DockStyle.None;
            TLP.Controls.Add(loginControl);
        }
    }
}
