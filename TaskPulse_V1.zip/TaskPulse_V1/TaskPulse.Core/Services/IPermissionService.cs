﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Services
{
    /// <summary>
    /// 使用者權限服務介面。
    /// </summary>
    /// <remarks>管理員 ID 使用 int.MaxValue。<br/>訪客 ID 為 0。</remarks>
    public interface IPermissionService
    {
        /********************
         * from CurrentUserContext
         ********************/
        /// <summary>
        /// 登入者是否為管理員。
        /// </summary>
        bool IsAdmin { get; }

        /// <summary>
        /// 沒有登入者，為訪客狀態。
        /// </summary>
        bool IsGuest { get; }

        /********************
         * Employee Permissions
         ********************/
        /// <summary>
        /// 取得使用者完整權限清單，即以部門→群組→個人三組權限合併。
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        /// <returns>傳回使用者完整權限清單。</returns>
        HashSet<PermissionData> GetFullPermissions(string employeeId);

        /// <summary>
        /// 取得使用者權限清單。
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        /// <returns>傳回使用者權限清單。</returns>
        HashSet<PermissionData> GetUserPermissions(string employeeId);

        /// <summary>
        /// 檢查使用者是否具有指定權限。
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        /// <param name="permission">要檢查的權限字串。</param>
        /// <returns>傳回是否具有該權限。</returns>
        bool HasPermission(string employeeId, string permission);

        /********************
         * Department Permissions
         ********************/
        /// <summary>
        /// 取得部門權限清單。
        /// </summary>
        /// <param name="departmentId">部門 Id。</param>
        /// <returns>部門權限清單。</returns>
        HashSet<PermissionData> GetDepartmentPermissions(int departmentId);

        /********************
         * UserGroup Permissions
         ********************/
        /// <summary>
        /// 取得使用者群組權限清單。
        /// </summary>
        /// <param name="groupId">群組 Id。</param>
        /// <returns>使用者群組權限清單。</returns>
        HashSet<PermissionData> GetUserGroupPermissions(int groupId);

        /********************
         * Utilities
         ********************/
        /// <summary>
        /// 清除孤立的權限資料。
        /// </summary>
        /// <returns></returns>
        Task CleanOrphanPermissions();

        /********************
         *  Control Access
         ********************/
        /// <summary>
        /// 檢查使用者對控制項是否有權限
        /// </summary>
        /// <param name="module"></param>
        /// <param name="page"></param>
        /// <param name="control"></param>
        /// <param name="action"></param>
        /// <returns>是否有權限。</returns>
        bool HasControlAccess(string module, string page, string control, string action);

        /// <summary>
        /// 檢查使用者對控制項是否有權限
        /// </summary>
        /// <param name="module"></param>
        /// <param name="page"></param>
        /// <param name="control"></param>
        /// <returns>是否有權限。</returns>
        bool HasControlAccess(string module, string page, string control);

        /// <summary>
        /// 檢查使用者對控制項是否有權限
        /// </summary>
        /// <param name="module"></param>
        /// <param name="page"></param>
        /// <returns>是否有權限。</returns>
        bool HasControlAccess(string module, string page);

        /// <summary>
        /// 檢查使用者對控制項是否有權限
        /// </summary>
        /// <param name="control"></param>
        /// <returns>是否有權限。</returns>
        bool HasControlAccess(string control);

        /// <summary>
        /// 取得使用者所有權限來源（部門、群組、個人）。
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        /// <returns>使用者所有權限來源。</returns>
        Dictionary<string, PermissionSource> GetPermissionSources(string employeeId);

        /// <summary>
        /// 取得指定控制項的權限來源。
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        /// <returns>指定控制項的權限來源。</returns>
        PermissionSource GetPermissionSource(string employeeId, string module, string page, string control, string action);

        /// <summary>
        /// 清除指定控制項權限來源的快取。
        /// </summary>
        void ClearUserPermissionSourceCache(string employeeId);

        /********************
         * Refresh
         ********************/
        /// <summary>
        /// 當部門權限變動時呼叫，刷新該部門所有員工。
        /// </summary>
        /// <param name="departmentId">部門 Id。</param>
        void RefreshDepartmentPermissions(int departmentId);

        /// <summary>
        /// 當群組權限變動時呼叫，刷新所有屬於該群組的員工。
        /// </summary>
        /// <param name="userGroupId">群組 Id。</param>
        void RefreshUserGroupPermissions(int userGroupId);

        /// <summary>
        /// 當員工權限變動時呼叫。
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        void RefreshUserPermissions(string employeeId);

        /********************
         * 轉換
         ********************/
        /// <summary>
        /// 
        /// </summary>
        /// <param name="module"></param>
        /// <param name="page"></param>
        /// <param name="control"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        string LevelToString(string module, string page, string control, string action);

        /// <summary>
        /// 將權限字串解析至各階層。
        /// </summary>
        /// <param name="permission"></param>
        /// <returns></returns>
        (string module, string page, string control, string action) StringToLevel(string permission);

        /********************
         * 新增：權限分析與管理
         ********************/
        /// <summary>
        /// 取得指定員工的所有權限來源明細
        /// </summary>
        /// <param name="employeeId">員工工號</param>
        /// <returns>權限項目列表</returns>
        List<PermissionItemViewModel> GetPermissionDetails(string employeeId);

        /// <summary>
        /// 取得權限合併結果（包含衝突檢測）
        /// </summary>
        /// <param name="employeeId">員工工號</param>
        /// <returns>權限合併結果列表</returns>
        List<PermissionMergeResult> GetMergedPermissions(string employeeId);

        /// <summary>
        /// 取得權限衝突列表
        /// </summary>
        /// <param name="employeeId">員工工號</param>
        /// <returns>權限衝突列表</returns>
        List<PermissionConflictViewModel> GetPermissionConflicts(string employeeId);
    }
}
