﻿using System;
using System.DirectoryServices.Protocols;
using System.Net;
using System.Security;
using Calin.TaskPulse.Core.DB.Services;
using Serilog.Context;

namespace Calin.TaskPulse.Core.Services
{
    /// <summary>
    /// 登入驗證。
    /// </summary>
    public interface IAuthService
    {
        /********************
         * AD認證服務
         ********************/
        /// <summary>
        /// LDAP伺服器AD認證服務。
        /// </summary>
        /// <param name="userName">使用者名稱。</param>
        /// <param name="password">密碼。</param>
        /// <returns>認證是否通過。</returns>
        bool ActiveDirectoryAsync(string userName, string password);
    }

    /// <summary>
    /// 登入驗證服務實作。
    /// </summary>
    public class AuthService : IAuthService
    {
        private readonly Serilog.ILogger _logger;
        private readonly IEmployeeService _employee;
        private readonly ICurrentUserService _currentUser;

        public AuthService(
            Serilog.ILogger logger,
            IEmployeeService employeeService,
            ICurrentUserService currentUserService)
        {
            _logger = logger;
            _employee = employeeService;
            _currentUser = currentUserService;
        }

        /********************
         * AD認證服務
         ********************/
        /// <inheritdoc/>
        public bool ActiveDirectoryAsync(string employeeId, string password)
        {
#if OFFLINE
            return true;
#endif
            var user = _employee.GetByEmployeeId(employeeId);
            try
            {
                SecureString securePwd = new SecureString();
                foreach (var c in password)
                    securePwd.AppendChar(c);

                var identifier = new LdapDirectoryIdentifier("172.16.254.200");
                using (var connection = new LdapConnection(identifier))
                {
                    connection.SessionOptions.ProtocolVersion = 3;
                    connection.AuthType = AuthType.Negotiate;
                    var credential = new NetworkCredential(employeeId, securePwd);
                    connection.Bind(credential);
                    return user != null;
                }
            }
            catch (LdapException ex)
            {
                using (LogContext.PushProperty("Category", "UserActivity"))
                {
                    _logger.Error(ex, "LDAP伺服器異常或帳號密碼未通過認證: {0}", user.FullName);
                }
                //_currentUser.SwitchCurrentUserToGuest();
            }
            catch (Exception ex)
            {
                using (LogContext.PushProperty("Category", "UserActivity"))
                {
                    _logger.Error(ex, "LDAP驗證失敗 User: {0}", employeeId);
                }
                _currentUser.SwitchCurrentUserToGuest();
            }
            return false;
        }
    }
}
