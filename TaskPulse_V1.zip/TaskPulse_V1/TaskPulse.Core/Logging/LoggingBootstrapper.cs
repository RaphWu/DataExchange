using System;
using System.IO;
using Calin.TaskPulse.Core.Logging.Filters;
using Serilog;
using Serilog.Events;
using Serilog.Formatting.Compact;

namespace Calin.TaskPulse.Core.Logging
{
    /// <summary>
    /// ��x�t�αҰʾ��A�t�d Serilog ��l�ƻP Sink �]�w�C
    /// </summary>
    /// <remarks>
    /// <para>�����O�t�d�]�w�Ҧ���x Sink �Ψ���ѳW�h�C</para>
    /// <para>�ҰʱM�ץu�ݩI�s <see cref="Initialize"/> ��k�C</para>
    /// <para>
    /// �ݭn�� NuGet �M��G
    /// <list type="bullet">
    /// <item><description>Serilog</description></item>
    /// <item><description>Serilog.Sinks.File</description></item>
    /// <item><description>Serilog.Formatting.Compact</description></item>
    /// </list>
    /// </para>
    /// </remarks>
    public static class LoggingBootstrapper
    {
        private const string DefaultLogDirectory = "logs";

        /// <summary>
        /// ��r�榡��X�d���C
        /// </summary>
        private const string TextOutputTemplate =
            "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] [{SourceContext}] {Message:lj}{NewLine}{Exception}";

        /// <summary>
        /// ��l�Ƥ�x�t�ΡC
        /// </summary>
        /// <param name="logDirectory">��x�ؿ����|�A�w�]�� "logs"�C</param>
        /// <example>
        /// <code>
        /// // �b�{���i�J�I�I�s
        /// LoggingBootstrapper.Initialize();
        /// // �Ϋ��w�ۭq���|
        /// LoggingBootstrapper.Initialize("C:\\MyApp\\logs");
        /// </code>
        /// </example>
        public static void Initialize(string logDirectory = null)
        {
            var logDir = string.IsNullOrEmpty(logDirectory) ? DefaultLogDirectory : logDirectory;

            // �T�O��x�ؿ��s�b
            EnsureLogDirectoryExists(logDir);

            var configuration = new LoggerConfiguration()
                // Global MinimumLevel: Debug
                .MinimumLevel.Debug()
                // Override: Microsoft �� Warning
                .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                // Override: System �� Warning
                .MinimumLevel.Override("System", LogEventLevel.Warning)
                // �ҥ� LogContext�]���n�A�Ω� Category �ݩʡ^
                .Enrich.FromLogContext();

            // �]�w�U Sink
            ConfigureInformationSink(configuration, logDir);
            ConfigureErrorSink(configuration, logDir);
            ConfigureUserActivitySink(configuration, logDir);
            ConfigureDatabaseSink(configuration, logDir);

            // �إߨó]�w���� Logger
            Log.Logger = configuration.CreateLogger();

            // �O���ҰʰT��
            Log.Information("��x�t�Τw��l�ơA��x�ؿ��G{LogDirectory}", Path.GetFullPath(logDir));
        }

        /// <summary>
        /// ������x�t�ΡA�T�O�Ҧ���x���w�g�J�C
        /// </summary>
        /// <remarks>
        /// ���b���ε{�������e�I�s�C
        /// </remarks>
        public static void Shutdown()
        {
            Log.Information("��x�t�Υ��b����...");
            Log.CloseAndFlush();
        }

        /// <summary>
        /// �]�w�@���T�ƥ� Sink�C
        /// </summary>
        /// <remarks>
        /// - �ư� Category = UserActivity�BDatabase
        /// - Text �榡
        /// - �C��@��
        /// - �O�d 15 ��
        /// - Level: Debug �H�W
        /// </remarks>
        private static void ConfigureInformationSink(LoggerConfiguration configuration, string logDir)
        {
            var informationFilter = new CategoryExcludeFilter(
                LogCategories.UserActivity,
                LogCategories.Database);

            var filePath = Path.Combine(logDir, "information.txt");

            configuration.WriteTo.Logger(lc => lc
                .Filter.With(informationFilter)
                .WriteTo.File(
                    filePath,
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 15,
                    outputTemplate: TextOutputTemplate,
                    shared: true));
        }

        /// <summary>
        /// �]�w���~�P�ҥ~ Sink�C
        /// </summary>
        /// <remarks>
        /// - Text �榡
        /// - �C��@��
        /// - �O�d 90 ��
        /// - Level: Error �H�W
        /// </remarks>
        private static void ConfigureErrorSink(LoggerConfiguration configuration, string logDir)
        {
            var filePath = Path.Combine(logDir, "error_log_.txt");

            configuration.WriteTo.Logger(lc => lc
                .MinimumLevel.Error()
                .WriteTo.File(
                    filePath,
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 90,
                    outputTemplate: TextOutputTemplate,
                    shared: true));
        }

        /// <summary>
        /// �]�w�ϥΪ̾ާ@ Sink�C
        /// </summary>
        /// <remarks>
        /// - Category = UserActivity
        /// - Compact JSON �榡
        /// - �C��@��
        /// - �O�d 90 ��
        /// </remarks>
        private static void ConfigureUserActivitySink(LoggerConfiguration configuration, string logDir)
        {
            var userActivityFilter = new CategoryIncludeFilter(LogCategories.UserActivity);

            var filePath = Path.Combine(logDir, "user_activity.json");

            configuration.WriteTo.Logger(lc => lc
                .Filter.With(userActivityFilter)
                .WriteTo.File(
                    new CompactJsonFormatter(),
                    filePath,
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 90,
                    shared: true));
        }

        /// <summary>
        /// �]�w��Ʈw�ާ@ Sink�C
        /// </summary>
        /// <remarks>
        /// - Category = Database
        /// - Compact JSON �榡
        /// - �C��@��
        /// - �O�d 90 ��
        /// </remarks>
        private static void ConfigureDatabaseSink(LoggerConfiguration configuration, string logDir)
        {
            var databaseFilter = new CategoryIncludeFilter(LogCategories.Database);

            var filePath = Path.Combine(logDir, "database_event.json");

            configuration.WriteTo.Logger(lc => lc
                .Filter.With(databaseFilter)
                .WriteTo.File(
                    new CompactJsonFormatter(),
                    filePath,
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 90,
                    shared: true));
        }

        /// <summary>
        /// �T�O��x�ؿ��s�b�C
        /// </summary>
        private static void EnsureLogDirectoryExists(string logDir)
        {
            if (!Directory.Exists(logDir))
            {
                Directory.CreateDirectory(logDir);
            }
        }
    }
}
