﻿# TaskPulse Logging Module

## 概述

日誌服務模組位於 `Calin.TaskPulse.Core.Logging` 命名空間，提供完整的 Serilog 日誌功能，支援多分類路由。

## 所需 NuGet 套件

- Serilog.Sinks.File
- Serilog.Formatting.Compact

## 架構

```
Calin.TaskPulse.Core.Logging/
├── LogCategories.cs           # 日誌分類常數定義
├── LogContextExtensions.cs    # LogContext 輔助擴充方法
├── LoggingBootstrapper.cs     # Serilog 初始化與 Sink 設定
├── LoggingModule.cs           # Autofac 日誌註冊 Module
├── Filters/
│   └── CategoryFilters.cs     # Category 路由 Filter
└── Examples/
    └── LoggingUsageExamples.cs # 使用範例
```

## 快速開始

### 1. 在程式進入點初始化

```csharp
using Calin.TaskPulse.Core.Logging;
using Autofac;

static void Main()
{
    try
    {
        // 1. 初始化日誌系統（必須最先執行）
        LoggingBootstrapper.Initialize();
        
        // 2. 初始化 Autofac 容器
        var builder = new ContainerBuilder();
        builder.RegisterModule<CoreModule>();
        var container = builder.Build();
        
        // 3. 啟動應用程式
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        using (var scope = container.BeginLifetimeScope())
        {
            var mainForm = scope.Resolve<MainForm>();
            Application.Run(mainForm);
        }
    }
    catch (Exception ex)
    {
        Log.Fatal(ex, "應用程式發生未處理的例外");
    }
    finally
    {
        // 4. 關閉日誌系統
        LoggingBootstrapper.Shutdown();
    }
}
```

### 2. 在服務或 ViewModel 中使用

```csharp
using Serilog;
using Calin.TaskPulse.Core.Logging;

public class MyService
{
    private readonly ILogger _logger;
    
    public MyService(ILogger logger)
    {
        _logger = logger.ForContext<MyService>();
    }
    
    public void DoSomething()
    {
        // 一般日誌（寫入 information.txt）
        _logger.Information("執行操作");
        
        // 使用者操作日誌（寫入 user_activity.json）
        using (LogContextExtensions.WithUserActivity())
        {
            _logger.Information("使用者 {UserId} 執行重要操作", userId);
        }
        
        // 資料庫操作日誌（寫入 database_event.json）
        using (LogContextExtensions.WithDatabase())
        {
            _logger.Information("新增資料，Id={Id}", entity.Id);
        }
    }
}
```

## 日誌分類

| 分類 | 常數 | 輸出檔案 | 說明 |
|------|------|----------|------|
| UserActivity | `LogCategories.UserActivity` | user_activity.json | 使用者登入、登出、權限變更、重要操作 |
| Database | `LogCategories.Database` | database_event.json | CRUD、交易、連線、效能相關 |
| Business | `LogCategories.Business` | information.txt | 業務流程狀態、規則判斷 |
| System | `LogCategories.System` | information.txt | 系統啟動、關閉、背景服務狀態 |
| （無分類） | - | information.txt | 一般日誌 |
| Error 以上 | - | error_log_.txt | 所有錯誤與例外 |

## 日誌檔案

| 檔案 | 格式 | 保留天數 | 說明 |
|------|------|----------|------|
| `logs/information.txt` | Text | 15 天 | 一般資訊（排除 UserActivity、Database） |
| `logs/error_log_.txt` | Text | 90 天 | 錯誤與例外（Error 以上） |
| `logs/user_activity.json` | Compact JSON | 90 天 | 使用者操作 |
| `logs/database_event.json` | Compact JSON | 90 天 | 資料庫操作 |

## 日誌等級策略

- **Global MinimumLevel**: Debug
- **Override**:
  - Microsoft → Warning
  - System → Warning

## 使用規範

### ✅ 正確用法

```csharp
// 使用 LogContextExtensions 設定分類
using (LogContextExtensions.WithUserActivity())
{
    _logger.Information("使用者 {UserId} 登入", userId);
}

// 或使用 LogContext.PushProperty
using (LogContext.PushProperty("Category", LogCategories.UserActivity))
{
    _logger.Information("使用者 {UserId} 登入", userId);
}
```

### ❌ 錯誤用法

```csharp
// 嚴禁直接使用字串
using (LogContext.PushProperty("Category", "UserActivity")) // 錯誤！
{
    _logger.Information("使用者登入");
}

// 嚴禁將分類寫在訊息中
_logger.Information("[UserActivity] 使用者登入"); // 錯誤！
```

## 選用功能

### Microsoft.Extensions.Logging 整合

若需要使用 `ILoggerFactory` 和 `ILogger<T>`，請安裝：

```
Install-Package Microsoft.Extensions.Logging
Install-Package Serilog.Extensions.Logging
```

然後取消 `LoggingModule.cs` 中相關程式碼的註解。

## 注意事項

1. **初始化順序**：`LoggingBootstrapper.Initialize()` 必須在所有其他初始化之前執行
2. **關閉順序**：`LoggingBootstrapper.Shutdown()` 必須在應用程式結束時呼叫
3. **Category 常數**：Category 值為日誌路由契約，不得隨意變更
4. **Filter 實作**：Filter 使用 `ScalarValue` 正確判斷 Category，不使用 `ToString()`
