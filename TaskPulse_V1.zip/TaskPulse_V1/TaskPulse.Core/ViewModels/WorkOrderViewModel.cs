using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Services;
using Calin.TaskPulse.Entity.Contants;
using Serilog;

namespace Calin.TaskPulse.Core.ViewModels
{
    /// <summary>
    /// ���פu�� ViewModel�A�䴩�浧����P�M�檺 WinForm DataBinding�C
    /// </summary>
    public class WorkOrderViewModel : ViewModelBase
    {
        private readonly IWorkOrderService _workOrderService;
        private readonly ILogger _logger;

        private WorkOrderDto _selectedWorkOrder;
        private BindingList<WorkOrderDto> _workOrders;
        private bool _isLoading;
        private string _errorMessage;

        /// <summary>
        /// ��l�� WorkOrderViewModel�C
        /// </summary>
        /// <param name="workOrderService">�u��A�ȡC</param>
        /// <param name="logger">��x�O�����C</param>
        public WorkOrderViewModel(IWorkOrderService workOrderService, ILogger logger)
        {
            _workOrderService = workOrderService ?? throw new ArgumentNullException(nameof(workOrderService));
            _logger = logger?.ForContext<WorkOrderViewModel>() ?? Log.Logger.ForContext<WorkOrderViewModel>();
            _workOrders = new BindingList<WorkOrderDto>();
        }

        #region �ݩ�

        /// <summary>
        /// �ثe������u��C
        /// </summary>
        public WorkOrderDto SelectedWorkOrder
        {
            get => _selectedWorkOrder;
            set
            {
                if (SetProperty(ref _selectedWorkOrder, value))
                {
                    _logger.Debug("����u���ܧ�G{WorkOrderNo}", value?.WorkOrderNo);
                    OnPropertyChanged(nameof(HasSelectedWorkOrder));
                }
            }
        }

        /// <summary>
        /// �O�_������u��C
        /// </summary>
        public bool HasSelectedWorkOrder => SelectedWorkOrder != null;

        /// <summary>
        /// �u��M��]�䴩 DataBinding�^�C
        /// </summary>
        public BindingList<WorkOrderDto> WorkOrders
        {
            get => _workOrders;
            private set => SetProperty(ref _workOrders, value);
        }

        /// <summary>
        /// �O�_���b���J��ơC
        /// </summary>
        public bool IsLoading
        {
            get => _isLoading;
            private set => SetProperty(ref _isLoading, value);
        }

        /// <summary>
        /// ���~�T���C
        /// </summary>
        public string ErrorMessage
        {
            get => _errorMessage;
            private set => SetProperty(ref _errorMessage, value);
        }

        /// <summary>
        /// �O�_�����~�C
        /// </summary>
        public bool HasError => !string.IsNullOrEmpty(ErrorMessage);

        #endregion

        #region �ާ@��k

        /// <summary>
        /// ���J�Ҧ��u��C
        /// </summary>
        public void LoadAll()
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J�Ҧ��u��");
                var workOrders = _workOrderService.GetAll().ToList();
                RefreshWorkOrderList(workOrders);
                _logger.Information("���J�����A�@ {Count} ���u��", workOrders.Count);
            });
        }

        /// <summary>
        /// �̪��A���J�u��C
        /// </summary>
        /// <param name="status">�u�檬�A�C</param>
        public void LoadByStatus(FlowStatus status)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J���A {Status} ���u��", status);
                var workOrders = _workOrderService.GetByStatus(status).ToList();
                RefreshWorkOrderList(workOrders);
                _logger.Information("���J�����A�@ {Count} ���u��", workOrders.Count);
            });
        }

        /// <summary>
        /// �̫س�H�����J�u��C
        /// </summary>
        /// <param name="creatorId">�س�H�� Id�C</param>
        public void LoadByCreator(int creatorId)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J�س�H�� {CreatorId} ���u��", creatorId);
                var workOrders = _workOrderService.GetByCreatorId(creatorId).ToList();
                RefreshWorkOrderList(workOrders);
                _logger.Information("���J�����A�@ {Count} ���u��", workOrders.Count);
            });
        }

        /// <summary>
        /// �̾��x���J�u��C
        /// </summary>
        /// <param name="machineId">���x Id�C</param>
        public void LoadByMachine(int machineId)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J���x {MachineId} ���u��", machineId);
                var workOrders = _workOrderService.GetByMachineId(machineId).ToList();
                RefreshWorkOrderList(workOrders);
                _logger.Information("���J�����A�@ {Count} ���u��", workOrders.Count);
            });
        }

        /// <summary>
        /// �̤���d����J�u��C
        /// </summary>
        /// <param name="startDate">�}�l����C</param>
        /// <param name="endDate">��������C</param>
        public void LoadByDateRange(DateTime startDate, DateTime endDate)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J {StartDate:yyyy-MM-dd} �� {EndDate:yyyy-MM-dd} ���u��", startDate, endDate);
                var workOrders = _workOrderService.GetByDateRange(startDate, endDate).ToList();
                RefreshWorkOrderList(workOrders);
                _logger.Information("���J�����A�@ {Count} ���u��", workOrders.Count);
            });
        }

        /// <summary>
        /// �� Id ���J�u��]�t���װO���^�C
        /// </summary>
        /// <param name="id">�u��D��C</param>
        public void LoadById(int id)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J�u�� Id={Id}", id);
                SelectedWorkOrder = _workOrderService.GetWithMaintenanceRecords(id);
                if (SelectedWorkOrder != null)
                {
                    _logger.Information("���J�u�榨�\�G{WorkOrderNo}�A�t {RecordCount} �����װO��",
                        SelectedWorkOrder.WorkOrderNo,
                        SelectedWorkOrder.MaintenanceRecords?.Count ?? 0);
                }
                else
                {
                    _logger.Warning("�䤣��u�� Id={Id}", id);
                }
            });
        }

        /// <summary>
        /// �̤u��s�����J�u��C
        /// </summary>
        /// <param name="workOrderNo">�u��s���C</param>
        public void LoadByWorkOrderNo(string workOrderNo)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J�u�� WorkOrderNo={WorkOrderNo}", workOrderNo);
                SelectedWorkOrder = _workOrderService.GetByWorkOrderNo(workOrderNo);
                if (SelectedWorkOrder != null)
                {
                    _logger.Information("���J�u�榨�\�G{WorkOrderNo}", SelectedWorkOrder.WorkOrderNo);
                }
                else
                {
                    _logger.Warning("�䤣��u�� WorkOrderNo={WorkOrderNo}", workOrderNo);
                }
            });
        }

        /// <summary>
        /// �s�W�u��C
        /// </summary>
        /// <param name="dto">�u���ơC</param>
        /// <returns>�s�W�᪺�u��C</returns>
        public WorkOrderDto Create(WorkOrderDto dto)
        {
            WorkOrderDto result = null;
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l�s�W�u��G{WorkOrderNo}", dto.WorkOrderNo);
                result = _workOrderService.Create(dto);
                WorkOrders.Add(result);
                SelectedWorkOrder = result;
                _logger.Information("�s�W�u�榨�\�GId={Id}", result.Id);
            });
            return result;
        }

        /// <summary>
        /// ��s�u��C
        /// </summary>
        /// <param name="dto">�u���ơC</param>
        public void Update(WorkOrderDto dto)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l��s�u��GId={Id}", dto.Id);
                _workOrderService.Update(dto);

                var index = FindWorkOrderIndex(dto.Id);
                if (index >= 0)
                {
                    WorkOrders[index] = dto;
                }
                SelectedWorkOrder = dto;
                _logger.Information("��s�u�榨�\�GId={Id}", dto.Id);
            });
        }

        /// <summary>
        /// �R���u��C
        /// </summary>
        /// <param name="id">�u�� Id�C</param>
        public void Delete(int id)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l�R���u��GId={Id}", id);
                _workOrderService.Delete(id);

                var index = FindWorkOrderIndex(id);
                if (index >= 0)
                {
                    WorkOrders.RemoveAt(index);
                }

                if (SelectedWorkOrder?.Id == id)
                {
                    SelectedWorkOrder = null;
                }
                _logger.Information("�R���u�榨�\�GId={Id}", id);
            });
        }

        /// <summary>
        /// ���s��z�M��C
        /// </summary>
        public void Refresh()
        {
            LoadAll();
        }

        /// <summary>
        /// �M������C
        /// </summary>
        public void ClearSelection()
        {
            SelectedWorkOrder = null;
            _logger.Debug("�w�M���u����");
        }

        /// <summary>
        /// �إ߷s���ťդu��]�Ω�s�W�ɡ^�C
        /// </summary>
        /// <param name="creatorId">�س�H�� Id�C</param>
        public void CreateNew(int creatorId)
        {
            SelectedWorkOrder = new WorkOrderDto
            {
                CreatorId = creatorId,
                CreationDateTime = DateTime.Now,
                Status = FlowStatus.Pending
            };
            _logger.Debug("�w�إ߷s���ťդu��");
        }

        #endregion

        #region �p����k

        private void RefreshWorkOrderList(List<WorkOrderDto> workOrders)
        {
            WorkOrders.RaiseListChangedEvents = false;
            WorkOrders.Clear();
            foreach (var workOrder in workOrders)
            {
                WorkOrders.Add(workOrder);
            }
            WorkOrders.RaiseListChangedEvents = true;
            WorkOrders.ResetBindings();
        }

        private int FindWorkOrderIndex(int id)
        {
            for (int i = 0; i < WorkOrders.Count; i++)
            {
                if (WorkOrders[i].Id == id) return i;
            }
            return -1;
        }

        private void ExecuteWithLoading(Action action)
        {
            IsLoading = true;
            ErrorMessage = null;
            try
            {
                action();
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
                _logger.Error(ex, "�ާ@�o�Ϳ��~");
            }
            finally
            {
                IsLoading = false;
                OnPropertyChanged(nameof(HasError));
            }
        }

        #endregion
    }
}
