using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Services;
using Serilog;

namespace Calin.TaskPulse.Core.ViewModels
{
    /// <summary>
    /// ���x ViewModel�A�䴩�浧����P�M�檺 WinForm DataBinding�C
    /// </summary>
    public class MachineViewModel : ViewModelBase
    {
        private readonly IMachineService _machineService;
        private readonly ILogger _logger;

        private MachineReadDto _selectedMachine;
        private BindingList<MachineReadDto> _machines;
        private bool _isLoading;
        private string _errorMessage;

        /// <summary>
        /// ��l�� MachineViewModel�C
        /// </summary>
        /// <param name="machineService">���x�A�ȡC</param>
        /// <param name="logger">��x�O�����C</param>
        public MachineViewModel(IMachineService machineService, ILogger logger)
        {
            _machineService = machineService ?? throw new ArgumentNullException(nameof(machineService));
            _logger = logger?.ForContext<MachineViewModel>() ?? Log.Logger.ForContext<MachineViewModel>();
            _machines = new BindingList<MachineReadDto>();
        }

        #region �ݩ�

        /// <summary>
        /// �ثe��������x�C
        /// </summary>
        public MachineReadDto SelectedMachine
        {
            get => _selectedMachine;
            set
            {
                if (SetProperty(ref _selectedMachine, value))
                {
                    _logger.Debug("������x�ܧ�G{MachineCode}", value?.MachineCode);
                }
            }
        }

        /// <summary>
        /// ���x�M��]�䴩 DataBinding�^�C
        /// </summary>
        public BindingList<MachineReadDto> Machines
        {
            get => _machines;
            private set => SetProperty(ref _machines, value);
        }

        /// <summary>
        /// �O�_���b���J��ơC
        /// </summary>
        public bool IsLoading
        {
            get => _isLoading;
            private set => SetProperty(ref _isLoading, value);
        }

        /// <summary>
        /// ���~�T���C
        /// </summary>
        public string ErrorMessage
        {
            get => _errorMessage;
            private set => SetProperty(ref _errorMessage, value);
        }

        /// <summary>
        /// �O�_�����~�C
        /// </summary>
        public bool HasError => !string.IsNullOrEmpty(ErrorMessage);

        #endregion

        #region �ާ@��k

        /// <summary>
        /// ���J�Ҧ����x�C
        /// </summary>
        public void LoadAll()
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J�Ҧ����x");
                var machines = _machineService.GetAll().ToList();
                RefreshMachineList(machines);
                _logger.Information("���J�����A�@ {Count} �x���x", machines.Count);
            });
        }

        /// <summary>
        /// ���J�i�ξ��x�]�B�त�^�C
        /// </summary>
        public void LoadActiveMachines()
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J�i�ξ��x");
                var machines = _machineService.GetActiveMachines().ToList();
                RefreshMachineList(machines);
                _logger.Information("���J�����A�@ {Count} �x�i�ξ��x", machines.Count);
            });
        }

        /// <summary>
        /// �̪��A���J���x�C
        /// </summary>
        /// <param name="conditionId">���A Id�C</param>
        public void LoadByCondition(int conditionId)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J���A {ConditionId} �����x", conditionId);
                var machines = _machineService.GetByConditionId(conditionId).ToList();
                RefreshMachineList(machines);
                _logger.Information("���J�����A�@ {Count} �x���x", machines.Count);
            });
        }

        /// <summary>
        /// �̦�m���J���x�C
        /// </summary>
        /// <param name="locationId">��m Id�C</param>
        public void LoadByLocation(int locationId)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J��m {LocationId} �����x", locationId);
                var machines = _machineService.GetByLocationId(locationId).ToList();
                RefreshMachineList(machines);
                _logger.Information("���J�����A�@ {Count} �x���x", machines.Count);
            });
        }

        /// <summary>
        /// �� Id ���J���x�C
        /// </summary>
        /// <param name="id">���x�D��C</param>
        public void LoadById(int id)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J���x Id={Id}", id);
                SelectedMachine = _machineService.GetById(id);
                if (SelectedMachine != null)
                {
                    _logger.Information("���J���x���\�G{MachineCode}", SelectedMachine.MachineCode);
                }
                else
                {
                    _logger.Warning("�䤣����x Id={Id}", id);
                }
            });
        }

        /// <summary>
        /// �̾��x�s�����J���x�C
        /// </summary>
        /// <param name="machineCode">���x�s���C</param>
        public void LoadByMachineCode(string machineCode)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l���J���x MachineCode={MachineCode}", machineCode);
                SelectedMachine = _machineService.GetByMachineCode(machineCode);
                if (SelectedMachine != null)
                {
                    _logger.Information("���J���x���\�G{MachineCode}", SelectedMachine.MachineCode);
                }
                else
                {
                    _logger.Warning("�䤣����x MachineCode={MachineCode}", machineCode);
                }
            });
        }

        /// <summary>
        /// �s�W���x�C
        /// </summary>
        /// <param name="dto">���x��ơC</param>
        /// <returns>�s�W�᪺���x�C</returns>
        public MachineReadDto Create(MachineReadDto dto)
        {
            MachineReadDto result = null;
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l�s�W���x�G{MachineCode}", dto.MachineCode);
                result = _machineService.Create(dto);
                Machines.Add(result);
                SelectedMachine = result;
                _logger.Information("�s�W���x���\�GId={Id}", result.Id);
            });
            return result;
        }

        /// <summary>
        /// ��s���x�C
        /// </summary>
        /// <param name="dto">���x��ơC</param>
        public void Update(MachineReadDto dto)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l��s���x�GId={Id}", dto.Id);
                _machineService.Update(dto);

                var index = FindMachineIndex(dto.Id);
                if (index >= 0)
                {
                    Machines[index] = dto;
                }
                SelectedMachine = dto;
                _logger.Information("��s���x���\�GId={Id}", dto.Id);
            });
        }

        /// <summary>
        /// �R�����x�C
        /// </summary>
        /// <param name="id">���x Id�C</param>
        public void Delete(int id)
        {
            ExecuteWithLoading(() =>
            {
                _logger.Information("�}�l�R�����x�GId={Id}", id);
                _machineService.Delete(id);

                var index = FindMachineIndex(id);
                if (index >= 0)
                {
                    Machines.RemoveAt(index);
                }

                if (SelectedMachine?.Id == id)
                {
                    SelectedMachine = null;
                }
                _logger.Information("�R�����x���\�GId={Id}", id);
            });
        }

        /// <summary>
        /// ���s��z�M��C
        /// </summary>
        public void Refresh()
        {
            LoadAll();
        }

        /// <summary>
        /// �M������C
        /// </summary>
        public void ClearSelection()
        {
            SelectedMachine = null;
            _logger.Debug("�w�M�����x���");
        }

        /// <summary>
        /// �إ߷s���ťվ��x�]�Ω�s�W�ɡ^�C
        /// </summary>
        public void CreateNew()
        {
            SelectedMachine = new MachineReadDto
            {
                ConditionId = 1 // �w�]���A
            };
            _logger.Debug("�w�إ߷s���ťվ��x");
        }

        #endregion

        #region �p����k

        private void RefreshMachineList(List<MachineReadDto> machines)
        {
            Machines.RaiseListChangedEvents = false;
            Machines.Clear();
            foreach (var machine in machines)
            {
                Machines.Add(machine);
            }
            Machines.RaiseListChangedEvents = true;
            Machines.ResetBindings();
        }

        private int FindMachineIndex(int id)
        {
            for (int i = 0; i < Machines.Count; i++)
            {
                if (Machines[i].Id == id) return i;
            }
            return -1;
        }

        private void ExecuteWithLoading(Action action)
        {
            IsLoading = true;
            ErrorMessage = null;
            try
            {
                action();
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
                _logger.Error(ex, "�ާ@�o�Ϳ��~");
            }
            finally
            {
                IsLoading = false;
                OnPropertyChanged(nameof(HasError));
            }
        }

        #endregion
    }
}
