using System;

namespace Calin.TaskPulse.Core.Navigation
{
    /// <summary>
    /// Region ��@�A�N���޿�W�� UI �e���C
    /// </summary>
    public class Region : IRegion
    {
        private bool _disposed;
        private object _activeView;
        private int? _activePageId;

        /// <inheritdoc />
        public string Name { get; }

        /// <inheritdoc />
        public object ActiveView => _activeView;

        /// <inheritdoc />
        public int? ActivePageId => _activePageId;

        /// <inheritdoc />
        public INavigationJournal NavigationJournal { get; }

        /// <inheritdoc />
        public Action<object> ViewActivationHandler { get; set; }

        /// <inheritdoc />
        public Action<object> ViewDeactivationHandler { get; set; }

        /// <summary>
        /// ��l�� Region�C
        /// </summary>
        /// <param name="name">Region �W�١C</param>
        public Region(string name)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentNullException(nameof(name));

            Name = name;
            NavigationJournal = new NavigationJournal();
        }

        /// <inheritdoc />
        public void Activate(object view, int pageId)
        {
            if (view == null)
                throw new ArgumentNullException(nameof(view));

            ThrowIfDisposed();

            // �����Υثe�� View
            if (_activeView != null)
            {
                ViewDeactivationHandler?.Invoke(_activeView);
            }

            _activeView = view;
            _activePageId = pageId;

            // �Ұʷs�� View
            ViewActivationHandler?.Invoke(view);
        }

        /// <inheritdoc />
        public void Deactivate()
        {
            ThrowIfDisposed();

            if (_activeView != null)
            {
                ViewDeactivationHandler?.Invoke(_activeView);
                _activeView = null;
                _activePageId = null;
            }
        }

        /// <inheritdoc />
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        /// <param name="disposing">�O�_���b����C</param>
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
                return;

            if (disposing)
            {
                Deactivate();
                NavigationJournal.Clear();
            }

            _disposed = true;
        }

        private void ThrowIfDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(nameof(Region));
        }
    }
}
