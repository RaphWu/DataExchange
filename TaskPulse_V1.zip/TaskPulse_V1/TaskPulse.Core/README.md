﻿# TaskPulse Core Module

## 介紹

TaskPulse Core 模組是 TaskPulse 系統的核心組件，負責提供系統的基礎功能和服務。該模組使用 .NET Framework 4.6.2 作為目標框架，並採用 C# 7.3 語言版本進行開發。

## NuGet 套件依賴

- Newtonsoft.Json
- System.Configuration.ConfigurationManager
- System.Runtime.Caching
- System.DirectoryServices.Protocols

## 資料庫操作

位於命名空間 `Calin.TaskPulse.Core.DB`，提供資料庫操作功能。<br>
參考 `Calin.TaskPulse.Core.DB/README.md` 以取得詳細資訊。

## 日誌服務

位於命名空間 `Calin.TaskPulse.Core.Logging`，提供 Serilog 日誌功能，支援多分類路由。<br>
參考 `Calin.TaskPulse.Core.Logging/README.md` 以取得詳細資訊。

## 導航服務

位於命名空間 `Calin.TaskPulse.Core.Navigation`，提供 Region 導向的頁面導航功能。<br>
參考 `Calin.TaskPulse.Core.Navigation/README.md` 以取得詳細資訊。

## 對話框服務

位於命名空間 `Calin.TaskPulse.Core.Dialogs`，提供可擴充的對話框管理功能。<br>
參考 `Calin.TaskPulse.Core.Dialogs/README.md` 以取得詳細資訊。
