﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.DB;
using Calin.TaskPulse.Core.DB.Repositories;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Permission
{
    /// <summary>
    /// 使用者權限服務實作。
    /// </summary>
    public class PermissionService : IPermissionService
    {
        private readonly Func<CoreContext> _contextFactory;
        private readonly MemoryCacheService _cache;
        private readonly CurrentUserContext _user;

        /// <summary>
        /// 初始化 <see cref="PermissionService"/> 類別的新執行個體。
        /// </summary>
        /// <param name="contextFactory">資料庫上下文工廠方法。</param>
        /// <param name="cache">記憶體快取服務。</param>
        /// <param name="currentUserContext">目前使用者上下文。</param>
        public PermissionService(
            Func<CoreContext> contextFactory,
            MemoryCacheService cache,
            CurrentUserContext currentUserContext)
        {
            _contextFactory = contextFactory ?? throw new ArgumentNullException(nameof(contextFactory));
            _cache = cache;
            _user = currentUserContext;
        }

        /********************
         * from CurrentUserContext
         ********************/
        /// <inheritdoc/>
        public bool IsAdmin => _user.IsAdmin;

        /// <inheritdoc/>
        public bool IsGuest => _user.IsGuest;

        /********************
         * Employee Permissions
         ********************/
        /// <inheritdoc/>
        public HashSet<PermissionData> GetFullPermissions(string employeeId)
        {
            using (var context = _contextFactory())
            {
                var repository = new PermissionRepository(context, null);
                var user = repository.GetEmployeeWithFullPermissions(employeeId);

                if (user == null || user.StatusId != 1)
                    return new HashSet<PermissionData>();

                if (user.Id == int.MaxValue)
                    return new HashSet<PermissionData> { new PermissionData { PermissionString = "*" } };

                var permissions = new HashSet<PermissionData>();

                // 部門權限
                if (user.Department?.DepartmentPermissions != null)
                {
                    var deptPermissions = user.Department.DepartmentPermissions.Select(dp => dp.Permission);
                    permissions.UnionWith(ToPermissionDataSet(deptPermissions));
                }

                // 群組權限
                if (user.EmployeeGroups != null && user.EmployeeGroups.Count > 0)
                {
                    foreach (var eg in user.EmployeeGroups)
                    {
                        if (eg.Group?.GroupPermissions != null)
                        {
                            var groupPermissions = eg.Group.GroupPermissions.Select(gp => gp.Permission);
                            permissions.UnionWith(ToPermissionDataSet(groupPermissions));
                        }
                    }
                }

                // 使用者個人權限
                if (user.EmployeePermissions != null)
                {
                    var userPermissions = user.EmployeePermissions.Select(ep => ep.Permission);
                    permissions.UnionWith(ToPermissionDataSet(userPermissions));
                }

                return permissions;
            }
        }

        /// <inheritdoc/>
        public HashSet<PermissionData> GetUserPermissions(string employeeId)
        {
            string cacheKey = $"UserPermissions:{employeeId}";
            return _cache.GetOrCreate(cacheKey, policy =>
            {
                using (var context = _contextFactory())
                {
                    var repository = new PermissionRepository(context, null);
                    var user = repository.GetEmployeeWithUserPermissions(employeeId);

                    if (user == null || user.StatusId != 1)
                        return new HashSet<PermissionData>();

                    if (user.Id == int.MaxValue)
                        return new HashSet<PermissionData> { new PermissionData { PermissionString = "*" } };

                    var userPermissions = user.EmployeePermissions.Select(ep => ep.Permission);
                    return ToPermissionDataSet(userPermissions);
                }
            }, TimeSpan.FromMinutes(30));
        }

        /// <inheritdoc/>
        public bool HasPermission(string employeeId, string permission)
        {
            if (_user.IsAdmin)
                return true;

            using (var context = _contextFactory())
            {
                var repository = new PermissionRepository(context, null);
                var user = repository.GetEmployeeByEmployeeId(employeeId);
                if (user == null)
                    return false;
            }

            var all = GetFullPermissions(employeeId);
            return all.Any(p => IsMatch(p, permission));
        }

        /********************
         * Department Permissions
         ********************/
        /// <inheritdoc/>
        public HashSet<PermissionData> GetDepartmentPermissions(int departmentId)
        {
            string cacheKey = $"DepartmentPermissions:{departmentId}";
            return _cache.GetOrCreate(cacheKey, policy =>
            {
                using (var context = _contextFactory())
                {
                    var repository = new PermissionRepository(context, null);
                    var dept = repository.GetDepartmentWithPermissions(departmentId);

                    if (dept?.DepartmentPermissions == null)
                        return new HashSet<PermissionData>();

                    var permissions = dept.DepartmentPermissions.Select(dp => dp.Permission);
                    return ToPermissionDataSet(permissions);
                }
            }, TimeSpan.FromMinutes(30));
        }

        /********************
         * UserGroup Permissions
         ********************/
        /// <inheritdoc/>
        public HashSet<PermissionData> GetUserGroupPermissions(int groupId)
        {
            string cacheKey = $"UserGroupPermissions:{groupId}";
            return _cache.GetOrCreate(cacheKey, policy =>
            {
                using (var context = _contextFactory())
                {
                    var repository = new PermissionRepository(context, null);
                    var group = repository.GetGroupWithPermissions(groupId);

                    if (group?.GroupPermissions == null)
                        return new HashSet<PermissionData>();

                    var permissions = group.GroupPermissions.Select(gp => gp.Permission);
                    return ToPermissionDataSet(permissions);
                }
            }, TimeSpan.FromMinutes(30));
        }

        /********************
         * Utilities
         ********************/
        /// <inheritdoc/>
        public async Task CleanOrphanPermissions()
        {
            using (var context = _contextFactory())
            {
                var repository = new PermissionRepository(context, null);
                await repository.CleanOrphanPermissionsAsync();
            }
        }

        /// <summary>
        /// 將 EF 實體轉成權限集合。
        /// </summary>
        /// <param name="permissions">權限實體集合。</param>
        /// <returns>權限資料集合。</returns>
        private HashSet<PermissionData> ToPermissionDataSet(IEnumerable<PermissionEntity> permissions)
        {
            var result = new HashSet<PermissionData>();
            if (permissions == null)
                return result;

            foreach (var p in permissions)
            {
                if (p == null) continue;

                result.Add(new PermissionData
                {
                    Id = p.Id,
                    Module = p.Module,
                    Page = p.Page,
                    Control = p.Control,
                    Action = p.Action,
                    PermissionString = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}",
                    PermissionType = (PermissionType)p.PermissionType
                });
            }
            return result;
        }

        /// <summary>
        /// 權限比對，支援萬用字元。
        /// </summary>
        /// <param name="p">已授權的權限資料。</param>
        /// <param name="permission">目標權限字串。</param>
        /// <returns>傳回是否匹配。</returns>
        private bool IsMatch(PermissionData p, string permission)
        {
            if (p == null || string.IsNullOrEmpty(permission))
                return false;

            if (p.PermissionString == "*")
                return true;

            var parts = permission.Split(':');
            if (parts.Length != 4)
                return false;

            return string.Equals(p.Module, parts[0], StringComparison.OrdinalIgnoreCase)
                && string.Equals(p.Page, parts[1], StringComparison.OrdinalIgnoreCase)
                && string.Equals(p.Control, parts[2], StringComparison.OrdinalIgnoreCase)
                && string.Equals(p.Action, parts[3], StringComparison.OrdinalIgnoreCase);
        }

        /********************
         * Control Access
         ********************/
        /// <summary>
        /// 內部權限檢查方法，統一處理權限比對邏輯。
        /// </summary>
        /// <param name="module">模組名稱。</param>
        /// <param name="page">頁面名稱。</param>
        /// <param name="control">控制項名稱。</param>
        /// <param name="action">動作名稱。</param>
        /// <returns>是否有權限。</returns>
        private bool HasControlAccessInternal(string module, string page, string control, string action)
        {
            if (_user.IsAdmin)
                return true;

            if (_user.Permissions == null || !_user.Permissions.Any())
                return false;

            var cmp = StringComparison.OrdinalIgnoreCase;
            bool hasAllow = false;

            // 先檢查 Deny 權限（優先級最高）
            foreach (var p in _user.Permissions.Where(p => p.PermissionType == PermissionType.Deny))
            {
                if (p == null)
                    continue;

                if (string.Equals(p.PermissionString, "*", cmp))
                    return false;

                // Module 層級
                if (string.Equals(p.Module, "**", cmp))
                    return false;
                else if (!string.Equals(p.Module, "*", cmp))
                {
                    if (module != null)
                    {
                        if (!string.Equals(p.Module, module, cmp))
                            continue;
                    }
                }

                // Page 層級
                if (string.Equals(p.Page, "**", cmp))
                    return false;
                else if (!string.Equals(p.Page, "*", cmp))
                {
                    if (page != null)
                    {
                        if (!string.Equals(p.Page, page, cmp))
                            continue;
                    }
                }

                // Control 層級
                if (string.Equals(p.Control, "**", cmp))
                    return false;
                else if (!string.Equals(p.Control, "*", cmp))
                {
                    if (control != null)
                    {
                        if (!string.Equals(p.Control, control, cmp))
                            continue;
                    }
                }

                // Action 層級
                if (action == null)
                    return false;

                if (string.Equals(p.Action, "**", cmp))
                    return false;
                if (string.Equals(p.Action, "*", cmp))
                    return false;
                if (string.Equals(p.Action, action, cmp))
                    return false;
            }

            // 再檢查 Allow 權限
            foreach (var p in _user.Permissions.Where(p => p.PermissionType == PermissionType.Allow))
            {
                if (p == null)
                    continue;

                if (string.Equals(p.PermissionString, "*", cmp))
                {
                    hasAllow = true;
                    break;
                }

                // Module 層級
                if (string.Equals(p.Module, "**", cmp))
                {
                    hasAllow = true;
                    break;
                }
                else if (!string.Equals(p.Module, "*", cmp))
                {
                    if (module != null)
                    {
                        if (!string.Equals(p.Module, module, cmp))
                            continue;
                    }
                }

                // Page 層級
                if (string.Equals(p.Page, "**", cmp))
                {
                    hasAllow = true;
                    break;
                }
                else if (!string.Equals(p.Page, "*", cmp))
                {
                    if (page != null)
                    {
                        if (!string.Equals(p.Page, page, cmp))
                            continue;
                    }
                }

                // Control 層級
                if (string.Equals(p.Control, "**", cmp))
                {
                    hasAllow = true;
                    break;
                }
                else if (!string.Equals(p.Control, "*", cmp))
                {
                    if (control != null)
                    {
                        if (!string.Equals(p.Control, control, cmp))
                            continue;
                    }
                }

                // Action 層級
                if (action == null)
                {
                    hasAllow = true;
                    break;
                }

                if (string.Equals(p.Action, "**", cmp))
                {
                    hasAllow = true;
                    break;
                }
                if (string.Equals(p.Action, "*", cmp))
                {
                    hasAllow = true;
                    break;
                }
                if (string.Equals(p.Action, action, cmp))
                {
                    hasAllow = true;
                    break;
                }
            }

            return hasAllow;
        }

        /// <inheritdoc/>
        public bool HasControlAccess(string module, string page, string control, string action)
        {
            return HasControlAccessInternal(module, page, control, action);
        }

        /// <inheritdoc/>
        public bool HasControlAccess(string module, string page, string control)
        {
            return HasControlAccessInternal(module, page, control, null);
        }

        /// <inheritdoc/>
        public bool HasControlAccess(string module, string page)
        {
            return HasControlAccessInternal(module, page, null, null);
        }

        /// <inheritdoc/>
        public bool HasControlAccess(string module)
        {
            return HasControlAccessInternal(module, null, null, null);
        }

        /// <inheritdoc/>
        public Dictionary<string, PermissionSource> GetPermissionSources(string employeeId)
        {
            string cacheKey = $"UserPermissionSources_{employeeId}";

            return _cache.GetOrCreate(cacheKey, policy =>
            {
                var permissionSources = new Dictionary<string, PermissionSource>();

                using (var context = _contextFactory())
                {
                    var repository = new PermissionRepository(context, null);
                    var user = repository.GetEmployeeWithFullPermissions(employeeId);

                    if (user == null)
                        return permissionSources;

                    // 部門權限
                    if (user.Department?.DepartmentPermissions != null)
                    {
                        foreach (var dp in user.Department.DepartmentPermissions)
                        {
                            var p = dp.Permission;
                            if (p == null) continue;
                            string key = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}";
                            if (!permissionSources.ContainsKey(key))
                                permissionSources[key] = PermissionSource.Department;
                        }
                    }

                    // 群組權限
                    if (user.EmployeeGroups != null)
                    {
                        foreach (var eg in user.EmployeeGroups)
                        {
                            if (eg.Group?.GroupPermissions != null)
                            {
                                foreach (var gp in eg.Group.GroupPermissions)
                                {
                                    var p = gp.Permission;
                                    if (p == null) continue;
                                    string key = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}";
                                    if (!permissionSources.ContainsKey(key))
                                        permissionSources[key] = PermissionSource.UserGroup;
                                }
                            }
                        }
                    }

                    // 個人權限
                    if (user.EmployeePermissions != null)
                    {
                        foreach (var ep in user.EmployeePermissions)
                        {
                            var p = ep.Permission;
                            if (p == null) continue;
                            string key = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}";
                            if (!permissionSources.ContainsKey(key))
                                permissionSources[key] = PermissionSource.Employee;
                        }
                    }

                    return permissionSources;
                }
            }, TimeSpan.FromMinutes(30));
        }

        /// <inheritdoc/>
        public PermissionSource GetPermissionSource(string employeeId, string module, string page, string control, string action)
        {
            var sources = GetPermissionSources(employeeId);
            string key = $"{module}:{page}:{control}:{action}";

            return sources.TryGetValue(key, out var source)
                ? source
                : PermissionSource.None;
        }

        /// <inheritdoc/>
        public void ClearUserPermissionSourceCache(string employeeId)
        {
            string cacheKey = $"UserPermissionSources_{employeeId}";
            _cache.Remove(cacheKey);
        }

        /********************
         * Refresh
         ********************/
        /// <inheritdoc/>
        public void RefreshDepartmentPermissions(int departmentId)
        {
            _cache.Remove($"DepartmentPermissions:{departmentId}");
        }

        /// <inheritdoc/>
        public void RefreshUserGroupPermissions(int userGroupId)
        {
            _cache.Remove($"UserGroupPermissions:{userGroupId}");
        }

        /// <inheritdoc/>
        public void RefreshUserPermissions(string employeeId)
        {
            _cache.Remove($"UserPermissions:{employeeId}");
        }

        /********************
         * 轉換
         ********************/
        /// <inheritdoc/>
        public string LevelToString(string module, string page, string control, string action)
        {
            return $"{module}:{page}:{control}:{action}";
        }

        /// <inheritdoc/>
        public (string module, string page, string control, string action) StringToLevel(string permission)
        {
            var parts = permission?.Split(':').Select(p => p.Trim()).ToArray();
            if (parts == null || parts.Length != 4)
                throw new ArgumentException("permission format must be 'module:page:control:action'");
            return (parts[0], parts[1], parts[2], parts[3]);
        }

        /********************
         * 權限分析與管理
         ********************/
        /// <inheritdoc/>
        public List<PermissionItemViewModel> GetPermissionDetails(string employeeId)
        {
            var result = new List<PermissionItemViewModel>();

            using (var context = _contextFactory())
            {
                var repository = new PermissionRepository(context, null);
                var user = repository.GetEmployeeWithFullPermissions(employeeId);

                if (user == null)
                    return result;

                // 部門權限
                if (user.Department?.DepartmentPermissions != null)
                {
                    foreach (var dp in user.Department.DepartmentPermissions)
                    {
                        var p = dp.Permission;
                        if (p == null) continue;

                        result.Add(new PermissionItemViewModel
                        {
                            Module = p.Module,
                            Page = p.Page,
                            Control = p.Control,
                            Action = p.Action,
                            PermissionString = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}",
                            Type = (PermissionType)p.PermissionType,
                            Source = PermissionSource.Department,
                            SourceName = user.Department.DepartmentName,
                            IsInherited = true
                        });
                    }
                }

                // 群組權限
                if (user.EmployeeGroups != null)
                {
                    foreach (var eg in user.EmployeeGroups)
                    {
                        if (eg.Group?.GroupPermissions != null)
                        {
                            foreach (var gp in eg.Group.GroupPermissions)
                            {
                                var p = gp.Permission;
                                if (p == null) continue;

                                result.Add(new PermissionItemViewModel
                                {
                                    Module = p.Module,
                                    Page = p.Page,
                                    Control = p.Control,
                                    Action = p.Action,
                                    PermissionString = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}",
                                    Type = (PermissionType)p.PermissionType,
                                    Source = PermissionSource.UserGroup,
                                    SourceName = eg.Group.Name,
                                    IsInherited = true
                                });
                            }
                        }
                    }
                }

                // 個人權限
                if (user.EmployeePermissions != null)
                {
                    foreach (var ep in user.EmployeePermissions)
                    {
                        var p = ep.Permission;
                        if (p == null) continue;

                        result.Add(new PermissionItemViewModel
                        {
                            Module = p.Module,
                            Page = p.Page,
                            Control = p.Control,
                            Action = p.Action,
                            PermissionString = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}",
                            Type = (PermissionType)p.PermissionType,
                            Source = PermissionSource.Employee,
                            SourceName = user.EmployeeName,
                            IsInherited = false
                        });
                    }
                }
            }

            return result;
        }

        /// <inheritdoc/>
        public List<PermissionMergeResult> GetMergedPermissions(string employeeId)
        {
            var details = GetPermissionDetails(employeeId);
            var grouped = details.GroupBy(p => p.PermissionString);
            var results = new List<PermissionMergeResult>();

            foreach (var group in grouped)
            {
                var items = group.ToList();
                var first = items.First();

                var denyItem = items
                    .Where(p => p.Type == PermissionType.Deny)
                    .OrderBy(p => p.Source == PermissionSource.Employee ? 0 :
                                  p.Source == PermissionSource.UserGroup ? 1 : 2)
                    .FirstOrDefault();

                if (denyItem != null)
                {
                    results.Add(new PermissionMergeResult
                    {
                        Module = first.Module,
                        Page = first.Page,
                        Control = first.Control,
                        Action = first.Action,
                        PermissionString = first.PermissionString,
                        FinalType = PermissionType.Deny,
                        DecidingSource = denyItem.Source,
                        DecidingSourceName = denyItem.SourceName,
                        HasConflict = items.Any(p => p.Type == PermissionType.Allow),
                        AllSources = items
                    });
                }
                else
                {
                    var allowItem = items
                        .OrderBy(p => p.Source == PermissionSource.Employee ? 0 :
                                      p.Source == PermissionSource.UserGroup ? 1 : 2)
                        .First();

                    results.Add(new PermissionMergeResult
                    {
                        Module = first.Module,
                        Page = first.Page,
                        Control = first.Control,
                        Action = first.Action,
                        PermissionString = first.PermissionString,
                        FinalType = PermissionType.Allow,
                        DecidingSource = allowItem.Source,
                        DecidingSourceName = allowItem.SourceName,
                        HasConflict = false,
                        AllSources = items
                    });
                }
            }

            return results;
        }

        /// <inheritdoc/>
        public List<PermissionConflictViewModel> GetPermissionConflicts(string employeeId)
        {
            var details = GetPermissionDetails(employeeId);
            var grouped = details.GroupBy(p => p.PermissionString);
            var conflicts = new List<PermissionConflictViewModel>();

            foreach (var group in grouped)
            {
                var items = group.ToList();

                if (items.Select(p => p.Type).Distinct().Count() <= 1)
                    continue;

                var first = items.First();
                var deptItem = items.FirstOrDefault(p => p.Source == PermissionSource.Department);
                var groupItems = items.Where(p => p.Source == PermissionSource.UserGroup).ToList();
                var empItem = items.FirstOrDefault(p => p.Source == PermissionSource.Employee);

                var conflict = new PermissionConflictViewModel
                {
                    Module = first.Module,
                    Page = first.Page,
                    Control = first.Control,
                    Action = first.Action,
                    PermissionString = first.PermissionString,
                    DepartmentSetting = deptItem?.Type,
                    DepartmentName = deptItem?.SourceName,
                    EmployeeSetting = empItem?.Type
                };

                foreach (var gi in groupItems)
                {
                    conflict.UserGroupSettings.Add((gi.SourceName, gi.Type));
                }

                if (empItem?.Type == PermissionType.Deny)
                {
                    conflict.FinalType = PermissionType.Deny;
                    conflict.ConflictLevel = 2;
                    conflict.ConflictDescription = "個人設定為禁止，覆蓋其他來源";
                }
                else if (groupItems.Any(g => g.Type == PermissionType.Deny))
                {
                    conflict.FinalType = PermissionType.Deny;
                    conflict.ConflictLevel = 2;
                    var denyGroup = groupItems.First(g => g.Type == PermissionType.Deny);
                    conflict.ConflictDescription = $"群組「{denyGroup.SourceName}」設定為禁止";
                }
                else if (deptItem?.Type == PermissionType.Deny)
                {
                    conflict.FinalType = PermissionType.Deny;
                    conflict.ConflictLevel = 2;
                    conflict.ConflictDescription = "部門設定為禁止";
                }
                else
                {
                    conflict.FinalType = PermissionType.Allow;
                    conflict.ConflictLevel = 1;
                    conflict.ConflictDescription = "有允許設定，但存在來源衝突";
                }

                conflicts.Add(conflict);
            }

            return conflicts;
        }
    }
}
