﻿namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// TextBox 資料。
    /// </summary>
    public class TextBoxInfo
    {
        /// <summary>
        /// 值。
        /// </summary>
        public string Value { get; set; } = "";

        /// <summary>
        /// 標題。
        /// </summary>
        public string Caption { get; set; } = "";

        /// <summary>
        /// 浮水印文字。
        /// </summary>
        public string WaterMark { get; set; } = "";
    }
}
