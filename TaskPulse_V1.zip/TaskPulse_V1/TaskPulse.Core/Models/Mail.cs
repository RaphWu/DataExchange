﻿namespace Calin.TaskPulse.Core.Models
{
    public class Mail
    {
        //public string EmployeeId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
