﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB.Mappers
{
    /// <summary>
    /// 提供 MachineEntity 與 MachineReadDto 之間的映射方法。
    /// </summary>
    public static class MachineMapper
    {
        /// <summary>
        /// 將 MachineEntity 轉換為 MachineReadDto。
        /// </summary>
        /// <param name="entity">要轉換的 MachineEntity 實例。</param>
        /// <returns>對應的 MachineReadDto 實例，若 <paramref name="entity"/> 為 null，則返回 null。</returns>
        public static MachineReadDto ToDto(this MachineEntity entity)
        {
            if (entity == null) return null;

            var assetCodes = entity.Assets?.Select(a => a.AssetCode).ToList() ?? new List<string>();

            return new MachineReadDto
            {
                Id = entity.Id,
                MachineCode = entity.MachineCode,
                MachineNameId = entity.MachineNameId,
                ModelName = entity.MachineName?.ModelName,
                TypeId = entity.MachineTypeId,
                TypeName = entity.MachineType?.TypeName,
                ConditionId = entity.ConditionId,
                ConditionName = entity.Condition?.ConditionName,
                BrandId = entity.BrandId,
                BrandName = entity.Brand?.BrandName,
                LocationId = entity.LocationId,
                LocationName = entity.Location?.LocationName,
                Assets = string.Join(", ", assetCodes),
                SerialNumber = entity.SerialNumber,
                Barcode = entity.Barcode,
                IssueCategoryId = entity.IssueCategoryId,
                IssueCategory = entity.IssueCategory?.CategoryName,
                Connected = entity.Connected,
                Disposal = entity.Disposal,
                Remark = entity.Remark,

                CategoryId = entity.MachineName?.MachineType?.CategoryId ?? -1,
                CategoryName = entity.MachineName?.MachineType?.Category?.CategoryName,
                CategoryOrderNo = entity.MachineName?.MachineType?.Category?.OrderNo ?? int.MaxValue,
                TypeOrderNo = entity.MachineName?.MachineType?.OrderNo ?? int.MaxValue,
                AssetList = string.Join(Environment.NewLine, assetCodes),
                ConnectedString = entity.Connected ? "可連網" : "",
                DisposalString = entity.Disposal ? "已處置" : "",
            };
        }

        /// <summary>
        /// 將 MachineReadDto 轉換為 MachineEntity。
        /// </summary>
        /// <param name="dto">要轉換的 MachineReadDto 實例。</param>
        /// <returns>對應的 MachineEntity 實例，若 <paramref name="dto"/> 為 null，則返回 null。</returns>
        public static MachineEntity ToEntity(this MachineReadDto dto)
        {
            if (dto == null) return null;

            return new MachineEntity
            {
                Id = dto.Id,
                MachineCode = dto.MachineCode,
                MachineNameId = dto.MachineNameId,
                MachineTypeId = dto.TypeId,
                ConditionId = dto.ConditionId,
                BrandId = dto.BrandId,
                LocationId = dto.LocationId,
                // Assets 需要另外處理，因為是一對多關聯
                SerialNumber = dto.SerialNumber,
                Barcode = dto.Barcode,
                IssueCategoryId = dto.IssueCategoryId,
                Connected = dto.Connected,
                Disposal = dto.Disposal,
                Remark = dto.Remark
            };
        }

        /// <summary>
        /// 將 MachineEntity 集合轉換為 MachineReadDto 集合。
        /// </summary>
        /// <param name="entities">要轉換的 MachineEntity 集合。</param>
        /// <returns>對應的 MachineReadDto 集合，若 <paramref name="entities"/> 為 null，則返回空集合。</returns>
        public static IEnumerable<MachineReadDto> ToDtoList(this IEnumerable<MachineEntity> entities)
        {
            return entities?.Select(e => e.ToDto()) ?? Enumerable.Empty<MachineReadDto>();
        }
    }
}
