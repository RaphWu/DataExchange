﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB.Mappers
{
    /// <summary>
    /// 提供 GroupEntity 與 GroupDto 之間的轉換方法。
    /// </summary>
    public static class GroupMapper
    {
        /// <summary>
        /// 將 <see cref="GroupEntity"/> 轉換為 <see cref="GroupDto"/>。
        /// </summary>
        /// <param name="entity">要轉換的 <see cref="GroupEntity"/> 實例。</param>
        /// <returns>轉換後的 <see cref="GroupDto"/> 實例；如果輸入為 null，則回傳 null。</returns>
        public static GroupDto ToDto(this GroupEntity entity)
        {
            if (entity == null) return null;

            return new GroupDto
            {
                Id = entity.Id,
                OrderNo = entity.OrderNo,
                Name = entity.Name
            };
        }

        /// <summary>
        /// 將 <see cref="GroupDto"/> 轉換為 <see cref="GroupEntity"/>。
        /// </summary>
        /// <param name="dto">要轉換的 <see cref="GroupDto"/> 實例。</param>
        /// <returns>轉換後的 <see cref="GroupEntity"/> 實例；如果輸入為 null，則回傳 null。</returns>
        public static GroupEntity ToEntity(this GroupDto dto)
        {
            if (dto == null) return null;

            return new GroupEntity
            {
                Id = dto.Id,
                OrderNo = dto.OrderNo,
                Name = dto.Name
            };
        }

        /// <summary>
        /// 將 <see cref="IEnumerable{GroupEntity}"/> 轉換為 <see cref="IEnumerable{GroupDto}"/>。
        /// </summary>
        /// <param name="entities">要轉換的 <see cref="GroupEntity"/> 集合。</param>
        /// <returns>轉換後的 <see cref="GroupDto"/> 集合；如果輸入為 null，則回傳空集合。</returns>
        public static IEnumerable<GroupDto> ToDtoList(this IEnumerable<GroupEntity> entities)
        {
            return entities?.Select(e => e.ToDto()) ?? Enumerable.Empty<GroupDto>();
        }
    }
}
