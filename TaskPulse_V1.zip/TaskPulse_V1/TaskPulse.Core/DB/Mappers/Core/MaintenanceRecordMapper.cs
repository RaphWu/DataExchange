﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.DB.Mappers
{
    /// <summary>
    /// 提供 MaintenanceRecordEntity 與 MaintenanceRecordDto 之間的映射功能。
    /// </summary>
    public static class MaintenanceRecordMapper
    {
        /// <summary>
        /// 將 MaintenanceRecordEntity 轉換為 MaintenanceRecordDto。
        /// </summary>
        /// <param name="entity">要轉換的 MaintenanceRecordEntity 實例。</param>
        /// <returns>對應的 MaintenanceRecordDto 實例，若輸入為 null 則返回 null。</returns>
        public static MaintenanceRecordDto ToDto(this MaintenanceRecordEntity entity)
        {
            if (entity == null) return null;

            return new MaintenanceRecordDto
            {
                Id = entity.Id,
                WorkOrderId = entity.WorkOrderId,
                IssueCategoryId = entity.IssueCategoryId,
                IssueCategoryName = entity.IssueCategory?.CategoryName,
                IssueDescription = entity.IssueDescription,
                Details = entity.Details,
                FillingTime = entity.FillingTime,
                FeedbackEmployeeId = entity.FeedbackEmployeeId,
                FeedbackEmployeeName = entity.FeedbackEmployee?.EmployeeName,
                Feedback = entity.Feedback,
                OutageStarted = entity.OutageStarted,
                OutageEnded = entity.OutageEnded,
                OutageDurationTick = entity.OutageDurationTick,
                EngineerIds = entity.MaintenanceRecordEngineers?.Select(e => e.EmployeeId).ToList() ?? new List<int>()
            };
        }

        /// <summary>
        /// 將 MaintenanceRecordDto 轉換為 MaintenanceRecordEntity。
        /// </summary>
        /// <param name="dto">要轉換的 MaintenanceRecordDto 實例。</param>
        /// <returns>對應的 MaintenanceRecordEntity 實例，若輸入為 null 則返回 null。</returns>
        public static MaintenanceRecordEntity ToEntity(this MaintenanceRecordDto dto)
        {
            if (dto == null) return null;

            return new MaintenanceRecordEntity
            {
                Id = dto.Id,
                WorkOrderId = dto.WorkOrderId,
                IssueCategoryId = dto.IssueCategoryId,
                IssueDescription = dto.IssueDescription,
                Details = dto.Details,
                FillingTime = dto.FillingTime,
                FeedbackEmployeeId = dto.FeedbackEmployeeId,
                Feedback = dto.Feedback,
                OutageStarted = dto.OutageStarted,
                OutageEnded = dto.OutageEnded,
                OutageDurationTick = dto.OutageDurationTick
            };
        }

        /// <summary>
        /// 將一組 MaintenanceRecordEntity 轉換為對應的 MaintenanceRecordDto 集合。
        /// </summary>
        /// <param name="entities">要轉換的 MaintenanceRecordEntity 集合。</param>
        /// <returns>對應的 MaintenanceRecordDto 集合，若輸入為 null 則返回空集合。</returns>
        public static IEnumerable<MaintenanceRecordDto> ToDtoList(this IEnumerable<MaintenanceRecordEntity> entities)
        {
            return entities?.Select(e => e.ToDto()) ?? Enumerable.Empty<MaintenanceRecordDto>();
        }
    }
}
