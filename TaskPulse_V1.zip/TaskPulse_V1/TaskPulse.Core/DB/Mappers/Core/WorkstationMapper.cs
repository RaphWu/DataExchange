﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB.Mappers
{
    /// <summary>
    /// 提供將 <see cref="WorkstationEntity"/> 和 <see cref="WorkstationReadDto"/> 之間進行轉換的靜態方法。
    /// </summary>
    public static class WorkstationMapper
    {
        /// <summary>
        /// 將 <see cref="WorkstationEntity"/> 轉換為 <see cref="WorkstationReadDto"/>。
        /// </summary>
        /// <param name="entity">要轉換的 <see cref="WorkstationEntity"/> 實例。</param>
        /// <returns>轉換後的 <see cref="WorkstationReadDto"/> 實例。如果 <paramref name="entity"/> 為 null，則返回 null。</returns>
        public static WorkstationReadDto ToDto(this WorkstationEntity entity)
        {
            if (entity == null) return null;

            string modelName = entity.Model?.ModelName;
            string workstationName = entity.WorkstationName;
            bool hasWorkstation = !string.IsNullOrWhiteSpace(workstationName);
            string fullWorkstationName = "";
            if (entity.Model != null)
            {
                fullWorkstationName = modelName;
                if (hasWorkstation)
                    fullWorkstationName += " » ";
            }
            if (hasWorkstation)
                fullWorkstationName += workstationName;

            return new WorkstationReadDto
            {
                Id = entity.Id,
                OrderNo = entity.OrderNo,
                WorkstationName = workstationName,
                ModelId = entity.ModelId,
                ModelName = modelName,

                FullWorkstationName = fullWorkstationName,
            };
        }

        /// <summary>
        /// 將 <see cref="WorkstationReadDto"/> 轉換為 <see cref="WorkstationEntity"/>。
        /// </summary>
        /// <param name="dto">要轉換的 <see cref="WorkstationReadDto"/> 實例。</param>
        /// <returns>轉換後的 <see cref="WorkstationEntity"/> 實例。如果 <paramref name="dto"/> 為 null，則返回 null。</returns>
        public static WorkstationEntity ToEntity(this WorkstationReadDto dto)
        {
            if (dto == null) return null;

            return new WorkstationEntity
            {
                Id = dto.Id,
                OrderNo = dto.OrderNo,
                WorkstationName = dto.WorkstationName,
                ModelId = dto.ModelId
            };
        }

        /// <summary>
        /// 將 <see cref="IEnumerable{WorkstationEntity}"/> 轉換為 <see cref="IEnumerable{WorkstationReadDto}"/>。
        /// </summary>
        /// <param name="entities">要轉換的 <see cref="WorkstationEntity"/> 集合。</param>
        /// <returns>轉換後的 <see cref="WorkstationReadDto"/> 集合。如果 <paramref name="entities"/> 為 null，則返回空集合。</returns>
        public static IEnumerable<WorkstationReadDto> ToDtoList(this IEnumerable<WorkstationEntity> entities)
        {
            return entities?.Select(e => e.ToDto()) ?? Enumerable.Empty<WorkstationReadDto>();
        }
    }
}
