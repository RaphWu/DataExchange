﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB.Mappers
{
    /// <summary>
    /// 提供 MachineCategoryEntity 與 MachineCategoryDto 之間的轉換方法。
    /// </summary>
    public static class MachineCategoryMapper
    {
        /// <summary>
        /// 將 MachineCategoryEntity 轉換為 MachineCategoryDto。
        /// </summary>
        /// <param name="entity">要轉換的 MachineCategoryEntity 實例。</param>
        /// <returns>轉換後的 MachineCategoryDto 實例，若輸入為 null 則回傳 null。</returns>
        public static MachineCategoryDto ToDto(this MachineCategoryEntity entity)
        {
            if (entity == null) return null;

            return new MachineCategoryDto
            {
                Id = entity.Id,
                OrderNo = entity.OrderNo,
                CategoryName = entity.CategoryName,
                MachineTypes = entity.MachineTypes?.Select(mt => mt.ToDto()).ToList()
            };
        }

        /// <summary>
        /// 將 MachineCategoryDto 轉換為 MachineCategoryEntity。
        /// </summary>
        /// <param name="dto">要轉換的 MachineCategoryDto 實例。</param>
        /// <returns>轉換後的 MachineCategoryEntity 實例，若輸入為 null 則回傳 null。</returns>
        public static MachineCategoryEntity ToEntity(this MachineCategoryDto dto)
        {
            if (dto == null) return null;

            return new MachineCategoryEntity
            {
                Id = dto.Id,
                OrderNo = dto.OrderNo,
                CategoryName = dto.CategoryName,
                MachineTypes = dto.MachineTypes?.Select(mt => mt.ToEntity()).ToList()
            };
        }

        /// <summary>
        /// 將一組 MachineCategoryEntity 轉換為 MachineCategoryDto 的集合。
        /// </summary>
        /// <param name="entities">要轉換的 MachineCategoryEntity 集合。</param>
        /// <returns>轉換後的 MachineCategoryDto 集合，若輸入為 null 則回傳空集合。</returns>
        public static IEnumerable<MachineCategoryDto> ToDtoList(this IEnumerable<MachineCategoryEntity> entities)
        {
            return entities?.Select(e => e.ToDto()) ?? Enumerable.Empty<MachineCategoryDto>();
        }
    }
}
