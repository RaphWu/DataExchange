using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB.Mappers
{
    /// <summary>
    /// ���� MachineTypeEntity �P MachineTypeDto �������ഫ��k�C
    /// </summary>
    public static class MachineTypeMapper
    {
        /// <summary>
        /// �N <see cref="MachineTypeEntity"/> �ഫ�� <see cref="MachineTypeDto"/>�C
        /// </summary>
        /// <param name="entity">�n�ഫ�� <see cref="MachineTypeEntity"/> ��ҡC</param>
        /// <returns>�ഫ�᪺ <see cref="MachineTypeDto"/> ��ҡC�p�G��J�� null�A�h��^ null�C</returns>
        public static MachineTypeDto ToDto(this MachineTypeEntity entity)
        {
            if (entity == null) return null;

            return new MachineTypeDto
            {
                Id = entity.Id,
                OrderNo = entity.OrderNo,
                TypeName = entity.TypeName,
                CategoryId = entity.CategoryId,
                CategoryName = entity.Category?.CategoryName,
                MachineNames = entity.MachineNames?.Select(m => m.ToDto()).ToList()
            };
        }

        /// <summary>
        /// �N <see cref="MachineTypeDto"/> �ഫ�� <see cref="MachineTypeEntity"/>�C
        /// </summary>
        /// <param name="dto">�n�ഫ�� <see cref="MachineTypeDto"/> ��ҡC</param>
        /// <returns>�ഫ�᪺ <see cref="MachineTypeEntity"/> ��ҡC�p�G��J�� null�A�h��^ null�C</returns>
        public static MachineTypeEntity ToEntity(this MachineTypeDto dto)
        {
            if (dto == null) return null;

            return new MachineTypeEntity
            {
                Id = dto.Id,
                OrderNo = dto.OrderNo,
                TypeName = dto.TypeName,
                CategoryId = dto.CategoryId,
                MachineNames = dto.MachineNames?.Select(m => m.ToEntity()).ToList()
            };
        }

        /// <summary>
        /// �N <see cref="IEnumerable{MachineTypeEntity}"/> �ഫ�� <see cref="IEnumerable{MachineTypeDto}"/>�C
        /// </summary>
        /// <param name="entities">�n�ഫ�� <see cref="IEnumerable{MachineTypeEntity}"/> ���X�C</param>
        /// <returns>�ഫ�᪺ <see cref="IEnumerable{MachineTypeDto}"/> ���X�C�p�G��J�� null�A�h��^�Ŷ��X�C</returns>
        public static IEnumerable<MachineTypeDto> ToDtoList(this IEnumerable<MachineTypeEntity> entities)
        {
            return entities?.Select(e => e.ToDto()) ?? Enumerable.Empty<MachineTypeDto>();
        }
    }
}