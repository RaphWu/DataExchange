﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB.Mappers
{
    /// <summary>
    /// 提供模型實體與資料傳輸物件 (DTO) 之間的映射功能。
    /// </summary>
    public static class ModelMapper
    {
        /// <summary>
        /// 將 <see cref="ModelEntity"/> 轉換為 <see cref="ModelDto"/>。
        /// </summary>
        /// <param name="entity">要轉換的 <see cref="ModelEntity"/> 實例。</param>
        /// <returns>轉換後的 <see cref="ModelDto"/> 實例；如果輸入為 null，則返回 null。</returns>
        public static ModelDto ToDto(this ModelEntity entity)
        {
            if (entity == null) return null;

            return new ModelDto
            {
                Id = entity.Id,
                ModelName = entity.ModelName,
                ModelStatusId = entity.ModelStatusId,
                ModelStatusName = entity.ModelStatus?.Status,
                Workstations = entity.Workstations?.Select(w => w.ToDto()).ToList() ?? new List<WorkstationReadDto>()
            };
        }

        /// <summary>
        /// 將 <see cref="ModelDto"/> 轉換為 <see cref="ModelEntity"/>。
        /// </summary>
        /// <param name="dto">要轉換的 <see cref="ModelDto"/> 實例。</param>
        /// <returns>轉換後的 <see cref="ModelEntity"/> 實例；如果輸入為 null，則返回 null。</returns>
        public static ModelEntity ToEntity(this ModelDto dto)
        {
            if (dto == null) return null;

            return new ModelEntity
            {
                Id = dto.Id,
                ModelName = dto.ModelName,
                ModelStatusId = dto.ModelStatusId
            };
        }

        /// <summary>
        /// 將 <see cref="ModelEntity"/> 集合轉換為 <see cref="ModelDto"/> 集合。
        /// </summary>
        /// <param name="entities">要轉換的 <see cref="ModelEntity"/> 集合。</param>
        /// <returns>轉換後的 <see cref="ModelDto"/> 集合；如果輸入為 null，則返回空集合。</returns>
        public static IEnumerable<ModelDto> ToDtoList(this IEnumerable<ModelEntity> entities)
        {
            return entities?.Select(e => e.ToDto()) ?? Enumerable.Empty<ModelDto>();
        }
    }
}
