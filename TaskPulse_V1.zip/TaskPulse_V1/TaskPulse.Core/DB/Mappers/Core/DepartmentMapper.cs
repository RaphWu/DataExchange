﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB.Mappers
{
    /// <summary>
    /// 提供將 <see cref="DepartmentEntity"/> 和 <see cref="DepartmentDto"/> 之間進行轉換的擴充方法。
    /// </summary>
    public static class DepartmentMapper
    {
        /// <summary>
        /// 將 <see cref="DepartmentEntity"/> 轉換為 <see cref="DepartmentDto"/>。
        /// </summary>
        /// <param name="entity">要轉換的 <see cref="DepartmentEntity"/> 實例。</param>
        /// <returns>轉換後的 <see cref="DepartmentDto"/> 實例；如果輸入為 null，則返回 null。</returns>
        public static DepartmentDto ToDto(this DepartmentEntity entity)
        {
            if (entity == null) return null;

            return new DepartmentDto
            {
                Id = entity.Id,
                OrderNo = entity.OrderNo,
                DepartmentName = entity.DepartmentName
            };
        }

        /// <summary>
        /// 將 <see cref="DepartmentDto"/> 轉換為 <see cref="DepartmentEntity"/>。
        /// </summary>
        /// <param name="dto">要轉換的 <see cref="DepartmentDto"/> 實例。</param>
        /// <returns>轉換後的 <see cref="DepartmentEntity"/> 實例；如果輸入為 null，則返回 null。</returns>
        public static DepartmentEntity ToEntity(this DepartmentDto dto)
        {
            if (dto == null) return null;

            return new DepartmentEntity
            {
                Id = dto.Id,
                OrderNo = dto.OrderNo,
                DepartmentName = dto.DepartmentName
            };
        }

        /// <summary>
        /// 將 <see cref="IEnumerable{DepartmentEntity}"/> 轉換為 <see cref="IEnumerable{DepartmentDto}"/>。
        /// </summary>
        /// <param name="entities">要轉換的 <see cref="IEnumerable{DepartmentEntity}"/> 集合。</param>
        /// <returns>轉換後的 <see cref="IEnumerable{DepartmentDto}"/> 集合；如果輸入為 null，則返回空集合。</returns>
        public static IEnumerable<DepartmentDto> ToDtoList(this IEnumerable<DepartmentEntity> entities)
        {
            return entities?.Select(e => e.ToDto()) ?? Enumerable.Empty<DepartmentDto>();
        }
    }
}
