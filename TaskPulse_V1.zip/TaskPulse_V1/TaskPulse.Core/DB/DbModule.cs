﻿using System;
using Autofac;
using Calin.TaskPulse.Core.DB.Repositories;
using Calin.TaskPulse.Core.DB.Services;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// 資料庫相關的 Autofac Module。
    /// </summary>
    public class DbModule : Module
    {
        /// <summary>
        /// 註冊所有資料庫相關的服務與 Repository。
        /// </summary>
        /// <param name="builder">Autofac 的容器建構器。</param>
        protected override void Load(ContainerBuilder builder)
        {
            // 註冊 DbContext Factory
            builder.Register(c => new Func<CoreContext>(() => new CoreContext()))
                .As<Func<CoreContext>>()
                .SingleInstance();

            builder.Register(c => new Func<MaintiFlowContext>(() => new MaintiFlowContext()))
                .As<Func<MaintiFlowContext>>()
                .SingleInstance();

            // 註冊 Repositories (InstancePerDependency)
            builder.RegisterType<EmployeeRepository>().As<IEmployeeRepository>().InstancePerDependency();
            builder.RegisterType<MachineRepository>().As<IMachineRepository>().InstancePerDependency();
            builder.RegisterType<ModelRepository>().As<IModelRepository>().InstancePerDependency();
            builder.RegisterType<WorkOrderRepository>().As<IWorkOrderRepository>().InstancePerDependency();
            builder.RegisterType<DepartmentRepository>().As<IDepartmentRepository>().InstancePerDependency();
            builder.RegisterType<GroupRepository>().As<IGroupRepository>().InstancePerDependency();
            builder.RegisterType<MachineCategoryRepository>().As<IMachineCategoryRepository>().InstancePerDependency();
            builder.RegisterType<MachineNameRepository>().As<IMachineNameRepository>().InstancePerDependency();
            builder.RegisterType<MachineTypeRepository>().As<IMachineTypeRepository>().InstancePerDependency();
            builder.RegisterType<WorkstationRepository>().As<IWorkstationRepository>().InstancePerDependency();
            builder.RegisterType<MaintenanceRecordRepository>().As<IMaintenanceRecordRepository>().InstancePerDependency();
            builder.RegisterType<JobTitleRepository>().As<IJobTitleRepository>().InstancePerDependency();
            builder.RegisterType<PermissionRepository>().As<IPermissionRepository>().InstancePerDependency();

            // 註冊 Services (InstancePerLifetimeScope)
            builder.RegisterType<EmployeeService>().As<IEmployeeService>().InstancePerLifetimeScope();
            builder.RegisterType<MachineService>().As<IMachineService>().InstancePerLifetimeScope();
            builder.RegisterType<ModelService>().As<IModelService>().InstancePerLifetimeScope();
            builder.RegisterType<WorkOrderService>().As<IWorkOrderService>().InstancePerLifetimeScope();
            builder.RegisterType<DepartmentService>().As<IDepartmentService>().InstancePerLifetimeScope();
            builder.RegisterType<GroupService>().As<IGroupService>().InstancePerLifetimeScope();
            builder.RegisterType<MachineCategoryService>().As<IMachineCategoryService>().InstancePerLifetimeScope();
            builder.RegisterType<MachineNameService>().As<IMachineNameService>().InstancePerLifetimeScope();
            builder.RegisterType<MachineTypeService>().As<IMachineTypeService>().InstancePerLifetimeScope();
            builder.RegisterType<WorkstationService>().As<IWorkstationService>().InstancePerLifetimeScope();
            builder.RegisterType<MaintenanceRecordService>().As<IMaintenanceRecordService>().InstancePerLifetimeScope();
            builder.RegisterType<JobTitleService>().As<IJobTitleService>().InstancePerLifetimeScope();
        }
    }
}
