using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MachineEntity �� Fluent API �]�w�C
    /// </summary>
    public class MachineEntityConfiguration : EntityTypeConfiguration<MachineEntity>
    {
        public MachineEntityConfiguration()
        {
            ToTable("Machines");

            HasKey(m => m.Id);

            Property(m => m.MachineCode)
                .HasMaxLength(10);

            Property(m => m.SerialNumber)
                .HasMaxLength(20);

            Property(m => m.Barcode)
                .HasMaxLength(50);

            // Machine -> ModelName (�h��@�A�i�� null)
            HasOptional(m => m.MachineName)
                .WithMany(mn => mn.Machines)
                .HasForeignKey(m => m.MachineNameId)
                .WillCascadeOnDelete(false);

            // Machine -> MachineType (�h��@�A�i�� null)
            HasOptional(m => m.MachineType)
                .WithMany(mt => mt.Machines)
                .HasForeignKey(m => m.MachineTypeId)
                .WillCascadeOnDelete(false);

            // Machine -> MachineConditionEntity (�h��@�A����)
            HasRequired(m => m.Condition)
                .WithMany(c => c.Machines)
                .HasForeignKey(m => m.ConditionId)
                .WillCascadeOnDelete(false);

            // Machine -> MachineBrand (�h��@�A�i�� null)
            HasOptional(m => m.Brand)
                .WithMany(b => b.Machines)
                .HasForeignKey(m => m.BrandId)
                .WillCascadeOnDelete(false);

            // Machine -> MachineLocation (�h��@�A�i�� null)
            HasOptional(m => m.Location)
                .WithMany(l => l.Machines)
                .HasForeignKey(m => m.LocationId)
                .WillCascadeOnDelete(false);

            // Machine -> MachineIssueCategory (�h��@�A�i�� null)
            HasOptional(m => m.IssueCategory)
                .WithMany(ic => ic.Machines)
                .HasForeignKey(m => m.IssueCategoryId)
                .WillCascadeOnDelete(false);
        }
    }
}
