using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// DepartmentEntity �� Fluent API �]�w�C
    /// </summary>
    public class DepartmentEntityConfiguration : EntityTypeConfiguration<DepartmentEntity>
    {
        public DepartmentEntityConfiguration()
        {
            ToTable("Departments");

            HasKey(d => d.Id);

            Property(d => d.DepartmentName)
                .IsRequired()
                .HasMaxLength(50);
        }
    }
}
