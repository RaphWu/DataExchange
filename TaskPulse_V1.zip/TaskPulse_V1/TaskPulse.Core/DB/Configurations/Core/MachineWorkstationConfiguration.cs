using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MachineWorkstation �� Fluent API �]�w�]���x�P�u���������^�C
    /// </summary>
    public class MachineWorkstationConfiguration : EntityTypeConfiguration<MachineWorkstation>
    {
        public MachineWorkstationConfiguration()
        {
            ToTable("MachineWorkstations");

            HasKey(mw => new { mw.MachineId, mw.WorkstationId });

            HasRequired(mw => mw.Machine)
                .WithMany(m => m.MachineWorkstations)
                .HasForeignKey(mw => mw.MachineId)
                .WillCascadeOnDelete(false);

            HasRequired(mw => mw.Workstation)
                .WithMany(w => w.MachineWorkstations)
                .HasForeignKey(mw => mw.WorkstationId)
                .WillCascadeOnDelete(false);
        }
    }
}
