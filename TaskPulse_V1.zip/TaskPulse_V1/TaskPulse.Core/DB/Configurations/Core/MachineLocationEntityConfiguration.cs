using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MachineLocationEntity �� Fluent API �]�w�C
    /// </summary>
    public class MachineLocationEntityConfiguration : EntityTypeConfiguration<MachineLocationEntity>
    {
        public MachineLocationEntityConfiguration()
        {
            ToTable("MachineLocations");

            HasKey(l => l.Id);

            Property(l => l.LocationName)
                .HasMaxLength(30);
        }
    }
}
