using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// GroupPermission �� Fluent API �]�w�]�s�ջP�v���������^�C
    /// </summary>
    public class GroupPermissionConfiguration : EntityTypeConfiguration<GroupPermission>
    {
        public GroupPermissionConfiguration()
        {
            ToTable("GroupPermissions");

            HasKey(gp => new { gp.GroupId, gp.PermissionId });

            HasRequired(gp => gp.Group)
                .WithMany(g => g.GroupPermissions)
                .HasForeignKey(gp => gp.GroupId)
                .WillCascadeOnDelete(false);

            HasRequired(gp => gp.Permission)
                .WithMany(p => p.GroupPermissions)
                .HasForeignKey(gp => gp.PermissionId)
                .WillCascadeOnDelete(false);
        }
    }
}
