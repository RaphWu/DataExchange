using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// EmployeeCarbonCopy �� Fluent API �]�w�]���u�ƥ��H���������^�C
    /// </summary>
    public class EmployeeCarbonCopyConfiguration : EntityTypeConfiguration<EmployeeCarbonCopy>
    {
        public EmployeeCarbonCopyConfiguration()
        {
            ToTable("EmployeeCarbonCopies");

            HasKey(cc => new { cc.SourceEmployeeId, cc.TargetEmployeeId });

            // SourceEmployee -> EmployeeCarbonCopy (�@��h)
            HasRequired(cc => cc.SourceEmployee)
                .WithMany(e => e.CarbonCopyRelations)
                .HasForeignKey(cc => cc.SourceEmployeeId)
                .WillCascadeOnDelete(false);

            // TargetEmployee -> EmployeeCarbonCopy (�@��h�A�L�ɯ��ݩ�)
            HasRequired(cc => cc.TargetEmployee)
                .WithMany()
                .HasForeignKey(cc => cc.TargetEmployeeId)
                .WillCascadeOnDelete(false);
        }
    }
}
