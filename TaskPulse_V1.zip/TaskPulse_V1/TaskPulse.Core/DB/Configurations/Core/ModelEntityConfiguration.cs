using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// ModelEntity �� Fluent API �]�w�C
    /// </summary>
    public class ModelEntityConfiguration : EntityTypeConfiguration<ModelEntity>
    {
        public ModelEntityConfiguration()
        {
            ToTable("Models");

            HasKey(m => m.Id);

            Property(m => m.ModelName)
                .HasMaxLength(10);

            // Model -> ModelStatus (�h��@�A����)
            HasRequired(m => m.ModelStatus)
                .WithMany(ms => ms.Models)
                .HasForeignKey(m => m.ModelStatusId)
                .WillCascadeOnDelete(false);
        }
    }
}
