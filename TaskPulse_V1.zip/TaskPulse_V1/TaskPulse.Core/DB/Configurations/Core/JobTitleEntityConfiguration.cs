using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// JobTitleEntity �� Fluent API �]�w�C
    /// </summary>
    public class JobTitleEntityConfiguration : EntityTypeConfiguration<JobTitleEntity>
    {
        public JobTitleEntityConfiguration()
        {
            ToTable("JobTitles");

            HasKey(j => j.Id);

            Property(j => j.JobTitleName)
                .HasMaxLength(12);
        }
    }
}
