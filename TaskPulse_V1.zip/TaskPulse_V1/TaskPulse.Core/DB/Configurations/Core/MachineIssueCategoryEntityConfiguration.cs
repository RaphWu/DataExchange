using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MachineIssueCategoryEntity �� Fluent API �]�w�C
    /// </summary>
    public class MachineIssueCategoryEntityConfiguration : EntityTypeConfiguration<MachineIssueCategoryEntity>
    {
        public MachineIssueCategoryEntityConfiguration()
        {
            ToTable("MachineIssueCategories");

            HasKey(ic => ic.Id);

            Property(ic => ic.CategoryName)
                .HasMaxLength(30);
        }
    }
}
