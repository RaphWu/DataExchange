using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// GroupEntity �� Fluent API �]�w�C
    /// </summary>
    public class GroupEntityConfiguration : EntityTypeConfiguration<GroupEntity>
    {
        public GroupEntityConfiguration()
        {
            ToTable("Groups");

            HasKey(g => g.Id);

            Property(g => g.Name)
                .HasMaxLength(50);
        }
    }
}
