using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// PermissionEntity �� Fluent API �]�w�C
    /// </summary>
    public class PermissionEntityConfiguration : EntityTypeConfiguration<PermissionEntity>
    {
        public PermissionEntityConfiguration()
        {
            ToTable("Permissions");

            HasKey(p => p.Id);

            Property(p => p.Module)
                .HasMaxLength(30);

            Property(p => p.Page)
                .HasMaxLength(30);

            Property(p => p.Control)
                .HasMaxLength(30);

            Property(p => p.Action)
                .HasMaxLength(30);

            Property(p => p.PermissionType)
                .IsRequired();
        }
    }
}
