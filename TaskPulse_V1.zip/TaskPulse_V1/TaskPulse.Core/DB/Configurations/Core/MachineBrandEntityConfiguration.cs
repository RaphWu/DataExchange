using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MachineBrandEntity �� Fluent API �]�w�C
    /// </summary>
    public class MachineBrandEntityConfiguration : EntityTypeConfiguration<MachineBrandEntity>
    {
        public MachineBrandEntityConfiguration()
        {
            ToTable("MachineBrands");

            HasKey(b => b.Id);

            Property(b => b.BrandName)
                .HasMaxLength(30);
        }
    }
}
