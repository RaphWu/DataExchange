using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MachineNameEntity �� Fluent API �]�w�C
    /// </summary>
    public class MachineNameEntityConfiguration : EntityTypeConfiguration<MachineNameEntity>
    {
        public MachineNameEntityConfiguration()
        {
            ToTable("MachineNames");

            HasKey(mn => mn.Id);

            Property(mn => mn.ModelName)
                .HasMaxLength(50);

            // ModelName -> MachineType (�h��@�A�i�� null)
            HasOptional(mn => mn.MachineType)
                .WithMany(mt => mt.MachineNames)
                .HasForeignKey(mn => mn.TypeId)
                .WillCascadeOnDelete(false);
        }
    }
}
