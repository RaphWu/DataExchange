using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// RepairPeriodEntity �� Fluent API �]�w�C
    /// </summary>
    public class RepairPeriodEntityConfiguration : EntityTypeConfiguration<RepairPeriodEntity>
    {
        public RepairPeriodEntityConfiguration()
        {
            ToTable("RepairPeriods");

            HasKey(rp => rp.Id);

            Property(rp => rp.Remark)
                .HasMaxLength(200);

            // RepairPeriod -> MaintenanceRecord (�h��@�A����)
            HasRequired(rp => rp.MaintenanceRecord)
                .WithMany(mr => mr.RepairPeriods)
                .HasForeignKey(rp => rp.MaintenanceRecordId)
                .WillCascadeOnDelete(false);
        }
    }
}
