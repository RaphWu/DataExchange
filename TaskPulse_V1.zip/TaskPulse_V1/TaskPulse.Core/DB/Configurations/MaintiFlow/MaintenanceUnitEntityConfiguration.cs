using System.Data.Entity.ModelConfiguration;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// MaintenanceUnitEntity �� Fluent API �]�w�C
    /// </summary>
    public class MaintenanceUnitEntityConfiguration : EntityTypeConfiguration<MaintenanceUnitEntity>
    {
        public MaintenanceUnitEntityConfiguration()
        {
            ToTable("MaintenanceUnits");

            HasKey(mu => mu.Id);

            Property(mu => mu.UnitName)
                .HasMaxLength(30);
        }
    }
}
