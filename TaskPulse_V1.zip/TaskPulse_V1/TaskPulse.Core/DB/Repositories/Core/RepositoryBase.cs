using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Serilog;

namespace Calin.TaskPulse.Core.DB.Repositories
{
    /// <summary>
    /// �x�� Repository �����O�C
    /// </summary>
    /// <typeparam name="TEntity">���������C</typeparam>
    /// <typeparam name="TContext">DbContext �����C</typeparam>
    public abstract class RepositoryBase<TEntity, TContext> : IRepository<TEntity>
        where TEntity : class
        where TContext : DbContext
    {
        protected readonly TContext Context;
        protected readonly DbSet<TEntity> DbSet;
        protected readonly ILogger Logger;

        protected RepositoryBase(TContext context, ILogger logger)
        {
            Context = context ?? throw new ArgumentNullException(nameof(context));
            DbSet = context.Set<TEntity>();
            Logger = logger?.ForContext(GetType()) ?? Log.Logger.ForContext(GetType());
        }

        /// <inheritdoc/>
        public virtual IEnumerable<TEntity> GetAll()
        {
            return DbSet.ToList();
        }

        /// <inheritdoc/>
        public virtual IEnumerable<TEntity> GetAllWithDisposal()
        {
            return DbSet.ToList();
        }

        /// <inheritdoc/>
        public virtual TEntity GetById(int id)
        {
            return DbSet.Find(id);
        }

        /// <inheritdoc/>
        public virtual TEntity Add(TEntity entity)
        {
            if (entity == null)
            {
                Logger.Warning("���շs�W null ����");
                throw new ArgumentNullException(nameof(entity));
            }

            try
            {
                var added = DbSet.Add(entity);
                Logger.Debug("�s�W���� {EntityType} ���\", typeof(TEntity).Name);
                return added;
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "�s�W���� {EntityType} ����", typeof(TEntity).Name);
                throw;
            }
        }

        /// <inheritdoc/>
        public virtual void Update(TEntity entity)
        {
            if (entity == null)
            {
                Logger.Warning("���է�s null ����");
                throw new ArgumentNullException(nameof(entity));
            }

            try
            {
                Context.Entry(entity).State = EntityState.Modified;
                Logger.Debug("��s���� {EntityType} ���\", typeof(TEntity).Name);
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "��s���� {EntityType} ����", typeof(TEntity).Name);
                throw;
            }
        }

        /// <inheritdoc/>
        public virtual void Delete(TEntity entity)
        {
            if (entity == null)
            {
                Logger.Warning("���էR�� null ����");
                throw new ArgumentNullException(nameof(entity));
            }

            try
            {
                if (Context.Entry(entity).State == EntityState.Detached)
                {
                    DbSet.Attach(entity);
                }
                DbSet.Remove(entity);
                Logger.Debug("�R������ {EntityType} ���\", typeof(TEntity).Name);
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "�R������ {EntityType} ����", typeof(TEntity).Name);
                throw;
            }
        }

        /// <inheritdoc/>
        public virtual void DeleteById(int id)
        {
            var entity = GetById(id);
            if (entity != null)
            {
                Delete(entity);
            }
            else
            {
                Logger.Warning("���էR�����s�b������ {EntityType}�AId={Id}", typeof(TEntity).Name, id);
            }
        }
    }
}
