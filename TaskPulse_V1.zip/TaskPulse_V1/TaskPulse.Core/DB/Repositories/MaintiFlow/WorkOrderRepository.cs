using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.MaintiFlow;
using Serilog;

namespace Calin.TaskPulse.Core.DB.Repositories
{
    /// <summary>
    /// ���@�u�� Repository �����C
    /// </summary>
    public interface IWorkOrderRepository : IRepository<WorkOrderEntity>
    {
        /// <summary>
        /// �ھڤu��s�����o���@�u��C
        /// </summary>
        /// <param name="workOrderNo">�u��s���C</param>
        /// <returns>���������@�u�����C</returns>
        WorkOrderEntity GetByWorkOrderNo(string workOrderNo);

        /// <summary>
        /// �ھڪ��A���o���@�u��M��C
        /// </summary>
        /// <param name="status">�u�檬�A�C</param>
        /// <returns>�ŦX���󪺺��@�u��M��C</returns>
        IEnumerable<WorkOrderEntity> GetByStatus(FlowStatus status);

        /// <summary>
        /// �ھګإߪ� ID ���o���@�u��M��C
        /// </summary>
        /// <param name="creatorId">�إߪ� ID�C</param>
        /// <returns>�ŦX���󪺺��@�u��M��C</returns>
        IEnumerable<WorkOrderEntity> GetByCreatorId(int creatorId);

        /// <summary>
        /// �ھھ��� ID ���o���@�u��M��C
        /// </summary>
        /// <param name="machineId">���� ID�C</param>
        /// <returns>�ŦX���󪺺��@�u��M��C</returns>
        IEnumerable<WorkOrderEntity> GetByMachineId(int machineId);

        /// <summary>
        /// �ھڤ���d����o���@�u��M��C
        /// </summary>
        /// <param name="startDate">�}�l����C</param>
        /// <param name="endDate">��������C</param>
        /// <returns>�ŦX���󪺺��@�u��M��C</returns>
        IEnumerable<WorkOrderEntity> GetByDateRange(DateTime startDate, DateTime endDate);

        /// <summary>
        /// �ھڤu�� ID ���o�]�t���@�O�������@�u��C
        /// </summary>
        /// <param name="id">�u�� ID�C</param>
        /// <returns>�]�t���@�O�������@�u�����C</returns>
        WorkOrderEntity GetWithMaintenanceRecords(int id);
    }

    /// <summary>
    /// ���@�u�� Repository ��@�C
    /// </summary>
    public class WorkOrderRepository : RepositoryBase<WorkOrderEntity, MaintiFlowContext>, IWorkOrderRepository
    {
        /// <summary>
        /// ��l�� <see cref="WorkOrderRepository"/> ���O���s�������C
        /// </summary>
        /// <param name="context">��Ʈw�W�U��C</param>
        /// <param name="logger">��x�O�����C</param>
        public WorkOrderRepository(MaintiFlowContext context, ILogger logger) : base(context, logger)
        {
        }

        /// <summary>
        /// ���o�Ҧ����@�u��C
        /// </summary>
        /// <returns>�Ҧ����@�u�檺�M��C</returns>
        public override IEnumerable<WorkOrderEntity> GetAll()
        {
            return DbSet
                .Include(w => w.Machine)
                .Include(w => w.Workstation)
                .Include(w => w.Creator)
                .Include(w => w.MaintenanceUnit)
                .Include(w => w.RequestingUnit)
                .ToList();
        }

        /// <summary>
        /// �ھ� ID ���o���@�u��C
        /// </summary>
        /// <param name="id">�u�� ID�C</param>
        /// <returns>���������@�u�����C</returns>
        public override WorkOrderEntity GetById(int id)
        {
            return DbSet
                .Include(w => w.Machine)
                .Include(w => w.Workstation)
                .Include(w => w.Creator)
                .Include(w => w.MaintenanceUnit)
                .Include(w => w.RequestingUnit)
                .FirstOrDefault(w => w.Id == id);
        }

        /// <inheritdoc/>
        public WorkOrderEntity GetByWorkOrderNo(string workOrderNo)
        {
            return DbSet
                .Include(w => w.Machine)
                .Include(w => w.Workstation)
                .Include(w => w.Creator)
                .Include(w => w.MaintenanceUnit)
                .Include(w => w.RequestingUnit)
                .FirstOrDefault(w => w.WorkOrderNo == workOrderNo);
        }

        /// <inheritdoc/>
        public IEnumerable<WorkOrderEntity> GetByStatus(FlowStatus status)
        {
            return DbSet
                .Include(w => w.Machine)
                .Include(w => w.Workstation)
                .Include(w => w.Creator)
                .Include(w => w.MaintenanceUnit)
                .Include(w => w.RequestingUnit)
                .Where(w => w.Status == status)
                .ToList();
        }

        /// <inheritdoc/>
        public IEnumerable<WorkOrderEntity> GetByCreatorId(int creatorId)
        {
            return DbSet
                .Include(w => w.Machine)
                .Include(w => w.Workstation)
                .Include(w => w.Creator)
                .Include(w => w.MaintenanceUnit)
                .Include(w => w.RequestingUnit)
                .Where(w => w.CreatorId == creatorId)
                .ToList();
        }

        /// <inheritdoc/>
        public IEnumerable<WorkOrderEntity> GetByMachineId(int machineId)
        {
            return DbSet
                .Include(w => w.Machine)
                .Include(w => w.Workstation)
                .Include(w => w.Creator)
                .Include(w => w.MaintenanceUnit)
                .Include(w => w.RequestingUnit)
                .Where(w => w.MachineId == machineId)
                .ToList();
        }

        /// <inheritdoc/>
        public IEnumerable<WorkOrderEntity> GetByDateRange(DateTime startDate, DateTime endDate)
        {
            return DbSet
                .Include(w => w.Machine)
                .Include(w => w.Workstation)
                .Include(w => w.Creator)
                .Include(w => w.MaintenanceUnit)
                .Include(w => w.RequestingUnit)
                .Where(w => w.CreationDateTime >= startDate && w.CreationDateTime <= endDate)
                .ToList();
        }

        /// <inheritdoc/>
        public WorkOrderEntity GetWithMaintenanceRecords(int id)
        {
            return DbSet
                .Include(w => w.Machine)
                .Include(w => w.Workstation)
                .Include(w => w.Creator)
                .Include(w => w.MaintenanceUnit)
                .Include(w => w.RequestingUnit)
                .Include(w => w.MaintenanceRecords.Select(r => r.IssueCategory))
                .Include(w => w.MaintenanceRecords.Select(r => r.FeedbackEmployee))
                .Include(w => w.MaintenanceRecords.Select(r => r.MaintenanceRecordEngineers.Select(e => e.Engineer)))
                .FirstOrDefault(w => w.Id == id);
        }
    }
}
