/*
Core ��Ʈw�W�U��A�]�t�Ҧ� Core �Ҳժ�����]�w�C
�ϥ� SQLite + Entity Framework 6 + Code First�C
*/

using System.Data.Entity;
using Calin.TaskPulse.Entity.Core;
using SQLite.CodeFirst;

namespace Calin.TaskPulse.Core.DB
{
    /// <summary>
    /// Core ��Ʈw�W�U��C
    /// </summary>
    public class CoreContext : DbContext
    {
        /// <summary>
        /// ��l�� CoreContext�A�ϥ� App.config ���W�� "CoreContext" ���s�u�r��C
        /// </summary>
        public CoreContext() : base("name=CoreContext")
        {
        }

        #region DbSets

        public DbSet<EmployeeEntity> Employees { get; set; }
        public DbSet<DepartmentEntity> Departments { get; set; }
        public DbSet<JobTitleEntity> JobTitles { get; set; }
        public DbSet<EmployeeStatusEntity> EmployeeStatuses { get; set; }
        public DbSet<EmployeeCarbonCopy> EmployeeCarbonCopies { get; set; }
        public DbSet<EmployeeGroup> EmployeeGroups { get; set; }
        public DbSet<EmployeePermission> EmployeePermissions { get; set; }

        public DbSet<GroupEntity> Groups { get; set; }
        public DbSet<GroupPermission> GroupPermissions { get; set; }
        public DbSet<MachineGroup> MachineGroups { get; set; }

        public DbSet<PermissionEntity> Permissions { get; set; }
        public DbSet<DepartmentPermission> DepartmentPermissions { get; set; }

        public DbSet<MachineEntity> Machines { get; set; }
        public DbSet<MachineNameEntity> MachineNames { get; set; }
        public DbSet<MachineTypeEntity> MachineTypes { get; set; }
        public DbSet<MachineCategoryEntity> MachineCategories { get; set; }
        public DbSet<MachineConditionEntity> MachineConditions { get; set; }
        public DbSet<MachineBrandEntity> MachineBrands { get; set; }
        public DbSet<MachineLocationEntity> MachineLocations { get; set; }
        public DbSet<MachineIssueCategoryEntity> MachineIssueCategories { get; set; }
        public DbSet<MachineAssetEntity> MachineAssets { get; set; }
        public DbSet<MachineWorkstation> MachineWorkstations { get; set; }

        public DbSet<ModelEntity> Models { get; set; }
        public DbSet<ModelStatusEntity> ModelStatuses { get; set; }
        public DbSet<WorkstationEntity> Workstations { get; set; }

        #endregion

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // SQLite Code First ��l�ƾ�
            var sqliteInitializer = new SqliteCreateDatabaseIfNotExists<CoreContext>(modelBuilder);
            Database.SetInitializer(sqliteInitializer);

            // �M�ΩҦ� Entity �]�w
            modelBuilder.Configurations.Add(new EmployeeEntityConfiguration());
            modelBuilder.Configurations.Add(new DepartmentEntityConfiguration());
            modelBuilder.Configurations.Add(new JobTitleEntityConfiguration());
            modelBuilder.Configurations.Add(new EmployeeStatusEntityConfiguration());
            modelBuilder.Configurations.Add(new EmployeeCarbonCopyConfiguration());
            modelBuilder.Configurations.Add(new EmployeeGroupConfiguration());
            modelBuilder.Configurations.Add(new EmployeePermissionConfiguration());

            modelBuilder.Configurations.Add(new GroupEntityConfiguration());
            modelBuilder.Configurations.Add(new GroupPermissionConfiguration());
            modelBuilder.Configurations.Add(new MachineGroupConfiguration());

            modelBuilder.Configurations.Add(new PermissionEntityConfiguration());
            modelBuilder.Configurations.Add(new DepartmentPermissionConfiguration());

            modelBuilder.Configurations.Add(new MachineEntityConfiguration());
            modelBuilder.Configurations.Add(new MachineNameEntityConfiguration());
            modelBuilder.Configurations.Add(new MachineTypeEntityConfiguration());
            modelBuilder.Configurations.Add(new MachineCategoryEntityConfiguration());
            modelBuilder.Configurations.Add(new MachineConditionConfiguration());
            modelBuilder.Configurations.Add(new MachineBrandEntityConfiguration());
            modelBuilder.Configurations.Add(new MachineLocationEntityConfiguration());
            modelBuilder.Configurations.Add(new MachineIssueCategoryEntityConfiguration());
            modelBuilder.Configurations.Add(new MachineAssetEntityConfiguration());
            modelBuilder.Configurations.Add(new MachineWorkstationConfiguration());

            modelBuilder.Configurations.Add(new ModelEntityConfiguration());
            modelBuilder.Configurations.Add(new ModelStatusEntityConfiguration());
            modelBuilder.Configurations.Add(new WorkstationEntityConfiguration());

            base.OnModelCreating(modelBuilder);
        }
    }
}
