﻿using System;
using System.ComponentModel;

namespace Calin.TaskPulse.Core.DB.DTOs
{
    /// <summary>
    /// 員工編輯資料傳輸物件。
    /// </summary>
    public class EmployeeEditDto
    {
        [Description("員工識別碼")]
        public int Id { get; set; }

        [Description("工號")]
        public string EmployeeId { get; set; }

        [Description("姓名")]
        public string EmployeeName { get; set; }

        [Description("部門編號")]
        public int? DepartmentId { get; set; }

        [Description("部門")]
        public string DepartmentName { get; set; }

        [Description("職稱編號")]
        public int? JobTitleId { get; set; }

        [Description("職稱名稱")]
        public string JobTitleName { get; set; }

        [Description("工程師")]
        public bool IsEngineer { get; set; }

        [Description("狀態編號")]
        public int StatusId { get; set; }

        [Description("狀態名稱")]
        public string StatusName { get; set; }

        [Description("狀態變更時間")]
        public DateTime? StatusChangeAt { get; set; }

        [Description("Email")]
        public string Email { get; set; }
    }
}
