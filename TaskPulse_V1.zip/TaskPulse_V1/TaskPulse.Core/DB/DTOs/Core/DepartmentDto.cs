namespace Calin.TaskPulse.Core.DB.DTOs
{
    /// <summary>
    /// ������ƶǿ骫��C
    /// </summary>
    public class DepartmentDto
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public string DepartmentName { get; set; }
    }
}
