using System.Collections.Generic;
using System.ComponentModel;

namespace Calin.TaskPulse.Core.DB.DTOs
{
    /// <summary>
    /// ���ظ�ƶǿ骫��C
    /// </summary>
    public class ModelDto
    {
        [Description("����ID")]
        public int Id { get; set; }

        [Description("����")]
        public string ModelName { get; set; }

        [Description("���ت��AID")]
        public int ModelStatusId { get; set; }

        [Description("���A")]
        public string ModelStatusName { get; set; }

        [Description("�u���M��")]
        public List<WorkstationReadDto> Workstations { get; set; } = new List<WorkstationReadDto>();
    }
}
