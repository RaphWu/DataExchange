using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Calin.TaskPulse.Core.DB.DTOs
{
    /// <summary>
    /// ���uŪ����ƶǿ骫��C
    /// </summary>
    public class EmployeeReadDto
    {
        [Description("���u�ѧO�X")]
        public int Id { get; set; }

        [Description("�u��")]
        public string EmployeeId { get; set; }

        [Description("�m�W")]
        public string EmployeeName { get; set; }

        [Description("�����s��")]
        public int? DepartmentId { get; set; }

        [Description("����")]
        public string DepartmentName { get; set; }

        [Description("¾�ٽs��")]
        public int? JobTitleId { get; set; }

        [Description("¾�٦W��")]
        public string JobTitleName { get; set; }

        [Description("�u�{�v")]
        public bool IsEngineer { get; set; }

        [Description("���A�s��")]
        public int StatusId { get; set; }

        [Description("���A�W��")]
        public string StatusName { get; set; }

        [Description("���A�ܧ�ɶ�")]
        public DateTime? StatusChangeAt { get; set; }

        [Description("Email")]
        public string Email { get; set; }

        /********************
         * �B�~�ݩ�
         ********************/

        [Description("���u���W")]
        public string FullName { get; set; }

        [Description("�ƥ��H��")]
        public string CarbonCopyString { get; set; }

        [Description("�ƥ��H��")]
        public ICollection<EmployeeReadDto> CarbonCopyList { get; set; }

        [Description("�u�{�v")]
        public string IsEngineerString { get; set; }

        [Description("���A�ܧ�ɶ��r��")]
        public string StatusChangeAtString { get; set; }

        [Description("�����Ƨ�")]
        public int DepartmentOrderNo { get; set; }

        [Description("¾�ٱƧ�")]
        public int JobTotleOrderNo { get; set; }
    }
}
