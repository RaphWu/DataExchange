using System;
using System.Collections.Generic;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Mappers;
using Calin.TaskPulse.Core.DB.Repositories;
using Calin.TaskPulse.Entity.Contants;
using Serilog;

namespace Calin.TaskPulse.Core.DB.Services
{
    /// <summary>
    /// ���@�u��A�Ȥ����C
    /// </summary>
    public interface IWorkOrderService
    {
        /// <summary>
        /// ���o�Ҧ��u��C
        /// </summary>
        /// <returns>�u�檺���X�C</returns>
        IEnumerable<WorkOrderDto> GetAll();

        /// <summary>
        /// �ھڤu�� ID ���o�u��C
        /// </summary>
        /// <param name="id">�u�� ID�C</param>
        /// <returns>�������u���ơC</returns>
        WorkOrderDto GetById(int id);

        /// <summary>
        /// �ھڤu��s�����o�u��C
        /// </summary>
        /// <param name="workOrderNo">�u��s���C</param>
        /// <returns>�������u���ơC</returns>
        WorkOrderDto GetByWorkOrderNo(string workOrderNo);

        /// <summary>
        /// �ھڤu�檬�A���o�u�涰�X�C
        /// </summary>
        /// <param name="status">�u�檬�A�C</param>
        /// <returns>�ŦX���󪺤u�涰�X�C</returns>
        IEnumerable<WorkOrderDto> GetByStatus(FlowStatus status);

        /// <summary>
        /// �ھګإߪ� ID ���o�u�涰�X�C
        /// </summary>
        /// <param name="creatorId">�إߪ� ID�C</param>
        /// <returns>�ŦX���󪺤u�涰�X�C</returns>
        IEnumerable<WorkOrderDto> GetByCreatorId(int creatorId);

        /// <summary>
        /// �ھھ��� ID ���o�u�涰�X�C
        /// </summary>
        /// <param name="machineId">���� ID�C</param>
        /// <returns>�ŦX���󪺤u�涰�X�C</returns>
        IEnumerable<WorkOrderDto> GetByMachineId(int machineId);

        /// <summary>
        /// �ھڤ���d����o�u�涰�X�C
        /// </summary>
        /// <param name="startDate">�}�l����C</param>
        /// <param name="endDate">��������C</param>
        /// <returns>�ŦX���󪺤u�涰�X�C</returns>
        IEnumerable<WorkOrderDto> GetByDateRange(DateTime startDate, DateTime endDate);

        /// <summary>
        /// ���o�]�t���@�O�����u��C
        /// </summary>
        /// <param name="id">�u�� ID�C</param>
        /// <returns>�]�t���@�O�����u���ơC</returns>
        WorkOrderDto GetWithMaintenanceRecords(int id);

        /// <summary>
        /// �إ߷s���u��C
        /// </summary>
        /// <param name="dto">�u���ƶǿ骫��C</param>
        /// <returns>�إ᪺߫�u���ơC</returns>
        WorkOrderDto Create(WorkOrderDto dto);

        /// <summary>
        /// ��s�u���ơC
        /// </summary>
        /// <param name="dto">�u���ƶǿ骫��C</param>
        void Update(WorkOrderDto dto);

        /// <summary>
        /// �R�����w ID ���u��C
        /// </summary>
        /// <param name="id">�u�� ID�C</param>
        void Delete(int id);
    }

    /// <summary>
    /// ���@�u��A�ȹ�@�C
    /// </summary>
    public class WorkOrderService : IWorkOrderService
    {
        private readonly Func<MaintiFlowContext> _contextFactory;
        private readonly ILogger _logger;

        /// <summary>
        /// ��l�� <see cref="WorkOrderService"/> ���O���s�������C
        /// </summary>
        /// <param name="contextFactory">��Ʈw�W�U��u�t�C</param>
        /// <param name="logger">��x�O�����C</param>
        public WorkOrderService(Func<MaintiFlowContext> contextFactory, ILogger logger)
        {
            _contextFactory = contextFactory ?? throw new ArgumentNullException(nameof(contextFactory));
            _logger = logger?.ForContext<WorkOrderService>() ?? Log.Logger.ForContext<WorkOrderService>();
        }

        /// <inheritdoc/>
        public IEnumerable<WorkOrderDto> GetAll()
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkOrderRepository(context, _logger);
                return repository.GetAll().ToDtoList();
            }
        }

        /// <inheritdoc/>
        public WorkOrderDto GetById(int id)
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkOrderRepository(context, _logger);
                return repository.GetById(id)?.ToDto();
            }
        }

        /// <inheritdoc/>
        public WorkOrderDto GetByWorkOrderNo(string workOrderNo)
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkOrderRepository(context, _logger);
                return repository.GetByWorkOrderNo(workOrderNo)?.ToDto();
            }
        }

        /// <inheritdoc/>
        public IEnumerable<WorkOrderDto> GetByStatus(FlowStatus status)
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkOrderRepository(context, _logger);
                return repository.GetByStatus(status).ToDtoList();
            }
        }

        /// <inheritdoc/>
        public IEnumerable<WorkOrderDto> GetByCreatorId(int creatorId)
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkOrderRepository(context, _logger);
                return repository.GetByCreatorId(creatorId).ToDtoList();
            }
        }

        /// <inheritdoc/>
        public IEnumerable<WorkOrderDto> GetByMachineId(int machineId)
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkOrderRepository(context, _logger);
                return repository.GetByMachineId(machineId).ToDtoList();
            }
        }

        /// <inheritdoc/>
        public IEnumerable<WorkOrderDto> GetByDateRange(DateTime startDate, DateTime endDate)
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkOrderRepository(context, _logger);
                return repository.GetByDateRange(startDate, endDate).ToDtoList();
            }
        }

        /// <inheritdoc/>
        public WorkOrderDto GetWithMaintenanceRecords(int id)
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkOrderRepository(context, _logger);
                return repository.GetWithMaintenanceRecords(id)?.ToDto();
            }
        }

        /// <inheritdoc/>
        public WorkOrderDto Create(WorkOrderDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l�إߤu��G{WorkOrderNo}", dto.WorkOrderNo);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new WorkOrderRepository(context, _logger);
                    var entity = dto.ToEntity();
                    var added = repository.Add(entity);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("�u��إߦ��\�G{WorkOrderNo}�AId={Id}", dto.WorkOrderNo, added.Id);
                    return added.ToDto();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "�u��إߥ��ѡG{WorkOrderNo}", dto.WorkOrderNo);
                    throw;
                }
            }
        }

        /// <inheritdoc/>
        public void Update(WorkOrderDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l��s�u��GId={Id}", dto.Id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new WorkOrderRepository(context, _logger);
                    var existing = repository.GetById(dto.Id);
                    if (existing == null)
                    {
                        throw new InvalidOperationException($"�䤣��u��AId={dto.Id}");
                    }

                    existing.WorkOrderNo = dto.WorkOrderNo;
                    existing.Status = dto.Status;
                    existing.MachineId = dto.MachineId;
                    existing.WorkstationId = dto.WorkstationId;
                    existing.CreatorId = dto.CreatorId;
                    existing.CreationDateTime = dto.CreationDateTime;
                    existing.MaintenanceUnitId = dto.MaintenanceUnitId;
                    existing.AcceptedTime = dto.AcceptedTime;
                    existing.RequestingUnitId = dto.RequestingUnitId;
                    existing.Responsible = dto.Responsible;

                    repository.Update(existing);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("�u���s���\�GId={Id}", dto.Id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "�u���s���ѡGId={Id}", dto.Id);
                    throw;
                }
            }
        }

        /// <inheritdoc/>
        public void Delete(int id)
        {
            _logger.Information("�}�l�R���u��GId={Id}", id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new WorkOrderRepository(context, _logger);
                    repository.DeleteById(id);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("�u��R�����\�GId={Id}", id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "�u��R�����ѡGId={Id}", id);
                    throw;
                }
            }
        }
    }
}
