using System;
using System.Collections.Generic;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Mappers;
using Calin.TaskPulse.Core.DB.Repositories;
using Serilog;

namespace Calin.TaskPulse.Core.DB.Services
{
    /// <summary>
    /// �u���A�Ȥ����C
    /// </summary>
    public interface IWorkstationService
    {
        /// <summary>
        /// ���o�Ҧ��u���C
        /// </summary>
        /// <returns>�Ҧ��u������ƶǿ骫�󶰦X�C</returns>
        IEnumerable<WorkstationReadDto> GetAll();

        /// <summary>
        /// ���o�Ҧ��u���A�è̷ӱƧǽs���i��ƧǡC
        /// </summary>
        /// <returns>�Ƨǫ᪺�u����ƶǿ骫�󶰦X�C</returns>
        IEnumerable<WorkstationReadDto> GetAllOrdered();

        /// <summary>
        /// �ھڤu�� ID ���o�u���C
        /// </summary>
        /// <param name="id">�u�����ߤ@�ѧO�X�C</param>
        /// <returns>�ŦX���󪺤u����ƶǿ骫��C</returns>
        WorkstationReadDto GetById(int id);

        /// <summary>
        /// �ھڤu���W�٨��o�u���C
        /// </summary>
        /// <param name="workstationName">�u���W�١C</param>
        /// <returns>�ŦX���󪺤u����ƶǿ骫��C</returns>
        WorkstationReadDto GetByName(string workstationName);

        /// <summary>
        /// �ھھ��� ID ���o�u���M��C
        /// </summary>
        /// <param name="modelId">���� ID�C</param>
        /// <returns>�ŦX���󪺤u����ƶǿ骫�󶰦X�C</returns>
        IEnumerable<WorkstationReadDto> GetByModelId(int modelId);

        /// <summary>
        /// �إ߷s���u���C
        /// </summary>
        /// <param name="dto">�u������ƶǿ骫��C</param>
        /// <returns>�إ᪺߫�u����ƶǿ骫��C</returns>
        WorkstationReadDto Create(WorkstationReadDto dto);

        /// <summary>
        /// ��s�{�����u���C
        /// </summary>
        /// <param name="dto">�]�t��s��ƪ��u����ƶǿ骫��C</param>
        void Update(WorkstationReadDto dto);

        /// <summary>
        /// �R�����w ID ���u���C
        /// </summary>
        /// <param name="id">�n�R�����u���ߤ@�ѧO�X�C</param>
        void Delete(int id);
    }

    /// <summary>
    /// �u���A�ȹ�@�C
    /// </summary>
    public class WorkstationService : IWorkstationService
    {
        private readonly Func<CoreContext> _contextFactory;
        private readonly ILogger _logger;

        /// <summary>
        /// ��l�� <see cref="WorkstationService"/> ���O���s�������C
        /// </summary>
        /// <param name="contextFactory">��Ʈw�W�U��u�t��k�C</param>
        /// <param name="logger">�O������ҡC</param>
        public WorkstationService(Func<CoreContext> contextFactory, ILogger logger)
        {
            _contextFactory = contextFactory ?? throw new ArgumentNullException(nameof(contextFactory));
            _logger = logger?.ForContext<WorkstationService>() ?? Log.Logger.ForContext<WorkstationService>();
        }

        /// <inheritdoc />
        public IEnumerable<WorkstationReadDto> GetAll()
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkstationRepository(context, _logger);
                return repository.GetAll().ToDtoList();
            }
        }

        /// <inheritdoc />
        public IEnumerable<WorkstationReadDto> GetAllOrdered()
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkstationRepository(context, _logger);
                return repository.GetAllOrdered().ToDtoList();
            }
        }

        /// <inheritdoc />
        public WorkstationReadDto GetById(int id)
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkstationRepository(context, _logger);
                return repository.GetById(id)?.ToDto();
            }
        }

        /// <inheritdoc />
        public WorkstationReadDto GetByName(string workstationName)
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkstationRepository(context, _logger);
                return repository.GetByName(workstationName)?.ToDto();
            }
        }

        /// <inheritdoc />
        public IEnumerable<WorkstationReadDto> GetByModelId(int modelId)
        {
            using (var context = _contextFactory())
            {
                var repository = new WorkstationRepository(context, _logger);
                return repository.GetByModelId(modelId).ToDtoList();
            }
        }

        /// <inheritdoc />
        public WorkstationReadDto Create(WorkstationReadDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l�إߤu���G{WorkstationName}", dto.WorkstationName);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new WorkstationRepository(context, _logger);
                    var entity = dto.ToEntity();
                    var added = repository.Add(entity);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("�u���إߦ��\�G{WorkstationName}�AId={Id}", dto.WorkstationName, added.Id);
                    return added.ToDto();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "�u���إߥ��ѡG{WorkstationName}", dto.WorkstationName);
                    throw;
                }
            }
        }

        /// <inheritdoc />
        public void Update(WorkstationReadDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l��s�u���GId={Id}", dto.Id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new WorkstationRepository(context, _logger);
                    var existing = repository.GetById(dto.Id);
                    if (existing == null)
                    {
                        throw new InvalidOperationException($"�䤣��u���AId={dto.Id}");
                    }

                    existing.OrderNo = dto.OrderNo;
                    existing.WorkstationName = dto.WorkstationName;
                    existing.ModelId = dto.ModelId;

                    repository.Update(existing);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("�u����s���\�GId={Id}", dto.Id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "�u����s���ѡGId={Id}", dto.Id);
                    throw;
                }
            }
        }

        /// <inheritdoc />
        public void Delete(int id)
        {
            _logger.Information("�}�l�R���u���GId={Id}", id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new WorkstationRepository(context, _logger);
                    repository.DeleteById(id);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("�u���R�����\�GId={Id}", id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "�u���R�����ѡGId={Id}", id);
                    throw;
                }
            }
        }
    }
}
