using System;
using System.Collections.Generic;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Mappers;
using Calin.TaskPulse.Core.DB.Repositories;
using Serilog;

namespace Calin.TaskPulse.Core.DB.Services
{
    /// <summary>
    /// �����A�Ȥ����C
    /// </summary>
    public interface IDepartmentService
    {
        /// <summary>
        /// ���o�Ҧ������C
        /// </summary>
        /// <returns>�Ҧ���������ƶǿ骫�󶰦X�C</returns>
        IEnumerable<DepartmentDto> GetAll();

        /// <summary>
        /// ���o�Ҧ������A�è̷ӱƧǽs���i��ƧǡC
        /// </summary>
        /// <returns>�Ƨǫ᪺������ƶǿ骫�󶰦X�C</returns>
        IEnumerable<DepartmentDto> GetAllOrdered();

        /// <summary>
        /// �ھڳ��� ID ���o�����C
        /// </summary>
        /// <param name="id">�������ߤ@�ѧO�X�C</param>
        /// <returns>�ŦX���󪺳�����ƶǿ骫��C</returns>
        DepartmentDto GetById(int id);

        /// <summary>
        /// �ھڳ����W�٨��o�����C
        /// </summary>
        /// <param name="departmentName">�����W�١C</param>
        /// <returns>�ŦX���󪺳�����ƶǿ骫��C</returns>
        DepartmentDto GetByName(string departmentName);

        /// <summary>
        /// �إ߷s�������C
        /// </summary>
        /// <param name="dto">��������ƶǿ骫��C</param>
        /// <returns>�إ᪺߫������ƶǿ骫��C</returns>
        DepartmentDto Create(DepartmentDto dto);

        /// <summary>
        /// ��s�{���������C
        /// </summary>
        /// <param name="dto">�]�t��s��ƪ�������ƶǿ骫��C</param>
        void Update(DepartmentDto dto);

        /// <summary>
        /// �R�����w ID �������C
        /// </summary>
        /// <param name="id">�n�R���������ߤ@�ѧO�X�C</param>
        void Delete(int id);
    }

    /// <summary>
    /// �����A�ȹ�@�C
    /// </summary>
    public class DepartmentService : IDepartmentService
    {
        private readonly Func<CoreContext> _contextFactory;
        private readonly ILogger _logger;

        /// <summary>
        /// ��l�� <see cref="DepartmentService"/> ���O���s�������C
        /// </summary>
        /// <param name="contextFactory">��Ʈw�W�U��u�t��k�C</param>
        /// <param name="logger">�O������ҡC</param>
        public DepartmentService(Func<CoreContext> contextFactory, ILogger logger)
        {
            _contextFactory = contextFactory ?? throw new ArgumentNullException(nameof(contextFactory));
            _logger = logger?.ForContext<DepartmentService>() ?? Log.Logger.ForContext<DepartmentService>();
        }

        /// <inheritdoc />
        public IEnumerable<DepartmentDto> GetAll()
        {
            using (var context = _contextFactory())
            {
                var repository = new DepartmentRepository(context, _logger);
                return repository.GetAll().ToDtoList();
            }
        }

        /// <inheritdoc />
        public IEnumerable<DepartmentDto> GetAllOrdered()
        {
            using (var context = _contextFactory())
            {
                var repository = new DepartmentRepository(context, _logger);
                return repository.GetAllOrdered().ToDtoList();
            }
        }

        /// <inheritdoc />
        public DepartmentDto GetById(int id)
        {
            using (var context = _contextFactory())
            {
                var repository = new DepartmentRepository(context, _logger);
                return repository.GetById(id)?.ToDto();
            }
        }

        /// <inheritdoc />
        public DepartmentDto GetByName(string departmentName)
        {
            using (var context = _contextFactory())
            {
                var repository = new DepartmentRepository(context, _logger);
                return repository.GetByName(departmentName)?.ToDto();
            }
        }

        /// <inheritdoc />
        public DepartmentDto Create(DepartmentDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l�إ߳����G{DepartmentName}", dto.DepartmentName);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new DepartmentRepository(context, _logger);
                    var entity = dto.ToEntity();
                    var added = repository.Add(entity);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("�����إߦ��\�G{DepartmentName}�AId={Id}", dto.DepartmentName, added.Id);
                    return added.ToDto();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "�����إߥ��ѡG{DepartmentName}", dto.DepartmentName);
                    throw;
                }
            }
        }

        /// <inheritdoc />
        public void Update(DepartmentDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l��s�����GId={Id}", dto.Id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new DepartmentRepository(context, _logger);
                    var existing = repository.GetById(dto.Id);
                    if (existing == null)
                    {
                        throw new InvalidOperationException($"�䤣�쳡���AId={dto.Id}");
                    }

                    existing.OrderNo = dto.OrderNo;
                    existing.DepartmentName = dto.DepartmentName;

                    repository.Update(existing);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("������s���\�GId={Id}", dto.Id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "������s���ѡGId={Id}", dto.Id);
                    throw;
                }
            }
        }

        /// <inheritdoc />
        public void Delete(int id)
        {
            _logger.Information("�}�l�R�������GId={Id}", id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new DepartmentRepository(context, _logger);
                    repository.DeleteById(id);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("�����R�����\�GId={Id}", id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "�����R�����ѡGId={Id}", id);
                    throw;
                }
            }
        }
    }
}
