using System;
using System.Collections.Generic;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Mappers;
using Calin.TaskPulse.Core.DB.Repositories;
using Serilog;

namespace Calin.TaskPulse.Core.DB.Services
{
    /// <summary>
    /// ¾�٪A�Ȥ����C
    /// </summary>
    public interface IJobTitleService
    {
        /// <summary>
        /// ���o�Ҧ�¾�١C
        /// </summary>
        /// <returns>�Ҧ�¾�٪���ƶǿ骫�󶰦X�C</returns>
        IEnumerable<JobTitleDto> GetAll();

        /// <summary>
        /// ���o�Ҧ�¾�١A�è̷ӱƧǽs���i��ƧǡC
        /// </summary>
        /// <returns>�Ƨǫ᪺¾�ٸ�ƶǿ骫�󶰦X�C</returns>
        IEnumerable<JobTitleDto> GetAllOrdered();

        /// <summary>
        /// �ھ�¾�� ID ���o¾�١C
        /// </summary>
        /// <param name="id">¾�٪��ߤ@�ѧO�X�C</param>
        /// <returns>�ŦX����¾�ٸ�ƶǿ骫��C</returns>
        JobTitleDto GetById(int id);

        /// <summary>
        /// �ھ�¾�٦W�٨��o¾�١C
        /// </summary>
        /// <param name="jobTitleName">¾�٦W�١C</param>
        /// <returns>�ŦX����¾�ٸ�ƶǿ骫��C</returns>
        JobTitleDto GetByName(string jobTitleName);

        /// <summary>
        /// �إ߷s��¾�١C
        /// </summary>
        /// <param name="dto">¾�٪���ƶǿ骫��C</param>
        /// <returns>�إ᪺߫¾�ٸ�ƶǿ骫��C</returns>
        JobTitleDto Create(JobTitleDto dto);

        /// <summary>
        /// ��s�{����¾�١C
        /// </summary>
        /// <param name="dto">�]�t��s��ƪ�¾�ٸ�ƶǿ骫��C</param>
        void Update(JobTitleDto dto);

        /// <summary>
        /// �R�����w ID ��¾�١C
        /// </summary>
        /// <param name="id">�n�R����¾�ٰߤ@�ѧO�X�C</param>
        void Delete(int id);
    }

    /// <summary>
    /// ¾�٪A�ȹ�@�C
    /// </summary>
    public class JobTitleService : IJobTitleService
    {
        private readonly Func<CoreContext> _contextFactory;
        private readonly ILogger _logger;

        /// <summary>
        /// ��l�� <see cref="JobTitleService"/> ���O���s�������C
        /// </summary>
        /// <param name="contextFactory">��Ʈw�W�U��u�t��k�C</param>
        /// <param name="logger">�O������ҡC</param>
        public JobTitleService(Func<CoreContext> contextFactory, ILogger logger)
        {
            _contextFactory = contextFactory ?? throw new ArgumentNullException(nameof(contextFactory));
            _logger = logger?.ForContext<JobTitleService>() ?? Log.Logger.ForContext<JobTitleService>();
        }

        /// <inheritdoc />
        public IEnumerable<JobTitleDto> GetAll()
        {
            using (var context = _contextFactory())
            {
                var repository = new JobTitleRepository(context, _logger);
                return repository.GetAll().ToDtoList();
            }
        }

        /// <inheritdoc />
        public IEnumerable<JobTitleDto> GetAllOrdered()
        {
            using (var context = _contextFactory())
            {
                var repository = new JobTitleRepository(context, _logger);
                return repository.GetAllOrdered().ToDtoList();
            }
        }

        /// <inheritdoc />
        public JobTitleDto GetById(int id)
        {
            using (var context = _contextFactory())
            {
                var repository = new JobTitleRepository(context, _logger);
                return repository.GetById(id)?.ToDto();
            }
        }

        /// <inheritdoc />
        public JobTitleDto GetByName(string jobTitleName)
        {
            using (var context = _contextFactory())
            {
                var repository = new JobTitleRepository(context, _logger);
                return repository.GetByName(jobTitleName)?.ToDto();
            }
        }

        /// <inheritdoc />
        public JobTitleDto Create(JobTitleDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l�إ�¾�١G{JobTitleName}", dto.JobTitleName);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new JobTitleRepository(context, _logger);
                    var entity = dto.ToEntity();
                    var added = repository.Add(entity);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("¾�٫إߦ��\�G{JobTitleName}�AId={Id}", dto.JobTitleName, added.Id);
                    return added.ToDto();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "¾�٫إߥ��ѡG{JobTitleName}", dto.JobTitleName);
                    throw;
                }
            }
        }

        /// <inheritdoc />
        public void Update(JobTitleDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l��s¾�١GId={Id}", dto.Id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new JobTitleRepository(context, _logger);
                    var existing = repository.GetById(dto.Id);
                    if (existing == null)
                    {
                        throw new InvalidOperationException($"�䤣��¾�١AId={dto.Id}");
                    }

                    existing.OrderNo = dto.OrderNo;
                    existing.JobTitleName = dto.JobTitleName;

                    repository.Update(existing);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("¾�٧�s���\�GId={Id}", dto.Id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "¾�٧�s���ѡGId={Id}", dto.Id);
                    throw;
                }
            }
        }

        /// <inheritdoc />
        public void Delete(int id)
        {
            _logger.Information("�}�l�R��¾�١GId={Id}", id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new JobTitleRepository(context, _logger);
                    repository.DeleteById(id);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("¾�٧R�����\�GId={Id}", id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "¾�٧R�����ѡGId={Id}", id);
                    throw;
                }
            }
        }
    }
}
