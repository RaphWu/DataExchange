using System;
using System.Collections.Generic;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Mappers;
using Calin.TaskPulse.Core.DB.Repositories;
using Serilog;

namespace Calin.TaskPulse.Core.DB.Services
{
    /// <summary>
    /// ���تA�Ȥ����C
    /// </summary>
    public interface IModelService
    {
        /// <summary>
        /// ���o�Ҧ����ءC
        /// </summary>
        /// <returns>�Ҧ����ت���ƶǿ骫�󶰦X�C</returns>
        IEnumerable<ModelDto> GetAll();

        /// <summary>
        /// �ھھ��� ID ���o���ءC
        /// </summary>
        /// <param name="id">���ت��ߤ@�ѧO�X�C</param>
        /// <returns>���������ظ�ƶǿ骫��C</returns>
        ModelDto GetById(int id);

        /// <summary>
        /// �ھھ��ئW�٨��o���ءC
        /// </summary>
        /// <param name="modelName">���ئW�١C</param>
        /// <returns>���������ظ�ƶǿ骫��C</returns>
        ModelDto GetByModelName(string modelName);

        /// <summary>
        /// �ھڪ��A ID ���o���ض��X�C
        /// </summary>
        /// <param name="statusId">���A���ߤ@�ѧO�X�C</param>
        /// <returns>�ŦX���󪺾��ظ�ƶǿ骫�󶰦X�C</returns>
        IEnumerable<ModelDto> GetByStatusId(int statusId);

        /// <summary>
        /// ���o�]�t�u�@�������ءC
        /// </summary>
        /// <param name="id">���ت��ߤ@�ѧO�X�C</param>
        /// <returns>�]�t�u�@�������ظ�ƶǿ骫��C</returns>
        ModelDto GetWithWorkstations(int id);

        /// <summary>
        /// �إ߷s�����ءC
        /// </summary>
        /// <param name="dto">���ت���ƶǿ骫��C</param>
        /// <returns>�إ᪺߫���ظ�ƶǿ骫��C</returns>
        ModelDto Create(ModelDto dto);

        /// <summary>
        /// ��s�{�������ءC
        /// </summary>
        /// <param name="dto">�]�t��s��ƪ����ظ�ƶǿ骫��C</param>
        void Update(ModelDto dto);

        /// <summary>
        /// �R�����w ID �����ءC
        /// </summary>
        /// <param name="id">�n�R�������ذߤ@�ѧO�X�C</param>
        void Delete(int id);
    }

    /// <summary>
    /// ���تA�ȹ�@�C
    /// </summary>
    public class ModelService : IModelService
    {
        private readonly Func<CoreContext> _contextFactory;
        private readonly ILogger _logger;

        /// <summary>
        /// ��l�� <see cref="ModelService"/> ���O���s�������C
        /// </summary>
        /// <param name="contextFactory">��Ʈw�W�U��u�t��k�C</param>
        /// <param name="logger">�O������ҡC</param>
        public ModelService(Func<CoreContext> contextFactory, ILogger logger)
        {
            _contextFactory = contextFactory ?? throw new ArgumentNullException(nameof(contextFactory));
            _logger = logger?.ForContext<ModelService>() ?? Log.Logger.ForContext<ModelService>();
        }

        /// <inheritdoc />
        public IEnumerable<ModelDto> GetAll()
        {
            using (var context = _contextFactory())
            {
                var repository = new ModelRepository(context, _logger);
                return repository.GetAll().ToDtoList();
            }
        }

        /// <inheritdoc />
        public ModelDto GetById(int id)
        {
            using (var context = _contextFactory())
            {
                var repository = new ModelRepository(context, _logger);
                return repository.GetById(id)?.ToDto();
            }
        }

        /// <inheritdoc />
        public ModelDto GetByModelName(string modelName)
        {
            using (var context = _contextFactory())
            {
                var repository = new ModelRepository(context, _logger);
                return repository.GetByModelName(modelName)?.ToDto();
            }
        }

        /// <inheritdoc />
        public IEnumerable<ModelDto> GetByStatusId(int statusId)
        {
            using (var context = _contextFactory())
            {
                var repository = new ModelRepository(context, _logger);
                return repository.GetByStatusId(statusId).ToDtoList();
            }
        }

        /// <inheritdoc />
        public ModelDto GetWithWorkstations(int id)
        {
            using (var context = _contextFactory())
            {
                var repository = new ModelRepository(context, _logger);
                return repository.GetWithWorkstations(id)?.ToDto();
            }
        }

        /// <inheritdoc />
        public ModelDto Create(ModelDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l�إ߾��ءG{ModelName}", dto.ModelName);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new ModelRepository(context, _logger);
                    var entity = dto.ToEntity();
                    var added = repository.Add(entity);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("���ثإߦ��\�G{ModelName}�AId={Id}", dto.ModelName, added.Id);
                    return added.ToDto();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "���ثإߥ��ѡG{ModelName}", dto.ModelName);
                    throw;
                }
            }
        }

        /// <inheritdoc />
        public void Update(ModelDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l��s���ءGId={Id}", dto.Id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new ModelRepository(context, _logger);
                    var existing = repository.GetById(dto.Id);
                    if (existing == null)
                    {
                        throw new InvalidOperationException($"�䤣����ءAId={dto.Id}");
                    }

                    existing.ModelName = dto.ModelName;
                    existing.ModelStatusId = dto.ModelStatusId;

                    repository.Update(existing);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("���ا�s���\�GId={Id}", dto.Id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "���ا�s���ѡGId={Id}", dto.Id);
                    throw;
                }
            }
        }

        /// <inheritdoc />
        public void Delete(int id)
        {
            _logger.Information("�}�l�R�����ءGId={Id}", id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new ModelRepository(context, _logger);
                    repository.DeleteById(id);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("���اR�����\�GId={Id}", id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "���اR�����ѡGId={Id}", id);
                    throw;
                }
            }
        }
    }
}
