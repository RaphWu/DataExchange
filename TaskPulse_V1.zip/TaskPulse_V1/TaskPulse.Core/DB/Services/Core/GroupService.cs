using System;
using System.Collections.Generic;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Mappers;
using Calin.TaskPulse.Core.DB.Repositories;
using Serilog;

namespace Calin.TaskPulse.Core.DB.Services
{
    /// <summary>
    /// �s�ժA�Ȥ����C
    /// </summary>
    public interface IGroupService
    {
        /// <summary>
        /// ���o�Ҧ��s�աC
        /// </summary>
        /// <returns>�Ҧ��s�ժ���ƶǿ骫�󶰦X�C</returns>
        IEnumerable<GroupDto> GetAll();

        /// <summary>
        /// ���o�Ҧ��s�աA�è̷ӱƧǽs���i��ƧǡC
        /// </summary>
        /// <returns>�Ƨǫ᪺�s�ո�ƶǿ骫�󶰦X�C</returns>
        IEnumerable<GroupDto> GetAllOrdered();

        /// <summary>
        /// �ھڸs�� ID ���o�s�աC
        /// </summary>
        /// <param name="id">�s�ժ��ߤ@�ѧO�X�C</param>
        /// <returns>�ŦX���󪺸s�ո�ƶǿ骫��C</returns>
        GroupDto GetById(int id);

        /// <summary>
        /// �ھڸs�զW�٨��o�s�աC
        /// </summary>
        /// <param name="name">�s�զW�١C</param>
        /// <returns>�ŦX���󪺸s�ո�ƶǿ骫��C</returns>
        GroupDto GetByName(string name);

        /// <summary>
        /// �إ߷s���s�աC
        /// </summary>
        /// <param name="dto">�s�ժ���ƶǿ骫��C</param>
        /// <returns>�إ᪺߫�s�ո�ƶǿ骫��C</returns>
        GroupDto Create(GroupDto dto);

        /// <summary>
        /// ��s�{�����s�աC
        /// </summary>
        /// <param name="dto">�]�t��s��ƪ��s�ո�ƶǿ骫��C</param>
        void Update(GroupDto dto);

        /// <summary>
        /// �R�����w ID ���s�աC
        /// </summary>
        /// <param name="id">�n�R�����s�հߤ@�ѧO�X�C</param>
        void Delete(int id);
    }

    /// <summary>
    /// �s�ժA�ȹ�@�C
    /// </summary>
    public class GroupService : IGroupService
    {
        private readonly Func<CoreContext> _contextFactory;
        private readonly ILogger _logger;

        /// <summary>
        /// ��l�� <see cref="GroupService"/> ���O���s�������C
        /// </summary>
        /// <param name="contextFactory">��Ʈw�W�U��u�t��k�C</param>
        /// <param name="logger">�O������ҡC</param>
        public GroupService(Func<CoreContext> contextFactory, ILogger logger)
        {
            _contextFactory = contextFactory ?? throw new ArgumentNullException(nameof(contextFactory));
            _logger = logger?.ForContext<GroupService>() ?? Log.Logger.ForContext<GroupService>();
        }

        /// <inheritdoc />
        public IEnumerable<GroupDto> GetAll()
        {
            using (var context = _contextFactory())
            {
                var repository = new GroupRepository(context, _logger);
                return repository.GetAll().ToDtoList();
            }
        }

        /// <inheritdoc />
        public IEnumerable<GroupDto> GetAllOrdered()
        {
            using (var context = _contextFactory())
            {
                var repository = new GroupRepository(context, _logger);
                return repository.GetAllOrdered().ToDtoList();
            }
        }

        /// <inheritdoc />
        public GroupDto GetById(int id)
        {
            using (var context = _contextFactory())
            {
                var repository = new GroupRepository(context, _logger);
                return repository.GetById(id)?.ToDto();
            }
        }

        /// <inheritdoc />
        public GroupDto GetByName(string name)
        {
            using (var context = _contextFactory())
            {
                var repository = new GroupRepository(context, _logger);
                return repository.GetByName(name)?.ToDto();
            }
        }

        /// <inheritdoc />
        public GroupDto Create(GroupDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l�إ߸s�աG{Name}", dto.Name);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new GroupRepository(context, _logger);
                    var entity = dto.ToEntity();
                    var added = repository.Add(entity);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("�s�իإߦ��\�G{Name}�AId={Id}", dto.Name, added.Id);
                    return added.ToDto();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "�s�իإߥ��ѡG{Name}", dto.Name);
                    throw;
                }
            }
        }

        /// <inheritdoc />
        public void Update(GroupDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            _logger.Information("�}�l��s�s�աGId={Id}", dto.Id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new GroupRepository(context, _logger);
                    var existing = repository.GetById(dto.Id);
                    if (existing == null)
                    {
                        throw new InvalidOperationException($"�䤣��s�աAId={dto.Id}");
                    }

                    existing.OrderNo = dto.OrderNo;
                    existing.Name = dto.Name;

                    repository.Update(existing);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("�s�է�s���\�GId={Id}", dto.Id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "�s�է�s���ѡGId={Id}", dto.Id);
                    throw;
                }
            }
        }

        /// <inheritdoc />
        public void Delete(int id)
        {
            _logger.Information("�}�l�R���s�աGId={Id}", id);

            using (var context = _contextFactory())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var repository = new GroupRepository(context, _logger);
                    repository.DeleteById(id);
                    context.SaveChanges();
                    transaction.Commit();

                    _logger.Information("�s�էR�����\�GId={Id}", id);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.Error(ex, "�s�էR�����ѡGId={Id}", id);
                    throw;
                }
            }
        }
    }
}
