﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.SharedUI
{
    public class TreeViewContextMenu : ContextMenuStrip
    {
        private ToolStripMenuItem _expandAll;
        private ToolStripMenuItem _collapseAll;
        private ToolStripMenuItem _expand;
        private ToolStripMenuItem _collapse;

        public TreeViewContextMenu()
        {
            _expandAll = new ToolStripMenuItem("全部展開");
            _collapseAll = new ToolStripMenuItem("全部收摺");
            _expand = new ToolStripMenuItem("展開此層");
            _collapse = new ToolStripMenuItem("收摺此層");

            _expandAll.Click += ExpandAll_Click;
            _collapseAll.Click += CollapseAll_Click;
            _expand.Click += Expand_Click;
            _collapse.Click += Collapse_Click;

            Items.AddRange(new ToolStripItem[]
            {
                _expandAll,
                _collapseAll,
                new ToolStripSeparator(),
                _expand,
                _collapse,
            });

            CommonStyles.SetToolStripMenuItem(_expandAll);
            CommonStyles.SetToolStripMenuItem(_collapseAll);
            CommonStyles.SetToolStripMenuItem(_expand);
            CommonStyles.SetToolStripMenuItem(_collapse);

            Opening += TreeViewContextMenu_Opening;
        }

        private void TreeViewContextMenu_Opening(object sender, CancelEventArgs e)
        {
            if (!(SourceControl is TreeView tree) || tree.SelectedNode == null)
            {
                e.Cancel = true;
                return;
            }

            TreeNode node = tree.SelectedNode;
            int level = node.Level;

            //_expandAll.Enabled = hasChildren && !expanded;
            //_collapseAll.Enabled = expanded;

            _expand.Enabled = level == 0 && !node.IsExpanded;
            _collapse.Enabled = level > 0 && node.Parent.IsExpanded;
        }

        private void ExpandAll_Click(object sender, EventArgs e)
        {
            if (SourceControl is TreeView tree && tree.SelectedNode != null)
                tree.ExpandAll();
        }

        private void CollapseAll_Click(object sender, EventArgs e)
        {
            if (SourceControl is TreeView tree && tree.SelectedNode != null)
                tree.CollapseAll();
        }

        private void Expand_Click(object sender, EventArgs e)
        {
            if (SourceControl is TreeView tree && tree.SelectedNode != null)
                tree.SelectedNode.Expand();
        }

        private void Collapse_Click(object sender, EventArgs e)
        {
            if (SourceControl is TreeView tree && tree.SelectedNode != null)
                tree.SelectedNode.Parent.Collapse();
        }
    }
}
