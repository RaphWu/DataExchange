﻿# TaskPulse.Core History

## 2026.01.

- V1 版本重建。
