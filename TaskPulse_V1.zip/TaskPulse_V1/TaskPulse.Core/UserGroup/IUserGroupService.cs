﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.DB.DTOs;

namespace Calin.TaskPulse.Core.UserGroup
{
    /// <summary>
    /// 使用者群組服務介面，提供群組的 CRUD 操作及權限、成員指派功能。
    /// </summary>
    public interface IUserGroupService
    {
        /// <summary>
        /// 建立新的群組。
        /// </summary>
        /// <param name="group">群組資料傳輸物件。</param>
        /// <param name="currentUserId">目前使用者識別碼。</param>
        /// <returns>建立完成的群組資料傳輸物件。</returns>
        Task<GroupDto> CreateAsync(GroupDto group, string currentUserId);

        /// <summary>
        /// 更新現有群組。
        /// </summary>
        /// <param name="group">群組資料傳輸物件。</param>
        /// <param name="currentUserId">目前使用者識別碼。</param>
        /// <returns>更新後的群組資料傳輸物件。</returns>
        Task<GroupDto> UpdateAsync(GroupDto group, string currentUserId);

        /// <summary>
        /// 刪除群組。
        /// </summary>
        /// <param name="groupId">群組識別碼。</param>
        /// <param name="currentUserId">目前使用者識別碼。</param>
        Task DeleteAsync(int groupId, string currentUserId);

        /// <summary>
        /// 根據識別碼取得群組。
        /// </summary>
        /// <param name="groupId">群組識別碼。</param>
        /// <returns>群組資料傳輸物件，若不存在則為 null。</returns>
        Task<GroupDto> GetByIdAsync(int groupId);

        /// <summary>
        /// 取得所有群組。
        /// </summary>
        /// <returns>群組資料傳輸物件清單。</returns>
        Task<List<GroupDto>> GetAllAsync();

        /// <summary>
        /// 指派使用者到群組。
        /// </summary>
        /// <param name="groupId">群組識別碼。</param>
        /// <param name="userIds">使用者識別碼清單。</param>
        /// <param name="currentUserId">目前使用者識別碼。</param>
        Task AssignUsersAsync(int groupId, List<int> userIds, string currentUserId);

        /// <summary>
        /// 指派權限到群組。
        /// </summary>
        /// <param name="groupId">群組識別碼。</param>
        /// <param name="permissionIds">權限識別碼清單。</param>
        /// <param name="currentUserId">目前使用者識別碼。</param>
        Task AssignPermissionsAsync(int groupId, List<int> permissionIds, string currentUserId);
    }
}
