﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.DB;
using Calin.TaskPulse.Core.DB.DTOs;
using Calin.TaskPulse.Core.DB.Mappers;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Services;
using Serilog.Context;

namespace Calin.TaskPulse.Core.UserGroup
{
    public class UserGroupService : IUserGroupService
    {
        private readonly Serilog.ILogger _logger;
        private readonly Func<CoreContext> _contextFactory;
        private readonly CurrentUserContext _currentUser;
        private readonly MemoryCacheService _cache;

        /// <summary>
        /// 初始化 <see cref="UserGroupService"/> 類別的新執行個體。
        /// </summary>
        /// <param name="logger">日誌記錄器。</param>
        /// <param name="currentUserContext">目前使用者上下文。</param>
        /// <param name="contextFactory">資料庫上下文工廠方法。</param>
        /// <param name="cache">記憶體快取服務。</param>
        public UserGroupService(
            Serilog.ILogger logger,
            CurrentUserContext currentUserContext,
            Func<CoreContext> contextFactory,
            MemoryCacheService cache)
        {
            _logger = logger;
            _currentUser = currentUserContext;
            _contextFactory = contextFactory ?? throw new ArgumentNullException(nameof(contextFactory));
            _cache = cache;
        }

        /// <inheritdoc/>
        public async Task<GroupDto> CreateAsync(GroupDto group, string currentUserId)
        {
            using (var context = _contextFactory())
            {
                var entity = group.ToEntity();
                context.Groups.Add(entity);
                await context.SaveChangesAsync();

                // 記錄資料庫操作日誌
                using (LogContext.PushProperty("Category", "Database"))
                {
                    var gp = new
                    {
                        群組名稱 = group.Name,
                        建立時間 = DateTime.UtcNow,
                        建立人員 = _currentUser.UserName,
                    };
                    _logger.Information("{@gp}", gp);
                }

                // 回傳包含新產生 Id 的 DTO
                group.Id = entity.Id;
                return group;
            }
        }

        /// <inheritdoc/>
        public async Task<GroupDto> UpdateAsync(GroupDto group, string currentUserId)
        {
            using (var context = _contextFactory())
            {
                var existing = await context.Groups.FindAsync(group.Id);
                if (existing == null)
                    throw new Exception("找不到指定的群組");

                existing.Name = group.Name;
                existing.OrderNo = group.OrderNo;
                await context.SaveChangesAsync();

                // 更新群組後清空所有使用者權限快取
                _cache.RemoveByPrefix("permissions_");

                return existing.ToDto();
            }
        }

        /// <inheritdoc/>
        public async Task DeleteAsync(int groupId, string currentUserId)
        {
            using (var context = _contextFactory())
            {
                var existing = await context.Groups.FindAsync(groupId);
                if (existing == null)
                    throw new Exception("找不到指定的群組");

                context.Groups.Remove(existing);
                await context.SaveChangesAsync();

                // 刪除群組後清空所有使用者權限快取
                _cache.RemoveByPrefix("permissions_");
            }
        }

        /// <inheritdoc/>
        public async Task<GroupDto> GetByIdAsync(int groupId)
        {
            using (var context = _contextFactory())
            {
                var entity = await context.Groups
                    .Include(ug => ug.GroupPermissions)
                    .Include(ug => ug.EmployeeGroups)
                    .FirstOrDefaultAsync(ug => ug.Id == groupId);

                return entity?.ToDto();
            }
        }

        /// <inheritdoc/>
        public async Task<List<GroupDto>> GetAllAsync()
        {
            using (var context = _contextFactory())
            {
                var entities = await context.Groups
                    .Include(ug => ug.GroupPermissions)
                    .Include(ug => ug.EmployeeGroups)
                    .ToListAsync();

                return entities.ToDtoList().ToList();
            }
        }

        /// <inheritdoc/>
        public async Task AssignUsersAsync(int groupId, List<int> userIds, string currentUserId)
        {
            using (var context = _contextFactory())
            {
                var group = await context.Groups
                    .Include(ug => ug.EmployeeGroups)
                    .FirstOrDefaultAsync(ug => ug.Id == groupId);

                if (group == null)
                    throw new Exception("找不到指定的群組");

                // 清除現有成員關聯
                group.EmployeeGroups.Clear();

                // 建立新的成員關聯
                foreach (var userId in userIds)
                {
                    group.EmployeeGroups.Add(new Entity.Core.EmployeeGroup
                    {
                        GroupId = groupId,
                        EmployeeId = userId
                    });
                }

                await context.SaveChangesAsync();

                // 變更成員後清空權限快取
                _cache.RemoveByPrefix("permissions_");
            }
        }

        /// <inheritdoc/>
        public async Task AssignPermissionsAsync(int groupId, List<int> permissionIds, string currentUserId)
        {
            using (var context = _contextFactory())
            {
                var group = await context.Groups
                    .Include(ug => ug.GroupPermissions)
                    .FirstOrDefaultAsync(ug => ug.Id == groupId);

                if (group == null)
                    throw new Exception("找不到指定的群組");

                // 清除現有權限關聯
                group.GroupPermissions.Clear();

                // 建立新的權限關聯
                foreach (var permissionId in permissionIds)
                {
                    group.GroupPermissions.Add(new Entity.Core.GroupPermission
                    {
                        GroupId = groupId,
                        PermissionId = permissionId
                    });
                }

                await context.SaveChangesAsync();

                // 變更權限後清空權限快取
                _cache.RemoveByPrefix("permissions_");
            }
        }
    }
}
