﻿using System.Threading.Tasks;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    /// <summary>
    /// 維護工單服務介面。
    /// </summary>
    public interface IMaintiFlow : ITaskOrderAction
    {
        /// <summary>
        /// 初始化服務。
        /// </summary>
        Task Initialize();

        /// <summary>
        /// 更新快取。
        /// </summary>
        Task UpdateWorkOrdersCacheAsync();
    }
}
