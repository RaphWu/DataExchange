﻿using Autofac;

namespace Calin.TaskPulse.MaintiFlow
{
    public class MaintiFlowModule : Module
    {
    }
}
