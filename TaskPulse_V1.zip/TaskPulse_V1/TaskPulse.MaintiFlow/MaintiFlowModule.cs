﻿using Autofac;
using Calin.TaskPulse.MaintiFlow.Service;

namespace Calin.TaskPulse.MaintiFlow
{
    public class MaintiFlowModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // service
            builder.RegisterType<MaintiFlowService>().As<IMaintiFlow>().SingleInstance();
        }
    }
}
