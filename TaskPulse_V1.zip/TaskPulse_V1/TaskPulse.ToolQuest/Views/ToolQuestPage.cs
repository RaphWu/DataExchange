﻿using System.Windows.Forms;

namespace Calin.TaskPulse.ToolQuest.Views
{
    public partial class ToolQuestPage : UserControl
    {
        public ToolQuestPage()
        {
            InitializeComponent();
        }
    }
}
