﻿/*
維護單位實體類別。

關聯設定：
WorkOrderEntity: 一對多關聯，表示一個維護單位可包含多個工單。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.MaintiFlow
{
    /// <summary>
    /// 維護單位。
    /// </summary>
    public class MaintenanceUnitEntity : IEquatable<MaintenanceUnitEntity>
    {
        /// <summary>
        /// 維護單位主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 單位名稱。
        /// </summary>
        public string UnitName { get; set; }

        /// <summary>
        /// 此單位負責的工單清單。
        /// </summary>
        public virtual ICollection<WorkOrderEntity> WorkOrders { get; set; } = new HashSet<WorkOrderEntity>();

        #region IEquatable<MaintenanceUnitEntity>

        public bool Equals(MaintenanceUnitEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as MaintenanceUnitEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(MaintenanceUnitEntity left, MaintenanceUnitEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(MaintenanceUnitEntity left, MaintenanceUnitEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
