﻿/*
維護類型實體類別。

關聯設定：
WorkOrderEntity: 一對多關聯，表示一個維護類型可包含多個工單。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.MaintiFlow
{
    /// <summary>
    /// 維護類型。
    /// </summary>
    public class MaintiFlowIssueCategoryEntity : IEquatable<MaintiFlowIssueCategoryEntity>
    {
        /// <summary>
        /// 維護類型主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 維護類型名稱。
        /// </summary>
        public string CategoryName { get; set; }

        /// <summary>
        /// 此類型的工單清單。
        /// </summary>
        public virtual ICollection<WorkOrderEntity> WorkOrders { get; set; } = new HashSet<WorkOrderEntity>();

        #region IEquatable<MaintiFlowIssueCategoryEntity>

        public bool Equals(MaintiFlowIssueCategoryEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as MaintiFlowIssueCategoryEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(MaintiFlowIssueCategoryEntity left, MaintiFlowIssueCategoryEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(MaintiFlowIssueCategoryEntity left, MaintiFlowIssueCategoryEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
