﻿/*
維護工單實體類別。
代表一張維護工作的主要記錄，包含工單基本資訊、機台/工站關聯、維護單位及接單狀態。
實際的維護內容（問題描述、處理詳情、工程師、維護期間等）已正規化至 MaintenanceRecordEntity。

關聯設定：
MachineEntity: 多對一關聯，表示一張工單對應一台機台（CoreContext 實體）。
WorkstationEntity: 多對一關聯，表示一張工單對應一個工站（CoreContext 實體）。
EmployeeEntity (Creator): 多對一關聯，表示工單由某員工建立。
MaintenanceUnitEntity: 多對一關聯，表示工單由某維護單位負責。
DepartmentEntity (RequestingUnit): 多對一關聯，表示工單的需求單位（CoreContext 實體）。
MaintenanceRecordEntity: 一對多關聯，表示一張工單可包含多筆維護內容記錄。

註：因為一張工單只能有一台機台、一個工站，所以 MachineEntity、WorkstationEntity 是多對一關係。如果維護多個機台，需拆分多張工單。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Entity.MaintiFlow
{
    /// <summary>
    /// 維護工單。
    /// </summary>
    public class WorkOrderEntity : IEquatable<WorkOrderEntity>
    {
        /// <summary>
        /// 維護工單主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        #region 工單資料

        /// <summary>
        /// 維護工單編號（唯一）。
        /// </summary>
        [Index(IsUnique = true)]
        public string WorkOrderNo { get; set; }

        /// <summary>
        /// 維護狀態。
        /// </summary>
        public FlowStatus Status { get; set; }

        /// <summary>
        /// 機台。
        /// </summary>
        public virtual MachineEntity Machine { get; set; }

        /// <summary>
        /// 機台外鍵。
        /// </summary>
        [Index]
        public int? MachineId { get; set; }

        /// <summary>
        /// 工站。
        /// </summary>
        public virtual WorkstationEntity Workstation { get; set; }

        /// <summary>
        /// 工站外鍵。
        /// </summary>
        [Index]
        public int? WorkstationId { get; set; }

        /// <summary>
        /// 建檔人員。
        /// </summary>
        public virtual EmployeeEntity Creator { get; set; }

        /// <summary>
        /// 建檔人員外鍵。
        /// </summary>
        public int CreatorId { get; set; }

        /// <summary>
        /// 建檔日期。
        /// </summary>
        public DateTime CreationDateTime { get; set; }

        #endregion

        #region 維護部門

        /// <summary>
        /// 維護單位。
        /// </summary>
        public virtual MaintenanceUnitEntity MaintenanceUnit { get; set; }

        /// <summary>
        /// 維護單位外鍵。
        /// </summary>
        public int? MaintenanceUnitId { get; set; }

        /// <summary>
        /// 接單時間。
        /// </summary>
        public DateTime? AcceptedTime { get; set; }

        #endregion

        #region 維護申請資訊

        /// <summary>
        /// 需求單位。
        /// </summary>
        public virtual DepartmentEntity RequestingUnit { get; set; }

        /// <summary>
        /// 需求單位外鍵。
        /// </summary>
        public int? RequestingUnitId { get; set; }

        #endregion

        #region 維護內容記錄

        /// <summary>
        /// 維護內容清單。
        /// </summary>
        /// <remarks>
        /// 一張工單可包含多筆維護內容，表示該工單歷經多次維護處理。
        /// 若需取得維護次數，請使用 MaintenanceRecords.Count。
        /// </remarks>
        public virtual ICollection<MaintenanceRecordEntity> MaintenanceRecords { get; set; } = new HashSet<MaintenanceRecordEntity>();

        #endregion

        #region 其他

        /// <summary>
        /// 責任歸屬。
        /// </summary>
        [MaxLength(50)]
        public string Responsible { get; set; }

        #endregion

        #region IEquatable<WorkOrderEntity>

        public bool Equals(WorkOrderEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as WorkOrderEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(WorkOrderEntity left, WorkOrderEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(WorkOrderEntity left, WorkOrderEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
