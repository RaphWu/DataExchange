/*
���u�P�s�դ������A�Ω�إ� EmployeeEntity �P GroupEntity ���h��h���p�C
*/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// ���u�P�s�����p�]�h��h�������^�C
    /// </summary>
    public class EmployeeGroup : IEquatable<EmployeeGroup>
    {
        /// <summary>
        /// ���u�D��C
        /// </summary>
        [Key, Column(Order = 0)]
        public int EmployeeId { get; set; }

        /// <summary>
        /// �s�եD��C
        /// </summary>
        [Key, Column(Order = 1)]
        public int GroupId { get; set; }

        /// <summary>
        /// ���u�C
        /// </summary>
        public virtual EmployeeEntity Employee { get; set; }

        /// <summary>
        /// �s�աC
        /// </summary>
        public virtual GroupEntity Group { get; set; }

        #region IEquatable<EmployeeGroup>

        public bool Equals(EmployeeGroup other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return EmployeeId == other.EmployeeId && GroupId == other.GroupId;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as EmployeeGroup);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (EmployeeId * 397) ^ GroupId;
            }
        }

        public static bool operator ==(EmployeeGroup left, EmployeeGroup right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(EmployeeGroup left, EmployeeGroup right)
        {
            return !(left == right);
        }

        #endregion
    }
}
