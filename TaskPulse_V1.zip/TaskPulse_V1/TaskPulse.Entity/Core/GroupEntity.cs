﻿/*
群組實體。
群組原本是要為 EmployeeEntity 做延伸分類用並套用權限，
但課長覺得不需要，便將群組做為 MachineEntity 的分組使用，不套用權限，
人員分組的功能仍保留，可以成為兩種分類用途。

關聯設定：
PermissionEntity: 透過 GroupPermission 中介表建立多對多關聯。
EmployeeEntity: 透過 EmployeeGroup 中介表建立多對多關聯。
MachineEntity: 透過 MachineGroup 中介表建立多對多關聯，表示群組包含的機台。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 使用者群組。
    /// </summary>
    public class GroupEntity : IEquatable<GroupEntity>
    {
        /// <summary>
        /// 群組主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 群組名稱。
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 群組與員工關聯（透過中介表）。
        /// </summary>
        public virtual ICollection<EmployeeGroup> EmployeeGroups { get; set; } = new HashSet<EmployeeGroup>();

        /// <summary>
        /// 群組與權限關聯（透過中介表）。
        /// </summary>
        public virtual ICollection<GroupPermission> GroupPermissions { get; set; } = new HashSet<GroupPermission>();

        /// <summary>
        /// 群組與機台關聯（透過中介表）。
        /// </summary>
        public virtual ICollection<MachineGroup> MachineGroups { get; set; } = new HashSet<MachineGroup>();

        #region IEquatable<GroupEntity>

        public bool Equals(GroupEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as GroupEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(GroupEntity left, GroupEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(GroupEntity left, GroupEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
