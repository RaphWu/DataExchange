﻿/*
員工職稱實體類別。

關聯設定：
EmployeeEntity: 一對多關聯，表示多個員工可以擁有相同的職稱。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 職稱。
    /// </summary>
    public class JobTitleEntity : IEquatable<JobTitleEntity>
    {
        /// <summary>
        /// 職稱主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 職稱名稱。
        /// </summary>
        public string JobTitleName { get; set; }

        /// <summary>
        /// 擁有此職稱的員工清單。
        /// </summary>
        public virtual ICollection<EmployeeEntity> Employees { get; set; } = new HashSet<EmployeeEntity>();

        #region IEquatable<JobTitleEntity>

        public bool Equals(JobTitleEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as JobTitleEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(JobTitleEntity left, JobTitleEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(JobTitleEntity left, JobTitleEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
