﻿/*
機台分類實體類別。

關聯設定：
MachineTypeEntity: 一對多關聯，表示一個分類可以包含多個設備別。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機台分類。  
    /// </summary>
    public class MachineCategoryEntity : IEquatable<MachineCategoryEntity>
    {
        /// <summary>
        /// 分類主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 分類名稱。
        /// </summary>
        public string CategoryName { get; set; }

        /// <summary>
        /// 此分類下的設備別清單。
        /// </summary>
        public virtual ICollection<MachineTypeEntity> MachineTypes { get; set; } = new HashSet<MachineTypeEntity>();

        #region IEquatable<MachineCategoryEntity>

        public bool Equals(MachineCategoryEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as MachineCategoryEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(MachineCategoryEntity left, MachineCategoryEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(MachineCategoryEntity left, MachineCategoryEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
