﻿/*
機台型號實體類別，表示機台型號，比如半自動生產設備 (MachineCategory) 下的桌上型點膠機 (MachineType) 下的 DT-200T (ModelName)。

關聯設定：
MachineEntity: 一對多關聯，表示多個機台可以擁有相同的機台名稱。
MachineTypeEntity: 多對一關聯，表示多個機台名稱可以屬於同一設備別，當設備別被刪除時，導航屬性設為 null。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機台型號。
    /// </summary>
    public class MachineNameEntity : IEquatable<MachineNameEntity>
    {
        /// <summary>
        /// 機台型號主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 機台型號名稱。
        /// </summary>
        public string ModelName { get; set; }

        /// <summary>
        /// 所屬設備別。
        /// </summary>
        public virtual MachineTypeEntity MachineType { get; set; }

        /// <summary>
        /// 設備別外鍵。
        /// </summary>
        public int? TypeId { get; set; }

        /// <summary>
        /// 擁有此型號的機台清單。
        /// </summary>
        public virtual ICollection<MachineEntity> Machines { get; set; } = new HashSet<MachineEntity>();

        #region IEquatable<MachineNameEntity>

        public bool Equals(MachineNameEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as MachineNameEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(MachineNameEntity left, MachineNameEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(MachineNameEntity left, MachineNameEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
