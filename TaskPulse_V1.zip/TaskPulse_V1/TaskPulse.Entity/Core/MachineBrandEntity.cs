﻿/*
機台廠牌實體類別。

關聯設定：
MachineEntity: 一對多關聯，表示多個機台可以屬於相同的廠牌。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 廠牌。
    /// </summary>
    public class MachineBrandEntity : IEquatable<MachineBrandEntity>
    {
        /// <summary>
        /// 廠牌主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 是否啟用。
        /// </summary>
        public bool IsActive { get; set; } = true;

        /// <summary>
        /// 廠牌名稱。
        /// </summary>
        public string BrandName { get; set; }

        /// <summary>
        /// 擁有此廠牌的機台清單。
        /// </summary>
        public virtual ICollection<MachineEntity> Machines { get; set; } = new HashSet<MachineEntity>();

        #region IEquatable<MachineBrandEntity>

        public bool Equals(MachineBrandEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as MachineBrandEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(MachineBrandEntity left, MachineBrandEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(MachineBrandEntity left, MachineBrandEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
