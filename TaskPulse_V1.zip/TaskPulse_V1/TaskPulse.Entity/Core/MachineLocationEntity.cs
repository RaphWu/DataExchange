﻿/*
機台位置實體。

關聯設定：
MachineEntity: 一對多關聯，表示多個機台可以位於相同的位置。
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機台位置。
    /// </summary>
    public class MachineLocationEntity : IEquatable<MachineLocationEntity>
    {
        /// <summary>
        /// 位置主鍵。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        [Index(IsUnique = false)]
        public int OrderNo { get; set; }

        /// <summary>
        /// 位置名稱。
        /// </summary>
        public string LocationName { get; set; }

        /// <summary>
        /// 位於此處的機台清單。
        /// </summary>
        public virtual ICollection<MachineEntity> Machines { get; set; } = new HashSet<MachineEntity>();

        #region IEquatable<MachineLocationEntity>

        public bool Equals(MachineLocationEntity other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as MachineLocationEntity);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(MachineLocationEntity left, MachineLocationEntity right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(MachineLocationEntity left, MachineLocationEntity right)
        {
            return !(left == right);
        }

        #endregion
    }
}
