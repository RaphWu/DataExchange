﻿# TaskPulse Entity Module

## 介紹

TaskPulse Entity 模組是 TaskPulse 系統中的一個核心組件，負責 SQLite 資料庫實體定義，使用 Entity Framework 6 作為物件關聯對映（ORM）工具。

此命名空間只定義資料模型，並不包含任何商業邏輯或資料存取程式碼。

## NuGet 套件依賴

**重要**：System.Data.SQLite 及 System.Data.SQLite.EF6 須安裝 1.0.119 版本，因為 System.Data.SQLite.EF6 從 2.x 之後只支援 .NET Framework 4.7.1 以上版本，而 TaskPulse 目前目標框架為 .NET Framework 4.6.2。NuGet 管理員也要注意不要自動更新這些套件。

- EntityFramework 6.5.1
- System.Data.SQLite 1.0.119
	- System.Data.SQLite.EF6
	- System.Data.SQLite.Core
	- System.Data.SQLite.Linq
- SQLite.CodeFirst 1.7.0.36

Migration:
- FluentMigrator

### Fluent API 關聯檔案

- 核心實體關聯設定位於 [CoreContext](Calin.TaskPulse.Core.DB.CoreContext.cs) 中，包含：
    - [EmployeeEntity](Calin.TaskPulse.Entity.Core.EmployeeEntity.cs)、[MachineEntity](Calin.TaskPulse.Entity.Core.MachineEntity.cs)、[ModelEntity](Calin.TaskPulse.Entity.Core.ModelEntity.cs) 及所屬正規化與中介的 Entity。
    - [GroupEntity](Calin.TaskPulse.Entity.Core.GroupEntity.cs)、[PermissionEntity](Calin.TaskPulse.Entity.Core.PermissionEntity.cs) 及所屬中介的 Entity。
- 維護工單實體關聯設定位於 [MaintiFlowContext](Calin.TaskPulse.Core.DB.MaintiFlowContext.cs) 中，包含：
    - [WorkOrderEntity](Calin.TaskPulse.Entity.MaintiFlow.WorkOrderEntity.cs) 及所屬正規化與中介的 Entity：

## ER 圖

- 關聯箭頭說明：
	- ||--|{：一對多 (1..*)
	- ||--o{：一對多 (0..*)
	- }o--o{：多對多（需中介 Entity）
- 次要實體省略標示 PK、FK，僅顯示主要實體欄位與關聯。
- PK 名稱皆為 Id，FK 命名規則為 主要實體名稱 + Id。
- 顏色標示說明：
	- 橘色框線：主要 Entity
	- 紫色框線：中介 Entity
	- 綠色框線：外關聯的主要 Entity

### EmployeeEntity (不含群組與權限)

```mermaid
erDiagram

DepartmentEntity ||--o{ EmployeeEntity : "所屬部門"
JobTitleEntity ||--o{ EmployeeEntity : "職稱"
EmployeeEntity }|--|| EmployeeStatusEntity : "員工在職狀態"
EmployeeEntity }o--o{ EmployeeCarbonCopy : "副本人員/員工"

DepartmentEntity ||--o{ WorkOrderEntity : "需求單位"
EmployeeEntity }o--|| WorkOrderEntity : "建檔人員"
EmployeeEntity }o--|| MaintenanceRecordEntity : "回覆人員"
MaintenanceRecordEngineer }o--o{ EmployeeEntity : "員工"

EmployeeEntity {
 int EmployeeId PK
 int DepartmentId FK "DepartmentEntity, nullable"
 int JobTitleId FK "JobTitleEntity, nullable"
 int StatusId FK "EmployeeStatusEntity"
 EmployeeCarbonCopy CarbonCopyRelations
}

EmployeeCarbonCopy {
 int SourceEmployeeId PK, FK
 int TargetEmployeeId PK, FK
}

style EmployeeEntity stroke:#F90,stroke-width:2px
style EmployeeCarbonCopy stroke:#639,stroke-width:2px
style MaintenanceRecordEngineer stroke:#639,stroke-width:2px
style WorkOrderEntity stroke:#396,stroke-width:2px
style MaintenanceRecordEntity stroke:#396,stroke-width:2px

```

### ModelEntity

```mermaid
erDiagram

ModelEntity }o--|| ModelStatusEntity : "機種狀態"
ModelEntity ||--o{ WorkstationEntity : "工站"

MachineEntity }o--o{ MachineWorkstation : "機台"
MachineWorkstation }o--o{ WorkstationEntity : "工站"
WorkstationEntity ||--o{ WorkOrderEntity : "工站"

ModelEntity {
 int Id PK
 int ModelStatusId FK
 WorkstationEntity Workstations
}

WorkstationEntity {
 int Id PK
 int ModelId FK
}

MachineWorkstation {
 int MachineId PK, FK
 int WorkstationId PK, FK
}

style ModelEntity stroke:#F90,stroke-width:2px
style WorkstationEntity stroke:#F90,stroke-width:2px
style MachineEntity stroke:#396,stroke-width:2px
style WorkOrderEntity stroke:#396,stroke-width:2px

```

### MachineEntity (不含群組)

```mermaid
erDiagram

MachineBrandEntity ||--o{ MachineEntity : "廠牌"
MachineLocationEntity ||--o{ MachineEntity : "位置"
MachineIssueCategoryEntity ||--o{ MachineEntity : "維修分類"

MachineEntity }o--|| MachineNameEntity : "型號"
MachineNameEntity }o--|| MachineTypeEntity : "設備別"
MachineTypeEntity }o--|| MachineCategoryEntity : "分類"
MachineEntity }o--|| MachineTypeEntity : "設備別" 
MachineEntity }o--|| MachineConditionEntity : "狀態" 

MachineEntity }o--o{ MachineWorkstation : "機台"
MachineWorkstation }o--o{ WorkstationEntity : "工站"

MachineEntity ||--o{ WorkOrderEntity : "機台"

MachineEntity {
 int Id PK
 int MachineNameId FK "MachineNameEntity"
 int MachineTypeId FK "MachineTypeEntity"
 int ConditionId FK "MachineConditionEntity, nullable"
 int BrandId FK "MachineBrandEntity"
 int LocationId FK "MachineLocationEntity"
 int IssueCategoryId FK "MachineIssueCategoryEntity"
 MachineWorkstation MachineWorkstations
}

MachineWorkstation {
 int MachineId PK, FK
 int WorkstationId PK, FK
}

style MachineEntity stroke:#F90,stroke-width:2px
style WorkstationEntity stroke:#396,stroke-width:2px
style WorkOrderEntity stroke:#396,stroke-width:2px
style MachineWorkstation stroke:#639,stroke-width:2px

```

### WorkOrderEntity

```mermaid
erDiagram

MachineEntity ||--o{ WorkOrderEntity : "機台"
WorkstationEntity ||--o{ WorkOrderEntity : "工站"
EmployeeEntity }o--|| WorkOrderEntity : "建檔人員"
MaintenanceUnitEntity ||--o{ WorkOrderEntity : "維護單位"
DepartmentEntity ||--o{ WorkOrderEntity : "需求單位"
WorkOrderEntity ||--o{ MaintenanceRecordEntity : "維護記錄"

MaintenanceRecordEntity ||--o{ MaintiFlowIssueCategoryEntity : "維護類型"
MaintenanceRecordEntity ||--o{ RepairPeriodEntity : "維修期間"

MaintenanceRecordEntity }o--o{ MaintenanceRecordEngineer : "工程師"
MaintenanceRecordEngineer }o--o{ EmployeeEntity : "員工"

EmployeeEntity }o--|| MaintenanceRecordEntity : "回覆人員"


WorkOrderEntity {
 int Id PK
 int MachineId FK "MachineEntity, unllable"
 int WorkstationId FK "WorkstationEntity, unllable"
 int CreatorId FK "EmployeeEntity"
 int MaintenanceUnitId FK "MaintenanceUnitEntity, unllable"
 int RequestingUnitId FK "DepartmentEntity, unllable"
 MaintenanceRecordEntity MaintenanceRecords
}

MaintenanceRecordEntity {
 int Id PK
 int WorkOrderId FK "WorkOrderEntity"
 int IssueCategoryId FK "MaintiFlowIssueCategoryEntity, unllable"
 int FeedbackEmployeeId FK "EmployeeEntity, unllable"
 MaintenanceRecordEngineer MaintenanceRecordEngineers
 RepairPeriodEntity RepairPeriods
}

MaintenanceRecordEngineer {
 int MaintenanceRecordId PK, FK
 int EmployeeId PK, FK
}

style WorkOrderEntity stroke:#F90,stroke-width:2px
style MaintenanceRecordEngineer stroke:#639,stroke-width:2px
style MachineEntity stroke:#396,stroke-width:2px
style EmployeeEntity stroke:#396,stroke-width:2px
style WorkstationEntity stroke:#396,stroke-width:2px
style DepartmentEntity stroke:#396,stroke-width:2px

```

### GroupEntity、PermissionEntity

```mermaid
erDiagram

GroupEntity }o--o{ MachineGroup : "機台"
MachineGroup }o--o{ MachineEntity : "機台"

GroupEntity }o--o{ EmployeeGroup : "員工"
EmployeeGroup }o--o{ EmployeeEntity : "員工"

GroupEntity }o--o{ GroupPermission : "權限"
PermissionEntity }o--o{ GroupPermission : "群組"

PermissionEntity }o--o{ EmployeePermission : "員工"
EmployeePermission }o--o{ EmployeeEntity : "員工"

PermissionEntity }o--o{ DepartmentPermission : "部門"
DepartmentPermission }o--o{ DepartmentEntity : "部門"

style GroupEntity stroke:#F90,stroke-width:2px
style PermissionEntity stroke:#F90,stroke-width:2px
style EmployeeGroup stroke:#639,stroke-width:2px
style MachineGroup stroke:#639,stroke-width:2px
style EmployeePermission stroke:#639,stroke-width:2px
style GroupPermission stroke:#639,stroke-width:2px
style DepartmentPermission stroke:#639,stroke-width:2px
style EmployeeEntity stroke:#396,stroke-width:2px
style DepartmentEntity stroke:#396,stroke-width:2px
style MachineEntity stroke:#396,stroke-width:2px

```
