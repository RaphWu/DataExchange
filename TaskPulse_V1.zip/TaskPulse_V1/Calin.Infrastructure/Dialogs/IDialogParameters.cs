namespace Calin.Infrastructure.Dialogs
{
    /// <summary>
    /// ��ܮذѼƤ����C
    /// </summary>
    /// <remarks>
    /// <para>�䴩 Key-Value ���Ѽƶǻ��A�i�Ω��ܮ���ܮɶǻ���ƻP������^���G�C</para>
    /// <para>
    /// �ϥνd�ҡG
    /// <code>
    /// // �إ߰Ѽ�
    /// var parameters = new DialogParameters();
    /// parameters.Add("Title", "�T�{�R��");
    /// parameters.Add("Message", "�T�w�n�R�������ضܡH");
    /// parameters.Add("ItemId", 123);
    /// 
    /// // ���o�Ѽ�
    /// var title = parameters.GetValue&lt;string&gt;("Title");
    /// var itemId = parameters.GetValue&lt;int&gt;("ItemId");
    /// </code>
    /// </para>
    /// </remarks>
    public interface IDialogParameters
    {
        /// <summary>
        /// �s�W�ѼơC
        /// </summary>
        /// <param name="key">�Ѽ���C</param>
        /// <param name="value">�ѼƭȡC</param>
        void Add(string key, object value);

        /// <summary>
        /// ���o�ѼƭȡC
        /// </summary>
        /// <typeparam name="T">�Ѽƫ��O�C</typeparam>
        /// <param name="key">�Ѽ���C</param>
        /// <returns>�ѼƭȡA�Y���s�b�h�Ǧ^���O�w�]�ȡC</returns>
        T GetValue<T>(string key);

        /// <summary>
        /// ���ը��o�ѼƭȡC
        /// </summary>
        /// <typeparam name="T">�Ѽƫ��O�C</typeparam>
        /// <param name="key">�Ѽ���C</param>
        /// <param name="value">�ѼƭȡC</param>
        /// <returns>�Y�ѼƦs�b�h�Ǧ^ true�C</returns>
        bool TryGetValue<T>(string key, out T value);

        /// <summary>
        /// �ˬd�ѼƬO�_�s�b�C
        /// </summary>
        /// <param name="key">�Ѽ���C</param>
        /// <returns>�Y�ѼƦs�b�h�Ǧ^ true�C</returns>
        bool ContainsKey(string key);

        /// <summary>
        /// ���o�Ҧ��Ѽ���C
        /// </summary>
        IEnumerable<string> Keys { get; }

        /// <summary>
        /// ���o�ѼƼƶq�C
        /// </summary>
        int Count { get; }
    }

    /// <summary>
    /// ��ܮذѼƹ�@�C
    /// </summary>
    public class DialogParameters : IDialogParameters
    {
        private readonly Dictionary<string, object> _parameters = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// ��l�ƹ�ܮذѼơC
        /// </summary>
        public DialogParameters()
        {
        }

        /// <summary>
        /// �ϥβ{���r���l�ƹ�ܮذѼơC
        /// </summary>
        /// <param name="parameters">�ѼƦr��C</param>
        public DialogParameters(IDictionary<string, object> parameters)
        {
            if (parameters != null)
            {
                foreach (var kvp in parameters)
                {
                    _parameters[kvp.Key] = kvp.Value;
                }
            }
        }

        /// <inheritdoc />
        public void Add(string key, object value)
        {
            if (string.IsNullOrEmpty(key))
                throw new ArgumentNullException(nameof(key));

            _parameters[key] = value;
        }

        /// <inheritdoc />
        public T GetValue<T>(string key)
        {
            if (TryGetValue<T>(key, out var value))
            {
                return value;
            }

            return default(T);
        }

        /// <inheritdoc />
        public bool TryGetValue<T>(string key, out T value)
        {
            value = default(T);

            if (string.IsNullOrEmpty(key))
                return false;

            if (!_parameters.TryGetValue(key, out var obj))
                return false;

            if (obj == null)
            {
                value = default(T);
                return true;
            }

            if (obj is T typedValue)
            {
                value = typedValue;
                return true;
            }

            try
            {
                value = (T)Convert.ChangeType(obj, typeof(T));
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <inheritdoc />
        public bool ContainsKey(string key)
        {
            if (string.IsNullOrEmpty(key))
                return false;

            return _parameters.ContainsKey(key);
        }

        /// <inheritdoc />
        public IEnumerable<string> Keys => _parameters.Keys;

        /// <inheritdoc />
        public int Count => _parameters.Count;

        /// <summary>
        /// ���o�γ]�w�ѼƭȡC
        /// </summary>
        /// <param name="key">�Ѽ���C</param>
        /// <returns>�ѼƭȡC</returns>
        public object this[string key]
        {
            get => _parameters.TryGetValue(key, out var value) ? value : null;
            set => _parameters[key] = value;
        }
    }
}
