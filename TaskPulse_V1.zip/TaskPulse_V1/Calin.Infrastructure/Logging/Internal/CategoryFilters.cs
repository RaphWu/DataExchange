using Serilog.Core;
using Serilog.Events;

namespace Calin.Infrastructure.Logging.Internal
{
    /// <summary>
    /// �ھ� Category �ݩʥ]�t�S�w������ Filter�C
    /// </summary>
    /// <remarks>
    /// �Ȩ� Logging Infrastructure �����ϥΡC
    /// </remarks>
    internal sealed class CategoryIncludeFilter : ILogEventFilter
    {
        private readonly string[] _categories;

        /// <summary>
        /// ��l�� CategoryIncludeFilter�C
        /// </summary>
        /// <param name="categories">�n�]�t�������C</param>
        public CategoryIncludeFilter(params string[] categories)
        {
            _categories = categories ?? throw new ArgumentNullException(nameof(categories));
        }

        /// <summary>
        /// �P�_��x�ƥ�O�_���ӳQ�O���C
        /// </summary>
        public bool IsEnabled(LogEvent logEvent)
        {
            if (logEvent == null) return false;

            if (!logEvent.Properties.TryGetValue("Category", out var categoryValue))
            {
                return false;
            }

            // ���T�B�z ScalarValue�A���ϥ� ToString()
            if (categoryValue is ScalarValue scalarValue && scalarValue.Value is string category)
            {
                foreach (var includedCategory in _categories)
                {
                    if (string.Equals(category, includedCategory, StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }

    /// <summary>
    /// �ھ� Category �ݩʱư��S�w������ Filter�C
    /// </summary>
    /// <remarks>
    /// �Ȩ� Logging Infrastructure �����ϥΡC
    /// </remarks>
    internal sealed class CategoryExcludeFilter : ILogEventFilter
    {
        private readonly string[] _excludedCategories;

        /// <summary>
        /// ��l�� CategoryExcludeFilter�C
        /// </summary>
        /// <param name="excludedCategories">�n�ư��������C</param>
        public CategoryExcludeFilter(params string[] excludedCategories)
        {
            _excludedCategories = excludedCategories ?? throw new ArgumentNullException(nameof(excludedCategories));
        }

        /// <summary>
        /// �P�_��x�ƥ�O�_���ӳQ�O���C
        /// </summary>
        public bool IsEnabled(LogEvent logEvent)
        {
            if (logEvent == null) return false;

            if (!logEvent.Properties.TryGetValue("Category", out var categoryValue))
            {
                // �S�� Category �ݩʡA���\�O��
                return true;
            }

            // ���T�B�z ScalarValue�A���ϥ� ToString()
            if (categoryValue is ScalarValue scalarValue && scalarValue.Value is string category)
            {
                foreach (var excludedCategory in _excludedCategories)
                {
                    if (string.Equals(category, excludedCategory, StringComparison.OrdinalIgnoreCase))
                    {
                        return false;
                    }
                }
            }

            return true;
        }
    }
}
