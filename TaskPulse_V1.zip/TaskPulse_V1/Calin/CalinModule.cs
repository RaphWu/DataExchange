using Autofac;
using Calin.Framework.Coordination;
using Calin.Framework.Dialogs;
using Calin.Framework.Logging;
using Calin.Framework.Navigation;

namespace Calin
{
    public class CalinModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterModule<LoggingModule>();
            builder.RegisterModule<NavigationModule>();
            builder.RegisterModule<DialogModule>();
            builder.RegisterModule<CoordinationModule>();
        }
    }
}
