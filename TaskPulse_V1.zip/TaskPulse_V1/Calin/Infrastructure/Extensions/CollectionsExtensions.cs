﻿using System.Data;
using System.Reflection;

namespace Calin.Infrastructure.Extensions
{
    public static class CollectionsExtensions
    {
        public static DataTable ToDataTable<TSource>(this IList<TSource> data)
        {
            DataTable dataTable = new DataTable(typeof(TSource).Name);
            PropertyInfo[] properties = typeof(TSource).GetProperties(BindingFlags.Instance | BindingFlags.Public);
            PropertyInfo[] array = properties;
            foreach (PropertyInfo propertyInfo in array)
            {
                dataTable.Columns.Add(propertyInfo.Name, Nullable.GetUnderlyingType(propertyInfo.PropertyType) ?? propertyInfo.PropertyType);
            }

            foreach (TSource datum in data)
            {
                object[] array2 = new object[properties.Length];
                for (int j = 0; j < properties.Length; j++)
                {
                    array2[j] = properties[j].GetValue(datum, null);
                }

                dataTable.Rows.Add(array2);
            }

            return dataTable;
        }

        public static List<T> ToList<T>(this DataTable dataTable) where T : new()
        {
            var properties = typeof(T).GetProperties();
            var list = new List<T>();
            foreach (DataRow row in dataTable.Rows)
            {
                var obj = new T();
                foreach (var prop in properties)
                {
                    if (dataTable.Columns.Contains(prop.Name) && row[prop.Name] != DBNull.Value)
                    {
                        prop.SetValue(obj, row[prop.Name]);
                    }
                }
                list.Add(obj);
            }
            return list;
        }
    }
}