namespace Calin.Framework.Dialogs
{
    /// <summary>
    /// WinForms ��ܮص�����@�C
    /// </summary>
    public class WinFormsDialogWindow : Form, IDialogWindow
    {
        private IDialogAware _dialogContent;
        private bool _isDisposed;

        /// <summary>
        /// ��l�� WinForms ��ܮص����C
        /// </summary>
        public WinFormsDialogWindow()
        {
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
        }

        /// <inheritdoc />
        public object Content
        {
            get => _dialogContent;
            set
            {
                _dialogContent = value as IDialogAware;

                if (value is Control control)
                {
                    // �M���{�����
                    Controls.Clear();

                    // �]�w���
                    control.Dock = DockStyle.Fill;
                    Controls.Add(control);

                    // �վ�����j�p
                    ClientSize = control.Size;
                }
            }
        }

        /// <inheritdoc />
        public string Title
        {
            get => Text;
            set => Text = value;
        }

        /// <inheritdoc />
        public IDialogResult Result { get; set; }

        /// <inheritdoc />
        object IDialogWindow.Owner
        {
            get => Owner;
            set
            {
                if (value is Form form)
                {
                    Owner = form;
                }
            }
        }

        /// <inheritdoc />
        IDialogResult IDialogWindow.ShowDialog()
        {
            base.ShowDialog();
            return Result ?? new DialogResult(ButtonResult.None);
        }

        /// <inheritdoc />
        public new void Show()
        {
            base.Show();
        }

        /// <inheritdoc />
        event EventHandler IDialogWindow.Closed
        {
            add => FormClosed += (s, e) => value?.Invoke(s, e);
            remove { }
        }

        /// <inheritdoc />
        protected override void Dispose(bool disposing)
        {
            if (!_isDisposed)
            {
                if (disposing)
                {
                    _dialogContent = null;
                }
                _isDisposed = true;
            }
            base.Dispose(disposing);
        }
    }

    /// <summary>
    /// WinForms ��ܮص����u�t�C
    /// </summary>
    public class WinFormsDialogWindowFactory : IDialogWindowFactory
    {
        /// <inheritdoc />
        public IDialogWindow CreateDialogWindow()
        {
            return new WinFormsDialogWindow();
        }
    }
}
