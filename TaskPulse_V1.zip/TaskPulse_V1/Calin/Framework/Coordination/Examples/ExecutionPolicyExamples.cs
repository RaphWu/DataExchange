#if DEBUG || OFFLINE

using Autofac;
using Calin.Framework.Coordination.Policies;

namespace Calin.Framework.Coordination.Examples
{
    /*
     * ====================================================================
     * ���浦���ϥνd��
     * ====================================================================
     * 
     * ���ɮץܽd�p��ϥΤ��P�����浦���]ExecutionPolicy�^�ӱ�����Ȫ�����覡�C
     * �]�t�G���ǰ���B�������B���հ���B�O�ɱ���������ϥνd�ҡC
     * 
     * �`�N�G�o�Ȭ��d�ҡA�u��~���޿�Щ�b�ϥΪ̱M�פ��C
     * 
     * �ϥΨB�J�G
     * 1. ��ܩΦۭq���浦��
     * 2. �b Autofac �e�������U���浦��
     * 3. ��ժ̱N�۰ʨϥε��U�����浦��
     */

    #region 1. �w�q�ШD�P TaskKey

    /// <summary>
    /// ��ƳB�z�ШD�d�ҡC
    /// </summary>
    public class DataProcessingRequest : CoordinationRequest
    {
        public int DataCount { get; }
        public bool HighPriority { get; }

        public DataProcessingRequest(int dataCount, bool highPriority = false)
            : base("DataProcessing")
        {
            DataCount = dataCount;
            HighPriority = highPriority;
        }
    }

    /// <summary>
    /// ��ƳB�z���Ȫ� TaskKey �w�q�C
    /// </summary>
    public static class DataProcessingTaskKeys
    {
        public static readonly TaskKey ValidateData = new TaskKey("DataProcessing.Validate");
        public static readonly TaskKey FetchFromDatabase = new TaskKey("DataProcessing.Fetch");
        public static readonly TaskKey TransformData = new TaskKey("DataProcessing.Transform");
        public static readonly TaskKey SaveToCache = new TaskKey("DataProcessing.SaveCache");
        public static readonly TaskKey NotifySubscribers = new TaskKey("DataProcessing.Notify");
    }

    #endregion

    #region 2. ��@ Task Handler

    /// <summary>
    /// ���Ҹ�� Handler�C
    /// </summary>
    public class ValidateDataHandler : TaskHandlerBase<DataProcessingRequest>
    {
        public override TaskKey TaskKey => DataProcessingTaskKeys.ValidateData;

        protected override async Task ExecuteAsync(ITaskExecutionContext context, DataProcessingRequest request)
        {
            // �������ҳB�z
            await Task.Delay(100);
        }
    }

    /// <summary>
    /// �q��Ʈw�^����� Handler�C
    /// </summary>
    public class FetchFromDatabaseHandler : TaskHandlerBase<DataProcessingRequest>
    {
        public override TaskKey TaskKey => DataProcessingTaskKeys.FetchFromDatabase;

        protected override async Task ExecuteAsync(ITaskExecutionContext context, DataProcessingRequest request)
        {
            // ������Ʈw�d��
            await Task.Delay(200);
        }
    }

    /// <summary>
    /// �ഫ��� Handler�C
    /// </summary>
    public class TransformDataHandler : TaskHandlerBase<DataProcessingRequest>
    {
        public override TaskKey TaskKey => DataProcessingTaskKeys.TransformData;

        protected override async Task ExecuteAsync(ITaskExecutionContext context, DataProcessingRequest request)
        {
            // ��������ഫ
            await Task.Delay(150);
        }
    }

    /// <summary>
    /// �x�s��֨� Handler�C
    /// </summary>
    public class SaveToCacheHandler : TaskHandlerBase<DataProcessingRequest>
    {
        public override TaskKey TaskKey => DataProcessingTaskKeys.SaveToCache;

        protected override async Task ExecuteAsync(ITaskExecutionContext context, DataProcessingRequest request)
        {
            // �����֨��x�s
            await Task.Delay(50);
        }
    }

    /// <summary>
    /// �q���q�\�� Handler�C
    /// </summary>
    public class NotifySubscribersHandler : TaskHandlerBase<DataProcessingRequest>
    {
        public override TaskKey TaskKey => DataProcessingTaskKeys.NotifySubscribers;

        protected override async Task ExecuteAsync(ITaskExecutionContext context, DataProcessingRequest request)
        {
            // �����q���o�e
            await Task.Delay(80);
        }
    }

    #endregion

    #region 3. ��@�M�g����

    /// <summary>
    /// ��ƳB�z���M�g�����C
    /// </summary>
    public class DataProcessingMappingStrategy : TaskMappingStrategyBase<DataProcessingRequest>
    {
        protected override IEnumerable<TaskKey> GetRequiredTasks(DataProcessingRequest request)
        {
            // �Ҧ��ШD���ݭn���ҩM�^��
            yield return DataProcessingTaskKeys.ValidateData;
            yield return DataProcessingTaskKeys.FetchFromDatabase;
            yield return DataProcessingTaskKeys.TransformData;

            // �p�G�O���u���šA�h�ݭn�֨��M�q��
            if (request.HighPriority)
            {
                yield return DataProcessingTaskKeys.SaveToCache;
                yield return DataProcessingTaskKeys.NotifySubscribers;
            }
        }
    }

    #endregion

    #region 4. ���浦���ϥνd��

    /// <summary>
    /// �d�� 1�G�ϥζ��ǰ��浦���]�w�]�^�C
    /// ���ȱN�̦�����A�A�Ω󦳨̿����Y�����ȡC
    /// </summary>
    public class SequentialPolicyModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // ���U��հ�¦�Ҳ�
            builder.RegisterModule<CoordinationModule>();

            // ���U Task Handler
            builder.RegisterTaskHandler<ValidateDataHandler>();
            builder.RegisterTaskHandler<FetchFromDatabaseHandler>();
            builder.RegisterTaskHandler<TransformDataHandler>();
            builder.RegisterTaskHandler<SaveToCacheHandler>();
            builder.RegisterTaskHandler<NotifySubscribersHandler>();

            // ���U�M�g����
            builder.RegisterTaskMappingStrategy<DataProcessingMappingStrategy>();

            // ���U���ǰ��浦��
            builder.RegisterType<SequentialExecutionPolicy>()
                   .As<IExecutionPolicy>()
                   .SingleInstance();
        }
    }

    /// <summary>
    /// �d�� 2�G�ϥΥ�����浦���]�L����^�C
    /// �Ҧ����ȱN�P�ɰ���A�A�Ω󤬬ۿW�ߪ����ȡC
    /// </summary>
    public class ParallelPolicyModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // ���U��հ�¦�Ҳ�
            builder.RegisterModule<CoordinationModule>();

            // ���U Task Handler
            builder.RegisterTaskHandler<ValidateDataHandler>();
            builder.RegisterTaskHandler<FetchFromDatabaseHandler>();
            builder.RegisterTaskHandler<TransformDataHandler>();
            builder.RegisterTaskHandler<SaveToCacheHandler>();
            builder.RegisterTaskHandler<NotifySubscribersHandler>();

            // ���U�M�g����
            builder.RegisterTaskMappingStrategy<DataProcessingMappingStrategy>();

            // ���U������浦���]�L����^
            builder.RegisterType<ParallelExecutionPolicy>()
                   .As<IExecutionPolicy>()
                   .WithParameter("maxDegreeOfParallelism", 0)
                   .SingleInstance();
        }
    }

    /// <summary>
    /// �d�� 3�G�ϥΥ�����浦���]����̤j����ס^�C
    /// �̦h�P�ɰ��� 3 �ӥ��ȡA�קK�귽�L�׮��ӡC
    /// </summary>
    public class ThrottledParallelPolicyModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // ���U��հ�¦�Ҳ�
            builder.RegisterModule<CoordinationModule>();

            // ���U Task Handler
            builder.RegisterTaskHandler<ValidateDataHandler>();
            builder.RegisterTaskHandler<FetchFromDatabaseHandler>();
            builder.RegisterTaskHandler<TransformDataHandler>();
            builder.RegisterTaskHandler<SaveToCacheHandler>();
            builder.RegisterTaskHandler<NotifySubscribersHandler>();

            // ���U�M�g����
            builder.RegisterTaskMappingStrategy<DataProcessingMappingStrategy>();

            // ���U������浦���]�̤j����׬� 3�^
            builder.RegisterType<ParallelExecutionPolicy>()
                   .As<IExecutionPolicy>()
                   .WithParameter("maxDegreeOfParallelism", 3)
                   .SingleInstance();
        }
    }

    /// <summary>
    /// �d�� 4�G�ϥέ��հ��浦���C
    /// ���ȥ��Ѯɦ۰ʭ��աA�A�Ω�i��X�{�Ȯɩʿ��~�����ȡC
    /// </summary>
    public class RetryPolicyModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // ���U��հ�¦�Ҳ�
            builder.RegisterModule<CoordinationModule>();

            // ���U Task Handler
            builder.RegisterTaskHandler<ValidateDataHandler>();
            builder.RegisterTaskHandler<FetchFromDatabaseHandler>();
            builder.RegisterTaskHandler<TransformDataHandler>();
            builder.RegisterTaskHandler<SaveToCacheHandler>();
            builder.RegisterTaskHandler<NotifySubscribersHandler>();

            // ���U�M�g����
            builder.RegisterTaskMappingStrategy<DataProcessingMappingStrategy>();

            // ���U���հ��浦���]�̦h���� 3 ���A�C�����j 500ms�^
            builder.RegisterType<RetryExecutionPolicy>()
                   .As<IExecutionPolicy>()
                   .WithParameter("maxRetries", 3)
                   .WithParameter("retryDelay", TimeSpan.FromMilliseconds(500))
                   .SingleInstance();
        }
    }

    /// <summary>
    /// �d�� 5�G�ϥιO�ɰ��浦���C
    /// ������Ȱ���ɶ��A�קK���ɶ�����C
    /// </summary>
    public class TimeoutPolicyModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // ���U��հ�¦�Ҳ�
            builder.RegisterModule<CoordinationModule>();

            // ���U Task Handler
            builder.RegisterTaskHandler<ValidateDataHandler>();
            builder.RegisterTaskHandler<FetchFromDatabaseHandler>();
            builder.RegisterTaskHandler<TransformDataHandler>();
            builder.RegisterTaskHandler<SaveToCacheHandler>();
            builder.RegisterTaskHandler<NotifySubscribersHandler>();

            // ���U�M�g����
            builder.RegisterTaskMappingStrategy<DataProcessingMappingStrategy>();

            // ���U�O�ɰ��浦���]�C�ӥ��ȳ̦h���� 5 ���^
            builder.RegisterType<TimeoutExecutionPolicy>()
                   .As<IExecutionPolicy>()
                   .WithParameter("timeout", TimeSpan.FromSeconds(5))
                   .SingleInstance();
        }
    }

    #endregion

    #region 5. �ϥνd��

    /// <summary>
    /// ���浦���ϥνd�ҵ{���X�C
    /// </summary>
    public static class ExecutionPolicyUsageExamples
    {
        /// <summary>
        /// �d�� 1�G�ϥζ��ǰ��浦���C
        /// </summary>
        public static async Task UseSequentialPolicyAsync()
        {
            var builder = new ContainerBuilder();
            builder.RegisterModule<SequentialPolicyModule>();
            var container = builder.Build();

            using (var scope = container.BeginLifetimeScope())
            {
                var coordinator = scope.Resolve<ICoordinator>();
                var request = new DataProcessingRequest(dataCount: 100);

                var result = await coordinator.CoordinateAsync(request);

                // ���ȱN�̦�����GValidateData -> FetchFromDatabase -> TransformData
                if (result.IsSuccess)
                {
                    // �Ҧ����ȶ��ǰ��槹��
                }
            }
        }

        /// <summary>
        /// �d�� 2�G�ϥΥ�����浦���]�L����^�C
        /// </summary>
        public static async Task UseParallelPolicyAsync()
        {
            var builder = new ContainerBuilder();
            builder.RegisterModule<ParallelPolicyModule>();
            var container = builder.Build();

            using (var scope = container.BeginLifetimeScope())
            {
                var coordinator = scope.Resolve<ICoordinator>();
                var request = new DataProcessingRequest(dataCount: 100);

                var result = await coordinator.CoordinateAsync(request);

                // ���ȱN�P�ɰ���GValidateData, FetchFromDatabase, TransformData �����æ�
                if (result.IsSuccess)
                {
                    // �Ҧ����ȥ�����槹��
                }
            }
        }

        /// <summary>
        /// �d�� 3�G�ϥΥ�����浦���]����̤j����ס^�C
        /// </summary>
        public static async Task UseThrottledParallelPolicyAsync()
        {
            var builder = new ContainerBuilder();
            builder.RegisterModule<ThrottledParallelPolicyModule>();
            var container = builder.Build();

            using (var scope = container.BeginLifetimeScope())
            {
                var coordinator = scope.Resolve<ICoordinator>();
                var request = new DataProcessingRequest(dataCount: 100, highPriority: true);

                var result = await coordinator.CoordinateAsync(request);

                // ���ȱN�H�̦h 3 �Өæ檺�覡����
                // �Ҧp�G������ ValidateData, FetchFromDatabase, TransformData
                // ���䤤�@�ӧ�����A�A���� SaveToCache �� NotifySubscribers
                if (result.IsSuccess)
                {
                    // �Ҧ����Ȧb�����פU���槹��
                }
            }
        }

        /// <summary>
        /// �d�� 4�G�ϥέ��հ��浦���C
        /// </summary>
        public static async Task UseRetryPolicyAsync()
        {
            var builder = new ContainerBuilder();
            builder.RegisterModule<RetryPolicyModule>();
            var container = builder.Build();

            using (var scope = container.BeginLifetimeScope())
            {
                var coordinator = scope.Resolve<ICoordinator>();
                var request = new DataProcessingRequest(dataCount: 100);

                var result = await coordinator.CoordinateAsync(request);

                // �p�G�Y�ӥ��ȥ��ѡA�N�۰ʭ��ճ̦h 3 ��
                // �C�����ն��j 500ms
                if (result.IsSuccess)
                {
                    // �Ҧ����Ȱ��槹���]�i��g�L���ա^
                }
                else
                {
                    // �Y�ǥ��Ȧb���իᤴ�M����
                    foreach (var error in result.Errors)
                    {
                        // �ˬd���Ѫ�����
                    }
                }
            }
        }

        /// <summary>
        /// �d�� 5�G�ϥιO�ɰ��浦���C
        /// </summary>
        public static async Task UseTimeoutPolicyAsync()
        {
            var builder = new ContainerBuilder();
            builder.RegisterModule<TimeoutPolicyModule>();
            var container = builder.Build();

            using (var scope = container.BeginLifetimeScope())
            {
                var coordinator = scope.Resolve<ICoordinator>();
                var request = new DataProcessingRequest(dataCount: 100);

                var result = await coordinator.CoordinateAsync(request);

                // �C�ӥ��ȳ̦h���� 5 ���A�W�ɱN�Q����
                if (result.IsSuccess)
                {
                    // �Ҧ����Ȧb�ɭ������槹��
                }
                else
                {
                    // �Y�ǥ��ȶW�ɳQ����
                    foreach (var error in result.Errors)
                    {
                        if (error.Value is OperationCanceledException)
                        {
                            // ���Ȧ]�W�ɳQ����
                        }
                    }
                }
            }
        }

        /// <summary>
        /// �d�� 6�G������P����������ɶ��C
        /// </summary>
        public static async Task CompareExecutionPoliciesAsync()
        {
            var request = new DataProcessingRequest(dataCount: 100);

            // ���ն��ǰ���
            var sequentialBuilder = new ContainerBuilder();
            sequentialBuilder.RegisterModule<SequentialPolicyModule>();
            var sequentialContainer = sequentialBuilder.Build();

            using (var scope = sequentialContainer.BeginLifetimeScope())
            {
                var coordinator = scope.Resolve<ICoordinator>();
                var sw = System.Diagnostics.Stopwatch.StartNew();

                var result = await coordinator.CoordinateAsync(request);

                sw.Stop();
                // ���ǰ���ɶ��G�� 450ms (100 + 200 + 150)
                // Console.WriteLine($"Sequential: {sw.ElapsedMilliseconds}ms");
            }

            // ���ե������
            var parallelBuilder = new ContainerBuilder();
            parallelBuilder.RegisterModule<ParallelPolicyModule>();
            var parallelContainer = parallelBuilder.Build();

            using (var scope = parallelContainer.BeginLifetimeScope())
            {
                var coordinator = scope.Resolve<ICoordinator>();
                var sw = System.Diagnostics.Stopwatch.StartNew();

                var result = await coordinator.CoordinateAsync(request);

                sw.Stop();
                // �������ɶ��G�� 200ms (�̪������Ȯɶ�)
                // Console.WriteLine($"Parallel: {sw.ElapsedMilliseconds}ms");
            }
        }

        /// <summary>
        /// �d�� 7�G�b�P�@�e�������U�h�Ӱ��浦���A�îھڻݨD��ܨϥΡC
        /// �ϥΩR�W���U�ӰϤ����P�����浦���C
        /// </summary>
        public static async Task UseMultiplePoliciesWithNamedRegistrationAsync()
        {
            var builder = new ContainerBuilder();

            // ���U��հ�¦�Ҳա]���]�t�w�]���浦���^
            builder.RegisterModule<CoordinationModule>();

            // ���U Task Handler
            builder.RegisterTaskHandler<ValidateDataHandler>();
            builder.RegisterTaskHandler<FetchFromDatabaseHandler>();
            builder.RegisterTaskHandler<TransformDataHandler>();
            builder.RegisterTaskHandler<SaveToCacheHandler>();
            builder.RegisterTaskHandler<NotifySubscribersHandler>();

            // ���U�M�g����
            builder.RegisterTaskMappingStrategy<DataProcessingMappingStrategy>();

            // ���U�h�Ӱ��浦���A�ϥΩR�W���U
            builder.RegisterType<SequentialExecutionPolicy>()
                   .Named<IExecutionPolicy>("Sequential")
                   .SingleInstance();

            builder.RegisterType<ParallelExecutionPolicy>()
                   .Named<IExecutionPolicy>("Parallel")
                   .WithParameter("maxDegreeOfParallelism", 0)
                   .SingleInstance();

            builder.RegisterType<ParallelExecutionPolicy>()
                   .Named<IExecutionPolicy>("ParallelThrottled")
                   .WithParameter("maxDegreeOfParallelism", 3)
                   .SingleInstance();

            builder.RegisterType<RetryExecutionPolicy>()
                   .Named<IExecutionPolicy>("Retry")
                   .WithParameter("maxRetries", 3)
                   .WithParameter("retryDelay", TimeSpan.FromMilliseconds(500))
                   .SingleInstance();

            var container = builder.Build();

            using (var scope = container.BeginLifetimeScope())
            {
                var mappingStrategies = scope.Resolve<IEnumerable<ITaskMappingStrategy>>();
                var handlerResolver = scope.Resolve<ITaskHandlerResolver>();
                var resultPublisher = scope.Resolve<IResultPublisher>();

                var request = new DataProcessingRequest(dataCount: 100);

                // ���� 1�G�ϥζ��ǰ��浦��
                {
                    var sequentialPolicy = scope.ResolveNamed<IExecutionPolicy>("Sequential");
                    var coordinator = new Coordinator(mappingStrategies, handlerResolver, sequentialPolicy, resultPublisher);
                    var result = await coordinator.CoordinateAsync(request);
                    // Console.WriteLine($"Sequential execution completed: {result.IsSuccess}");
                }

                // ���� 2�G�ϥΥ�����浦��
                {
                    var parallelPolicy = scope.ResolveNamed<IExecutionPolicy>("Parallel");
                    var coordinator = new Coordinator(mappingStrategies, handlerResolver, parallelPolicy, resultPublisher);
                    var result = await coordinator.CoordinateAsync(request);
                    // Console.WriteLine($"Parallel execution completed: {result.IsSuccess}");
                }

                // ���� 3�G�ϥέ����ת����浦��
                {
                    var throttledPolicy = scope.ResolveNamed<IExecutionPolicy>("ParallelThrottled");
                    var coordinator = new Coordinator(mappingStrategies, handlerResolver, throttledPolicy, resultPublisher);
                    var result = await coordinator.CoordinateAsync(request);
                    // Console.WriteLine($"Throttled parallel execution completed: {result.IsSuccess}");
                }

                // ���� 4�G�ϥέ��հ��浦��
                {
                    var retryPolicy = scope.ResolveNamed<IExecutionPolicy>("Retry");
                    var coordinator = new Coordinator(mappingStrategies, handlerResolver, retryPolicy, resultPublisher);
                    var result = await coordinator.CoordinateAsync(request);
                    // Console.WriteLine($"Retry execution completed: {result.IsSuccess}");
                }
            }
        }

        /// <summary>
        /// �d�� 8�G���U�h�Ӱ��浦���èϥΤu�t�Ҧ��ӰʺA��ܵ����C
        /// �o�ؤ覡���F���A�i�H�ھڽШD���S�ʨӿ�ܦX�A�����浦���C
        /// </summary>
        public static async Task UseMultiplePoliciesWithFactoryAsync()
        {
            var builder = new ContainerBuilder();

            // ���U��հ�¦�Ҳ�
            builder.RegisterModule<CoordinationModule>();

            // ���U Task Handler
            builder.RegisterTaskHandler<ValidateDataHandler>();
            builder.RegisterTaskHandler<FetchFromDatabaseHandler>();
            builder.RegisterTaskHandler<TransformDataHandler>();
            builder.RegisterTaskHandler<SaveToCacheHandler>();
            builder.RegisterTaskHandler<NotifySubscribersHandler>();

            // ���U�M�g����
            builder.RegisterTaskMappingStrategy<DataProcessingMappingStrategy>();

            // ���U�h�Ӱ��浦���A�ϥ���ȵ��U
            builder.RegisterType<SequentialExecutionPolicy>()
                   .Keyed<IExecutionPolicy>("Sequential")
                   .SingleInstance();

            builder.RegisterType<ParallelExecutionPolicy>()
                   .Keyed<IExecutionPolicy>("Parallel")
                   .WithParameter("maxDegreeOfParallelism", 0)
                   .SingleInstance();

            builder.RegisterType<RetryExecutionPolicy>()
                   .Keyed<IExecutionPolicy>("Retry")
                   .WithParameter("maxRetries", 3)
                   .WithParameter("retryDelay", TimeSpan.FromMilliseconds(500))
                   .SingleInstance();

            // ���U���浦���u�t
            builder.Register<Func<string, IExecutionPolicy>>(c =>
            {
                var context = c.Resolve<IComponentContext>();
                return policyName => context.ResolveKeyed<IExecutionPolicy>(policyName);
            });

            var container = builder.Build();

            using (var scope = container.BeginLifetimeScope())
            {
                var mappingStrategies = scope.Resolve<IEnumerable<ITaskMappingStrategy>>();
                var handlerResolver = scope.Resolve<ITaskHandlerResolver>();
                var resultPublisher = scope.Resolve<IResultPublisher>();
                var policyFactory = scope.Resolve<Func<string, IExecutionPolicy>>();

                // �ھڤ��P���ШD�S�ʿ�ܤ��P�����浦��
                var request1 = new DataProcessingRequest(dataCount: 10);
                var request2 = new DataProcessingRequest(dataCount: 1000, highPriority: true);

                // ���p�q��ơA�ϥζ��ǰ���
                {
                    var policy = policyFactory("Sequential");
                    var coordinator = new Coordinator(mappingStrategies, handlerResolver, policy, resultPublisher);
                    var result = await coordinator.CoordinateAsync(request1);
                    // Console.WriteLine($"Small data processed with Sequential policy: {result.IsSuccess}");
                }

                // ���j�q��ơA�ϥΥ������
                {
                    var policy = policyFactory("Parallel");
                    var coordinator = new Coordinator(mappingStrategies, handlerResolver, policy, resultPublisher);
                    var result = await coordinator.CoordinateAsync(request2);
                    // Console.WriteLine($"Large data processed with Parallel policy: {result.IsSuccess}");
                }
            }
        }
    }

    #endregion

    #region 6. �h�����ϥνd�� - �ϥαM�μҲ�

    /// <summary>
    /// �d�� 9�G�Ыإ]�t�h�Ӱ��浦�����M�μҲաC
    /// ���Ҳյ��U�Ҧ��i�Ϊ����浦���A�ô��ѵ�����ܾ��C
    /// </summary>
    public class MultiPolicyModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // ���U��հ�¦�Ҳ�
            builder.RegisterModule<CoordinationModule>();

            // ���U Task Handler
            builder.RegisterTaskHandler<ValidateDataHandler>();
            builder.RegisterTaskHandler<FetchFromDatabaseHandler>();
            builder.RegisterTaskHandler<TransformDataHandler>();
            builder.RegisterTaskHandler<SaveToCacheHandler>();
            builder.RegisterTaskHandler<NotifySubscribersHandler>();

            // ���U�M�g����
            builder.RegisterTaskMappingStrategy<DataProcessingMappingStrategy>();

            // ���U�Ҧ����浦���A�ϥΩR�W���U
            builder.RegisterType<SequentialExecutionPolicy>()
                   .Named<IExecutionPolicy>("Sequential")
                   .SingleInstance();

            builder.RegisterType<ParallelExecutionPolicy>()
                   .Named<IExecutionPolicy>("Parallel")
                   .WithParameter("maxDegreeOfParallelism", 0)
                   .SingleInstance();

            builder.RegisterType<ParallelExecutionPolicy>()
                   .Named<IExecutionPolicy>("ParallelThrottled")
                   .WithParameter("maxDegreeOfParallelism", 3)
                   .SingleInstance();

            builder.RegisterType<RetryExecutionPolicy>()
                   .Named<IExecutionPolicy>("Retry")
                   .WithParameter("maxRetries", 3)
                   .WithParameter("retryDelay", TimeSpan.FromMilliseconds(500))
                   .SingleInstance();

            builder.RegisterType<TimeoutExecutionPolicy>()
                   .Named<IExecutionPolicy>("Timeout")
                   .WithParameter("timeout", TimeSpan.FromSeconds(5))
                   .SingleInstance();

            // ���U���浦����ܾ�
            builder.RegisterType<ExecutionPolicySelector>()
                   .AsSelf()
                   .SingleInstance();
        }
    }

    /// <summary>
    /// ���浦����ܾ��A�Ω�ھڵ����W�ٿ�ܰ��浦���C
    /// </summary>
    public class ExecutionPolicySelector
    {
        private readonly IComponentContext _context;

        public ExecutionPolicySelector(IComponentContext context)
        {
            _context = context;
        }

        /// <summary>
        /// �ھڵ����W�ٸѪR���浦���C
        /// </summary>
        /// <param name="policyName">�����W�١]Sequential�BParallel�BParallelThrottled�BRetry�BTimeout�^�C</param>
        /// <returns>���������浦����ҡC</returns>
        public IExecutionPolicy GetPolicy(string policyName)
        {
            return _context.ResolveNamed<IExecutionPolicy>(policyName);
        }

        /// <summary>
        /// �ЫبϥΫ��w���浦������ժ̡C
        /// </summary>
        /// <param name="policyName">�����W�١C</param>
        /// <returns>�t�m�F���w��������ժ̹�ҡC</returns>
        public ICoordinator CreateCoordinator(string policyName)
        {
            var policy = GetPolicy(policyName);
            var mappingStrategies = _context.Resolve<IEnumerable<ITaskMappingStrategy>>();
            var handlerResolver = _context.Resolve<ITaskHandlerResolver>();
            var resultPublisher = _context.Resolve<IResultPublisher>();

            return new Coordinator(mappingStrategies, handlerResolver, policy, resultPublisher);
        }
    }

    /// <summary>
    /// �ϥε�����ܾ����d�ҵ{���X�C
    /// </summary>
    public static class MultiPolicyUsageExamples
    {
        /// <summary>
        /// �d�ҡG�ϥε�����ܾ��ӰʺA��ܰ��浦���C
        /// </summary>
        public static async Task UseExecutionPolicySelectorAsync()
        {
            var builder = new ContainerBuilder();
            builder.RegisterModule<MultiPolicyModule>();
            var container = builder.Build();

            using (var scope = container.BeginLifetimeScope())
            {
                var policySelector = scope.Resolve<ExecutionPolicySelector>();
                var request = new DataProcessingRequest(dataCount: 100);

                // �ϥΤ��P�����浦���B�z�P�@�ӽШD
                var policies = new[] { "Sequential", "Parallel", "ParallelThrottled", "Retry" };

                foreach (var policyName in policies)
                {
                    var coordinator = policySelector.CreateCoordinator(policyName);
                    var result = await coordinator.CoordinateAsync(request);
                    // Console.WriteLine($"Execution with {policyName} policy: {result.IsSuccess}, Duration: {result.Session.Duration}");
                }
            }
        }

        /// <summary>
        /// �d�ҡG�ھڽШD�S�ʴ����ܰ��浦���C
        /// </summary>
        public static async Task SmartPolicySelectionAsync()
        {
            var builder = new ContainerBuilder();
            builder.RegisterModule<MultiPolicyModule>();
            var container = builder.Build();

            using (var scope = container.BeginLifetimeScope())
            {
                var policySelector = scope.Resolve<ExecutionPolicySelector>();

                // ���� 1�G�p�q��� + �@���u���� -> �ϥζ��ǰ���
                var smallRequest = new DataProcessingRequest(dataCount: 10, highPriority: false);
                var smallCoordinator = policySelector.CreateCoordinator("Sequential");
                var smallResult = await smallCoordinator.CoordinateAsync(smallRequest);

                // ���� 2�G�j�q��� + ���u���� -> �ϥΥ������
                var largeRequest = new DataProcessingRequest(dataCount: 1000, highPriority: true);
                var largeCoordinator = policySelector.CreateCoordinator("Parallel");
                var largeResult = await largeCoordinator.CoordinateAsync(largeRequest);

                // ���� 3�G�ݭn�e�������n�ާ@ -> �ϥέ��յ���
                var criticalRequest = new DataProcessingRequest(dataCount: 100, highPriority: true);
                var criticalCoordinator = policySelector.CreateCoordinator("Retry");
                var criticalResult = await criticalCoordinator.CoordinateAsync(criticalRequest);
            }
        }

        /// <summary>
        /// �d�ҡG�ʺA�M�w���浦�������U��k�C
        /// </summary>
        public static string SelectPolicyBasedOnRequest(DataProcessingRequest request)
        {
            // �ھڸ�ƶq�M�u���ŨM�w����
            if (request.DataCount > 500 && request.HighPriority)
            {
                return "Parallel";
            }
            else if (request.DataCount > 100)
            {
                return "ParallelThrottled";
            }
            else if (request.HighPriority)
            {
                return "Retry";
            }
            else
            {
                return "Sequential";
            }
        }

        /// <summary>
        /// �d�ҡG�ϥδ��൦����ܡC
        /// </summary>
        public static async Task UseSmartPolicySelectionAsync()
        {
            var builder = new ContainerBuilder();
            builder.RegisterModule<MultiPolicyModule>();
            var container = builder.Build();

            using (var scope = container.BeginLifetimeScope())
            {
                var policySelector = scope.Resolve<ExecutionPolicySelector>();

                var requests = new[]
                {
                    new DataProcessingRequest(dataCount: 10, highPriority: false),
                    new DataProcessingRequest(dataCount: 150, highPriority: false),
                    new DataProcessingRequest(dataCount: 50, highPriority: true),
                    new DataProcessingRequest(dataCount: 1000, highPriority: true)
                };

                foreach (var request in requests)
                {
                    var policyName = SelectPolicyBasedOnRequest(request);
                    var coordinator = policySelector.CreateCoordinator(policyName);
                    var result = await coordinator.CoordinateAsync(request);
                    // Console.WriteLine($"Request (Count: {request.DataCount}, Priority: {request.HighPriority}) " +
                    //                   $"executed with {policyName} policy: {result.IsSuccess}");
                }
            }
        }
    }

    #endregion
}

#endif
